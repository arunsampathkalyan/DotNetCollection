﻿using System;
using System.Windows.Forms;
using TreeNode = System.Web.UI.WebControls.TreeNode;

namespace AspDotNet_TreeView
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            AddNode("Images/Folder_Icon.png");
        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            AddNode("Images/Video_Icon.png");
        }

        private void AddNode(string imageUrl)
        {
            var treeNode = new TreeNode(" " + txtName.Text) { ImageUrl = imageUrl };
            if (treeview.SelectedNode == null)
            {
                treeview.Nodes.Add(treeNode);
            }
            else
            {
                treeview.SelectedNode.ChildNodes.Add(treeNode);
                treeview.SelectedNode.Expand();
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            if (treeview.SelectedNode == null)
            {
                MessageBox.Show("Please select the folder to perform this action", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                treeview.SelectedNode.Text = txtName.Text;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (treeview.SelectedNode == null)
            {
                MessageBox.Show("Please select the folder to perform this action", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                if (treeview.SelectedNode.Parent != null)
                {
                    treeview.SelectedNode.Parent.ChildNodes.Remove(treeview.SelectedNode);
                }
                else
                {
                    treeview.Nodes.Remove(treeview.SelectedNode);
                }
            }
        }
    }
}
