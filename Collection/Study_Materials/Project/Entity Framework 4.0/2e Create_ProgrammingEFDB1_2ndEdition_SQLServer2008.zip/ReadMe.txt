This sql script will create the sample database used in chapters 1-6 of Programming Entity Framework 2nd Edition.

The script currently creates the database & log file in C:\databases. Modify the first few lines of the script file to target a different location for the fiels to be created.

This script is optimized for SQL Server 2008 and SQL Server 2008 Express.

www.learnentityframework.com