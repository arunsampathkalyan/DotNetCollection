Programming Entity Framework 2nd Edition
by Julia Lerman
www.ProgrammingEntityFramework.com
Chapter 7, Using Stored Procedures with the EDM

This is the Entity Data Model created in Chapter 2 along with the stored procedure mappings added in Chatper 7.
