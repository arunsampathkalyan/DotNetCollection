Programming Entity Framework 2nd Edition
by Julia Lerman
www.ProgrammingEntityFramework.com
Chapter 2-6, Using EntityObjects in WCF Services

This is the Entity Data Model created in Chapter 2 and used through Chapter 6
