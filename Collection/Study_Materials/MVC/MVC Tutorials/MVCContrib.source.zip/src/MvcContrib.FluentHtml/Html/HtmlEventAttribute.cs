namespace MvcContrib.FluentHtml.Html
{
	public static class HtmlEventAttribute
	{
		public const string OnClick = "onclick";
	}
}
