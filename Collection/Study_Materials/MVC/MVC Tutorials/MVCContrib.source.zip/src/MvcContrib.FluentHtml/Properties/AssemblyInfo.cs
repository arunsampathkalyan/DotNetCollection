using System.Reflection;

[assembly: AssemblyTitle("MvcContrib.FluentHtml")]
