namespace MvcContrib.FluentHtml.Behaviors
{
	public interface IBehaviorMarker
	{
	}
}