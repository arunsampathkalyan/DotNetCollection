﻿namespace MvcContrib.Samples.Models
{
	public class Shipment
	{
		public Address ShipTo { get; set; }
		public Dimension Dimensions { get; set; }
	}
}