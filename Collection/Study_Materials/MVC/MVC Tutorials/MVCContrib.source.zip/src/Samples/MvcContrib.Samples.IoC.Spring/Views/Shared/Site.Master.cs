﻿using System;
using System.Web;
using System.Web.Mvc;

namespace MvcContrib.Samples.IoC.Views.Layouts
{
    public partial class Site : System.Web.Mvc.ViewMasterPage
    {
    }
}
