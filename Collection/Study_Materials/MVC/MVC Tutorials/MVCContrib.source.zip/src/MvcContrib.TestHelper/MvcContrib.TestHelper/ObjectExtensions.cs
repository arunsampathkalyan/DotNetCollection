﻿namespace MvcContrib.TestHelper
{
    public static class ObjectExtensions
    {
    }
}