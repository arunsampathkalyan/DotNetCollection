namespace MvcContrib.SimplyRestful
{
	public enum RestfulPostAction
	{
		Create = 2,
		Update = 4,
		Destroy = 8
	}
}
