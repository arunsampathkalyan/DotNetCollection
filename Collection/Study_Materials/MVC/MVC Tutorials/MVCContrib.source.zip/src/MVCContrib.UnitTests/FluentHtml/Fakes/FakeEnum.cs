namespace MvcContrib.UnitTests.FluentHtml.Fakes
{
	public enum FakeEnum
	{
		Zero,
		One,
		Two,
		Three
	}
}
