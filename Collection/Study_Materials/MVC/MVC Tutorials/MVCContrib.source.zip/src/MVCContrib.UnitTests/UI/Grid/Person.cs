using System;

namespace MvcContrib.UnitTests.UI.Grid
{
	public class Person
	{
		public string Name { get; set; }

		public DateTime DateOfBirth { get; set; }

		public int Id { get; set; }
	}
}