namespace MvcContrib.UnitTests.IoC
{
    public class SimpleDependency : IDependency
    {
    
    }
}