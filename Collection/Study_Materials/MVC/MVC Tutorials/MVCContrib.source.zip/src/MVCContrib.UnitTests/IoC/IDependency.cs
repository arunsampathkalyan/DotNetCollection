namespace MvcContrib.UnitTests.IoC
{
    public interface IDependency
    {
    }
}