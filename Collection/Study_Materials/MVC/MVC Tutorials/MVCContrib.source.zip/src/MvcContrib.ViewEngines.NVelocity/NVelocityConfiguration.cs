﻿using System;

namespace MvcContrib.ViewEngines
{
	public class NVelocityConfiguration
	{
		public Type[] HtmlExtensionTypes { get; set; }
	}
}