using System;

namespace MvcApplication2.Models
{
    public class Task
    {
        public string Name { get; set; }
        public DateTime Due { get; set; }
        public string Description { get; set; }
    }
}