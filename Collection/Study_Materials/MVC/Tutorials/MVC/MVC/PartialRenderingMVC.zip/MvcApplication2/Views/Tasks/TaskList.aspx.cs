﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcApplication2.Views
{
    public partial class TaskList : ViewPage<IEnumerable<Models.Task>>
    {
    }
}
