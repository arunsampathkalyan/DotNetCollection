﻿function AddTask()
{
    var name = $("#newtask_name").attr("value");
    var due = $("#newtask_due").attr("value");
    var desc = $("#newtask_desc").attr("value");
        
    $.ajax(
    {
       type: "POST",
       url: "/Tasks/New",
       data: "name=" + name + "&due=" + due + "&desc= "+ desc,
       dataType: "html",
       success: function(result)
       {
            var domElement = $(result); // create element from html
            $("#task_list").append(domElement); // append to end of list        
       },
       error: function(error)
       {
            alert(error);
       }
    });         
}