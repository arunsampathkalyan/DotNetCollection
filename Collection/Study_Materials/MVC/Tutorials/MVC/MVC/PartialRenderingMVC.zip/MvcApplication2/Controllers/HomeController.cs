﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;

namespace MvcApplication2.Controllers
{
    public class TasksController : Controller
    {
        private static readonly List<Task> taskList = new List<Task>
        {
           new Task {Name = "Task #1", Due = DateTime.Now.AddDays(1), Description = "Description #1"},
           new Task {Name = "Task #2", Due = DateTime.Now.AddDays(4), Description = "Description #2"}
       };

        public ActionResult Index()
        {
            return RenderView("TaskList", taskList);
        }

        public ActionResult New(string name, string desc, DateTime due)
        {
            Task task = new Task { Name = name, Description = desc, Due = due };
            taskList.Add(task);
            return RenderView("Task", task);
        }
    }
}
