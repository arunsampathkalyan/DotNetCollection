#region Using Directives

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcAjaxForm.Models;

#endregion

namespace MvcAjaxForm.Controllers
{
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            return View(new ContactMessage());
        }

        [ActionName("Index")]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult SubmitMessage(ContactMessage message)
        {
            return this.View("Confirmation", message);
        }

    }
}
