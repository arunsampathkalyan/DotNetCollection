﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcAjaxForm.Models
{
    public class ContactMessage
    {
        public string EmailAddress { get; set; }
        public string MessageText { get; set; }
    }
}
