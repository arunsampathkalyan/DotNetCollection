﻿using System;
using System.Linq;
using System.Web.Mvc;
using MvcTutorials.Blog.Domain;
using MvcTutorials.Blog.Domain.LinqToSql;

namespace MvcTutorials.Blog.ReferenceWebsite.Models
{
	public class PostBinder : IModelBinder
	{

		private readonly IPostRepository posts = new PostRepository();

		#region IModelBinder Members

		public object GetValue( ControllerContext controllerContext, string modelName, Type modelType, ModelStateDictionary modelState )
		{
			var id = int.Parse( controllerContext.RouteData.GetRequiredString( "id" ) );
			return posts.Retrieve().Where( p => p.ID == id ).Single();
		}

		#endregion
	}
}