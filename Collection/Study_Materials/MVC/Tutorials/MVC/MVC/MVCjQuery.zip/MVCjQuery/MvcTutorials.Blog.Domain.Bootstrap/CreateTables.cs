﻿using System;

namespace MvcTutorials.Blog.Domain.Bootstrap
{
	public static class CreateTables
	{
		public static void Execute( LinqToSql.BlogDataContext db )
		{
			var create_posts_table = @"
				CREATE TABLE Posts(
					ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
					Title nvarchar(255) NOT NULL,
					Author nvarchar(255) NOT NULL,
					Text nvarchar(max) NOT NULL,
					DatePosted datetime NOT NULL
				);
			";
			db.ExecuteCommand( create_posts_table, "NOT_NEEDED" );
			Console.WriteLine( "Created 'Posts' table." );

			var create_comments_table = @"
				CREATE TABLE Comments(
					ID int NOT NULL IDENTITY(1,1) PRIMARY KEY,
					PostID int NOT NULL REFERENCES Posts(ID),
					Author nvarchar(255) NOT NULL,
					Text nvarchar(max) NOT NULL,
					DatePosted datetime NOT NULL
				);
			";
			db.ExecuteCommand( create_comments_table, "NOT_NEEDED" );
			Console.WriteLine( "Created 'Comments' table." );
		}
	}
}