﻿using System;
using System.Collections.Generic;
using MvcTutorials.Blog.Domain.LinqToSql;

namespace MvcTutorials.Blog.Domain.Bootstrap
{
	public static class AddData
	{
		public static void Execute( BlogDataContext db )
		{
			var r = new Random();
			var lipsum = new LoremIpsumGenerator( r );

			// create posts
			var posts = new List<Post>();
			for( var i = 0; i < r.Next( 20, 80 ); i++ )
			{
				var p = new Post{
				                	Title = lipsum.GetWords( r.Next( 5, 10 ) ),
				                	Author = lipsum.GetProperNouns( 2 ),
				                	DatePosted = RandomDate( r, DateTime.Now.Year - 20, DateTime.Now.Year ),
				                	Text = lipsum.GetWords( r.Next( 150, 1000 ) )
				                };
				Console.WriteLine( "NEW POST" );
				Console.WriteLine( "   - Title: " + p.Title );
				Console.WriteLine( "   - Author: " + p.Author );
				Console.WriteLine( "   - Date: " + p.DatePosted );
				//Console.WriteLine( "   - Text:" + p.Text );
				Console.WriteLine( "" );
				posts.Add( p );

				for( var j = 0; j < r.Next( 8 ); j++ )
				{
					var c = new Comment{
					                   	Author = lipsum.GetProperNouns( 2 ),
					                   	DatePosted = RandomDate( r, p.DatePosted.Year + 1, p.DatePosted.Year + 3 ),
					                   	Text = lipsum.GetWords( r.Next( 10, 25 ) )
					                   };
					Console.WriteLine( "NEW COMMENT" );
					Console.WriteLine( "  - Author: " + c.Author );
					Console.WriteLine( "  - Date: " + c.DatePosted );
					//Console.WriteLine( "  - Text: " + c.Text );
					p.Comments.Add( c );
				}
			}
			db.Posts.InsertAllOnSubmit( posts );
			db.SubmitChanges();
		}

		public static DateTime RandomDate( Random r, int minYear, int maxYear )
		{
			var year = r.Next( minYear, maxYear );
			var month = r.Next( 1, 12 );
			var day = r.Next( 1, 28 );
			var hour = r.Next( 1, 24 );
			var minute = r.Next( 1, 59 );
			return new DateTime( year, month, day, hour, minute, 0, 0 );
		}
	}
}