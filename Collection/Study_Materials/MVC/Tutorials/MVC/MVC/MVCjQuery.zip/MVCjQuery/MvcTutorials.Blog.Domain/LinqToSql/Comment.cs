﻿namespace MvcTutorials.Blog.Domain.LinqToSql
{
	public partial class Comment : IComment {}
}