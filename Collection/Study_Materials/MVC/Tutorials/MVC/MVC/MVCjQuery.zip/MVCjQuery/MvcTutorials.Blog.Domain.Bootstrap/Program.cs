﻿using System;

namespace MvcTutorials.Blog.Domain.Bootstrap
{
	public class Program
	{
		private static void Main( string[] args )
		{
			Console.WriteLine( "Starting bootstrap process." );
			Console.WriteLine( "===============================================================================");

			var db = new LinqToSql.BlogDataContext();

			Console.WriteLine( "DROPPING TABLES ===============================================================" );
			DeleteTables.Execute( db );

			Console.WriteLine( "CREATING TABLES ===============================================================" );
			CreateTables.Execute( db );

			Console.WriteLine( "GENERATING DATA ===============================================================" );
			AddData.Execute( db );

			Console.WriteLine( "===============================================================================" );
			Console.WriteLine( "Bootstrap process complete." );

			Console.ReadKey( true );
		}
	}
}