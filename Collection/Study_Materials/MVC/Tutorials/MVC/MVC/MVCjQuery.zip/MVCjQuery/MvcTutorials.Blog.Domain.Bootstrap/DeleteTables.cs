﻿using System;

namespace MvcTutorials.Blog.Domain.Bootstrap
{
	public static class DeleteTables
	{
		public static void Execute( LinqToSql.BlogDataContext db )
		{
			db.ExecuteCommand( @"IF EXISTS(select * from INFORMATION_SCHEMA.tables where table_name = 'Comments') DROP TABLE Comments;", "NOT_NEEDED" );
			Console.WriteLine( "Dropped 'Comments' table." );
			db.ExecuteCommand( @"IF EXISTS(select * from INFORMATION_SCHEMA.tables where table_name = 'Posts') DROP TABLE Posts;", "NOT_NEEDED" );
			Console.WriteLine( "Dropped 'Posts' table." );
		}
	}
}