﻿using System;
using System.Linq;
using System.Web.Mvc;
using MvcTutorials.Blog.Domain;
using MvcTutorials.Blog.Domain.LinqToSql;
using MvcTutorials.Blog.ReferenceWebsite.Models;

namespace MvcTutorials.Blog.ReferenceWebsite.Controllers
{
	public class BlogController : Controller
	{
		private readonly ICommentRepository comments = new CommentRepository();
		private readonly IPostRepository posts = new PostRepository();

		public ViewResult Posts( int page )
		{
			var pageSize = 5;
			ViewData["page"] = page;
			return View(
				posts.Retrieve()
					.OrderByDescending( p => p.DatePosted )
					.Skip( page * pageSize ).Take( pageSize )
					.ToList()
				);
		}

		[AcceptVerbs( "GET" )]
		public ViewResult Post( int id )
		{
			return View( posts.Retrieve().Where( p => p.ID == id ).Single() );
		}

		[AcceptVerbs( "GET" )]
		public ViewResult PostBound(
			[ModelBinder( typeof(PostBinder) )] Post post
			)
		{
			return View( "Post", post );
		}

		[AcceptVerbs( "POST" )]
		[ActionName( "Post" )]
        public ActionResult AddComment(int postId, string commentAuthor, string commentText)
		{
			var comment = new Comment{
                                        PostID = postId,
			                         	Author = commentAuthor,
			                         	Text = commentText,
			                         	DatePosted = DateTime.Now
			                         };
			try
			{
				
				comments.Create( comment );
                return View("PostComment", comment);   
			}
			catch( Exception ex )
			{
                throw ex;
			}
		}
	}
}