﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcTutorials.Blog.ReferenceWebsite.Views.Blog {
    public partial class PostComment : System.Web.Mvc.ViewUserControl<MvcTutorials.Blog.Domain.LinqToSql.Comment> {
    }
}
