﻿namespace MvcTutorials.Blog.Domain.LinqToSql
{
	public partial class Post : IPost {}
}