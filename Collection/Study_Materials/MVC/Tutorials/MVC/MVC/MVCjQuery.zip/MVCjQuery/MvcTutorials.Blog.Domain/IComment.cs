﻿using System;

namespace MvcTutorials.Blog.Domain
{
	public interface IComment
	{
		int ID { get; set; }
		int PostID { get; set; }
		string Author { get; set; }
		string Text { get; set; }
		DateTime DatePosted { get; set; }
	}
}