﻿using System.Linq;

namespace MvcTutorials.Blog.Domain.LinqToSql
{
	public class CommentRepository : ICommentRepository
	{
		private readonly BlogDataContext db = new BlogDataContext();

		#region ICommentRepository Members

		public IComment Create( IComment obj )
		{
			var comment = new Comment{
			                         	Author = obj.Author,
			                         	DatePosted = obj.DatePosted,
			                         	PostID = obj.PostID,
			                         	Text = obj.Text
			                         };
			db.Comments.InsertOnSubmit( comment );
			db.SubmitChanges();
			return comment;
		}

		public IQueryable<IComment> Retrieve()
		{
			return db.Comments.Select( c => c as IComment );
		}

		public IComment Update( IComment obj )
		{
			var comment = db.Comments.Where( c => c.ID == obj.ID ).Single();
			comment.Author = obj.Author;
			comment.Text = obj.Text;
			comment.DatePosted = obj.DatePosted;
			comment.PostID = obj.PostID;
			db.SubmitChanges();
			return comment;
		}

		public void Delete( IComment obj )
		{
			var comment = db.Comments.Where( c => c.ID == obj.ID ).Single();
			db.Comments.DeleteOnSubmit( comment );
			db.SubmitChanges();
		}

		#endregion
	}
}