﻿using System.Linq;

namespace MvcTutorials.Blog.Domain
{
	public interface IRepository<T>
	{
		T Create( T obj );
		IQueryable<T> Retrieve();
		T Update( T obj );
		void Delete( T obj );
	}
}