﻿namespace MvcTutorials.Blog.Domain
{
	public interface IPostRepository : IRepository<IPost> {}
}