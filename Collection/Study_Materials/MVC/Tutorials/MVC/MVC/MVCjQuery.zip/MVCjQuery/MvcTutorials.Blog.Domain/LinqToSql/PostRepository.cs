﻿using System.Linq;

namespace MvcTutorials.Blog.Domain.LinqToSql
{
	public class PostRepository : IPostRepository
	{
		private readonly BlogDataContext db = new BlogDataContext();

		#region IPostRepository Members

		public IPost Create( IPost obj )
		{
			var post = new Post{
			                   	Title = obj.Title,
			                   	Author = obj.Author,
			                   	Text = obj.Text,
			                   	DatePosted = obj.DatePosted
			                   };
			db.Posts.InsertOnSubmit( post );
			db.SubmitChanges();
			return post;
		}

		public IQueryable<IPost> Retrieve()
		{
			return db.Posts.Select( p => p as IPost );
		}

		public IPost Update( IPost obj )
		{
			var post = db.Posts.Where( p => p.ID == obj.ID ).Single();
			post.Title = obj.Title;
			post.Author = obj.Author;
			post.Text = obj.Text;
			post.DatePosted = obj.DatePosted;
			db.SubmitChanges();
			return post;
		}

		public void Delete( IPost obj )
		{
			var post = db.Posts.Where( p => p.ID == obj.ID ).Single();
			db.Posts.DeleteOnSubmit( post );
			db.SubmitChanges();
		}

		#endregion
	}
}