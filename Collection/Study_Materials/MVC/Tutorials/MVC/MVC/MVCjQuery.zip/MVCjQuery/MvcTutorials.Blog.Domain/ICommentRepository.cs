﻿namespace MvcTutorials.Blog.Domain
{
	public interface ICommentRepository : IRepository<IComment> {}
}