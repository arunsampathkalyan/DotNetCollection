﻿using System;

namespace MvcTutorials.Blog.Domain
{
	public interface IPost
	{
		int ID { get; set; }
		string Title { get; set; }
		string Author { get; set; }
		string Text { get; set; }
		DateTime DatePosted { get; set; }
	}
}