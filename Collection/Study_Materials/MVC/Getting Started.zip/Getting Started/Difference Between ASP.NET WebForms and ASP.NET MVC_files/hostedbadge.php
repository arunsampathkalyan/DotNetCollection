
	function writeSuBadge () { 
		var bdg = "<iframe src=\"http:\/\/www.stumbleupon.com\/badge\/embed\/5\/?url=http:\/\/www.devcurry.com\/2009\/09\/difference-between-aspnet-webforms-and.html\" scrolling=\"no\" frameborder=\"0\" style=\"border:none; overflow:hidden; width:50px; height: 60px;\" allowTransparency=\"true\"><\/iframe>";
		document.write(bdg);
	}
	writeSuBadge();