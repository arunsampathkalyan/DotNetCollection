﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Yoga.Models
{
    public class Yoga
    {
        public long YogaID { get; set; }
        public string PostureName { get; set; }
        public List<string> Steps { get; set; }
        public List<string> Benefits { get; set; }
    }
}