﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Yoga.Models;

namespace Yoga.Controllers
{
    public class YogaController : Controller
    {
        // GET: Yoga
        public JsonResult Index()
        {
            IEnumerable<Models.Yoga> yogas = new List<Models.Yoga>()
            {
                new Models.Yoga() {
                    YogaID =1,
                    PostureName ="YogaOne",
                    Steps =new List<string>(){"ONE Step1","ONE Step2"},
                    Benefits =new List<string>(){"One Benefit1","One Benefit2" }
                },
                new Models.Yoga() {
                    YogaID =2,
                    PostureName ="YogaTwo",
                    Steps =new List<string>(){ "Two Step1", "Two Step2"},
                    Benefits =new List<string>(){ "Two Benefit1", "Two Benefit2" }
                },
                new Models.Yoga() {
                    YogaID =3,
                    PostureName ="YogaThree",
                    Steps =new List<string>(){ "Three Step1", "Three Step2"},
                    Benefits =new List<string>(){ "Three Benefit1", "Three Benefit2" }
                }
            };
            return Json( new JsonResult() { Data=yogas },JsonRequestBehavior.AllowGet);
        }

        public ViewResult MainPage()
        {
            return View();
        }

        public JsonResult getDetails(List<Models.Yoga> recData)
        {
            return Json(new JsonResult() { Data = "Data is Received" }, JsonRequestBehavior.AllowGet);
        }
    }
}