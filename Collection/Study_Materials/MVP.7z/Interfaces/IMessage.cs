﻿using System;

namespace Dashboard.Interfaces
{
    public interface IMessage
    {
        String MessageType();
        String MessageText();
    }
}
