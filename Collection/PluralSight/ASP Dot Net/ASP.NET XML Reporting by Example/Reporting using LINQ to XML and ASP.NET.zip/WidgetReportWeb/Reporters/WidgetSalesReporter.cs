﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Configuration;
using System.Xml.Linq;
using WidgetReportWeb.DataLayer;
using System.Xml;
using System.Text;

namespace WidgetReportWeb.Reporters
{
    public class WidgetSalesReporter
    {
        public static void GenerateReport(DateTime startMonth, DateTime endMonth)
        {
            XElement eReport = new XElement("widgetSales",
                MonthRange(startMonth, endMonth)
                .Select(month => new
                {
                    Month = month,
                    RevenueByCountry = ComputeRevenueByCountryForMonth(month)
                })
                .Select(monthData => new XElement("period",
                    new XAttribute("month", monthData.Month.ToString("yyyy-MM")),

                    new XAttribute("overall", monthData.RevenueByCountry
                        .Sum(pair => pair.Value)),

                    new XAttribute("domestic", monthData.RevenueByCountry
                        .Where(pair => pair.Key == "US")
                        .Sum(pair => pair.Value)),

                    new XAttribute("foreign", monthData.RevenueByCountry
                        .Where(pair => pair.Key != "US")
                        .Sum(pair => pair.Value)),

                    monthData.RevenueByCountry
                        .OrderByDescending(pair => pair.Value)
                        .Select(pair => new XElement("country",
                            new XAttribute("code", pair.Key),
                            new XAttribute("revenue", pair.Value))))));

            SaveToDisk(eReport);
        }

        private static Dictionary<string, decimal> ComputeRevenueByCountryForMonth(DateTime month)
        {
            Dictionary<string, decimal> revenueByCountryForMonth = new Dictionary<string, decimal>();

            foreach (WidgetSale sale in WidgetSale.GetSalesForMonth(month))
            {
                if (revenueByCountryForMonth.ContainsKey(sale.Country))
                    revenueByCountryForMonth[sale.Country] += sale.Amount;
                else revenueByCountryForMonth.Add(sale.Country, sale.Amount);
            }

            return revenueByCountryForMonth;
        }

        /// <summary>
        /// Does not include end.
        /// Ranges backward if start > end.
        /// </summary>
        private static IEnumerable<DateTime> MonthRange(DateTime start, DateTime end)
        {
            DateTime current = new DateTime(start.Year, start.Month, 1);
            end = new DateTime(end.Year, end.Month, 1);

            if (end > start)
            {
                while (current < end)
                {
                    yield return current;
                    current = current.AddMonths(1);
                }
            }
            else
            {
                while (current > end)
                {
                    yield return current;
                    current = current.AddMonths(-1);
                }
            }
        }

        private static void SaveToDisk(XElement element)
        {
            using (Stream outputStream = File.Create(ReportPath))
            using (XmlTextWriter writer = new XmlTextWriter(outputStream, Encoding.UTF8))
            {
                writer.Formatting = Formatting.Indented;

                element.Save(writer);
            }
        }

        public static string ReportPath
        {
            get
            {
                return Path.Combine(GetRequiredAppSetting("ReportsFolder"),
                    "widget-sales.xml");
            }
        }

        public static bool ReportExists
        {
            get
            {
                return File.Exists(ReportPath);
            }
        }

        /// <summary>
        /// Returns default(DateTime) if report does not yet exist
        /// </summary>
        public static DateTime ReportDate
        {
            get
            {
                DateTime reportDate = default(DateTime);

                if (File.Exists(ReportPath))
                    reportDate = File.GetLastWriteTime(ReportPath);

                return reportDate;
            }
        }

        private static string GetRequiredAppSetting(string key)
        {
            string value = ConfigurationManager.AppSettings[key];
            if (null == value)
                throw new ApplicationException(
                    "Please configure an <appSetting> for " + key);
            return value;
        }
    }
}
