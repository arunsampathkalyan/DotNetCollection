﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WidgetReportWeb.DataLayer
{
    public class WidgetSale
    {
        // totally reasonable for this simple demo,
        // but consider thread safety carefully whenever using static variables
        static Random random = new Random();

        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
        public string Country { get; set; }

        // simulate random sales for a company doing some domestic business
        // who is emerging into an international market
        public static IEnumerable<WidgetSale> GetSalesForMonth(DateTime month)
        {
            var results = new List<WidgetSale>();

            for (int i = 0; i < random.Next(50, 75); ++i)
                results.Add(new WidgetSale { Country = "US", Amount = random.Next(100, 1000), Date = month });

            for (int i = 0; i < random.Next(5, 10); ++i)
                results.Add(new WidgetSale { Country = RandomCountry(), Amount = random.Next(100, 1000), Date = month });

            return results;
        }

        private static string RandomCountry()
        {
            string[] countries = { "IN", "DK", "GB", "AU", "CA" };

            return countries[random.Next(countries.Length)];
        }
    }
}