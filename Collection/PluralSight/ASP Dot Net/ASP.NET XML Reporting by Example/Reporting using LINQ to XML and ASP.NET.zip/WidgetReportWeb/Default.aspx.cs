﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WidgetReportWeb.Reporters;
using System.Xml;

namespace WidgetReportWeb
{
    public partial class _Default : Page
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            SelectView();
        }

        private void SelectView()
        {
            if (WidgetSalesReporter.ReportExists)
            {
                mvMain.SetActiveView(vReportExists);

                lblReportAge.Text = HowLongAgo(WidgetSalesReporter.ReportDate);

                dsReport.DataFile = WidgetSalesReporter.ReportPath;
            }
            else mvMain.SetActiveView(vReportDoesNotExist);
        }

        private static string HowLongAgo(DateTime pastTime)
        {
            TimeSpan span = DateTime.Now - pastTime;
            if (span.TotalMinutes < 2)
                return "moments ago";
            else if (span.TotalHours < 2)
                return string.Format("{0} minutes ago", ((int)span.TotalMinutes).ToString());
            else if (span.TotalDays < 2)
                return string.Format("{0} hours ago", ((int)span.TotalHours).ToString());
            else return string.Format("{0} days ago", ((int)span.TotalDays).ToString());
        }

        protected void Regenerate_Report(object sender, EventArgs e)
        {
            WidgetSalesReporter.GenerateReport(new DateTime(2009, 1, 1), new DateTime(2010, 1, 1));
            Response.Redirect(Request.Path);
        }

        protected string CountryName(object dataItem)
        {
            XmlElement eCountry = (XmlElement)dataItem;

            switch (eCountry.Attributes["code"].Value)
            {
                case "AU": return "Australia";
                case "CA": return "Canada";
                case "DK": return "Denmark";
                case "GB": return "United Kingdom";
                case "IN": return "India";
                case "US": return "United States";
                default: return "Unknown";
            }
        }
    }
}
