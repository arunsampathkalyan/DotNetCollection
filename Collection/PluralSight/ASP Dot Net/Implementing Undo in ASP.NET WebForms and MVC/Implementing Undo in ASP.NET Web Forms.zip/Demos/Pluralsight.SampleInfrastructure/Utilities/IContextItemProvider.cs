﻿namespace Pluralsight.SampleInfrastructure.Utilities
{
    public interface IContextItemProvider
    {
        void SetContextItem(string key, string value);
        string GetContextItem(string key);
    }
}