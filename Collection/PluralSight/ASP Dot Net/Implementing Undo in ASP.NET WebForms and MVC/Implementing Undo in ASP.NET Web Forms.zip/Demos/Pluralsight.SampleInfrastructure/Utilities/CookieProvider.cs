﻿using System.Web;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public class CookieProvider : ICookieProvider
    {
        public void SetCookie(HttpCookie cookie)
        {
            var response = HttpContext.Current.Response;
            response.Cookies.Remove(cookie.Name);
            response.Cookies.Add(cookie);
        }

        public HttpCookie GetCookie(string name)
        {
            return HttpContext.Current.Request.Cookies[name];
        }
    }
}