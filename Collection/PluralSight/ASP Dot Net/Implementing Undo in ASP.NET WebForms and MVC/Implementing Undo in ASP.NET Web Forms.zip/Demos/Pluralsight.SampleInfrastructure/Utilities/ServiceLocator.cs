﻿using System;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public static class ServiceLocator
    {
        public static void Init(Func<Type, object> getServiceImpl)
        {
            GetServiceImpl = getServiceImpl;
        }

        static Func<Type, object> GetServiceImpl;

        public static T GetService<T>() where T : class
        {
            ThrowIfNotInitialized();
            return GetImplementation<T>();
        }

        static T GetImplementation<T>() where T : class
        {
            var type = typeof (T);
            var implementation = GetServiceImpl(type) as T;
            if (null == implementation)
                throw new InvalidOperationException("Couldn't find a default implementation of " + type.FullName);
            return implementation;
        }

        static void ThrowIfNotInitialized()
        {
            if (null == GetServiceImpl)
                throw new InvalidOperationException("ServiceLocator.Init must be called to initialize this class");
        }
    }
}
