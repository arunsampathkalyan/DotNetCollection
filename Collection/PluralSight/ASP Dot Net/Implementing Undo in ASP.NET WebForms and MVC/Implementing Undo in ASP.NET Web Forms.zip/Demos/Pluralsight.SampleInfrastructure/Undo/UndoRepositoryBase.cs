﻿using System;
using System.IO;
using System.Linq;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public abstract class UndoRepositoryBase
    {
        readonly TimeSpan TimeToLive = TimeSpan.FromDays(1);
        protected const string BaseDirectory = @"c:\temp\undo-repository";
        protected const string FileExtension = ".undo";
        protected IFileSystem fileSystem;
        public abstract Guid Save(IUndoCommand undoCommand);
        public abstract IUndoCommand Find(Guid id);

        protected string PathFor(Guid id)
        {
            return Path.Combine(BaseDirectory, AsString(id) + FileExtension);
        }

        string AsString(Guid id)
        {
            return id.ToString("N");
        }

        public void Delete(Guid id)
        {
            fileSystem.Delete(PathFor(id));
        }

        public bool Exists(Guid id)
        {
            return fileSystem.Exists(PathFor(id));
        }

        protected void CleanupExpiredFiles()
        {
            foreach (var expiredFile in fileSystem
                .GetAllFilesUnderThisDirectory(BaseDirectory)
                .Where(path => HasExpired(fileSystem.GetLastWriteTime(path))))
            {
                fileSystem.Delete(expiredFile);
            }
        }

        bool HasExpired(DateTime lastWriteTime)
        {
            return SystemTime.Now() > lastWriteTime + TimeToLive;
        }
    }
}