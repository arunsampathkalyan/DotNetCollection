﻿using System;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public interface IUndoProvider
    {
        void RegisterUndoCommand(IUndoCommand undoCommand);
        void BeginRequestHandler();
        bool IsUndoAvailable { get; }
        Guid GetUndoIdFromContextItem();
        string UndoCommandDescription { get; }
        void Undo(Guid id);
    }
}