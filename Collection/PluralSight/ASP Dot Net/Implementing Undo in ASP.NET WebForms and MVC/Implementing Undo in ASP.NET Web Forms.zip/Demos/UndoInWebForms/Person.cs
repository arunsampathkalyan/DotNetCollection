﻿using System.Collections.Generic;

namespace UndoInWebForms
{
    public class Person
    {
        public string Name { get; set; }

        public static List<Person> AllPersons { get { return allPersons; } }
        static readonly List<Person> allPersons = new List<Person>
            {
                new Person{Name="Alice Wu"},
                new Person{Name="Ron Sanchez"},
                new Person{Name="Rajesh Ramamurthy"},
                new Person{Name="Samantha Peterson"},
            };
    }
}
