using Pluralsight.SampleInfrastructure.Undo;
using Pluralsight.SampleInfrastructure.Utilities;

namespace UndoInWebForms.Undo
{
    public class UndoProviderFactory
    {
        public IUndoProvider MakeUndoProvider()
        {
            var fileSystem = new FileSystem();
            var undoRepository = new UndoRepository1(fileSystem);
            var cookieProvider = new CookieProvider();
            var contextItemProvider = new ContextItemProvider();
            return new UndoProvider(undoRepository, cookieProvider, contextItemProvider);
        }
    }
}