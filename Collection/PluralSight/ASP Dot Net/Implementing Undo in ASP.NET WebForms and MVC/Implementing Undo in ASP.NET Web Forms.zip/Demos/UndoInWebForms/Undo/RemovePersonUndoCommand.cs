﻿using System;
using Pluralsight.SampleInfrastructure.Undo;

namespace UndoInWebForms.Undo
{
    [Serializable]
    public class RemovePersonUndoCommand : IUndoCommand
    {
        public string Name { get; set; }
        public void Execute()
        {
            Person.AllPersons.Add(new Person { Name = Name });
        }

        public string DescriptionOfActionToBeUndone
        {
            get { return string.Format("{0} was delete.", Name); }
        }
    }
}
