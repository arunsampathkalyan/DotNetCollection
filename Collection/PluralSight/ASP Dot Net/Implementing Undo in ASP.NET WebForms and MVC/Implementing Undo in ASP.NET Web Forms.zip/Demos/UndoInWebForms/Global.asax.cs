﻿using System;
using Pluralsight.SampleInfrastructure.Undo;
using Pluralsight.SampleInfrastructure.Utilities;
using UndoInWebForms.Undo;

namespace UndoInWebForms
{
    public class Global : System.Web.HttpApplication
    {
        public override void Init()
        {
            base.Init();

            BeginRequest += new EventHandler(Global_BeginRequest);

            ServiceLocator.Init(LocateService);
        }

        void Global_BeginRequest(object sender, EventArgs e)
        {
            UndoProvider.BeginRequestHandler();
        }

        object LocateService(Type typeOfService)
        {
            if (typeOfService == typeof(IUndoProvider))
                return UndoProvider;
            throw new ArgumentException();
        }

        void Application_Start(object sender, EventArgs e)
        {
            SetupUndo();
        }

        void SetupUndo()
        {
            var factory = new UndoProviderFactory();
            UndoProvider = factory.MakeUndoProvider();
        }

        public static IUndoProvider UndoProvider { get; private set; }
    }
}
