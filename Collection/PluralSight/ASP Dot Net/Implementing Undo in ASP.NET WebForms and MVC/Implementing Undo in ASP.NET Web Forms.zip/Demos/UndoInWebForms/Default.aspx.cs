﻿using System;
using System.Linq;
using System.Web.UI.WebControls;
using Pluralsight.SampleInfrastructure.Undo;
using UndoInWebForms.Undo;

namespace UndoInWebForms
{
    public partial class _Default : System.Web.UI.Page
    {
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (IsPostBack)
                return;

            gvPeople.DataSource = Person.AllPersons.OrderBy(person => person.Name);
            gvPeople.DataBind();
        }

        protected void People_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName != "DeletePerson")
                return;

            var name = (string) e.CommandArgument;
            RemovePersonFromList(name);
            RegisterUndoCommand(name);
            Response.Redirect(Request.Url.PathAndQuery);
        }

        void RegisterUndoCommand(string name)
        {
            var cmd = new RemovePersonUndoCommand {Name = name};
            Global.UndoProvider.RegisterUndoCommand(cmd);
        }

        bool RemovePersonFromList(string name)
        {
            for (var i = 0; i < Person.AllPersons.Count; ++i)
            {
                if (Person.AllPersons[i].Name == name)
                {
                    Person.AllPersons.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        protected void Add_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Length > 0)
                Person.AllPersons.Add(new Person {Name = txtName.Text});
            Response.Redirect(Request.Url.PathAndQuery);
        }
    }

}
