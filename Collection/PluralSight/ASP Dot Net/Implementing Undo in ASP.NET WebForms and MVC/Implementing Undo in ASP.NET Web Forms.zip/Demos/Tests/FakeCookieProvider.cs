﻿using System.Collections.Generic;
using System.Web;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Tests
{
    public class FakeCookieProvider : ICookieProvider
    {
        readonly Dictionary<string, HttpCookie> cookies = new Dictionary<string, HttpCookie>();

        public void SetCookie(HttpCookie cookie)
        {
            cookies[cookie.Name] = cookie;
        }

        public HttpCookie GetCookie(string name)
        {
            HttpCookie cookie;
            return cookies.TryGetValue(name, out cookie) ? cookie : null;
        }
    }
}