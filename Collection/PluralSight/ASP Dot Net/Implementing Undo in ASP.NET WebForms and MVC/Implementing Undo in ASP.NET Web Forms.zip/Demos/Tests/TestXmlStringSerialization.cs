﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pluralsight.SampleInfrastructure.Serialization;

namespace Tests
{
    [TestClass]
    public class TestXmlStringSerialization
    {
        [TestMethod]
        public void SerializeAndDeserialize()
        {
            // arrange
            var bob = new Person
            {
                Name = "Bob",
                Age = 24,
                Mother = new Person()
                {
                    Name = "Alice",
                    Age = 50,
                },
            };

            var typeRegistry = new XmlStringSerializableTypeRegistry();
            typeRegistry.RegisterType(bob.GetType());

            var ser = new XmlStringSerializer();
            var serializedData = ser.Serialize(bob);

            var deserializer = new XmlStringDeserializer(typeRegistry);

            var deserializedBob = deserializer.Deserialize(serializedData) as Person;
            Assert.IsNotNull(deserializedBob);
            Assert.AreEqual("Bob", deserializedBob.Name);
            Assert.AreEqual(24, deserializedBob.Age);
            Assert.IsNotNull(deserializedBob.Mother);
            Assert.AreEqual("Alice", deserializedBob.Mother.Name);
            Assert.AreEqual(50, deserializedBob.Mother.Age);
        }
    }
}
