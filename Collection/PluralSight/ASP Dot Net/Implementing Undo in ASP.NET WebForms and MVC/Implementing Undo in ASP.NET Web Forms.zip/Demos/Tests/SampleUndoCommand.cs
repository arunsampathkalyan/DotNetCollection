﻿using System;
using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Undo;

namespace Tests
{
    [Serializable] // required for UndoRepository1
    [XmlStringSerializable("12341234-1234-1234-1234-123412341234")] // required for UndoRepository2
    public class SampleUndoCommand : IUndoCommand
    {
        public string Text { get; set; }

        public void Execute()
        {
            // record that we were executed so our test can verify this
            CommandExecuted = this; 
        }

        public string DescriptionOfActionToBeUndone
        {
            get { return "undo-description"; }
        }

        public static SampleUndoCommand CommandExecuted { get; set; }
    }
}
