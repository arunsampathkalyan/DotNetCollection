﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pluralsight.SampleInfrastructure.Utilities;
using System.IO;

namespace Tests
{
    public class FakeFileSystem : IFileSystem
    {
        private readonly Dictionary<string, MemoryStream> _files =
            new Dictionary<string, MemoryStream>(StringComparer.InvariantCultureIgnoreCase);

        public void WriteAllText(string path, string contents)
        {
            using (var stream = CreateFile(path))
            using (var writer = new StreamWriter(stream))
                writer.Write(contents);
        }

        public Stream CreateFile(string path)
        {
            var contents = new MemoryStream();

            if (!_files.ContainsKey(path))
                _files.Add(path, contents);
            else _files[path] = contents;

            return contents;
        }

        public string ReadAllText(string path)
        {
            using (var stream = OpenRead(path))
            using (var reader = new StreamReader(stream))
                return reader.ReadToEnd();
        }

        public Stream OpenRead(string path)
        {
            try
            {
                return new MemoryStream(_files[path].ToArray(), false);
            }
            catch (KeyNotFoundException x)
            {
                throw new FileNotFoundException("FakeFileSystem.OpenRead could not find this file: " + path, x);
            }
        }

        public bool Exists(string path)
        {
            return _files.ContainsKey(path);
        }

        public void Delete(string path)
        {
            _files.Remove(path);
        }

        public DateTime GetLastWriteTime(string path)
        {
            return lastWriteTime;
        }

        public string[] GetAllFilesUnderThisDirectory(string directory)
        {
            directory = NormalizeDirectoryName(directory);

            return _files
                .Keys
                .Where(path => path.StartsWith(directory, StringComparison.InvariantCultureIgnoreCase) && !IsDirectoryPath(path))
                .ToArray();
        }

        private string NormalizeDirectoryName(string directory)
        {
            return IsDirectoryPath(directory) ? directory : directory + @"\";
        }

        private bool IsDirectoryPath(string path)
        {
            return path.EndsWith(@"\");
        }

        DateTime lastWriteTime;

        public void SetLastWriteTime(DateTime dateTime)
        {
            lastWriteTime = dateTime;
        }
    }
}
