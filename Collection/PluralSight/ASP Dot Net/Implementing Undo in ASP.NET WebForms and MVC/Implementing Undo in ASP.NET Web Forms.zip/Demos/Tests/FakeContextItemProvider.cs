﻿using System.Collections;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Tests
{
    public class FakeContextItemProvider : IContextItemProvider
    {
        readonly Hashtable items = new Hashtable();

        public void SetContextItem(string key, string value)
        {
            items[key] = value;
        }

        public string GetContextItem(string key)
        {
            return (string)items[key];
        }
    }
}