﻿using System;

namespace SerializationDemo.Pluralsight.SampleInfrastructure
{
    public interface IXmlStringSerializableTypeRegistry
    {
        Type Lookup(Guid typeId);
        void RegisterType(Type xmlStringSerializableType);
    }
}