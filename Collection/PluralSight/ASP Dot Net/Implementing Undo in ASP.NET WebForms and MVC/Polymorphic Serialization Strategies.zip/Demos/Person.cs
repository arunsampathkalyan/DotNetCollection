﻿using SerializationDemo.Pluralsight.SampleInfrastructure;

namespace SerializationDemo
{
    [XmlStringSerializable("75d345a6-2f36-40fb-91b6-c98878de1b8f")]
    public class Person
    {
        public string Name { get; set; }
    }
}