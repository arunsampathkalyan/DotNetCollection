﻿using System;
using System.IO;
using SerializationDemo.Pluralsight.SampleInfrastructure;

namespace SerializationDemo
{
    class Program
    {
        const string FileName = @"C:\temp\serializationDemo\bob.txt";
        static IXmlStringSerializableTypeRegistry typeRegistry;

        static void Main()
        {
            typeRegistry = new XmlStringSerializableTypeRegistry();
            typeRegistry.RegisterType(typeof (Person));
            LoadBob();
        }

        static void SaveBob()
        {
            Serialize(new Person { Name = "Bob" });
        }

        static void Serialize(Person person)
        {
            var serializer = new XmlStringSerializer();
            var serializedData = serializer.Serialize(person);
            File.WriteAllText(FileName, serializedData);
        }

        static void LoadBob()
        {
            var bob = Deserialize();
            Console.WriteLine(bob.Name);
        }

        static Person Deserialize()
        {
            var serializer = new XmlStringDeserializer(typeRegistry);
            var serializedData = File.ReadAllText(FileName);
            return (Person) serializer.Deserialize(serializedData);
        }
    }
}
