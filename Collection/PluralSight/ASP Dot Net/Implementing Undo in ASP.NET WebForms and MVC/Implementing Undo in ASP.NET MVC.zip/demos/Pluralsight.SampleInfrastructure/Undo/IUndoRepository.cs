﻿using System;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public interface IUndoRepository
    {
        Guid Save(IUndoCommand undoCommand);
        IUndoCommand Find(Guid id);
        void Delete(Guid id);
        bool Exists(Guid id);
    }
}