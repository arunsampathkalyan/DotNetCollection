﻿using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public interface IUndoCommand : ICommand
    {
        string DescriptionOfActionToBeUndone { get; }
    }
}