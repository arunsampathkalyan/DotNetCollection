﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public class UndoPanel : WebControl, INamingContainer
    {
        readonly IUndoProvider undoProvider;

        Guid undoId = Guid.Empty;
        bool needToCreateChildControls;

        public UndoPanel(IUndoProvider undoProvider)
        {
            this.undoProvider = undoProvider;
        }

        public UndoPanel()
            : this(ServiceLocator.GetService<IUndoProvider>())
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            Page.RegisterRequiresControlState(this);
        }

        protected override object SaveControlState()
        {
            return undoId;
        }

        protected override void LoadControlState(object savedState)
        {
            undoId = (Guid) savedState;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            if (undoProvider.IsUndoAvailable)
            {
                CopyUndoIdFromContextItemIntoControlState();
                needToCreateChildControls = true;
            }
            else needToCreateChildControls = InAnUndoClickPostBack; // in order to receive the click event, must create button during postback
        }

        void CopyUndoIdFromContextItemIntoControlState()
        {
            undoId = undoProvider.GetUndoIdFromContextItem();
        }

        protected bool InAnUndoClickPostBack
        {
            get { return Page.IsPostBack && Guid.Empty != undoId; }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            if (!needToCreateChildControls)
                return;

            var description = undoProvider.UndoCommandDescription;

            AddLiteral("<div style='background-color:#FFFF99;color:black;text-align:center;padding:5px'>");
            AddLiteral(description + " ");
            AddUndoButton();
            AddLiteral("</div>");
        }

        void AddUndoButton()
        {
            var button = AssembleUndoButton();
            Controls.Add(button);
        }

        LinkButton AssembleUndoButton()
        {
            var button = new LinkButton {Text = "Undo"};
            button.Click += Undo_Click;
            return button;
        }

        void Undo_Click(object sender, EventArgs e)
        {
            TryUndo();
            RefreshView();
        }

        void TryUndo()
        {
            if (Guid.Empty == undoId)
                return;
            undoProvider.Undo(undoId);
        }

        private void RefreshView()
        {
            Page.Response.Redirect(Page.Request.Url.PathAndQuery);
        }

        void AddLiteral(string text)
        {
            Controls.Add(new LiteralControl(text));
        }
    }
}
