﻿using System;
using System.Web;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public class UndoProvider : IUndoProvider
    {
        readonly IUndoRepository undoRepository;
        readonly ICookieProvider cookieProvider;
        readonly IContextItemProvider contextItemProvider;
        internal const string CookieName = "undo";
        internal const string ContextItemKey = "undo";

        public UndoProvider(
            IUndoRepository undoRepository,
            ICookieProvider cookieProvider,
            IContextItemProvider contextItemProvider)
        {
            this.undoRepository = undoRepository;
            this.cookieProvider = cookieProvider;
            this.contextItemProvider = contextItemProvider;
        }

        public void RegisterUndoCommand(IUndoCommand undoCommand)
        {
            var id = undoRepository.Save(undoCommand);
            SetUndoCookie(id);
        }

        public Guid GetUndoIdFromContextItem()
        {
            Guid id;
            return GetIdFromContextItem(out id) ? id : Guid.Empty;
        }

        public string UndoCommandDescription
        {
            get
            {
                Guid id;
                if (!GetIdFromContextItem(out id))
                    return "";
                return GetUndoCommandDescription(id);
            }
        }

        string GetUndoCommandDescription(Guid id)
        {
            var undoCommand = undoRepository.Find(id);
            return undoCommand != null ? undoCommand.DescriptionOfActionToBeUndone : "";
        }

        bool GetIdFromContextItem(out Guid id)
        {
            var idAsString = contextItemProvider.GetContextItem(ContextItemKey);
            return Guid.TryParse(idAsString, out id);
        }

        public bool IsUndoAvailable
        {
            get
            {
                Guid id;
                if (!GetIdFromContextItem(out id))
                    return false;
                return undoRepository.Exists(id);
            }
        }

        void SetUndoCookie(Guid id)
        {
            cookieProvider.ExpireCookie(CookieName);
            if (Guid.Empty == id)
                return;
            var cookie = CreateCookie(CookieName, AsString(id));
            cookieProvider.SetCookie(cookie);
        }

        string AsString(Guid id)
        {
            return id.ToString("N");
        }

        public void BeginRequestHandler()
        {
            TransferInformationFromUndoCookieIntoContextItem();
        }

        void TransferInformationFromUndoCookieIntoContextItem()
        {
            var undoCookie = cookieProvider.GetCookie(CookieName);
            if (null == undoCookie)
                return;

            ClearUndoCookie();

            Guid id;
            if (!Guid.TryParse(undoCookie.Value, out id))
                return;

            contextItemProvider.SetContextItem(ContextItemKey, AsString(id));
        }

        HttpCookie CreateCookie(string name, string value)
        {
            return new HttpCookie(name, value)
                {
                    HttpOnly = true,
                };
        }

        private void ClearUndoCookie()
        {
            SetUndoCookie(Guid.Empty);
        }

        public void Undo(Guid id)
        {
            var undoCommand = undoRepository.Find(id);
            if (null == undoCommand)
                return;
            undoCommand.Execute();
            undoRepository.Delete(id);
        }
    }
}
