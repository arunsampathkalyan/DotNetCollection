﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public class UndoRepository1 : UndoRepositoryBase, IUndoRepository
    {
        public UndoRepository1(IFileSystem fileSystem)
        {
            this.fileSystem = fileSystem;
        }

        public override Guid Save(IUndoCommand undoCommand)
        {
            var id = Guid.NewGuid();
            SerializeToFile(PathFor(id), undoCommand);
            CleanupExpiredFiles();
            return id;
        }

        void SerializeToFile(string path, IUndoCommand undoCommand)
        {
            var formatter = new BinaryFormatter();
            using (var stream = fileSystem.CreateFile(path))
                formatter.Serialize(stream, undoCommand);
        }
        public override IUndoCommand Find(Guid id)
        {
            var path = PathFor(id);
            return !fileSystem.Exists(path) ? null : LoadFromFile(path);
        }

        IUndoCommand LoadFromFile(string path)
        {
            var formatter = new BinaryFormatter();
            using (var stream = fileSystem.OpenRead(path))
                return (IUndoCommand) formatter.Deserialize(stream);
        }
    }
}