﻿using System;
using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public class UndoRepository2 : UndoRepositoryBase, IUndoRepository
    {
        readonly IXmlStringSerializableTypeRegistry typeRegistry;

        public UndoRepository2(IFileSystem fileSystem, IXmlStringSerializableTypeRegistry typeRegistry)
        {
            this.fileSystem = fileSystem;
            this.typeRegistry = typeRegistry;
        }

        public override Guid Save(IUndoCommand undoCommand)
        {
            var serializedData = SerializeCommand(undoCommand);
            var id = WriteFileWithNewId(serializedData);
            CleanupExpiredFiles();
            return id;
        }

        string SerializeCommand(IUndoCommand undoCommand)
        {
            var ser = new XmlStringSerializer();
            return ser.Serialize(undoCommand);
        }

        Guid WriteFileWithNewId(string serializedData)
        {
            var id = Guid.NewGuid();
            CreateFile(id, serializedData);
            return id;
        }

        void CreateFile(Guid id, string serializedData)
        {
            fileSystem.WriteAllText(PathFor(id), serializedData);
        }

        public override IUndoCommand Find(Guid id)
        {
            var serializedData = LoadFromFile(id);
            if (null == serializedData)
                return null;
            return DeserializeCommand(serializedData);
        }

        string LoadFromFile(Guid id)
        {
            var path = PathFor(id);
            return !fileSystem.Exists(path) ? null : fileSystem.ReadAllText(path);
        }

        IUndoCommand DeserializeCommand(string serializedData)
        {
            var ser = new XmlStringDeserializer(typeRegistry);
            return ser.Deserialize(serializedData) as IUndoCommand;
        }
    }
}