﻿using System;

namespace Pluralsight.SampleInfrastructure.Undo
{
    public interface IUndoProvider
    {
        void RegisterUndoCommand(IUndoCommand undoCommand);
        bool IsUndoAvailable { get; }
        Guid GetUndoIdFromContextItem();
        string UndoCommandDescription { get; }
        void BeginRequestHandler();
        void Undo(Guid id);
    }
}