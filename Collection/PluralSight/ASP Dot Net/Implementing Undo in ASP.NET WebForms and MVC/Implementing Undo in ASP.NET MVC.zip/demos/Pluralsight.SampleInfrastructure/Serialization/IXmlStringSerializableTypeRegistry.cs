﻿using System;

namespace Pluralsight.SampleInfrastructure.Serialization
{
    public interface IXmlStringSerializableTypeRegistry
    {
        Type Lookup(Guid typeId);
        void RegisterType(Type xmlStringSerializableType);
    }
}