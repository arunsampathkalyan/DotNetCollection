﻿using System;
using System.Web;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public static class ICookieProviderExtensions
    {
        public static void ExpireCookie(this ICookieProvider cookieProvider, string name)
        {
            var expiredCookie = new HttpCookie(name) {Expires = SystemTime.Now().AddYears(-20)};
            cookieProvider.SetCookie(expiredCookie);
        }
    }
}