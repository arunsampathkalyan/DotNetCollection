﻿using System.Web;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public interface ICookieProvider
    {
        void SetCookie(HttpCookie cookie);
        HttpCookie GetCookie(string name);
    }
}