﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public class FileSystem : IFileSystem
    {
        public bool Exists(string path)
        {
            return File.Exists(path);
        }

        public void WriteAllText(string path, string contents)
        {
            File.WriteAllText(path, contents);
        }

        public string ReadAllText(string path)
        {
            return File.ReadAllText(path);
        }

        public Stream CreateFile(string path)
        {
            return File.Create(path);
        }

        public Stream OpenRead(string path)
        {
            return File.OpenRead(path);
        }

        public void Delete(string path)
        {
            File.Delete(path);
        }

        public DateTime GetLastWriteTime(string path)
        {
            return new FileInfo(path).LastWriteTime;
        }

        public string[] GetAllFilesUnderThisDirectory(string directory)
        {
            return Directory.GetFiles(directory);
        }
    }
}
