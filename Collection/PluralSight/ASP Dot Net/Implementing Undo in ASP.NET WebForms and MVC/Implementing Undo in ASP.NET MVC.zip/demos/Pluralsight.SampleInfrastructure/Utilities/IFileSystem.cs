﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public interface IFileSystem
    {
        bool Exists(string path);
        void WriteAllText(string path, string contents);
        string ReadAllText(string path);
        Stream CreateFile(string path);
        Stream OpenRead(string path);
        void Delete(string path);
        DateTime GetLastWriteTime(string path);
        string[] GetAllFilesUnderThisDirectory(string directory);
    }
}
