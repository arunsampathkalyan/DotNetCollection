﻿using System.Web;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public class ContextItemProvider : IContextItemProvider
    {
        public void SetContextItem(string key, string value)
        {
            HttpContext.Current.Items[key] = value;
        }

        public string GetContextItem(string key)
        {
            return (string)HttpContext.Current.Items[key];
        }
    }
}