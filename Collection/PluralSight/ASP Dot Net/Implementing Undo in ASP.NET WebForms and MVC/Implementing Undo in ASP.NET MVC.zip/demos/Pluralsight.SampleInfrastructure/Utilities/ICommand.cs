﻿namespace Pluralsight.SampleInfrastructure.Utilities
{
    public interface ICommand
    {
        void Execute();
    }
}