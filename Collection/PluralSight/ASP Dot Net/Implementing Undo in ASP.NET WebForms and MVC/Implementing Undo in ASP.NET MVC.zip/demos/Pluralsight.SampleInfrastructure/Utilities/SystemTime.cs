﻿using System;

namespace Pluralsight.SampleInfrastructure.Utilities
{
    public static class SystemTime
    {
        public static void UseDefaultImplementation()
        {
            Now = () => DateTime.Now;
        }

        public static Func<DateTime> Now = () => DateTime.Now;

        public static DateTime Today
        {
            get { return Now().Date; }
        }
    }
}