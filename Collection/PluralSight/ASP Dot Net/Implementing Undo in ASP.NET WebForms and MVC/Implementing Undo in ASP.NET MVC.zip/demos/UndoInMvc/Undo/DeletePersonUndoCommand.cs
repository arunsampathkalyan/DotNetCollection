﻿using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Undo;
using UndoInMvc.Controllers;

namespace UndoInMvc.Undo
{
    [XmlStringSerializable("8bf2328e-4720-43c9-828d-3533d2259c0b")]
    public class DeletePersonUndoCommand : IUndoCommand
    {
        public string Name { get; set; }

        public void Execute()
        {
            new HomeController().Create(Name);
        }

        public string DescriptionOfActionToBeUndone
        {
            get { return string.Format("{0} was deleted.", Name); }
        }
    }
}