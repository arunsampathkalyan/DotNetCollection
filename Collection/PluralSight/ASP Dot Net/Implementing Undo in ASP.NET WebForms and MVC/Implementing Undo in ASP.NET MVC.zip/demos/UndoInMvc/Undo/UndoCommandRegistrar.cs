﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Undo;

namespace UndoInMvc.Undo
{
    public static class UndoCommandRegistrar
    {
        public static void RegisterUndoCommandsWith(IXmlStringSerializableTypeRegistry typeRegistry)
        {
            foreach (var type in AllTypesThatImplementIUndoCommand)
                typeRegistry.RegisterType(type);
        }

        static IEnumerable<Type> AllTypesThatImplementIUndoCommand
        {
            get
            {
                return typeof (UndoCommandRegistrar)
                    .Assembly
                    .GetTypes()
                    .Where(t => typeof (IUndoCommand).IsAssignableFrom(t));
            }
        }
    }
}