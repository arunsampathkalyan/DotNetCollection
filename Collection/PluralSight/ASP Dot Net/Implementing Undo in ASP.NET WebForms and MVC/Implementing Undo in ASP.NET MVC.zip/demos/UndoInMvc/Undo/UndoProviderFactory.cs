﻿using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Undo;
using Pluralsight.SampleInfrastructure.Utilities;

namespace UndoInMvc.Undo
{
    public class UndoProviderFactory
    {
        public IUndoProvider MakeUndoProvider()
        {
            var fileSystem = new FileSystem();
            var typeRegistry = new XmlStringSerializableTypeRegistry();
            UndoCommandRegistrar.RegisterUndoCommandsWith(typeRegistry);
            var undoRepository = new UndoRepository2(fileSystem, typeRegistry);
            var cookieProvider = new CookieProvider();
            var contextItemProvider = new ContextItemProvider();
            return new UndoProvider(undoRepository, cookieProvider, contextItemProvider);
        }
    }
}