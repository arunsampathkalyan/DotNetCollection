﻿using System;
using System.Web.Mvc;

namespace UndoInMvc.Controllers
{
    public class UndoController : Controller
    {
        [HttpPost]
        public ActionResult Undo(string undoId, string returnUrl)
        {
            Guid id;
            if (Guid.TryParse(undoId, out id))
                MvcApplication.UndoProvider.Undo(id);
            return Redirect(returnUrl);
        }
    }
}
