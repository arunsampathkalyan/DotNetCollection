﻿using System.Linq;
using System.Web.Mvc;
using UndoInMvc.Models;
using UndoInMvc.Undo;

namespace UndoInMvc.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View(Person.AllPersons.OrderBy(p => p.Name));
        }

        [HttpPost]
        public ActionResult Create(string name)
        {
            Person.AllPersons.Add(new Person{Name=name});
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Delete(string name)
        {
            if (RemovePersonFromList(name))
                MvcApplication.UndoProvider.RegisterUndoCommand(new DeletePersonUndoCommand {Name = name});
            return RedirectToAction("Index");
        }

        bool RemovePersonFromList(string name)
        {
            for (var i = 0; i < Person.AllPersons.Count; ++i)
            {
                if (Person.AllPersons[i].Name == name)
                {
                    Person.AllPersons.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
