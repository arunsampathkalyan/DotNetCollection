﻿using Pluralsight.SampleInfrastructure.Serialization;

namespace Tests
{
    [XmlStringSerializable("12341234-1234-1234-1234-123412341234")]
    public class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public Person Mother { get; set; }
    }
}