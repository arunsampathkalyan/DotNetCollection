﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pluralsight.SampleInfrastructure.Serialization;
using Pluralsight.SampleInfrastructure.Undo;
using Pluralsight.SampleInfrastructure.Utilities;

namespace Tests
{
    [TestClass]
    public abstract class TestUndoProviderBase
    {
        protected abstract IUndoRepository CreateRepository(IFileSystem fileSystem);
        [TestMethod]
        public void TestUndoLifeCycle()
        {
            SystemTime.Now = () => new DateTime(2010, 1, 1);

            var fileSystem = new FakeFileSystem();
            fileSystem.SetLastWriteTime(SystemTime.Now());
            var undoRepository = CreateRepository(fileSystem);
            var cookieProvider = new FakeCookieProvider();
            var contextItemProvider = new FakeContextItemProvider();
            var undoProvider = new UndoProvider(undoRepository, cookieProvider, contextItemProvider);

            Assert.IsFalse(undoProvider.IsUndoAvailable);

            // act: register an undo command
            undoProvider.RegisterUndoCommand(new SampleUndoCommand {Text = "sample-text"});

            // assert: undo cookie should be set at this point
            Assert.IsNotNull(cookieProvider.GetCookie(UndoProvider.CookieName));

            // act: simulate a redirect, and a new request comes in
            //      this handler removes the cookie and xfers to HttpContext.Items
            undoProvider.BeginRequestHandler();

            // assert: undo should be "available" to show to user, with details in a context item
            Assert.IsTrue(cookieProvider.GetCookie(UndoProvider.CookieName).Expires < SystemTime.Today.AddYears(-1));
            Assert.IsNotNull(contextItemProvider.GetContextItem(UndoProvider.ContextItemKey));
            Assert.IsTrue(undoProvider.IsUndoAvailable);
            Assert.AreEqual("undo-description", undoProvider.UndoCommandDescription);

            // act: retrieve undo command from repository
            var undoId = undoProvider.GetUndoIdFromContextItem();
            undoProvider.Undo(undoId);
            Assert.IsNotNull(SampleUndoCommand.CommandExecuted);
            Assert.AreEqual("sample-text", SampleUndoCommand.CommandExecuted.Text);
        }
    }

    [TestClass]
    public class TestUndoProvider1 : TestUndoProviderBase
    {
        protected override IUndoRepository CreateRepository(IFileSystem fileSystem)
        {
            return new UndoRepository1(fileSystem);
        }
    }

    [TestClass]
    public class TestUndoProvider2 : TestUndoProviderBase
    {
        protected override IUndoRepository CreateRepository(IFileSystem fileSystem)
        {
            var typeRegistry = new XmlStringSerializableTypeRegistry();
            typeRegistry.RegisterType(typeof(SampleUndoCommand));
            return new UndoRepository2(fileSystem, typeRegistry);
        }
    }
}