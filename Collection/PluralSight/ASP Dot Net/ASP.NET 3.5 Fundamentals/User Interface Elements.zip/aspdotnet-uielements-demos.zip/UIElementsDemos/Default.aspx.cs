﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected override void OnPreInit(EventArgs e)
    {
        this.Theme = "MyTheme2";

        base.OnPreInit(e);
    }
    protected void Page_Load(object sender, EventArgs e)
    {
       // ((SiteTemplate)this.Master).NavVisible = false;
        this.Master.NavVisible = false;
    }
}
