using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Page1 : System.Web.UI.Page
{

  protected void enterButton_Click(object sender, EventArgs e)
  {
    messageLabel.Text = String.Format("Hello {0}, how do you like being a {1}?", 
            nameTextBox.Text, professionTextBox.Text);
  }
}
