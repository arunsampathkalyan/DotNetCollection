using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SetPreferences : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            _themeDropDownList.SelectedValue = Profile.theme;
            _masterPageDropDownList.SelectedValue = Profile.masterpage;
        }
    }
    protected void _setPreferencesButton_Click(object sender, EventArgs e)
    {
        Profile.theme = _themeDropDownList.SelectedValue;
        Profile.masterpage = _masterPageDropDownList.SelectedValue;
        Response.Redirect("~/default.aspx");
    }
    protected void _cancelbutton_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/default.aspx");
    }
}
