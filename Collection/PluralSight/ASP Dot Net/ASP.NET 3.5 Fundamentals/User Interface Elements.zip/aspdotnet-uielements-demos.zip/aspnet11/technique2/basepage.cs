using System;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace EssentialAspDotNet
{
  public abstract class BaseTemplatePage : Page
  {
	PlaceHolder _container;
	string      _templatePath = "template.ascx";

	public BaseTemplatePage()
	{
	  _container = new PlaceHolder();
	  _container.ID = "_container";
	}

	// protected property for derived classes to set
	// template path
	//
	protected string TemplatePath
	{
	  get { return _templatePath;  }
	  set { _templatePath = value; }
	}

	protected override void AddParsedSubObject(object obj) 
	{
	  // As controls are parsed on this page, add them to
	  // our container control which we will inject into
	  // out template later (in OnInit)
	  //
	  _container.Controls.Add((Control)obj);

	  // don't chain to base page so 
	  // that controls on this page are not added 
	  // directly as children to the page
	}

	protected override void OnInit(EventArgs e)
	{
	  // load an .ascx file here and inject content into placeholder 
	  // (currently hardcoded to template.ascx)
	  //
	  Control template = LoadControl(_templatePath);
	  if (template == null)
		throw new Exception("Error - missing template file: " + _templatePath);

	  // Locate control called _placeHolder
	  Control placeHolder = template.FindControl("_placeHolder");
	  if (placeHolder == null)
		throw new Exception("Error - template is missing control with id of _placeHolder");

	  placeHolder.Controls.Add(_container);

	  for (int i=0; i<template.Controls.Count; i++)
	  {
		Control c = template.Controls[0];
		template.Controls.Remove(c);
		Controls.Add(c);
	  }
	  
	  base.OnInit(e);
	}
  }
}
