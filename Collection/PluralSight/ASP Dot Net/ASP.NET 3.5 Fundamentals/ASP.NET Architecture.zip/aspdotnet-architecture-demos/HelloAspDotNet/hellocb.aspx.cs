using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PS
{
	public partial class HelloCbBase : Page
	{
		//protected BulletedList _displayList;
	
		string[] _displayItemData = {"Item #1", "Item #2", "Item #3", "Item #4", "Item #5", 
									 "Item #6", "Item #7", "Item #8", "Item #9", "Item #10"};
		
		protected const int _itemCount = 10;
		// Response.Write("hi");        -- invalid
		string GetDisplayItem(int n) {
			return "Item #" + n.ToString();
		}
		
		protected override void OnLoad(EventArgs e)
		{
			_displayList.DataSource = _displayItemData;
			_displayList.DataBind();
			
			base.OnLoad(e);
		}
		
		protected void Page_LoadComplete(object src, EventArgs e)
		{
			Response.Write("page load complete called!");
		}
		
		protected void _clickMeButton_Click(object sender, EventArgs e)
		{
			//_msgLabel.Text = "Hi there from button click";
			int x = int.Parse(_xVal.Text);
			int y = int.Parse(_yVal.Text);
			_msgLabel.Text = PS.Calc.Add(x,y).ToString();
		}
		
	}
}