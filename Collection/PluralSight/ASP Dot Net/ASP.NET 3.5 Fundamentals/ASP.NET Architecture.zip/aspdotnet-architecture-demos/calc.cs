using System;

namespace PS
{
	public class Calc
	{
		public static int Add(int x, int y)
		{
			return x+y;
		}
	}
}