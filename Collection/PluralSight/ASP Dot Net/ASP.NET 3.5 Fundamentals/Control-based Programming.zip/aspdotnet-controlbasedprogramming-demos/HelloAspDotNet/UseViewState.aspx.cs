﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UseViewState : System.Web.UI.Page
{
    const string LBCC = "listBoxClickCount";

    public int ListBoxClickCount 
    {
        get { return (int)(ViewState[LBCC] ?? 0); }
        set { ViewState[LBCC] = value;  }
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ListBoxClickCount++;
        Label1.Text = ListBoxClickCount.ToString();
    }
}
