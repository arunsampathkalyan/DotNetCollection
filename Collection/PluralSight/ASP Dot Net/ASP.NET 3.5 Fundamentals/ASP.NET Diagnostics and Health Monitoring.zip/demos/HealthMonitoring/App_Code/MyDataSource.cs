﻿using System;
using System.Collections;

public static class MyDataSource
{
    public static IEnumerable ThrowsException()
    {
        throw new ApplicationException("Oops!");
    }
}
