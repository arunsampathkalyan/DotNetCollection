﻿using System;
using System.Web;
using System.Web.UI;
using HealthMonitoringHelpers;

public partial class _Default : Page
{
    protected void GenerateException_Click(object sender, EventArgs e)
    {
        throw new ApplicationException("Oops!");
    }

    protected void GenerateCustomEvent_Click(object sender, EventArgs e)
    {
        MyEvent anEvent = new MyEvent(this, "Widget was created", MyEventCode.WidgetCreated);
        anEvent.Raise();
    }
}
