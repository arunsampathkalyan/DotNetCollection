﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Management;
using System.Globalization;

namespace HealthMonitoringHelpers
{
    public class MyEvent : WebRequestEvent
    {
        public MyEvent(object sender, string msg, MyEventCode code)
            : base(msg, sender, (int)code + WebEventCodes.WebExtendedBase)
        {
            this.culture = CultureInfo.CurrentCulture.Name;
        }

        public override void FormatCustomEventDetails(WebEventFormatter formatter)
        {
            base.FormatCustomEventDetails(formatter);

            formatter.AppendLine("Culture: " + culture);
        }

        string culture;
    }

    public enum MyEventCode : int {
        WidgetCreated = 1,
        WidgetDeleted = 2,
    }
}
