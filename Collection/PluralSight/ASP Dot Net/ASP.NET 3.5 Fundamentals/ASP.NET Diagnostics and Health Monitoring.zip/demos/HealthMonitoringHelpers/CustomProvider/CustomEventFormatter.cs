﻿using System;
using System.Web.Management;
using System.Text;

namespace Pluralsight.Samples
{
    /// <summary>
    /// Wraps a StringBuilder and adds support for indentation
    /// Modeled after WebEventFormatter, which has an internal ctor :(
    /// </summary>
	public class CustomEventFormatter
	{
        const int TabSpaces = 4;

        StringBuilder sb = new StringBuilder();
        private int indentLevel;
        private bool startingNewLine = true;

        public void Indent()
        {
            ++indentLevel;
        }

        public void RevertIndent()
        {
            if (indentLevel > 0)
                --indentLevel;
        }

        public void Append(string text)
        {
            if (startingNewLine)
                EmitIndent();
            sb.Append(text);
            startingNewLine = false;
        }

        public void AppendLine(string lineOfText)
        {
            if (startingNewLine)
                EmitIndent();
            EmitIndent();
            sb.AppendLine(lineOfText);
            startingNewLine = true;
        }

        private void EmitIndent()
        {
            sb.Append(' ', TabSpaces * indentLevel);
        }

        public void AppendLine()
        {
            AppendLine(string.Empty);
        }

        public override string ToString()
        {
            return sb.ToString();
        }
    }
}
