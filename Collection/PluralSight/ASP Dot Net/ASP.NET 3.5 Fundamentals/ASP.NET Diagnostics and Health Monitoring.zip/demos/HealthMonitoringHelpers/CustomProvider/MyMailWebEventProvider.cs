﻿using System;
using System.Web.Management;
using System.Collections.Specialized;
using System.Configuration;
using System.Reflection;
using System.Web;
using System.Text;
using System.Net.Mail;

namespace Pluralsight.Samples
{
    public class MyMailWebEventProvider : WebEventProvider
    {
        public override void Initialize(string name, NameValueCollection config)
        {
            base.Initialize(name, config);

            to = GetAndRemoveStringAttribute(config, "to", true);
            from = GetAndRemoveStringAttribute(config, "from", true);
            subjectPrefix = GetAndRemoveStringAttribute(config, "subjectPrefix", false);
        }
        public override void ProcessEvent(WebBaseEvent raisedEvent)
        {
            SendMail(raisedEvent);
        }

        public override void Flush()
        {
            // nothing to do - this is not a buffering provider
        }

        public override void Shutdown()
        {
            // nothing to do here either
        }

        string to;
        string from;
        string subjectPrefix;

        private void SendMail(WebBaseEvent raisedEvent)
        {
            string subject = ComputeEmailSubject(raisedEvent);
            string body = ComputeEmailBody(raisedEvent);

            MailMessage msg = new MailMessage(from, to, subject, body);
            new SmtpClient().Send(msg);
        }

        private string ComputeEmailBody(WebBaseEvent raisedEvent)
        {
            WebRequestErrorEvent errorEvent = raisedEvent as WebRequestErrorEvent;
            if (null != errorEvent)
                return ErrorEventFormattingHelper.FormatRequestErrorEvent(errorEvent);
            else return raisedEvent.ToString();
        }

        private string ComputeEmailSubject(WebBaseEvent raisedEvent)
        {
            StringBuilder subjectBuilder = new StringBuilder();

            // surface some details in subject about error events
            WebBaseErrorEvent errorEvent = raisedEvent as WebBaseErrorEvent;
            if (null != errorEvent)
            {
                Exception unhandledException = errorEvent.ErrorException;

                // drill through reflection exceptions to show the root cause
                TargetInvocationException invocationException = unhandledException as TargetInvocationException;
                if (null != invocationException)
                {
                    Exception innerException = DrillIntoTargetInvocationException(invocationException);
                    subjectBuilder.AppendFormat("{0}", (innerException ?? invocationException).GetType().Name);
                    if (null != innerException)
                        subjectBuilder.Append(" (via reflection)");
                }
                else subjectBuilder.Append(unhandledException.GetType().Name);
            }

            // if we've not got anything better, just show the event type in the subject
            if (0 == subjectBuilder.Length)
                subjectBuilder.AppendFormat("Event type: {0}", raisedEvent.GetType().Name);

            if (!string.IsNullOrEmpty(subjectPrefix)) {
                subjectBuilder.Insert(0, ' ');
                subjectBuilder.Insert(0, subjectPrefix);
            }
            return subjectBuilder.ToString();
        }

        /// <summary>
        /// Reflection often hides exception details, so we try to drill down
        /// through the plumbing exceptions to find a likely cause
        /// </summary>
        private Exception DrillIntoTargetInvocationException(TargetInvocationException outerException)
        {
            Exception innerException = outerException.InnerException;
            TargetInvocationException innerInvocationException = innerException as TargetInvocationException;
            if (null != innerInvocationException)
                return DrillIntoTargetInvocationException(innerInvocationException);
            else if (null != innerException)
                return innerException;
            else return null;
        }

        private static string GetAndRemoveStringAttribute(NameValueCollection config, string attributeName, bool required)
        {
            string value = config.Get(attributeName);
            if (required && string.IsNullOrEmpty(value))
                throw new ConfigurationErrorsException(string.Format("PSMailWebEventProvider expected attribute {0}, which is missing or empty.", attributeName));
            config.Remove(attributeName);
            return value;
        }
    }
}
