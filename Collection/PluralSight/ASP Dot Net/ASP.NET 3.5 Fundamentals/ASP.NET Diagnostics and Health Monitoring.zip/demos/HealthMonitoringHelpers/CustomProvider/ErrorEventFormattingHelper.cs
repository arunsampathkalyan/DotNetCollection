﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Management;
using System.Globalization;

namespace Pluralsight.Samples
{
    internal static class ErrorEventFormattingHelper
    {
        internal static string FormatRequestErrorEvent(WebRequestErrorEvent errorEvent)
        {
            CustomEventFormatter formatter = new CustomEventFormatter();

            formatter.AppendLine(string.Format("Unhandled Exception in {0}:", WebBaseEvent.ApplicationInformation.ApplicationVirtualPath));
            formatter.Indent();
            EmitExceptionAtAGlance(formatter, errorEvent.ErrorException);
            formatter.RevertIndent();

            formatter.AppendLine();
            formatter.AppendLine("Exception stack trace(s):");
            EmitExceptionStackTrace(formatter, errorEvent.ErrorException);

            formatter.AppendLine();
            formatter.AppendLine("Event information:");
            formatter.Indent();
            EmitEventInfo(formatter, errorEvent);
            formatter.RevertIndent();

            formatter.AppendLine();
            formatter.AppendLine("Application information:");
            formatter.Indent();
            EmitApplicationInfo(formatter, WebBaseEvent.ApplicationInformation);
            formatter.RevertIndent();

            formatter.AppendLine();
            formatter.AppendLine("Process/thread information:");
            formatter.Indent();
            EmitProcessInfo(formatter, errorEvent.ProcessInformation);
            formatter.RevertIndent();

            formatter.AppendLine();
            formatter.AppendLine("Request information:");
            formatter.Indent();
            EmitRequestInfo(formatter, errorEvent.RequestInformation);
            formatter.RevertIndent();

            return formatter.ToString();
        }

        private static void EmitEventInfo(CustomEventFormatter formatter, WebBaseEvent theEvent)
        {
            formatter.AppendLine(string.Format("Event code: {0}", theEvent.EventCode.ToString(CultureInfo.InvariantCulture)));
            formatter.AppendLine(string.Format("Event message: {0}", theEvent.Message));
            formatter.AppendLine(string.Format("Event time: {0}", theEvent.EventTime.ToString(CultureInfo.InvariantCulture)));
            formatter.AppendLine(string.Format("Event ID: {0}", theEvent.EventID.ToString("N", CultureInfo.InvariantCulture)));
        }

        private static void EmitApplicationInfo(CustomEventFormatter formatter, WebApplicationInformation appInfo)
        {
            formatter.AppendLine(string.Format("Application domain: {0}", appInfo.ApplicationDomain));
            formatter.AppendLine(string.Format("Application Virtual Path: {0}", appInfo.ApplicationVirtualPath));
            formatter.AppendLine(string.Format("Application Physical Path: {0}", appInfo.ApplicationPath));
        }

        private static void EmitProcessInfo(CustomEventFormatter formatter, WebProcessInformation webProcessInfo)
        {
            formatter.AppendLine(string.Format("Process ID: {0}", webProcessInfo.ProcessID.ToString(CultureInfo.InvariantCulture)));
            formatter.AppendLine(string.Format("Process name: {0}", webProcessInfo.ProcessName));
            formatter.AppendLine(string.Format("Account name: {0}", webProcessInfo.AccountName));
        }

        private static void EmitRequestInfo(CustomEventFormatter formatter, WebRequestInformation webRequestInfo)
        {
            string name = null;
            if (webRequestInfo.Principal != null)
                name = webRequestInfo.Principal.Identity.Name;

            formatter.AppendLine(string.Format("Request URL: {0}", webRequestInfo.RequestUrl));
            formatter.AppendLine(string.Format("Request path: {0}", webRequestInfo.RequestPath));
            formatter.AppendLine(string.Format("User name: {0}", name ?? "[ANONYMOUS]"));
            formatter.AppendLine(string.Format("User host address: {0}", webRequestInfo.UserHostAddress));
        }

        private static void EmitExceptionAtAGlance(CustomEventFormatter formatter, Exception exception)
        {
            formatter.AppendLine(string.Format("Type: {0}", exception.GetType().Name));
            formatter.AppendLine(string.Format("Message: {0}", exception.Message));
            if (null != exception.InnerException)
            {
                formatter.Indent();
                formatter.AppendLine("-->Inner Exception");
                EmitExceptionAtAGlance(formatter, exception.InnerException);
                formatter.RevertIndent();
            }
        }

        private static void EmitExceptionStackTrace(CustomEventFormatter formatter, Exception exception)
        {
            formatter.AppendLine(exception.StackTrace);

            if (null != exception.InnerException)
            {
                // no point indenting, since stack traces typically wrap like crazy
                formatter.AppendLine();
                formatter.AppendLine("-->Inner exception stack trace:");
                EmitExceptionStackTrace(formatter, exception.InnerException);
            }
        }
    }
}
