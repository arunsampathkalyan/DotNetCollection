﻿using System;
using System.Web;
using System.Web.UI;

public partial class _Default : Page
{
    protected void GenerateException_Click(object sender, EventArgs e)
    {
        throw new ApplicationException("Oops!");
    }
}
