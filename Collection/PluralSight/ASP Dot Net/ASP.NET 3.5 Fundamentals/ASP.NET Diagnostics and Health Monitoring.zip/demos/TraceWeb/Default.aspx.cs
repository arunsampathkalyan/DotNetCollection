﻿#define TRACE

using System;
using System.Web;
using System.Web.UI;

public partial class _Default : Page
{
    protected override void OnLoad(EventArgs e)
    {
        base.OnLoad(e);

        Session["MySessionState"] = "This is some session state.";
        Application["MyApplicationState"] = "This is some application state.";
        Response.Cookies.Add(new HttpCookie("MyCookie", "This is some cookie state."));
    }

    protected void Button_Click(object sender, EventArgs e)
    {
        System.Diagnostics.Trace.WriteLine(
            "This is from S.D.Trace", "My Category");

        Trace.Write("My Category", "Trace messages are ignored unless tracing is turned on.");

        if (Trace.IsEnabled)
        {
            // perform some potentially expensive tracing here
            Trace.Write("My Category", "You can add additional testing code that runs only when tracing is enabled");
        }

        Trace.Warn("My Category", "This is from Trace.Warn");

    }
}
