﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PS
{
    public static class MyUtils2
    {
        public static string DoubleString(string input)
        {
            return input + input + input;
        }
    }
}
