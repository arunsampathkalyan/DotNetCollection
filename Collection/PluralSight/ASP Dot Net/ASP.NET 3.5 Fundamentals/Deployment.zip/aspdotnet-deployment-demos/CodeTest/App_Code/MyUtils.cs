﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PS
{
    public static class MyUtils
    {
        public static string DoubleString(string input)
        {
            return input + input + input;
        }
    }

}