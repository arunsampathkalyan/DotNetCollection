﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using PS;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        CustomSettings cs = (CustomSettings)ConfigurationManager.GetSection("CustomSettings");

        _configSettingsLabel.Text = cs.BackgroundColor;

        _appSettingsLabel.Text = ConfigurationManager.AppSettings["BackgroundColor"];
    }
}
