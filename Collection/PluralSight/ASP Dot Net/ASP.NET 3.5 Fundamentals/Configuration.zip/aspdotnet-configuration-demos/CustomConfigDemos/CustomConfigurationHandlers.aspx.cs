﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PS;
using System.Configuration;
using System.Collections.Specialized;
using System.Text;

public partial class CustomConfigurationHandlers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        AcmeSettings set;
        set = ConfigurationManager.GetSection("acmeGroup/acme") as AcmeSettings;
        StringBuilder settings = new StringBuilder();
        settings.Append("<h4>font=");
        settings.Append(set.Font);
        settings.Append("</h4>");
        settings.Append("<h4>backgroundColor=");
        settings.Append(set.BackgroundColor);
        settings.Append("</h4>");
        settings.Append("<h4>underlineLinks=");
        settings.Append(set.UnderlineLinks);
        settings.Append("</h4>");
        settings.Append("<h4>horizontalWidth=");
        settings.Append(set.HorizontalWidth);
        settings.Append("</h4>");
        settings.Append("<h4>verticalWidth=");
        settings.Append(set.VerticalWidth);
        settings.Append("</h4>");

        _acmeLabel.Text = settings.ToString();

       
    }
}
