namespace PS
{
    public class CustomSettings
    {
        public string Font;
        public string BackgroundColor;
        public bool UnderlineLinks;
        public int HorizontalWidth;
        public int VerticalWidth;
    } 
}