using System;
using System.Xml;
using System.Configuration;
using System.Web;
using System.Web.Configuration;

namespace PS
{
  public class AcmeSettings
  {
    public string Font;
    public string BackgroundColor;
    public bool   UnderlineLinks;
    public int    HorizontalWidth;
    public int    VerticalWidth;

    public override string ToString()
    {
      string ret = string.Format("AcmeSettings: Font={0}, BackgroundColor={1}, UnderlineLinks={2}, HorizontalWidth={3}, VerticalWidth={4}",
                                  Font, BackgroundColor, UnderlineLinks, HorizontalWidth, VerticalWidth);
      return ret;
    }
  }

  public class AcmeConfigHandler : IConfigurationSectionHandler
  {
    public object Create(object parent, object input, XmlNode node)
    {
      AcmeSettings aset = new AcmeSettings();

      foreach (XmlNode n in node.ChildNodes)
      {
        switch (n.Name)
        {
          case ("font"):
            aset.Font = n.InnerText;
            break;
          case ("backgroundColor"):
            aset.BackgroundColor = n.InnerText;
            break;
          case ("underlineLinks"):
            aset.UnderlineLinks = bool.Parse(n.InnerText);
            break;
          case ("horizontalWidth"):
            aset.HorizontalWidth = int.Parse(n.InnerText);
            break;
          case ("verticalWidth"):
            aset.VerticalWidth = int.Parse(n.InnerText);
            break;
        }
      }
      return aset;
    }
  }
}
