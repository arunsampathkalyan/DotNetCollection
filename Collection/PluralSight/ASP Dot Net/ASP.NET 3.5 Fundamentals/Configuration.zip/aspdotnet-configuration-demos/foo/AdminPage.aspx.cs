﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.Configuration;

public partial class AdminPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            _fontTextBox.Text = ConfigurationManager.AppSettings["font"];
    }
    protected void _setFontButton_Click(object sender, EventArgs e)
    {
        string path = Request.CurrentExecutionFilePath;
        path = path.Substring(0, path.LastIndexOf("/"));

        Configuration config = WebConfigurationManager.OpenWebConfiguration(path);
        KeyValueConfigurationElement fontElement = config.AppSettings.Settings["font"];
        if (fontElement != null)
        {
            fontElement.Value = _fontTextBox.Text;
            config.Save();
        }
    }
}
