﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SessionPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["val"] == null)
            Session["val"] = 0;
        else
            Session["val"] = ((int)Session["val"]) + 1;

        _sessionValueLabel.Text = Session["val"].ToString();
    }
}
