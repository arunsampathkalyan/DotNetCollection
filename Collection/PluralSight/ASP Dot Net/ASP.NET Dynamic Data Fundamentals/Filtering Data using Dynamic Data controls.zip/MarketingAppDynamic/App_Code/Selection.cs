﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Marketing
{
    [MetadataType(typeof(SelectionMetadata))]
    public partial class Selection
    {
    }

    public class SelectionMetadata
    {
        [Display(AutoGenerateField=false)]
        //[ScaffoldColumn(false)]
        public object EmailOpened;

        [Display(Order=10001)]
        public object Optout;

        [EnumDataType(typeof(CallStatusEnum))]
        public object CallingStatus;

    }
}