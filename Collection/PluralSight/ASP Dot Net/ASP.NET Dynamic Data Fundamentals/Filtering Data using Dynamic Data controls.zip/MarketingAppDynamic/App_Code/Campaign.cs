﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Marketing
{
    [MetadataType(typeof(CampaignMetadata))]
    public partial class Campaign
    {
    }

    public class CampaignMetadata
    {
        [DisplayFormat(DataFormatString="{0:d}", ApplyFormatInEditMode=true)]
        public object StartDate;

        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public object EndDate;

        [Range(1,2000)]
        public object Target;

    }
}