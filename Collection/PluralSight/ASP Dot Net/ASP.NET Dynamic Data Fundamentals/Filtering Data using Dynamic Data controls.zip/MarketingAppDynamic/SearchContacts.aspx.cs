﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.Expressions;
using Marketing;

public partial class SearchContacts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    protected void ClearSelections(object sender, EventArgs e)
    {
        string listBoxName = ((LinkButton)sender).CommandName;
        Control control = Page.Master.FindControl("MainContent").FindControl(listBoxName);
        if (control != null)
        {
            ListBox lb = (ListBox)control;
            lb.ClearSelection();
        }
    }

    protected void ChkExternal_CheckedChanged(object sender, EventArgs e)
    {
        Panel2.Visible = chkExternal.Checked;
    }


    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        pnlSearch.Visible = !pnlSearch.Visible;
        pnlFilters.Visible = !pnlFilters.Visible;
        LinkButton5.Text = (pnlSearch.Visible ? "Basic Search" : "Advanced Search");
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvContacts.DataBind();
    }

}

