﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Marketing
{
    [DisplayColumn("Lname")]
    [MetadataType(typeof(ContactMetadata))]
    public partial class Contact
    {
        public override string ToString()
        {
            return Fname + " " + Lname;
        }
    }

    public class ContactMetadata
    {
        [UIHint("EmailAddress")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")]
        //[DataType( System.ComponentModel.DataAnnotations.DataType.EmailAddress)]
        public object Email;

        [UIHint("PositionType")]
        public object PositionType;

        [Required(ErrorMessage="Comments may not be empty!")]
        public object Comments;

        [RegularExpression(@"((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}")]
        public object WorkPhone;

    }

}