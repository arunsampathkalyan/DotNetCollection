
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 03/17/2010 14:07:58
-- Generated from EDMX file: F:\Visual Studio 2010\WebSites\MarketingApp (10)\App_Code\Marketing.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [MarketingApp];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_PositionTypeContact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Contacts] DROP CONSTRAINT [FK_PositionTypeContact];
GO
IF OBJECT_ID(N'[dbo].[FK_CompanyIndustryCat_Company]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CompanyIndustryCat] DROP CONSTRAINT [FK_CompanyIndustryCat_Company];
GO
IF OBJECT_ID(N'[dbo].[FK_CompanyIndustryCat_IndustryCat]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[CompanyIndustryCat] DROP CONSTRAINT [FK_CompanyIndustryCat_IndustryCat];
GO
IF OBJECT_ID(N'[dbo].[FK_ContactSelection]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Selections] DROP CONSTRAINT [FK_ContactSelection];
GO
IF OBJECT_ID(N'[dbo].[FK_CampaignSelection]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Selections] DROP CONSTRAINT [FK_CampaignSelection];
GO
IF OBJECT_ID(N'[dbo].[FK_CompanyContact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Contacts] DROP CONSTRAINT [FK_CompanyContact];
GO
IF OBJECT_ID(N'[dbo].[FK_CountryContact]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Contacts] DROP CONSTRAINT [FK_CountryContact];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Contacts]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Contacts];
GO
IF OBJECT_ID(N'[dbo].[Campaigns]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Campaigns];
GO
IF OBJECT_ID(N'[dbo].[PositionTypes]', 'U') IS NOT NULL
    DROP TABLE [dbo].[PositionTypes];
GO
IF OBJECT_ID(N'[dbo].[Companies]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Companies];
GO
IF OBJECT_ID(N'[dbo].[IndustryCats]', 'U') IS NOT NULL
    DROP TABLE [dbo].[IndustryCats];
GO
IF OBJECT_ID(N'[dbo].[Selections]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Selections];
GO
IF OBJECT_ID(N'[dbo].[Countries]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Countries];
GO
IF OBJECT_ID(N'[dbo].[CompanyIndustryCat]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CompanyIndustryCat];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Contacts'
CREATE TABLE [dbo].[Contacts] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Fname] nvarchar(max)  NOT NULL,
    [Lname] nvarchar(max)  NOT NULL,
    [WorkPhone] nvarchar(max)  NOT NULL,
    [Email] nvarchar(max)  NOT NULL,
    [EmailValid] bit  NOT NULL,
    [Unsubscribed] bit  NOT NULL,
    [LastUpdate] datetime  NOT NULL,
    [Comments] nvarchar(max)  NULL,
    [PositionTypeId] int  NOT NULL,
    [CompanyId] int  NOT NULL,
    [CountryId] int  NOT NULL,
    [Customer] nvarchar(max)  NULL,
    [ExpDate] datetime  NOT NULL
);
GO

-- Creating table 'Campaigns'
CREATE TABLE [dbo].[Campaigns] (
    [Id] nchar(5)  NOT NULL,
    [Name] nvarchar(20)  NOT NULL,
    [StartDate] datetime  NOT NULL,
    [EndDate] datetime  NOT NULL,
    [Target] int  NOT NULL,
    [MaxContacts] int  NOT NULL default 500,
    [Customer] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'PositionTypes'
CREATE TABLE [dbo].[PositionTypes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Priority] tinyint  NOT NULL
);
GO

-- Creating table 'Companies'
CREATE TABLE [dbo].[Companies] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Info_Website] nvarchar(max)  NULL,
    [Info_Regnum] nvarchar(max)  NULL,
    [Info_Groupsize] smallint  NULL
);
GO

-- Creating table 'IndustryCats'
CREATE TABLE [dbo].[IndustryCats] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Selections'
CREATE TABLE [dbo].[Selections] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [ContactId] int  NOT NULL,
    [CampaignId] nchar(5)  NOT NULL,
    [Optout] bit  NOT NULL,
    [EmailOpened] bit  NULL
);
GO

-- Creating table 'Countries'
CREATE TABLE [dbo].[Countries] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'CompanyIndustryCat'
CREATE TABLE [dbo].[CompanyIndustryCat] (
    [Companies_Id] int  NOT NULL,
    [IndustryCats_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'Contacts'
ALTER TABLE [dbo].[Contacts]
ADD CONSTRAINT [PK_Contacts]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Campaigns'
ALTER TABLE [dbo].[Campaigns]
ADD CONSTRAINT [PK_Campaigns]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'PositionTypes'
ALTER TABLE [dbo].[PositionTypes]
ADD CONSTRAINT [PK_PositionTypes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Companies'
ALTER TABLE [dbo].[Companies]
ADD CONSTRAINT [PK_Companies]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'IndustryCats'
ALTER TABLE [dbo].[IndustryCats]
ADD CONSTRAINT [PK_IndustryCats]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Selections'
ALTER TABLE [dbo].[Selections]
ADD CONSTRAINT [PK_Selections]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Countries'
ALTER TABLE [dbo].[Countries]
ADD CONSTRAINT [PK_Countries]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Companies_Id], [IndustryCats_Id] in table 'CompanyIndustryCat'
ALTER TABLE [dbo].[CompanyIndustryCat]
ADD CONSTRAINT [PK_CompanyIndustryCat]
    PRIMARY KEY NONCLUSTERED ([Companies_Id], [IndustryCats_Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [PositionTypeId] in table 'Contacts'
ALTER TABLE [dbo].[Contacts]
ADD CONSTRAINT [FK_PositionTypeContact]
    FOREIGN KEY ([PositionTypeId])
    REFERENCES [dbo].[PositionTypes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_PositionTypeContact'
CREATE INDEX [IX_FK_PositionTypeContact]
ON [dbo].[Contacts]
    ([PositionTypeId]);
GO

-- Creating foreign key on [Companies_Id] in table 'CompanyIndustryCat'
ALTER TABLE [dbo].[CompanyIndustryCat]
ADD CONSTRAINT [FK_CompanyIndustryCat_Company]
    FOREIGN KEY ([Companies_Id])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [IndustryCats_Id] in table 'CompanyIndustryCat'
ALTER TABLE [dbo].[CompanyIndustryCat]
ADD CONSTRAINT [FK_CompanyIndustryCat_IndustryCat]
    FOREIGN KEY ([IndustryCats_Id])
    REFERENCES [dbo].[IndustryCats]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CompanyIndustryCat_IndustryCat'
CREATE INDEX [IX_FK_CompanyIndustryCat_IndustryCat]
ON [dbo].[CompanyIndustryCat]
    ([IndustryCats_Id]);
GO

-- Creating foreign key on [ContactId] in table 'Selections'
ALTER TABLE [dbo].[Selections]
ADD CONSTRAINT [FK_ContactSelection]
    FOREIGN KEY ([ContactId])
    REFERENCES [dbo].[Contacts]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ContactSelection'
CREATE INDEX [IX_FK_ContactSelection]
ON [dbo].[Selections]
    ([ContactId]);
GO

-- Creating foreign key on [CampaignId] in table 'Selections'
ALTER TABLE [dbo].[Selections]
ADD CONSTRAINT [FK_CampaignSelection]
    FOREIGN KEY ([CampaignId])
    REFERENCES [dbo].[Campaigns]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CampaignSelection'
CREATE INDEX [IX_FK_CampaignSelection]
ON [dbo].[Selections]
    ([CampaignId]);
GO

-- Creating foreign key on [CompanyId] in table 'Contacts'
ALTER TABLE [dbo].[Contacts]
ADD CONSTRAINT [FK_CompanyContact]
    FOREIGN KEY ([CompanyId])
    REFERENCES [dbo].[Companies]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CompanyContact'
CREATE INDEX [IX_FK_CompanyContact]
ON [dbo].[Contacts]
    ([CompanyId]);
GO

-- Creating foreign key on [CountryId] in table 'Contacts'
ALTER TABLE [dbo].[Contacts]
ADD CONSTRAINT [FK_CountryContact]
    FOREIGN KEY ([CountryId])
    REFERENCES [dbo].[Countries]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_CountryContact'
CREATE INDEX [IX_FK_CountryContact]
ON [dbo].[Contacts]
    ([CountryId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------