﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.Expressions;
using Marketing;

public partial class SearchContacts : System.Web.UI.Page
{
    #region This part was added offline

    protected string CampaignId = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        //redirect to campaign list if no campaign is specified in Session var
        if (Session["CampaignId"] == null)
            Response.Redirect("ListCampaigns.aspx");
        CampaignId = Session["CampaignId"].ToString();

    }

    #endregion



    protected void EDS1_Selecting(object sender, EventArgs e)
    {
        if (chkExternal.Checked)
        {
            if (tbExpMin.Text.Length > 0 && tbExpMax.Text.Length > 0)
            {
                RangeExpression re = new RangeExpression
                {
                    DataField = "ExpDate",
                    MaxType = RangeType.Inclusive,
                    MinType = RangeType.Inclusive
                };
                re.Parameters.Add(new Parameter
                {
                    Type = TypeCode.DateTime,
                    Name = "MinVal",
                    DefaultValue = tbExpMin.Text
                });
                re.Parameters.Add(new Parameter
                {
                    Type = TypeCode.DateTime,
                    Name = "MaxVal",
                    DefaultValue = tbExpMax.Text
                });

                QueryExtender1.Expressions.Add(re);
            }
        }
    }

    protected void EDS1_ContextCreating(object sender, EventArgs e)
    {
        if (chkExternal.Checked)
        {
            EDS1.EntityTypeFilter = "ExtContact";
        }
        else
            EDS1.EntityTypeFilter = "";
    }

    protected void CustExpr_Querying(object sender, CustomExpressionEventArgs e)
    {
        if (IsPostBack && btnSearch.Visible)
        {
            //companies
            var compIds = lbCompany.GetSelectedIndices().AsQueryable()
                            .Select(i => int.Parse(lbCompany.Items[i].Value));
            if (compIds.Count() > 0)
                e.Query = e.Query.Cast<Contact>().Where(
                    c => compIds.Contains(c.CompanyId));

            //countries
            var countryIds = lbCountries.GetSelectedIndices().AsQueryable()
                        .Select(i => int.Parse(lbCountries.Items[i].Value));
            if (countryIds.Count() > 0)
                e.Query = e.Query.Cast<Contact>().Where(
                                c => countryIds.Contains(c.CountryId));

            //Position types
            var postypeIds = lbPostypes.GetSelectedIndices().AsQueryable()
                        .Select(i => int.Parse(lbPostypes.Items[i].Value));
            if (postypeIds.Count() > 0)
                e.Query = e.Query.Cast<Contact>().Where(
                                c => postypeIds.Contains(c.PositionTypeId));

            //Industry categories
            var indcatIds = lbIndcat.GetSelectedIndices().AsQueryable()
                        .Select(i => int.Parse(lbIndcat.Items[i].Value));
            if (indcatIds.Count() > 0)
                e.Query = e.Query.Cast<Contact>().Where(
                    c => c.Company.IndustryCats.Any(ic => indcatIds.Contains(ic.Id)));

            if (chkExternal.Checked)
            {
                var customers = lbCustomers.GetSelectedIndices().AsQueryable()
                                .Select(i => lbCustomers.Items[i].Value);
                if (customers.Count() > 0)
                    e.Query = e.Query.Cast<ExtContact>().Where(
                        ext => customers.Contains(ext.Customer));

                //cast to expected type
                e.Query = e.Query.Cast<ExtContact>();
            }
        }
    }

    protected void ClearSelections(object sender, EventArgs e)
    {
        string listBoxName = ((LinkButton)sender).CommandName;
        Control control = Page.Master.FindControl("MainContent").FindControl(listBoxName);
        if (control != null)
        {
            ListBox lb = (ListBox)control;
            lb.ClearSelection();
        }
    }

    protected void ChkExternal_CheckedChanged(object sender, EventArgs e)
    {
        if (((CheckBox)sender).Checked)
        {
            gvContacts.Columns.Add(new BoundField
            {
                DataField = "Customer",
                HeaderText = "External source",
                SortExpression = "Customer"
            });
            gvContacts.Columns.Add(new BoundField
            {
                DataField = "ExpDate",
                HeaderText = "Expires",
                DataFormatString = "{0:d}",
                SortExpression = "ExpDate"
            });
        }
        else
        {
            int lastColIndex = gvContacts.Columns.Count - 1;
            gvContacts.Columns.Remove(gvContacts.Columns[lastColIndex]);
            gvContacts.Columns.Remove(gvContacts.Columns[lastColIndex - 1]);
        }

        gvContacts.DataBind();
        Panel2.Visible = chkExternal.Checked;
    }


    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        pnlSearch.Visible = !pnlSearch.Visible;
        pnlFilters.Visible = !pnlFilters.Visible;
        LinkButton5.Text = (pnlSearch.Visible ? "Basic Search" : "Advanced Search");
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvContacts.DataBind();
    }


    #region This part was added offline

    protected void btnAddToCampaign_Click(object sender, EventArgs e)
    {
        List<int> contactIds = new List<int>();

        foreach (GridViewRow row in gvContacts.Rows)
        {
            CheckBox cb = (CheckBox)row.Cells[0].FindControl("chkAdd");
            if (cb != null)
            {
                if (cb.Checked)
                {
                    //store ids in a collection so we can retrieve and add them all at once
                    int id = (int)gvContacts.DataKeys[row.RowIndex][0];
                    contactIds.Add(id);
                }
            }
        }

        AddSelections(contactIds);
        gvContacts.DataBind();
    }

    private void AddSelections(List<int> contactIds)
    {
        using (MarketingContainer ctx = new MarketingContainer())
        {
            //first retrieve contacts
            var contactsToAdd = ctx.Contacts.Where(c => contactIds.Contains(c.Id));

            //instead of using a classic FK approach to insert into Selections table, 
            //use the OO approach through the navigation props
            Campaign thisCampaign = ctx.Campaigns.Single(camp => camp.Id == CampaignId);

            foreach (Contact contact in contactsToAdd)
                thisCampaign.Selections.Add(new Selection { Contact = contact, Campaign = thisCampaign });

            ctx.SaveChanges();
            Response.Redirect("ViewSelections.aspx?id=" + CampaignId);
        }
    }


    protected void chkAll_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = sender as CheckBox;
        if (cb == null) return;

        foreach (GridViewRow row in gvContacts.Rows)
        {
            CheckBox cb2 = (CheckBox)row.Cells[0].FindControl("chkAdd");
            if (cb2 != null) cb2.Checked = cb.Checked;
        }
    }

    #endregion

}

