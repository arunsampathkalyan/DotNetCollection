﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Objects;
using System.Data;
using System.Linq;
using System.Collections.Generic;

namespace Marketing
{
    public partial class MarketingContainer
    {
        List<Tuple<Selection, byte>> selectionsWithChangedStatus =
            new List<Tuple<Selection, byte>>();

        partial void OnContextCreated()
        {
            SavingChanges += new EventHandler(MarketingContainer_SavingChanges);
        }


        void MarketingContainer_SavingChanges(object sender, EventArgs e)
        {
            var stateManager = ((MarketingContainer)sender).ObjectStateManager;

            var changes = stateManager.GetObjectStateEntries(System.Data.EntityState.Added
                | System.Data.EntityState.Modified);

            foreach (var entry in changes)
            {
                if (entry.Entity is Campaign)
                    ValidateCampaign((Campaign)entry.Entity);

                if (entry.Entity is Selection)
                    ValidateStatus(entry);

                #region Handle update issue with EDS when Contact is a derived ExtContact
                if (entry.State == EntityState.Modified &&
                    entry.Entity is ExtContact)
                {
                    var origVals = entry.GetUpdatableOriginalValues();
                    origVals.SetString(12, entry.CurrentValues.GetString(12));
                    origVals.SetDateTime(13, entry.CurrentValues.GetDateTime(13));
                }
                #endregion

            }
        }

        private void ValidateStatus(ObjectStateEntry entry)
        {
            Selection sel = (Selection)entry.Entity;

            if (entry.State == EntityState.Added)
            {
                if (sel.CallingStatusId != (byte)CallStatusEnum.NOTCALLED)
                    throw new ValidationException("Status for a new selection must be NOTCALLED");
            }

            if (entry.State == EntityState.Modified)
            {
                if (sel.CallingStatusId == (byte)CallStatusEnum.PENDINGNEXT)
                {
                    sel.CallingStatusId = (byte)CallStatusEnum.PENDING;
                    sel.PendingLevel++;
                }

                byte oldStatusId = (byte)entry.OriginalValues["CallingStatusId"];
                byte proposedStatusId = (byte)entry.CurrentValues["CallingStatusId"];

                if (proposedStatusId != oldStatusId)
                {
                    if (!CallingStatus.IsLegalChange(oldStatusId, proposedStatusId))
                    {
                        string message = string.Format(
                            "Illegal status change : cannot change from {0} to {1}",
                            Enum.GetName(typeof(CallStatusEnum), oldStatusId),
                            Enum.GetName(typeof(CallStatusEnum), proposedStatusId));
                        throw new ValidationException(message);
                    }
                    else
                    {
                        selectionsWithChangedStatus.Add(
                            new Tuple<Selection, byte>(sel, oldStatusId));

                        SavedChanges += Company.ComputeCallingStatus;
                        SavedChanges += CallingStatus.LogStatusChanges;
                    }
                }
            }

        }

        private void ValidateCampaign(Campaign camp)
        {
            string message = "";

            if (camp.StartDate > camp.EndDate)
                message = "End Date must be later than Start Date;  ";

            if ((camp.EndDate - camp.StartDate).Days > 180)
                message = "Campaign duration cannot exceed 180 days;  ";

            if (camp.Name.Contains(camp.Id))
                message += "Campaign name should not contain campaign Id;  ";

            if (camp.MaxContacts < camp.Target * 3)
                message += "MaxContacts must be at least 3 times the campaign Target number";

            if (message.Length > 0)
                throw new ValidationException(message);

        }

        public event EventHandler<SavedChangesEventArgs> SavedChanges;

        public bool SavedChangesEventEnabled = true;

        public override int SaveChanges(SaveOptions options)
        {
            int count = base.SaveChanges(options);

            if (SavedChangesEventEnabled)
            {
                if (SavedChanges != null)
                    SavedChanges(this, new SavedChangesEventArgs
                        {
                            UpdatedSelections = selectionsWithChangedStatus
                        });
            }

            return count;
        }

    }

    public class SavedChangesEventArgs : EventArgs
    {
        public List<Tuple<Selection, byte>> UpdatedSelections
        { get; set; }
    }
}