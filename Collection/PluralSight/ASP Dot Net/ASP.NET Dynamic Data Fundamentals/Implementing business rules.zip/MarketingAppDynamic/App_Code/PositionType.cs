﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Marketing
{
    [DisplayColumn("Name","Name")]
    public partial class PositionType
    {
    }

}