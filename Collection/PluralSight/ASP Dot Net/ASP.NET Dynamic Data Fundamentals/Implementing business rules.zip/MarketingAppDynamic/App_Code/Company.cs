﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Marketing
{
    [DisplayColumn("Name","Name")]
    public partial class Company
    {
        public static void ComputeCallingStatus(object sender, SavedChangesEventArgs e)
        {
            MarketingContainer ctx = (MarketingContainer)sender;

            foreach (var pair in e.UpdatedSelections)
            {
                int contactId = pair.Item1.ContactId;
                string campaignId = pair.Item1.CampaignId;
                int companyId = ctx.Contacts.Single(c => c.Id == contactId).Company.Id;

                var statuses = ctx.Selections.Where(s => s.CampaignId == campaignId
                                                && s.Contact.Company.Id == companyId)
                                            .Select(s => s.CallingStatus);

                CallingStatus companyStatus = statuses.FirstOrDefault(
                    s => s.Rank == statuses.Max(s2 => s2.Rank));

                CompanyCampaign compCamp = ctx.CompanyCampaigns.SingleOrDefault(
                    cc => cc.CampaignId == campaignId && cc.CompanyId == companyId);

                if (compCamp == null)
                {
                    ctx.CompanyCampaigns.AddObject(new CompanyCampaign
                    {
                        CampaignId = campaignId,
                        CompanyId = companyId,
                        CallingStatus = companyStatus
                    });
                }
                else
                    compCamp.CallingStatus = companyStatus;

            }

            ctx.SavedChangesEventEnabled = false;
            ctx.SaveChanges();
            ctx.SavedChangesEventEnabled = true;
        }



    }



}