﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Marketing
{
    [MetadataType(typeof(CampaignMetadata))]
    public partial class Campaign
    {
        partial void OnTargetChanging(int value)
        {
            if (value % 5 > 0)
                throw new ValidationException("Target should be a multiple of 5");
        }

        partial void OnMaxContactsChanging(int value)
        {
            if (value % 10 > 0)
                throw new ValidationException("MaxContacts should be a multiple of 10");
            
        }
    }

    public class CampaignMetadata
    {
        [DisplayFormat(DataFormatString="{0:d}", ApplyFormatInEditMode=true)]
        public object StartDate;

        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        public object EndDate;

        [Range(1,2000)]
        public object Target;

    }
}