﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Marketing
{
    public partial class CallingStatus
    {
        public static bool IsLegalChange(int oldStatusId, int proposedStatusId)
        {
            using(MarketingContainer ctx = new MarketingContainer())
            {
                return ctx.StatusRules.Count(r => r.StatusFromId == oldStatusId &&
                                                    r.StatusToId == proposedStatusId) > 0;
            }
        }

        public static void LogStatusChanges(object sender, SavedChangesEventArgs e)
        {
            MarketingContainer ctx = (MarketingContainer)sender;

            foreach (var pair in e.UpdatedSelections)
            {
                int selectionId = pair.Item1.Id;
                byte newStatusId = pair.Item1.CallingStatusId;
                byte oldStatusId = pair.Item2;

                StatusChange change = new StatusChange
                {
                    StatusFromId = oldStatusId,
                    StatusToId = newStatusId,
                    Date = DateTime.Now,
                    SelectionId = selectionId
                };

                ctx.StatusChanges.AddObject(change);
            }

            ctx.SavedChangesEventEnabled = false;
            ctx.SaveChanges();
            ctx.SavedChangesEventEnabled = true;
        }
    }

}