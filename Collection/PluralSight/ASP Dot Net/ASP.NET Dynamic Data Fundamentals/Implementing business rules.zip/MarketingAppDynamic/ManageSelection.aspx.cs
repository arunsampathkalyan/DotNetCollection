﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;
using System.Web.DynamicData;

public partial class ManageSelection : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        fvContact.ChangeMode(FormViewMode.Edit);
        fvSelection.ChangeMode(FormViewMode.Edit);
        SetButtonVisibility(false);
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        fvContact.UpdateItem(true);
        fvSelection.UpdateItem(true);
        SetButtonVisibility(true);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        fvContact.ChangeMode(FormViewMode.ReadOnly);
        fvSelection.ChangeMode(FormViewMode.ReadOnly);
        SetButtonVisibility(true);
    }

    void SetButtonVisibility(bool b)
    {
        btnEdit.Visible = b;
        btnUpdate.Visible = !b;
        btnCancel.Visible = !b;
    }

    //added offline - enables update of ExtContact instances
    //When Selection instance is retrieved in EDS1, store related Contact instance,
    //set EDS2's filter to ExtContact if need be, and bind fvContact form
    protected void EDSSelection_Selected(object sender, EntityDataSourceSelectedEventArgs e)
    {
        Selection sel = e.Results.OfType<Selection>().FirstOrDefault();
        Contact contact = sel.Contact;
        ViewState["contact"] = contact;

        SetEDSValues(contact);

        fvContact.DataSourceID = "EDSContact";
        HyperLink1.NavigateUrl = "ViewSelections.aspx?Id=" + sel.CampaignId;
    }

    //added offline - enables update of ExtContact instances
    //set correct filter for EDS2 based on exact type of the contact attached to
    //the selection instance retrieved in EDS1
    private void SetEDSValues(Contact contact)
    {
        if (contact is ExtContact)
        {
            EDSContact.EntityTypeFilter = "ExtContact";
        }
        else
        {
            EDSContact.EntityTypeFilter = "Contact";
        }

        EDSContact.Where = "it.Id = " + contact.Id.ToString();
    }

    //added offline - enables update of ExtContact instances
    //When switching to Edit mode, retrieve contact instance from ViewState
    protected void EDSContact_Load(object sender, EventArgs e)
    {
        Contact cont = ViewState["contact"] as Contact;
        if (cont != null)
            SetEDSValues(cont);
    }

    //added offline - enables update of ExtContact instances
    //when updating, if ExtContact set Customer and ExpDate (can't have 
    //dynamiccontrols for these 2 ExtContact fields in fvContact
    protected void EDSContact_Updating(object sender, EntityDataSourceChangingEventArgs e)
    {
        ExtContact contact = ViewState["contact"] as ExtContact;
        ExtContact updContact = e.Entity as ExtContact;

        if (contact != null)
        {
            if (updContact != null)
            {
                ((ExtContact)e.Entity).Customer = contact.Customer;
                ((ExtContact)e.Entity).ExpDate = contact.ExpDate;
            }
        }
    }


}