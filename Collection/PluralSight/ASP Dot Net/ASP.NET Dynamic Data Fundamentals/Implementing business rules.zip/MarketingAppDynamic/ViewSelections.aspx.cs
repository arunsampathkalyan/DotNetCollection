﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;

public partial class ViewSelections : System.Web.UI.Page
{
    //added offline after Module5
    string campaignId;

    //added offline after Module5
    protected void Page_Load(object sender, EventArgs e)
    {
        campaignId = Request.QueryString["Id"];
        if (String.IsNullOrEmpty(campaignId))
            Response.Redirect("ListCampaigns.aspx");
    }

    //added offline after Module5
    protected string GetCampaignName()
    {
        using (MarketingContainer ctx = new MarketingContainer())
        {
            return ctx.Campaigns.Where(c => c.Id == campaignId)
                                .Select(c => c.Name)
                                .Single();

        }
    }

    protected void btnRemove_Click(object sender, EventArgs e)
    {
        var selectionIds = gvSelections.Rows.Cast<GridViewRow>()
            .Select(r => new
                        {
                            id = (int)gvSelections.DataKeys[r.RowIndex][0],
                            cb = (CheckBox)r.Cells[0].FindControl("chkRemove")

                        })
            .Where(a => a.cb.Checked)
            .Select(a => a.id)
            .ToList();

        RemoveSelections(selectionIds);
        gvSelections.DataBind();
    }

    private void RemoveSelections(List<int> selectionIds)
    {
        using (MarketingContainer ctx = new MarketingContainer())
        {
            var selectionDel = ctx.Selections.Where(s => selectionIds.Contains(s.Id));

            foreach (Selection sel in selectionDel)
                ctx.Selections.DeleteObject(sel);

            ctx.SaveChanges();
        }
    }
    protected void chkAll_CheckedChanged(object sender, EventArgs e)
    {
        CheckBox cb = sender as CheckBox;

        foreach (GridViewRow row in gvSelections.Rows)
        {
            CheckBox cb2 = (CheckBox)row.Cells[0].FindControl("chkRemove");
            if (cb2 != null) cb2.Checked = cb.Checked;
        }

    }
}