﻿using System;
using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using System.Web.DynamicData;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;
using System.Drawing;

public partial class PositionTypeField : System.Web.DynamicData.FieldTemplateUserControl {
    private bool _allowNavigation = true;

    public string NavigateUrl { 
        get;
        set;
    }

    public bool AllowNavigation {
        get {
            return _allowNavigation;
        }
        set {
            _allowNavigation = value;
        }
    }

    protected override void OnDataBinding(EventArgs e)
    {
        base.OnDataBinding(e);

        PositionType postype = (PositionType)FieldValue;
        switch (postype.Priority)
        {
            case 1:
                HyperLink1.ForeColor = Color.Red;
                HyperLink1.Font.Bold = true;
                break;
            case 2:
                HyperLink1.ForeColor = Color.Green;
                break;
        }
    }

    protected string GetDisplayString() {
        object value = FieldValue;
        
        if (value == null) {
            return FormatFieldValue(ForeignKeyColumn.GetForeignKeyString(Row));
        } else {
            return FormatFieldValue(ForeignKeyColumn.ParentTable.GetDisplayString(value));
        }
    }

    protected string GetNavigateUrl() {
        if (!AllowNavigation) {
            return null;
        }
        
        if (String.IsNullOrEmpty(NavigateUrl)) {
            return ForeignKeyPath;
        }
        else {
            return BuildForeignKeyPath(NavigateUrl);
        }
    }

    public override Control DataControl {
        get {
            return HyperLink1;
        }
    }

}
