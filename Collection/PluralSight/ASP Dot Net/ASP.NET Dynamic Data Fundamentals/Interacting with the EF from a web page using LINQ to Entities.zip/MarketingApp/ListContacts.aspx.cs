﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;

public partial class GetContacts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(IsPostBack)
        using (MarketingContainer ctx = new MarketingContainer())
        {
            var query = ctx.Contacts
                        .OrderBy(c => c.Lname)
                        .Select(c =>
                            new
                            {
                                c.Fname,
                                c.Lname,
                                Compname = c.Company.Name,
                                c.Email
                            });

            if (tbFname.Text.Length > 0 || tbLname.Text.Length > 0 || tbCompany.Text.Length > 0)
            {
                //use composition
                query = query.Where(c => c.Fname == tbFname.Text
                            || c.Lname == tbLname.Text
                            || c.Compname == tbCompany.Text);
            }

            gvContacts.DataSource = query;
            gvContacts.DataBind();

        }

    }


}