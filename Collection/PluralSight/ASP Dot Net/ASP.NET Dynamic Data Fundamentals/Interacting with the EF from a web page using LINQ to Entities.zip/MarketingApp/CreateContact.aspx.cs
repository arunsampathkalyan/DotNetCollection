﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;

public partial class CreateContact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        using (MarketingContainer ctx = new MarketingContainer())
        {
            var companies = ctx.Companies.OrderBy(c => c.Name);
            var countries = ctx.Countries.OrderBy(c => c.Name);
            var positiontypes = ctx.PositionTypes.OrderBy(p => p.Name);

            DropDownList[] ddls = { ddlCompany, ddlCountry, ddlPositionType };
            IQueryable<object>[] queries = {companies, countries, positiontypes };

            for(int i=0; i<3; i++)
            {
                ddls[i].DataSource = queries[i];
                ddls[i].DataValueField = "ID";
                ddls[i].DataTextField = "Name";
                ddls[i].DataBind();
            }
        }
    }


    protected void btnCreate_Click(object sender, EventArgs e)
    {
        Contact newContact = new Contact()
        {
            Fname = tbFname.Text,
            Lname = tbLname.Text,
            Email = tbEmail.Text,
            WorkPhone = tbPhone.Text,
            EmailValid = cbEmailValid.Checked,
            //CompanyId = int.Parse(ddlCompany.SelectedValue),
            CountryId = int.Parse(ddlCountry.SelectedValue),
            //PositionTypeId = int.Parse(ddlPositionType.SelectedValue),
            LastUpdate = DateTime.Now
        };


        if (tbNewCompany.Text.Length == 0)
            newContact.CompanyId = int.Parse(ddlCompany.SelectedValue);
        else
            newContact.Company = new Company { Name = tbNewCompany.Text };

        if (tbNewPostype.Text.Length == 0)
            newContact.PositionTypeId = int.Parse(ddlPositionType.SelectedValue);
        else
            newContact.PositionType = new PositionType { Name = tbNewPostype.Text };


        using (MarketingContainer ctx = new MarketingContainer())
        {
            ctx.Contacts.AddObject(newContact);
            ctx.SaveChanges();
        }

        lblMessage.Text = "Contact created successfully!";

    }
}