﻿
namespace MarketingAppWithDS
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Linq;
    using System.ServiceModel.DomainServices.EntityFramework;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;


    // Implements application logic using the MarketingContainer context.
    // TODO: Add your application logic to these methods or in additional methods.
    // TODO: Wire up authentication (Windows/ASP.NET Forms) and uncomment the following to disable anonymous access
    // Also consider adding roles to restrict access as appropriate.
    // [RequiresAuthentication]
    [EnableClientAccess()]
    public class MarketingDomainService : LinqToEntitiesDomainService<MarketingContainer>
    {

        // TODO: Consider
        // 1. Adding parameters to this method and constraining returned results, and/or
        // 2. Adding query methods taking different parameters.
        public IQueryable<Contact> GetContacts()
        {
            return this.ObjectContext.Contacts.OrderBy(c => c.Id);
        }

        public Contact GetContactBySelectionId(int selectionId)
        {
            return ObjectContext.Selections.Include("Contact.Company")
                                .Include("Contact.PositionType")
                                .Include("Contact.Country")
                                .SingleOrDefault(s => s.Id == selectionId)
                                .Contact;
        }

        public IQueryable<Company> GetCompanies()
        {
            return ObjectContext.Companies;
        }

        public IQueryable<Country> GetCountries()
        {
            return ObjectContext.Countries;
        }

        public IQueryable<PositionType> GetPositionTypes()
        {
            return ObjectContext.PositionTypes;
        }

        public IQueryable<CallingStatus> GetCallingStatuses()
        {
            return ObjectContext.CallingStatuses;
        }

        


        public void InsertContact(Contact contact)
        {
            if ((contact.EntityState != EntityState.Detached))
            {
                this.ObjectContext.ObjectStateManager.ChangeObjectState(contact, EntityState.Added);
            }
            else
            {
                this.ObjectContext.Contacts.AddObject(contact);
            }
        }

        public void UpdateContact(Contact currentContact)
        {
            this.ObjectContext.Contacts.AttachAsModified(currentContact, this.ChangeSet.GetOriginal(currentContact));
        }

        public void DeleteContact(Contact contact)
        {
            if ((contact.EntityState == EntityState.Detached))
            {
                this.ObjectContext.Contacts.Attach(contact);
            }
            this.ObjectContext.Contacts.DeleteObject(contact);
        }

        // TODO: Consider
        // 1. Adding parameters to this method and constraining returned results, and/or
        // 2. Adding query methods taking different parameters.
        public IQueryable<Selection> GetSelections()
        {
            return this.ObjectContext.Selections.OrderBy(c => c.Id);
        }

        public Selection GetSelectionById(int selectionId)
        {
            return ObjectContext.Selections.Include("CallingStatus").SingleOrDefault(s => s.Id == selectionId);
        }

        public void InsertSelection(Selection selection)
        {
            if ((selection.EntityState != EntityState.Detached))
            {
                this.ObjectContext.ObjectStateManager.ChangeObjectState(selection, EntityState.Added);
            }
            else
            {
                this.ObjectContext.Selections.AddObject(selection);
            }
        }

        public void UpdateSelection(Selection currentSelection)
        {
            //handle PENDINGNEXT
            if (currentSelection.CallingStatusId == (byte)CallingStatus.CallStatusEnum.PENDINGNEXT)
            {
                currentSelection.CallingStatusId = (byte)CallingStatus.CallStatusEnum.PENDING;
                currentSelection.PendingLevel++;
            }

            //validate status change is legal
            Selection original = ChangeSet.GetOriginal(currentSelection);
            byte oldStatusId = original.CallingStatusId;
            byte proposedStatusId = currentSelection.CallingStatusId;

            if (proposedStatusId != oldStatusId)
            {
                if (!IsLegalChange(oldStatusId, proposedStatusId))
                {
                    string message = string.Format(
                        "Illegal status change : cannot change from {0} to {1}",
                        Enum.GetName(typeof(CallingStatus.CallStatusEnum), oldStatusId),
                        Enum.GetName(typeof(CallingStatus.CallStatusEnum), proposedStatusId));
                    throw new ValidationException(message);
                }
            }

            this.ObjectContext.Selections.AttachAsModified(currentSelection, this.ChangeSet.GetOriginal(currentSelection));
            ObjectContext.SaveChanges();

            //log change, recalc overall company status
            if (proposedStatusId != oldStatusId)
            {
                ComputeCompanyCallingStatus(currentSelection.ContactId, currentSelection.CampaignId);
                LogStatusChange(currentSelection.Id, currentSelection.CallingStatusId, original.CallingStatusId);
            }

        }

        private void LogStatusChange(int selectionId, byte newStatusId, byte oldStatusId)
        {
            StatusChange change = new StatusChange
            {
                StatusFromId = oldStatusId,
                StatusToId = newStatusId,
                Date = DateTime.Now,
                SelectionId = selectionId
            };

            ObjectContext.StatusChanges.AddObject(change);
        }

        private void ComputeCompanyCallingStatus(int contactId, string campaignId)
        {
            int companyId = ObjectContext.Contacts.Single(c => c.Id == contactId).Company.Id;

            var statuses = ObjectContext.Selections.Where(s => s.CampaignId == campaignId
                                            && s.Contact.Company.Id == companyId)
                                        .Select(s => s.CallingStatus);

            CallingStatus companyStatus = statuses.FirstOrDefault(
                s => s.Rank == statuses.Max(s2 => s2.Rank));

            CompanyCampaign compCamp = ObjectContext.CompanyCampaigns.SingleOrDefault(
                cc => cc.CampaignId == campaignId && cc.CompanyId == companyId);

            if (compCamp == null)
            {
                ObjectContext.CompanyCampaigns.AddObject(new CompanyCampaign
                {
                    CampaignId = campaignId,
                    CompanyId = companyId,
                    CallingStatus = companyStatus
                });
            }
            else
                compCamp.CallingStatus = companyStatus;
        }

        private bool IsLegalChange(byte oldStatusId, byte proposedStatusId)
        {
            return ObjectContext.StatusRules.Count(r => r.StatusFromId == oldStatusId &&
                                                r.StatusToId == proposedStatusId) > 0;
        }

        public void DeleteSelection(Selection selection)
        {
            if ((selection.EntityState == EntityState.Detached))
            {
                this.ObjectContext.Selections.Attach(selection);
            }
            this.ObjectContext.Selections.DeleteObject(selection);
        }

        public object campaignId { get; set; }
    }
}


