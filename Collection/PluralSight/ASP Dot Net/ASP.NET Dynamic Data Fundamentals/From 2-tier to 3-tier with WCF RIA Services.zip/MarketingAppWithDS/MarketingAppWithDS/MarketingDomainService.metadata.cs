﻿
namespace MarketingAppWithDS
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data.Objects.DataClasses;
    using System.Linq;
    using System.ServiceModel.DomainServices.Hosting;
    using System.ServiceModel.DomainServices.Server;


    public partial class CallingStatus
    {
        public enum CallStatusEnum : byte
        {
            NOTCALLED = 0,
            PENDING = 1,
            INCONTACT = 2,
            NOPOTENTL = 3,
            NOTAPPROP = 4,
            FOLLOWUP = 5,
            SUSPECT = 6,
            MEETING = 7,
            PENDINGNEXT = 8
        }

    }

    // The MetadataTypeAttribute identifies ContactMetadata as the class
    // that carries additional metadata for the Contact class.
    [MetadataTypeAttribute(typeof(Contact.ContactMetadata))]
    public partial class Contact
    {
        public override string ToString()
        {
            return Fname + " " + Lname + (Company != null ? " - " + Company.Name : "");
        }

        // This class allows you to attach custom attributes to properties
        // of the Contact class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class ContactMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private ContactMetadata()
            {
            }

            public string Comments { get; set; }

            public Company Company { get; set; }

            public int CompanyId { get; set; }

            public Country Country { get; set; }

            public int CountryId { get; set; }

            public string Email { get; set; }

            public bool EmailValid { get; set; }

            public string Fname { get; set; }

            public int Id { get; set; }

            public DateTime LastUpdate { get; set; }

            public string Lname { get; set; }

            public PositionType PositionType { get; set; }

            public int PositionTypeId { get; set; }

            public EntityCollection<Selection> Selections { get; set; }

            public bool Unsubscribed { get; set; }

            public string WorkPhone { get; set; }
        }
    }

    // The MetadataTypeAttribute identifies SelectionMetadata as the class
    // that carries additional metadata for the Selection class.
    [MetadataTypeAttribute(typeof(Selection.SelectionMetadata))]
    public partial class Selection
    {

        // This class allows you to attach custom attributes to properties
        // of the Selection class.
        //
        // For example, the following marks the Xyz property as a
        // required property and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz { get; set; }
        internal sealed class SelectionMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private SelectionMetadata()
            {
            }

            public CallingStatus CallingStatus { get; set; }

            public byte CallingStatusId { get; set; }

            public Campaign Campaign { get; set; }

            public string CampaignId { get; set; }

            public Contact Contact { get; set; }

            public int ContactId { get; set; }

            public Nullable<bool> EmailOpened { get; set; }

            public int Id { get; set; }

            public bool Optout { get; set; }

            public byte PendingLevel { get; set; }

            public EntityCollection<StatusChange> StatusChanges { get; set; }
        }
    }
}
