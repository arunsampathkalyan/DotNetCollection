﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.DynamicData;

namespace MarketingAppWithDS
{
    public partial class ManageSelection : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Page_Init(object sender, EventArgs e)
        {
            fvContact.SetMetaTable(Global.DefaultModel.GetTable("Contact"));
            fvSelection.SetMetaTable(Global.DefaultModel.GetTable("Selection"));
        }

        protected void ddlCampaigns_SelectedIndexChanged(object sender, EventArgs e)
        {
            ddlSelections.DataSourceID = "EDSSelections";
            ddlSelections.DataValueField = "Id";
            ddlSelections.DataTextField = "Contact";
            ddlSelections.DataBind();

        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            fvContact.ChangeMode(FormViewMode.Edit);
            fvSelection.ChangeMode(FormViewMode.Edit);
            SetButtonVisibility(false);
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            fvContact.UpdateItem(true);
            fvSelection.UpdateItem(true);
            SetButtonVisibility(true);
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            fvContact.ChangeMode(FormViewMode.ReadOnly);
            fvSelection.ChangeMode(FormViewMode.ReadOnly);
            SetButtonVisibility(true);
        }

        void SetButtonVisibility(bool b)
        {
            btnEdit.Visible = b;
            btnUpdate.Visible = !b;
            btnCancel.Visible = !b;
        }

        protected void btnGo_Click(object sender, EventArgs e)
        {
            fvContact.DataSourceID = "ContactDDS";
            fvSelection.DataSourceID = "SelectionDDS";
            SetButtonVisibility(true);
        }

        //added offline
        protected void ContactDS_SetLastUpdate(object sender, Microsoft.Web.UI.WebControls.DomainDataSourceOperationEventArgs e)
        {
            Contact contact = (Contact)e.ChangeSetEntry.Entity;
            if (contact != null)
                contact.LastUpdate = DateTime.Now;
        }


    }
}