﻿using System;
using System.Collections.Specialized;
using System.ComponentModel.DataAnnotations;
using System.Web.DynamicData;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BooleanField : System.Web.DynamicData.FieldTemplateUserControl {
    protected override void OnDataBinding(EventArgs e) {
        base.OnDataBinding(e);

        object val = FieldValue;
        if (null == FieldValue)
            Image1.ImageUrl = "~/Images/empty.gif";
        else
        {
            bool b = (bool)FieldValue;
            Image1.ImageUrl = (b ? "~/Images/check.jpg" : "~/Images/empty.gif");
        }
    }

    public override Control DataControl {
        get {
            return Image1;
        }
    }

}
