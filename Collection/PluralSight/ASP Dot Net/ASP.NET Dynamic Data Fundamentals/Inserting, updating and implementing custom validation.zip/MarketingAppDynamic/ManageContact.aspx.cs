﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Marketing;

public partial class ManageContact : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.AllKeys.Contains("contactId"))
            {
                fvContact.ChangeMode(FormViewMode.ReadOnly);
            }
            else
            {
                fvContact.ChangeMode(FormViewMode.Insert);
            }
        }
    }

    protected void EDS1_SetLastUpdate(object sender, EntityDataSourceChangingEventArgs e)
    {
        Contact c= (Contact)e.Entity;
        if (c != null)
            c.LastUpdate = DateTime.Now;
    }

    protected void EDS1_Inserted(object sender, EntityDataSourceChangedEventArgs e)
    {
        string contactId = ((Contact)e.Entity).Id.ToString();
        Response.Redirect("ManageContact.aspx?contactId=" + contactId);
    }

}