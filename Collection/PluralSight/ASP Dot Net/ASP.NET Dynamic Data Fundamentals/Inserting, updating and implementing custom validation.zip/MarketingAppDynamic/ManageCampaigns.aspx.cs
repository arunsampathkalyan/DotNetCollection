﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ManageCampaigns : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void RebindGridView(object sender, EventArgs e)
    {
        gvCampaigns.DataBind();
    }


    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        dvCampaign.ChangeMode(DetailsViewMode.Insert);
    }

    protected void gvCampaigns_SelectedIndexChanged(object sender, EventArgs e)
    {
        dvCampaign.ChangeMode(DetailsViewMode.Edit);
    }

}