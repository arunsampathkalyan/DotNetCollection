/// <reference name="MicrosoftAjax.js"/>

// HighlightTextBox.js
// Sample script file for ASP.NET Ajax Fundamentals, Pluralsight
//
// Register the namespace for the control.
Type.registerNamespace('PS');

//
// Define the control properties.
//
PS.HighlightTextBox = function(element) { 
    PS.HighlightTextBox.initializeBase(this, [element]);

    this._highlightClass = null;
    this._lowlightClass = null;
}

//
// Create the prototype for the control.
//

PS.HighlightTextBox.prototype = {


    initialize: function()
    {
        PS.HighlightTextBox.callBaseMethod(this, 'initialize');

        this._onfocusHandler = Function.createDelegate(this, this._onFocus);
        this._onblurHandler = Function.createDelegate(this, this._onBlur);

        $addHandlers(this.get_element(),
                     { 'focus': this._onFocus,
                         'blur': this._onBlur
                     },
                     this);

        this.get_element().className = this._lowlightClass;

        alert(PS.ResourceStrings.hi);
        alert(PS.ResourceStrings.bye);
    },

    dispose: function()
    {
        $clearHandlers(this.get_element());

        PS.HighlightTextBox.callBaseMethod(this, 'dispose');
    },

    //
    // Event delegates
    //

    _onFocus: function(e)
    {
        if (this.get_element() && !this.get_element().disabled)
        {
            this.get_element().className = this._highlightClass;
        }
    },

    _onBlur: function(e)
    {
        if (this.get_element() && !this.get_element().disabled)
        {
            this.get_element().className = this._lowlightClass;
        }
    },


    //
    // Control properties
    //

    get_highlightClass: function()
    {
        return this._highlightClass;
    },

    set_highlightClass: function(value)
    {
        if (this._highlightClass !== value)
        {
            this._highlightClass = value;
            this.raisePropertyChanged('highlightClass');
        }
    },

    get_lowlightClass: function()
    {
        return this._lowlightClass;
    },

    set_lowlightClass: function(value)
    {
        if (this._lowlightClass !== value)
        {
            this._lowlightClass = value;
            this.raisePropertyChanged('lowlightClass');
        }
    }
}

// Register the class as a type that inherits from Sys.UI.Control.
PS.HighlightTextBox.registerClass('PS.HighlightTextBox', Sys.UI.Control);

if (typeof(Sys) !== 'undefined') Sys.Application.notifyScriptLoaded();
