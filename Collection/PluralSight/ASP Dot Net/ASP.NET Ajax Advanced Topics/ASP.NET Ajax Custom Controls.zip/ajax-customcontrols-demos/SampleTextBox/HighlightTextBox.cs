﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Web;

namespace PS
{
  public class HighlightTextBox : TextBox, IScriptControl
  {
    public string HighlightClass
    {
      get { return (string)(ViewState["hlc"] ?? ""); }
      set { ViewState["hlc"] = value; }
    }

    public string LowlightClass
    {
      get { return (string)(ViewState["llc"] ?? ""); }
      set { ViewState["llc"] = value; }
    }


    #region IScriptControl Members

    public IEnumerable<ScriptDescriptor> GetScriptDescriptors()
    {
      ScriptControlDescriptor descriptor = new ScriptControlDescriptor("PS.HighlightTextBox", this.ClientID);
      descriptor.AddProperty("highlightClass", this.HighlightClass);
      descriptor.AddProperty("lowlightClass", this.LowlightClass);

      return new ScriptDescriptor[] { descriptor };
    }

    public IEnumerable<ScriptReference> GetScriptReferences()
    {
      //return new ScriptReference[] {
      //  new ScriptReference(ResolveClientUrl("~/scripts/HighlightTextBox.js"))
      //};
      return new ScriptReference[] {
        new ScriptReference("SampleTextBox.HighlightTextBox.js", 
          GetType().Assembly.FullName)
      };
    }

    #endregion

    protected override void OnPreRender(EventArgs e)
    {
      if (!this.DesignMode)
      {
        // Test for ScriptManager and register if it exists
        if (ScriptManager.GetCurrent(Page) == null)
          throw new HttpException("A ScriptManager control must exist on the current page.");

        ScriptManager.GetCurrent(Page).RegisterScriptControl(this);
      }

      base.OnPreRender(e);
    }

    protected override void Render(HtmlTextWriter writer)
    {
      if (!this.DesignMode)
        ScriptManager.GetCurrent(Page).RegisterScriptDescriptors(this);

      base.Render(writer);
    }
  }
}
