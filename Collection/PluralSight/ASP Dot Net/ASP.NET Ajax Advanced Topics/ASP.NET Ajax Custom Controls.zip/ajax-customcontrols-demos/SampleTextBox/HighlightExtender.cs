﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PS
{
  [TargetControlType(typeof(Control))]
  public class HighlightBehavior : ExtenderControl
  {
    public string HighlightClass
    {
      get { return (string)(ViewState["hlc"] ?? ""); }
      set { ViewState["hlc"] = value; }
    }

    public string LowlightClass
    {
      get { return (string)(ViewState["llc"] ?? ""); }
      set { ViewState["llc"] = value; }
    }

    protected override IEnumerable<ScriptReference> GetScriptReferences()
    {
      ScriptReference reference = new ScriptReference("SampleTextBox.HighlightBehavior.js", GetType().Assembly.FullName);

      return new ScriptReference[] { reference };
    }

    protected override IEnumerable<ScriptDescriptor> GetScriptDescriptors(Control targetControl)
    {
      ScriptControlDescriptor descriptor = new ScriptControlDescriptor("PS.HighlightBehavior", targetControl.ClientID);
      descriptor.AddProperty("highlightClass", this.HighlightClass);
      descriptor.AddProperty("lowlightClass", this.LowlightClass);

      return new ScriptDescriptor[] { descriptor };
    }
  }
}
