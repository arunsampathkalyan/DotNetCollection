﻿function setHighlightClass(id, cls)
{
    var txt = document.getElementById(id);
    txt.className = cls;
}