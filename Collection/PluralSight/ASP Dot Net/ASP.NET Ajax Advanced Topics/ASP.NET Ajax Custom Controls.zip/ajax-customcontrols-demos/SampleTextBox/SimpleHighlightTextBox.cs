﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PS
{
  public class SimpleHighlightTextBox : TextBox
  {
//    const string _script = @"
//      function setHighlightClass(id, cls)
//      {
//        var txt = document.getElementById(id);
//        txt.className = cls;
//      }
//  ";

    protected override void OnInit(EventArgs e)
    {
      //Page.ClientScript.RegisterClientScriptBlock(GetType(),
      //        "shlClass", _script, true);
      Page.ClientScript.RegisterClientScriptResource(GetType(), "SampleTextBox.SimpleHighlightTextBox.js");

      this.Attributes["onfocus"] = 
        string.Format("setHighlightClass('{0}', '{1}')", 
                      this.ClientID, HighlightClass);
      this.Attributes["onblur"] = string.Format("setHighlightClass('{0}', '{1}')", this.ClientID, LowlightClass);

      this.Attributes["class"] = LowlightClass;

      base.OnInit(e);
    }

    public string HighlightClass
    {
      get { return (string)(ViewState["hlc"] ?? ""); }
      set { ViewState["hlc"] = value; }
    }

    public string LowlightClass
    {
      get { return (string)(ViewState["llc"] ?? ""); }
      set { ViewState["llc"] = value; }
    }

  }
}
