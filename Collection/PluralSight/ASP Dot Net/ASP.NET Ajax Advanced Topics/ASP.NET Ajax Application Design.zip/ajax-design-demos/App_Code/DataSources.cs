﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Pluralsight
{
    public static class DataSources
    {
        private static Thread _monitorThread = null;
        private static double _widgetCount = Math.Floor(DateTime.Now.TimeOfDay.TotalSeconds);
        private static string _airportsFileName = ""; 
        private volatile static bool _terminateMonitorThread = false;

        static DataSources()
        {
            // Spawn background thread to track widgets
            _monitorThread = new Thread(UpdateWidgetCount);
            _monitorThread.IsBackground = true;

            _monitorThread.Start();
        }

        static void UpdateWidgetCount()
        {
            Random r = new Random();
            while (!_terminateMonitorThread)
            {
                _widgetCount += r.Next(1000);
                Thread.Sleep(200);
            }
        }

        // Method to terminate background monitor thread (called in Application_End of global.asax)
        public static void TerminateMonitorThread()
        {
            _terminateMonitorThread = true;
        }

        public static double GetWidgetsSoldToday()
        {
            return _widgetCount;
        }

        public static Widget[] GetTruncatedListOfWidgetsSoldToday()
        {
            Random r = new Random();

            var result = new List<Widget>();
            int max = (int)_widgetCount;
            max = (max > 10000) ? 10000 : max;
            for (int i = 0; i < max; i++)
                result.Add(new Widget("Widget #" + i.ToString(), (float)r.NextDouble() * 500, i));
            return result.ToArray();
        }

        public static string GetWidgetReports()
        {
            System.Threading.Thread.Sleep(3000);
            return "Widgets sold today (" + DateTime.Now.ToShortDateString() + "): " + DataSources.GetWidgetsSoldToday().ToString() + "<br /><br />The forecast for new Widget sales over the next quarter looks very positive - sales are expected to double each month for the next six months, so if you've been putting off that large purchase, go for it today!<br /><br /><br /><br /><font size='1'>The hearing for our chief financial officer, Liven Good, is scheduled for next month - please wish him luck!</font>";
        }

        public static string GetCompanyNews()
        {
            return "Widgets are flying off the shelves! We're going to give everyone an extra bonus at Thanksgiving this year in addition to the Christmas bonus for doing such great work!";
        }

        public static string GetHRInfo()
        {
            System.Threading.Thread.Sleep(2000);
            return "Please welcome Eileen Tudor-Wright to the accounting department - she's a fiscal conservative that should really help get things on track!<br /><br />Also welcome Lou Gubrious to the HR department, he's got a great track record of hiring amazing people!<br /><br />Finally, a big welcome to Eaton Wright as our new in-house chef - we'll have a new menu posted with chef Wright's inspiring dishes later today!";
        }

        public static string GetSalesLeaders()
        {
            System.Threading.Thread.Sleep(1500);
            return "Lou Scannon <b>45%</b><br />Neil Down <b>33%</b><br />Laura Biden <b>25%</b><br />Sam Boney <b>22%</b><br />Hugh Lyon Sack <b>21%</b><br />Amanda B. Reckondwyth <b>12%</b><br />";
        }

        public static string AirportsFileName
        {
            get { return _airportsFileName;  }
            set { _airportsFileName = value; }
        }
    }
}