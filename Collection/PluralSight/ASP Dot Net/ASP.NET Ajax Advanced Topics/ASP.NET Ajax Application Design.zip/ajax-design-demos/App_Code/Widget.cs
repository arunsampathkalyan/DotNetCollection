﻿using System.Runtime.Serialization;

namespace Pluralsight
{
    [DataContract]
    public class Widget
    {
        public Widget() { }
        public Widget(string name, float price, int partNumber)
        {
            Name = name;
            Price = price;
            PartNumber = partNumber;
        }
        
        [DataMember]
        public string Name        { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public float Price        { get; set; }
        [DataMember]
        public int PartNumber     { get; set; }
        [DataMember]
        public int PartCategory   { get; set; }
    }
}