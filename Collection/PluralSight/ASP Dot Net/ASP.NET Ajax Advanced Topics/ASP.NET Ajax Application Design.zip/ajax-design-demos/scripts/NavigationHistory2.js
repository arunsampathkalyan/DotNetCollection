﻿Sys.Application.add_navigate(onNavigate); // Register onNavigate handler

//
// This event is raised when addHistoryPoint is called, and when the user
// hits the back or forward button:
//
function onNavigate(sender, args)
{
    var name = args.get_state().name;

    if (name === undefined)  // we went back to the beginning, reset state:
    {
        $get("txtInstructorName").value = "";
        $get("rfvInstructorName").style.visibility = 'hidden';
        $get("divInfo").innerHTML = "";
    }
    else  // restore text field and retrieve data for that instructor:
    {
        $get("txtInstructorName").value = name;
        RequestInfo(name);
    }
}

// 
// User has clicked find button to lookup instructor:
//
function OnFindClick()
{
    var name;
    name = $get("txtInstructorName").value;

    //
    // Set history point - note this will call onNavigate, so just
    // let our onNavigate handler do the work of retrieving the data
    // in all cases.
    //
    Sys.Application.addHistoryPoint( /*object state*/{"name": name });


    return false;  // so that server-side handler doesn't run  
}

//
// Make async request to lookup instructor's name:
//
function RequestInfo(name)
{
    var wRequest = new Sys.Net.WebRequest();

    wRequest.set_url("services/getInstructorInfo.ashx?instructor=" + name);
    wRequest.set_httpVerb("Get");
    wRequest.set_timeout(5000);  // 5 secs

    wRequest.add_completed(OnCallCompleted);
    wRequest.invoke();
}

//
// Async lookup has returned, update UI:
//
function OnCallCompleted(executor, eventArgs)
{
    if (executor.get_responseAvailable())  // success!
    {
        $get("divInfo").innerHTML = executor.get_responseData();
    }
    else  // call to server failed:
    {
        var reason;
        if (executor.get_timedOut())
            reason = "timed-out";
        else if (executor.get_aborted())
            reason = "aborted";
        else
            reason = "unknown";

        var s = "<p align='center'>Info not available (" + reason + ")</p><br /><br />";
        $get("divInfo").innerHTML = s;
    }
}
		