﻿/// <reference name="MicrosoftAjax.js" />
// Employees.js


Type.registerNamespace("PS");

// IPerson interface definition
PS.IPerson = function() {}
PS.IPerson.prototype = {
 get_name : function() { throw Error.notImplemented(); },
 set_name : function() { throw Error.notImplemented(); }
}
PS.IPerson.registerInterface("PS.IPerson");

// Employee class definition
//

PS.Employee = function(name, salary) {
    this.name = name;       
    this.salary = salary;   
}

PS.Employee.prototype =
{
    get_salary    : function()      { return this.salary;  },
    set_salary    : function(value) { this.salary = value; },
    get_name      : function()      { return this.name;    },
    set_name      : function(value) { this.name = value;   },   
    issuePaycheck : function()      {
        var monthly = this.get_salary() / 12;
        return this.name + ": " + monthly;
    }
}

PS.Employee.registerClass("PS.Employee", null, PS.IPerson);

// TechEmployee class definition
//
PS.TechEmployee = function(name, salary, area)
{
    PS.TechEmployee.initializeBase(this, [name, salary]);
    this.area = area;
}

PS.TechEmployee.prototype =
{
    get_area: function() { return this.area; },
    get_salary: function() { return PS.TechEmployee.callBaseMethod(this, "get_salary") + 1000; },
    writeCode: function() { /* code gen! */ }
}

PS.TechEmployee.registerClass("PS.TechEmployee", PS.Employee);

var emp = new PS.TechEmployee("Alice", 100000, ".NET");
var emp2 = new PS.Employee("Bob", 99999);

document.write("<br />");
document.write("emp.get_salary() = " + emp.get_salary());
document.write("<br />");
document.write("emp.issuePaycheck() = " + emp.issuePaycheck());

function GetPersonInfo(emp)
{
    var ret = new Sys.StringBuilder();

    if (PS.IPerson.isImplementedBy(emp))
        ret.append("Name : " + emp.get_name() + "<br />");

    if (PS.TechEmployee.isInstanceOfType(emp))
        ret.append("Tech employee<br />");

    if (PS.Employee.isInstanceOfType(emp))
        ret.append("Employee<br />");

    return ret.toString();
}

document.write("<hr />");
document.write(GetPersonInfo(emp));
document.write("<hr />");
document.write(GetPersonInfo(emp2));

if (typeof(Sys) !== 'undefined') // notify ScriptManager
  Sys.Application.notifyScriptLoaded();
  
