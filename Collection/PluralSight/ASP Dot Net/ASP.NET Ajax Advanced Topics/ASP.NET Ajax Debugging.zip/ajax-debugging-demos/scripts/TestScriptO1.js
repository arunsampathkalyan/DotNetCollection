﻿function MoveElement(elementRef)
{
    // Get the location of the element
    var elementLoc = Sys.UI.DomElement.getLocation(elementRef);
    alert('Before move - location (x,y) = (' + 
               elementLoc.x + ',' + elementLoc.y + ')');
    // Move the element
    Sys.UI.DomElement.setLocation(elementRef, elementLoc.x+100, elementLoc.y);
    elementLoc = Sys.UI.DomElement.getLocation(elementRef);
    alert('After move - location (x,y) = (' + 
               elementLoc.x + ',' + elementLoc.y + ')');
}
