﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

[ServiceContract(Namespace = "http://www.pluralsight.com/ws/")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class TestService
{
	[OperationContract]
  public string HelloWorld()
  {
    return "Hello World!";
  }

  [OperationContract]
  public int Add(int x, int y)
  {
    return x + y;
  }    
}
