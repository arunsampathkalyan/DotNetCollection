using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Text.RegularExpressions;

public partial class PostMessage : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        ((MyMasterPage)Master).SetTitles("Post Message", "Post a Message");
    }

    protected void btnPost_Click(object sender, EventArgs e) {
        string text = txtMessage.Text;
        string userName = User.Identity.IsAuthenticated ? User.Identity.Name : "Anonymous User";
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,
            string.Format(@"App_Data\{0}.txt", Guid.NewGuid().ToString()));

        using (StreamWriter w = File.CreateText(path)) {
            // format of post files is simple: first line is the user name, the rest is the message
            w.WriteLine(userName);
            w.Write(text);
        }
        // after posting a message, the user is taken to the message viewer so she can see her new message.
        Response.Redirect("~/ViewMessages.aspx");
    }
}
