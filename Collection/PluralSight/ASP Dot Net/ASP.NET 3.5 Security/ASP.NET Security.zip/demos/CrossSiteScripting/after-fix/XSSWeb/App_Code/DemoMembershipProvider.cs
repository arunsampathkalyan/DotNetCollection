using System;
using System.Xml;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration.Provider;
using System.Web.Security;
using System.Web.Hosting;
using System.Web.Management;
using System.Security.Permissions;
using System.Web;
using System.Text.RegularExpressions;

public class DemoMembershipProvider : MembershipProvider {
    public override bool ValidateUser(string username, string password) {
        // this is to simplify this lab so you don't need a database
        // NEVER hardcode secrets such as passwords in a real app!
        return ((username.Equals("alice", StringComparison.InvariantCultureIgnoreCase) ||
                 username.Equals("bob",   StringComparison.InvariantCultureIgnoreCase))
                 && "password" == password);
    }

    public override MembershipUser GetUser(string username, bool userIsOnline) {
        return new MembershipUser(
            base.Name,                  // Provider name
            username,                   // Username
            null,                       // providerUserKey
            string.Empty,               // Email
            String.Empty,               // passwordQuestion
            String.Empty,               // Comment
            true,                       // isApproved
            false,                      // isLockedOut
            DateTime.Now,               // creationDate
            DateTime.Now,               // lastLoginDate
            DateTime.Now,               // lastActivityDate
            DateTime.Now,               // lastPasswordChangedDate
            new DateTime(1980, 1, 1)    // lastLockoutDate
        );
    }

    #region All the stuff we don't support goes in this bucket
    public override string ApplicationName {
        get { throw new NotSupportedException(); }
        set { throw new NotSupportedException(); }
    }

    public override bool EnablePasswordRetrieval {
        get { return false; }
    }

    public override bool EnablePasswordReset {
        get { return false; }
    }

    public override int MaxInvalidPasswordAttempts {
        get { throw new NotSupportedException(); }
    }

    public override int MinRequiredNonAlphanumericCharacters {
        get { throw new NotSupportedException(); }
    }

    public override int MinRequiredPasswordLength {
        get { throw new NotSupportedException(); }
    }

    public override int PasswordAttemptWindow {
        get { throw new NotSupportedException(); }
    }

    public override MembershipPasswordFormat PasswordFormat {
        get { throw new NotSupportedException(); }
    }

    public override string PasswordStrengthRegularExpression {
        get { throw new NotSupportedException(); }
    }

    public override bool RequiresQuestionAndAnswer {
        get { throw new NotSupportedException(); }
    }

    public override bool RequiresUniqueEmail {
        get { throw new NotSupportedException(); }
    }

    public override MembershipUserCollection GetAllUsers(int pageIndex,
        int pageSize, out int totalRecords) {
        throw new NotSupportedException();
    }

    public override int GetNumberOfUsersOnline() {
        throw new NotSupportedException();
    }

    public override bool ChangePassword(string username,
        string oldPassword, string newPassword) {
        throw new NotSupportedException();
    }

    public override bool
        ChangePasswordQuestionAndAnswer(string username,
        string password, string newPasswordQuestion,
        string newPasswordAnswer) {
        throw new NotSupportedException();
    }

    public override MembershipUser CreateUser(string username,
        string password, string email, string passwordQuestion,
        string passwordAnswer, bool isApproved, object providerUserKey,
        out MembershipCreateStatus status) {
        throw new NotSupportedException();
    }

    public override bool DeleteUser(string username,
        bool deleteAllRelatedData) {
        throw new NotSupportedException();
    }

    public override MembershipUserCollection
        FindUsersByEmail(string emailToMatch, int pageIndex,
        int pageSize, out int totalRecords) {
        throw new NotSupportedException();
    }

    public override MembershipUserCollection
        FindUsersByName(string usernameToMatch, int pageIndex,
        int pageSize, out int totalRecords) {
        throw new NotSupportedException();
    }

    public override string GetPassword(string username, string answer) {
        throw new NotSupportedException();
    }

    public override MembershipUser GetUser(object providerUserKey,
        bool userIsOnline) {
        throw new NotSupportedException();
    }

    public override string GetUserNameByEmail(string email) {
        throw new NotSupportedException();
    }

    public override string ResetPassword(string username,
        string answer) {
        throw new NotSupportedException();
    }

    public override bool UnlockUser(string userName) {
        throw new NotSupportedException();
    }

    public override void UpdateUser(MembershipUser user) {
        throw new NotSupportedException();
    }

    #endregion
}