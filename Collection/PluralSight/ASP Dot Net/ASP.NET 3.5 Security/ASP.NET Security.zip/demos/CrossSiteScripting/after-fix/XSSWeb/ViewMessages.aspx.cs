using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;

public partial class ViewMessages : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ((MyMasterPage)Master).SetTitles("View Messages", "View Fabrikam Message Board");
        repeater.DataSource = readMessages();
        repeater.DataBind();
    }

    private ArrayList readMessages() {
        ArrayList messages = new ArrayList();
        foreach (string path in Directory.GetFiles(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "App_Data"), "*.txt")) {
            DateTime timeStamp = Directory.GetCreationTime(path);
            using (StreamReader r = File.OpenText(path)) {
                string user = r.ReadLine();
                string text = Server.HtmlEncode(r.ReadToEnd());
                messages.Add(new Message(user, timeStamp, text));
            }
        }
        messages.Sort();
        return messages;
    }
}

public class Message : IComparable {
    string user;
    DateTime timeStamp;
    string text;
    public Message(string user, DateTime timeStamp, string text) {
        this.user = user;
        this.timeStamp = timeStamp;
        this.text = text;
    }
    public string User { get { return user; } }
    public string Text { get { return text; } }
    public string TimeStamp { get { return timeStamp.ToString("MM-dd-yyyy"); } }
    public int CompareTo(object rhs) {
        // descending sort
        return -timeStamp.CompareTo(((Message)rhs).timeStamp);
    }
}