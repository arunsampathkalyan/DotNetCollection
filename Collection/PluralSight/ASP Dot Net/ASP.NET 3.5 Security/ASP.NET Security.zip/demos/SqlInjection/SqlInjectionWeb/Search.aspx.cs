using System;
using System.Web;
using System.Web.UI;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class Search : System.Web.UI.Page
{
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gridView.Visible = true;
        string searchString = txtSearch.Text;
        if (searchString.Length > 0)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            DataSet dataSet = new DataSet();

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = conn.CreateCommand())
            {
                // BAD - injects unfiltered user input into SQL statement
                cmd.CommandText = string.Format(
                    "select sku, description, price from Products " +
                    "where description like '%{0}%' order by price",
                    searchString);

                // MUCH BETTER - use parameterized query
                //cmd.CommandText =
                //    "select sku, description, price from Products " +
                //    "where description like @input order by price";
                //cmd.Parameters.AddWithValue("@input", '%' + searchString + '%');

                // execute command and fill DataSet
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dataSet);
            }
            // bind GridView to DataSet
            gridView.DataSource = dataSet;
            gridView.DataBind();
        }
    }
}
