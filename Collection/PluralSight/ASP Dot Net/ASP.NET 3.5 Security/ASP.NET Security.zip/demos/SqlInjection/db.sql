use master
go

if exists(select * from sys.databases where name='FabrikamSampleProductDatabase')
  drop database FabrikamSampleProductDatabase
go

create database FabrikamSampleProductDatabase
go

use FabrikamSampleProductDatabase
go

create table Products (
  sku           varchar(200),
  description   varchar(200),
  price         smallmoney,
)
go

create table Users (
  email      varchar(200),
  password   varchar(200),
  cc_type    varchar(200),
  cc_num     varchar(200),
  cc_exp     varchar(200),
  cc_vcode   varchar(200),
)
go

insert into Products values('V2K1004', 'Really sharp pencil', $0.75)
insert into Products values('V2K1005', 'Magic marker', $2.25)
insert into Products values('V2K1006', 'Pad of paper', $1.50)
insert into Products values('V2K1009', 'MP3 Player', $295.00)
insert into Products values('V2K1007', 'Box of 100 paper clips', $2.00)
insert into Products values('V2K1008', 'Box of tissues', $5.00)
go

-- note these credit card numbers are invalid according to http://www.merriampark.com/anatomycc.htm
insert into Users values('alice@fabrikam.com', 'password', 'visa', '4126 3335 2609 8990', '01/2010', '590')
insert into Users values('bob@fabrikam.com', 'P@ssw0rd', 'mastercard', '4126 3887 9012 8347', '06/2008', '222')
insert into Users values('jason@fabrikam.com', '0)8$tn!Bw@2j1', 'visa', '4126 2881 7791 0634', '02/2011', '458')
go

select table_name from FabrikamSampleProductDatabase.information_schema.tables