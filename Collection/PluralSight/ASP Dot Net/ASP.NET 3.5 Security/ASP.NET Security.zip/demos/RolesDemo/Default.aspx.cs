﻿using System;
using System.Web.UI;
using System.Web.Security;
using System.Security.Principal;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (User.Identity.IsAuthenticated)
        {
            lblUser.Text = User.Identity.Name;
            lblAuthnType.Text = User.Identity.AuthenticationType;

            lstRoles.DataSource = (string[])Context.Items["roles"];
            lstRoles.DataBind();

            pnlShowIfLoggedIn.Visible = true;
        }
        else lblUser.Text = "[Anonymous]";
    }

    protected void Logout_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Response.Redirect(Request.Path);
    }
}
