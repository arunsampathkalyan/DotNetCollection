﻿using System;
using System.Web;
using System.Security.Principal;
using System.Xml.XPath;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Collections.Generic;

public partial class MyApplication : HttpApplication
{
    public override void Init()
    {
        base.Init();

        AuthenticateRequest += new EventHandler(Global_AuthenticateRequest);
    }

    void Global_AuthenticateRequest(object sender, EventArgs e)
    {
        if (Request.IsAuthenticated)
            SetupRoles();
    }

    void SetupRoles()
    {
        IIdentity formsIdentity = Context.User.Identity;

        string[] roles = LookupRolesFor(formsIdentity.Name);

        IPrincipal principalWithRoles =
            new GenericPrincipal(formsIdentity, roles);

        Context.User = principalWithRoles;

        // this allows me to show the roles on the default page
        Context.Items["roles"] = roles;
    }

    // simple role lookup based on an XML file
    string[] LookupRolesFor(string userName)
    {
        // sanity check input
        if (!Regex.IsMatch(userName, "^[A-Za-z0-9]+$"))
            throw new FormatException("Invalid user name");

        // load roles.xml
        string roleFile = ConfigurationManager.AppSettings["roleFile"];
        if (string.IsNullOrEmpty(roleFile))
            throw new ApplicationException("Please configure an <appSetting> for roleFile");
        XPathNavigator rolesNav = new XPathDocument(roleFile).CreateNavigator();

        // quick search to find all roles in which the user is a member
        string xpathQuery = string.Format(
            "/roles/role/user[@name='{0}']/../@name",
            userName);
        List<string> roles = new List<string>();
        foreach (XPathNavigator roleNav in rolesNav.Select(xpathQuery))
            roles.Add(roleNav.Value);

        return roles.ToArray();
    }
}
