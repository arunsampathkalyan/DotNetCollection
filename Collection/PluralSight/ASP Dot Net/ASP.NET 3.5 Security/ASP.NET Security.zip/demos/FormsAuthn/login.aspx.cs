﻿using System;
using System.Web.UI;
using System.Web.Security;

public partial class loginpage : Page
{
    protected void Login_Click(object sender, System.EventArgs e)
    {
        if (IsAuthenticUser(usernameTextBox.Text,
                            passwordTextBox.Text))
            FormsAuthentication.RedirectFromLoginPage(
                              usernameTextBox.Text, true);
        else errorMessageLabel.Text = "Invalid username and/or password";
    }

    private bool IsAuthenticUser(string username, string password)
    {
        // for demo purposes only - replace this with a database lookup
        return username.Equals(password,
            StringComparison.InvariantCultureIgnoreCase);
    }
}
