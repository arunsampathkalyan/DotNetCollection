﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginControl : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    // fires when user presses Login button, but before login happens
    // typically used for input validation prior to authentication
    protected void PreLoginHandler(object sender, LoginCancelEventArgs e) { }
    
    // this is where you authenticate the user and decide whether
    // to log her in or not
    protected void LoginHandler(object sender, AuthenticateEventArgs e) { }

    // fires after a successful login
    protected void SuccessfulLoginHandler(object sender, EventArgs e) { }

    // fires after a failed login
    protected void FailedLoginHandler(object sender, EventArgs e) { }
}
