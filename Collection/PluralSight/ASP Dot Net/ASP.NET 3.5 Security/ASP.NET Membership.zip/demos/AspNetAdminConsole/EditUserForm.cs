using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web.Security;
using System.Configuration.Provider;

namespace AspNetAdminConsole {
    public partial class EditUserForm : Form {

        MembershipUser user;

        private void EditUserForm_Load(object sender, EventArgs e) {
            
            this.Text = user.UserName;

            txtEmail.Text = user.Email;

            bool requireAnswer = Program.MembershipProvider.RequiresQuestionAndAnswer;
            bool allowPwdReset = Program.MembershipProvider.EnablePasswordReset;
            txtAnswer.Enabled = requireAnswer;
            grpResetPassword.Enabled = allowPwdReset;
            grpResetQuestion.Enabled = requireAnswer;

            txtQuestion.Text = user.PasswordQuestion;
        }

        public EditUserForm(MembershipUser user) {
            this.user = user;
            InitializeComponent();
        }

        private void btnSavePersonalData_Click(object sender, EventArgs e) {
            user.Email = txtEmail.Text.Trim();
            try {
                Program.MembershipProvider.UpdateUser(user);
                Program.InfoMsg(this, "Updated {0}", user.UserName);
                this.Close();
            }
            catch (ProviderException x) {
                Program.ErrorMsg(this, x.Message);
            }
        }

        private void btnResetPassword_Click(object sender, EventArgs e) {
            errorProvider.Clear();
            try {
                if (Program.MembershipProvider.RequiresQuestionAndAnswer) {
                    if (0 == txtAnswer.Text.Trim().Length) {
                        setError(txtAnswer, "You must provide the answer to the user's question in order to reset the password.");
                    }
                }
                txtNewPassword.Text = Program.MembershipProvider.ResetPassword(user.UserName, StringUtil.NullIfEmpty(txtAnswer.Text.Trim()));
                txtNewPassword.Select();
                txtNewPassword.SelectAll();
                Program.InfoMsg(this, "Reset password for {0}", user.UserName);
            }
            catch (MembershipPasswordException x) {
                Program.ErrorMsg(this, x.Message);
            }
            catch (ProviderException x) {
                Program.ErrorMsg(this, x.Message);
            }
            catch (DataEntryException) { }
        }

        private void btnResetQuestion_Click(object sender, EventArgs e) {
            errorProvider.Clear();
            try {
                if (0 == txtPassword.Text.Length) setError(txtPassword, "You must provide the user's password in order to reset the question and answer.");
                if (0 == txtNewQuestion.Text.Trim().Length) setError(txtNewQuestion, "Please provide a new question and answer.");
                if (0 == txtNewAnswer.Text.Trim().Length) setError(txtNewAnswer, "Please provide a new question and answer.");
                Program.MembershipProvider.ChangePasswordQuestionAndAnswer(user.UserName, txtPassword.Text, txtNewQuestion.Text.Trim(), txtNewAnswer.Text.Trim());
                txtQuestion.Text = txtNewQuestion.Text.Trim();
                Program.InfoMsg(this, "Reset question and answer for {0}", user.UserName);
                this.Close();
            }
            catch (MembershipPasswordException x) {
                Program.ErrorMsg(this, x.Message);
            }
            catch (ProviderException x) {
                Program.ErrorMsg(this, x.Message);
            }
            catch (DataEntryException) { }
        }

        private void setError(Control c, string msg) {
            errorProvider.SetError(c, msg);
            DialogResult = DialogResult.None;
            throw new DataEntryException();
        }

    }
}