using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AspNetAdminConsole {
    public partial class DisplayPasswordForm : Form {
        public DisplayPasswordForm(string pwd) {
            InitializeComponent();
            txtPassword.Text = pwd;
        }
    }
}