using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AspNetAdminConsole {
    public partial class AskQuestionForm : Form {

        string answer;

        public string Answer {
            get { return answer; }
        }

        public AskQuestionForm(string question) {
            InitializeComponent();
            txtQ.Text = question;
        }

        private void btnOK_Click(object sender, EventArgs e) {
            try {
                StringUtil.TrimTextBox(txtA);
                if (0 == txtA.Text.Length) setError(txtA, "Please supply an answer.");
                answer = txtA.Text;
            }
            catch (DataEntryException) { }
        }

        private void setError(Control c, string msg) {
            errorProvider.SetError(c, msg);
            DialogResult = DialogResult.None;
            throw new DataEntryException();
        }
    }
}