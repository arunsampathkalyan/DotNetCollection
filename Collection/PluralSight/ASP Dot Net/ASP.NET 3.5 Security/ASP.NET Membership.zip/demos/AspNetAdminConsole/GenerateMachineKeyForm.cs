using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace AspNetAdminConsole {
    public partial class GenerateMachineKeyForm : Form {
        public GenerateMachineKeyForm() {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e) {
            StringBuilder media = new StringBuilder();
            using (XmlTextWriter writer = new XmlTextWriter(new StringWriter(media))) {
                writer.WriteStartElement("machineKey");
                if (chkValidation.Checked) writeValidationKey(writer);
                if (chkEncryption.Checked) writeDecryptionKey(writer);
                writer.WriteEndElement();
            }
            txtOutput.Text = media.ToString();
            txtOutput.Select();
            txtOutput.SelectAll();
        }

        private void writeValidationKey(XmlTextWriter writer) {
            string validationAlgorithm = null;
            int keyLengthInBytes = 0x40;

            if (rdoValidationSHA1.Checked) {
                validationAlgorithm = "SHA1";
            }
            else if (rdoValidationMD5.Checked) {
                validationAlgorithm = "MD5";
            }

            StringBuilder sb = new StringBuilder();
            writeRandomKey(sb, keyLengthInBytes);
            
            if (chkValidationIsolateApps.Checked) sb.Append(",IsolateApps");
            
            writer.WriteAttributeString("validation", validationAlgorithm);
            writer.WriteAttributeString("validationKey", sb.ToString());
        }

        private void writeRandomKey(StringBuilder sb, int keyLengthInBytes) {
            byte[] buf = new byte[keyLengthInBytes];
            new System.Security.Cryptography.RNGCryptoServiceProvider().GetBytes(buf);
            foreach (byte b in buf) {
                sb.AppendFormat("{0:X2}", b);
            }
        }

        private void writeDecryptionKey(XmlTextWriter writer) {
            string encryptionAlgorithm = null;
            int keyLengthInBytes = 0;
            if (rdoEncryptionAES.Checked) {
                encryptionAlgorithm = "AES";
                keyLengthInBytes = ((int)udAESKeyLength.Value)/8;
            }
            else if (rdoEncryption3DES.Checked) {
                encryptionAlgorithm = "3DES";
                keyLengthInBytes = 32;
            }
            else if (rdoEncryptionDES.Checked) {
                encryptionAlgorithm = "DES";
                keyLengthInBytes = 16;
            }

            StringBuilder sb = new StringBuilder();
            writeRandomKey(sb, keyLengthInBytes);

            if (chkEncryptionIsolateApps.Checked) sb.Append(",IsolateApps");
            
            writer.WriteAttributeString("decryption", encryptionAlgorithm);
            writer.WriteAttributeString("decryptionKey", sb.ToString());
        }

    }
}