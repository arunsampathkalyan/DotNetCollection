using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web.Security;

namespace AspNetAdminConsole {
    public partial class MainForm : Form {
        ManageUsersForm manageUsersForm = new ManageUsersForm();

        public MainForm() {
            InitializeComponent();
        }

        private void btnManageUsers_Click(object sender, EventArgs e) {
            manageUsersForm.Show(this);
            manageUsersForm.Activate();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e) {
            manageUsersForm.Close();
            this.DestroyHandle();
        }

        private void btnLogon_Click(object sender, EventArgs e) {
            new LogonForm().Show();
        }

        private void btnGenerateMachineKey_Click(object sender, EventArgs e) {
            new GenerateMachineKeyForm().ShowDialog(this);
        }
    }
}