using System;
using System.Collections.Generic;
using System.Text;

namespace AspNetAdminConsole {
    public class DataEntryException : Exception {
        public DataEntryException() : base() { }
    }
}
