using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web.Security;

namespace AspNetAdminConsole {
    public partial class LogonForm : Form {

        enum ValidationState {
            Unknown,
            Valid,
            Invalid
        }

        ValidationState validationState = ValidationState.Unknown;

        public LogonForm() {
            InitializeComponent();
        }

        private void btnLogon_Click(object sender, EventArgs e) {
            try {
                Program.WaitCursor();
                errorProvider.Clear();
                txtName.Text = txtName.Text.Trim();
                if (0 == txtName.Text.Length) setError(txtName, "Please specify a user name.");
                if (0 == txtPassword.Text.Length) setError(txtPassword, "Please specify a password.");
                if (Program.MembershipProvider.ValidateUser(txtName.Text, txtPassword.Text))
                     validationState = ValidationState.Valid;
                else validationState = ValidationState.Invalid;
                refreshValidLabels();
                refreshUserDetails();
            }
            catch (DataEntryException) { }
        }

        private void refreshValidLabels() {
            lblNo.Visible  = ValidationState.Invalid == validationState;
            lblYes.Visible = ValidationState.Valid   == validationState;
        }

        private void setError(Control c, string msg) {
            errorProvider.SetError(c, msg);
            DialogResult = DialogResult.None;
            throw new DataEntryException();
        }

        private void btnRefresh_Click(object sender, EventArgs e) {
            refreshUserDetails();
        }
        
        private void LogonForm_KeyPress(object sender, KeyPressEventArgs e) {
            if ((char)Keys.F5 == e.KeyChar) {
                refreshUserDetails();
                e.Handled = true;
            }
        }

        private void refreshUserDetails() {
            string name = txtName.Text.Trim();
            MembershipUser user = Program.MembershipProvider.GetUser(name, false);
            if (user != null) {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("User name: {0}", user.UserName).AppendLine();
                if (user.IsLockedOut) sb.AppendFormat("***ACCOUNT IS LOCKED OUT***").AppendLine();
                sb.AppendFormat("Last activity: {0:D}", user.LastActivityDate).AppendLine();
                sb.AppendFormat("Last login: {0:D}", user.LastLoginDate).AppendLine();
                sb.AppendFormat("Last lockout: {0:D}", user.LastLockoutDate).AppendLine();
                sb.AppendFormat("User is considered {0}.", user.IsOnline ? "online" : "offline").AppendLine();
                txtUserDetails.Text = sb.ToString();
            }
            else txtUserDetails.Text = string.Format("No user with the name [{0}] exists in this provider.", name);
        }

        private void txtNameOrPassword_TextChanged(object sender, EventArgs e) {
            errorProvider.Clear();
            validationState = ValidationState.Unknown;
            refreshValidLabels();
        }

    }
}