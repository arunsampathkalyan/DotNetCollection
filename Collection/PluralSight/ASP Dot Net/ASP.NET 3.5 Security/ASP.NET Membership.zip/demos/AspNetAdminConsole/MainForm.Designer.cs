namespace AspNetAdminConsole {
    partial class MainForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnManageUsers = new System.Windows.Forms.Button();
            this.btnLogon = new System.Windows.Forms.Button();
            this.btnGenerateMachineKey = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnManageUsers
            // 
            this.btnManageUsers.Location = new System.Drawing.Point(12, 12);
            this.btnManageUsers.Name = "btnManageUsers";
            this.btnManageUsers.Size = new System.Drawing.Size(105, 23);
            this.btnManageUsers.TabIndex = 0;
            this.btnManageUsers.Text = "Manage Users...";
            this.btnManageUsers.UseVisualStyleBackColor = true;
            this.btnManageUsers.Click += new System.EventHandler(this.btnManageUsers_Click);
            // 
            // btnLogon
            // 
            this.btnLogon.Location = new System.Drawing.Point(12, 41);
            this.btnLogon.Name = "btnLogon";
            this.btnLogon.Size = new System.Drawing.Size(105, 23);
            this.btnLogon.TabIndex = 1;
            this.btnLogon.Text = "Logon User";
            this.btnLogon.UseVisualStyleBackColor = true;
            this.btnLogon.Click += new System.EventHandler(this.btnLogon_Click);
            // 
            // btnGenerateMachineKey
            // 
            this.btnGenerateMachineKey.Location = new System.Drawing.Point(123, 12);
            this.btnGenerateMachineKey.Name = "btnGenerateMachineKey";
            this.btnGenerateMachineKey.Size = new System.Drawing.Size(154, 23);
            this.btnGenerateMachineKey.TabIndex = 2;
            this.btnGenerateMachineKey.Text = "Generate Machine Key";
            this.btnGenerateMachineKey.UseVisualStyleBackColor = true;
            this.btnGenerateMachineKey.Click += new System.EventHandler(this.btnGenerateMachineKey_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(289, 72);
            this.Controls.Add(this.btnGenerateMachineKey);
            this.Controls.Add(this.btnLogon);
            this.Controls.Add(this.btnManageUsers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "ASP.NET Administration Console";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button btnLogon;
        private System.Windows.Forms.Button btnGenerateMachineKey;
    }
}