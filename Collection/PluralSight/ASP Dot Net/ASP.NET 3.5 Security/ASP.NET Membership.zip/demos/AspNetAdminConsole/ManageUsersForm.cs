using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web.Security;
using System.Diagnostics;

namespace AspNetAdminConsole {
    public partial class ManageUsersForm : Form {

        bool updatingUserInfo;

        #region Form initialization

        public ManageUsersForm() {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e) {
            refreshUserList();
            updateUIBasedOnSelectedUser();
        }
        
        #endregion

        #region Click handlers

        private void btnAddUser_Click(object sender, EventArgs e) {
            AddUserForm form = new AddUserForm();
            if (DialogResult.OK == form.ShowDialog()) refreshUserList(form.LastUserNameAdded);
        }

        private void btnEdit_Click(object sender, EventArgs e) {
            MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
            if (null != user) {
                EditUserForm form = new EditUserForm(user);
                form.ShowDialog();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e) {
            MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
            if (null != user) {
                if (Program.MembershipProvider.DeleteUser(user.UserName, true)) {
                    refreshUserList();
                }
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e) {
            refreshUserList();
        }

        private void btnGetPassword_Click(object sender, EventArgs e) {
            MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
            if (null != user) {
                string answer = null;
                if (Program.MembershipProvider.RequiresQuestionAndAnswer) {
                    AskQuestionForm form = new AskQuestionForm(user.PasswordQuestion);
                    if (DialogResult.OK == form.ShowDialog(this)) {
                        answer = form.Answer;
                    }
                }
                string pwd = Program.MembershipProvider.GetPassword(user.UserName, answer);

                new DisplayPasswordForm(pwd).ShowDialog(this);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) {
            done();
        }

        private void linkEmail_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
            if (null != user) {
                ProcessStartInfo psi = new ProcessStartInfo("mailto:" + user.Email);
                psi.UseShellExecute = true;
                Process.Start(psi);
            }
        }

        private void chkLockedOut_CheckedChanged(object sender, EventArgs e) {
            if (!updatingUserInfo) {
                MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
                if (null != user) {
                    if (!chkLockedOut.Checked) {
                        Program.MembershipProvider.UnlockUser(user.UserName);
                        refreshUserList(user.UserName);
                    }
                }
            }
        }

        private void chkAllowLogon_CheckedChanged(object sender, EventArgs e) {
            if (!updatingUserInfo) {
                MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
                if (null != user) {
                    user.IsApproved = chkAllowLogon.Checked;
                    Program.MembershipProvider.UpdateUser(user);
                    if (user.IsApproved)
                        Program.InfoMsg(this, "{0} will now be allowed to log in.", user.UserName);
                    else Program.InfoMsg(this, "{0} will no longer be allowed to log in.", user.UserName);
                }
            }
        }

        #endregion

        #region User info display

        private void updateUIBasedOnSelectedUser() {
            updatingUserInfo = true;
            try {
                enableDisableButtons();
                MembershipUser user = (MembershipUser)lstUsers.SelectedItem;
                linkEmail.Text = (null == user) ? string.Empty : user.Email;
                txtComments.Text = (null == user) ? string.Empty : user.Comment;
                lblCreateDate.Text = (null == user) ? string.Empty : string.Format("Created on {0:ddd, MMM dd yyyy}", user.CreationDate);
                lblLastLogon.Text = computeLastLogonText(user);
                lblLastPwdChange.Text = computeLastPwdChangeText(user);

                if (null == user) {
                    chkLockedOut.Enabled = false;
                    chkAllowLogon.Enabled = false;
                    chkOnlineNow.Enabled = false;
                }
                else {
                    chkLockedOut.Enabled = user.IsLockedOut;
                    chkLockedOut.Checked = user.IsLockedOut;
                    chkAllowLogon.Enabled = true;
                    chkAllowLogon.Checked = user.IsApproved;
                    chkOnlineNow.Checked = user.IsOnline;
                }
            }
            finally {
                updatingUserInfo = false;
            }
        }

        private string computeLastPwdChangeText(MembershipUser user) {
            if (null == user) return string.Empty;
            int days = (int)DateTime.Now.Subtract(user.LastPasswordChangedDate).TotalDays;
            if (days > 1) {
                return "Password last changed " + days + " days ago.";
            }
            else {
                return "Password was changed today.";
            }
        }

        private string computeLastLogonText(MembershipUser user) {
            if (null == user) return string.Empty;
            int days = (int)DateTime.Now.Subtract(user.LastPasswordChangedDate).TotalDays;
            if (days > 1) {
                return "User logged in " + days + " days ago.";
            }
            else {
                return "User logged in today.";
            }
        }

        private void enableDisableButtons() {
            bool userIsSelected = (-1 != lstUsers.SelectedIndex);
            btnDelete.Enabled = userIsSelected;
            btnGetPassword.Enabled = Program.MembershipProvider.EnablePasswordRetrieval && userIsSelected;
        }

        #endregion

        #region User list management

        private void lstUsers_SelectedIndexChanged(object sender, EventArgs e) {
            updateUIBasedOnSelectedUser();
        }

        private void refreshUserList(string userNameToSelect) {
            Program.WaitCursor();
            lstUsers.Items.Clear();
            MembershipProvider mp = Program.MembershipProvider;
            int selectMe = -1;
            if (null != mp) {
                int numUsers;
                foreach (MembershipUser user in mp.GetAllUsers(0, int.MaxValue, out numUsers)) {
                    int index = lstUsers.Items.Add(user);
                    if (null != userNameToSelect && userNameToSelect == user.UserName) {
                        selectMe = index;
                    }
                }
            }
            if (-1 != selectMe) lstUsers.SelectedIndex = selectMe;
            updateUIBasedOnSelectedUser();
        }
        private void refreshUserList() {
            refreshUserList(null);
        }


        #endregion

        #region Form closure

        private void ManageUsersForm_KeyPress(object sender, KeyPressEventArgs e) {
            if ((char)Keys.Escape == e.KeyChar) {
                e.Handled = true;
                done();
            }
        }

        private void ManageUsersForm_FormClosing(object sender, FormClosingEventArgs e) {
            e.Cancel = true;
            done();
        }

        private void done() {
            this.Hide();
            Owner.Activate();
        }
        
        #endregion

    }
}