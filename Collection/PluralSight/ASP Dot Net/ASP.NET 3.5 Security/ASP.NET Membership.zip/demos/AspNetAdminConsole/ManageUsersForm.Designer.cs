namespace AspNetAdminConsole {
    partial class ManageUsersForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lstUsers = new System.Windows.Forms.ListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtComments = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkLockedOut = new System.Windows.Forms.CheckBox();
            this.chkAllowLogon = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkOnlineNow = new System.Windows.Forms.CheckBox();
            this.lblLastPwdChange = new System.Windows.Forms.Label();
            this.lblLastLogon = new System.Windows.Forms.Label();
            this.linkEmail = new System.Windows.Forms.LinkLabel();
            this.lblCreateDate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnGetPassword = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(113, 16);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(32, 16);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "&Add...";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAddUser_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(113, 75);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "&Close";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lstUsers
            // 
            this.lstUsers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstUsers.FormattingEnabled = true;
            this.lstUsers.IntegralHeight = false;
            this.lstUsers.Location = new System.Drawing.Point(0, 0);
            this.lstUsers.Name = "lstUsers";
            this.lstUsers.Size = new System.Drawing.Size(548, 408);
            this.lstUsers.TabIndex = 0;
            this.lstUsers.SelectedIndexChanged += new System.EventHandler(this.lstUsers_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnGetPassword);
            this.panel1.Controls.Add(this.btnRefresh);
            this.panel1.Controls.Add(this.txtComments);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnEdit);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Controls.Add(this.btnCancel);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(327, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(221, 408);
            this.panel1.TabIndex = 1;
            // 
            // txtComments
            // 
            this.txtComments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtComments.Enabled = false;
            this.txtComments.Location = new System.Drawing.Point(6, 353);
            this.txtComments.Multiline = true;
            this.txtComments.Name = "txtComments";
            this.txtComments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComments.Size = new System.Drawing.Size(212, 52);
            this.txtComments.TabIndex = 7;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkLockedOut);
            this.groupBox2.Controls.Add(this.chkAllowLogon);
            this.groupBox2.Location = new System.Drawing.Point(6, 265);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(203, 69);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Authorization";
            // 
            // chkLockedOut
            // 
            this.chkLockedOut.AutoSize = true;
            this.chkLockedOut.Enabled = false;
            this.chkLockedOut.Location = new System.Drawing.Point(10, 43);
            this.chkLockedOut.Name = "chkLockedOut";
            this.chkLockedOut.Size = new System.Drawing.Size(148, 17);
            this.chkLockedOut.TabIndex = 1;
            this.chkLockedOut.Text = "Account is &LOCKED OUT";
            this.chkLockedOut.UseVisualStyleBackColor = true;
            this.chkLockedOut.CheckedChanged += new System.EventHandler(this.chkLockedOut_CheckedChanged);
            // 
            // chkAllowLogon
            // 
            this.chkAllowLogon.AutoSize = true;
            this.chkAllowLogon.Enabled = false;
            this.chkAllowLogon.Location = new System.Drawing.Point(10, 20);
            this.chkAllowLogon.Name = "chkAllowLogon";
            this.chkAllowLogon.Size = new System.Drawing.Size(141, 17);
            this.chkAllowLogon.TabIndex = 0;
            this.chkAllowLogon.Text = "User is allowed to &log on";
            this.chkAllowLogon.UseVisualStyleBackColor = true;
            this.chkAllowLogon.CheckedChanged += new System.EventHandler(this.chkAllowLogon_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkOnlineNow);
            this.groupBox1.Controls.Add(this.lblLastPwdChange);
            this.groupBox1.Controls.Add(this.lblLastLogon);
            this.groupBox1.Controls.Add(this.linkEmail);
            this.groupBox1.Controls.Add(this.lblCreateDate);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(203, 136);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User information";
            // 
            // chkOnlineNow
            // 
            this.chkOnlineNow.AutoSize = true;
            this.chkOnlineNow.Enabled = false;
            this.chkOnlineNow.Location = new System.Drawing.Point(10, 110);
            this.chkOnlineNow.Name = "chkOnlineNow";
            this.chkOnlineNow.Size = new System.Drawing.Size(112, 17);
            this.chkOnlineNow.TabIndex = 5;
            this.chkOnlineNow.Text = "User is online now";
            this.chkOnlineNow.UseVisualStyleBackColor = true;
            // 
            // lblLastPwdChange
            // 
            this.lblLastPwdChange.AutoSize = true;
            this.lblLastPwdChange.Location = new System.Drawing.Point(7, 88);
            this.lblLastPwdChange.Name = "lblLastPwdChange";
            this.lblLastPwdChange.Size = new System.Drawing.Size(113, 13);
            this.lblLastPwdChange.TabIndex = 4;
            this.lblLastPwdChange.Text = "Password changed on";
            // 
            // lblLastLogon
            // 
            this.lblLastLogon.AutoSize = true;
            this.lblLastLogon.Location = new System.Drawing.Point(7, 66);
            this.lblLastLogon.Name = "lblLastLogon";
            this.lblLastLogon.Size = new System.Drawing.Size(78, 13);
            this.lblLastLogon.TabIndex = 3;
            this.lblLastLogon.Text = "Last logon was";
            // 
            // linkEmail
            // 
            this.linkEmail.AutoSize = true;
            this.linkEmail.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkEmail.Location = new System.Drawing.Point(79, 22);
            this.linkEmail.Name = "linkEmail";
            this.linkEmail.Size = new System.Drawing.Size(43, 13);
            this.linkEmail.TabIndex = 1;
            this.linkEmail.TabStop = true;
            this.linkEmail.Text = "<email>";
            this.linkEmail.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkEmail_LinkClicked);
            // 
            // lblCreateDate
            // 
            this.lblCreateDate.AutoSize = true;
            this.lblCreateDate.Location = new System.Drawing.Point(7, 44);
            this.lblCreateDate.Name = "lblCreateDate";
            this.lblCreateDate.Size = new System.Drawing.Size(101, 13);
            this.lblCreateDate.TabIndex = 2;
            this.lblCreateDate.Text = "Account created on";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Email address:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 337);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Comments:";
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(32, 45);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 1;
            this.btnEdit.Text = "&Edit...";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(32, 75);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 8;
            this.btnRefresh.Text = "&Refresh (F5)";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnGetPassword
            // 
            this.btnGetPassword.Location = new System.Drawing.Point(114, 45);
            this.btnGetPassword.Name = "btnGetPassword";
            this.btnGetPassword.Size = new System.Drawing.Size(75, 23);
            this.btnGetPassword.TabIndex = 9;
            this.btnGetPassword.Text = "Get &Pwd";
            this.btnGetPassword.UseVisualStyleBackColor = true;
            this.btnGetPassword.Click += new System.EventHandler(this.btnGetPassword_Click);
            // 
            // ManageUsersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 408);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lstUsers);
            this.KeyPreview = true;
            this.MinimizeBox = false;
            this.Name = "ManageUsersForm";
            this.Text = "Manage Users";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ManageUsersForm_KeyPress);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ManageUsersForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ListBox lstUsers;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.LinkLabel linkEmail;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox chkOnlineNow;
        private System.Windows.Forms.Label lblLastPwdChange;
        private System.Windows.Forms.Label lblLastLogon;
        private System.Windows.Forms.Label lblCreateDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkLockedOut;
        private System.Windows.Forms.CheckBox chkAllowLogon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtComments;
        private System.Windows.Forms.Button btnGetPassword;
        private System.Windows.Forms.Button btnRefresh;


    }
}

