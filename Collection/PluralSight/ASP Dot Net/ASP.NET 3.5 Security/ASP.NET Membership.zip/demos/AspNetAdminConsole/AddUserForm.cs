using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web.Security;
using System.Configuration.Provider;

namespace AspNetAdminConsole {
    public partial class AddUserForm : Form {
        public AddUserForm() {
            InitializeComponent();
        }

        public string LastUserNameAdded { get { return lastUserNameAdded; } }
        string lastUserNameAdded;

        private void AddUserForm_Load(object sender, EventArgs e) {
            string pwd = Membership.GeneratePassword(8, 2);
            txtPassword.Text = pwd;
            txtPasswordConfirm.Text = pwd;

            bool questionsRequired = Program.MembershipProvider.RequiresQuestionAndAnswer;
            txtPasswordQuestion.Enabled = questionsRequired;
            txtPasswordAnswer.Enabled = questionsRequired;
        }

        private void btnAdd_Click(object sender, EventArgs e) {
            Program.WaitCursor();
            errorProvider.Clear();
            try {
                if (Program.MembershipProvider.RequiresQuestionAndAnswer) {
                    if (0 == txtPasswordQuestion.Text.Trim().Length) setError(txtPasswordQuestion, "Question and answer are required by this provider.");
                    if (0 == txtPasswordAnswer.Text.Trim().Length) setError(txtPasswordAnswer, "Question and answer are required by this provider.");
                }
                txtName.Text = txtName.Text.Trim();
                if (0 == txtName.Text.Length) setError(txtName, "Name cannot be empty.");
                if (0 == txtPassword.Text.Length) setError(txtPassword, "Password cannot be empty.");
                if (txtPassword.Text != txtPasswordConfirm.Text) setError(txtPasswordConfirm, "Passwords do not match.");

                MembershipCreateStatus createStatus;
                MembershipUser user = Program.MembershipProvider.CreateUser(
                    txtName.Text,
                    txtPassword.Text,
                    StringUtil.NullIfEmpty(txtEmail.Text.Trim()),
                    StringUtil.NullIfEmpty(txtPasswordQuestion.Text.Trim()),
                    StringUtil.NullIfEmpty(txtPasswordAnswer.Text.Trim()),
                    chkApproved.Checked,
                    null,
                    out createStatus);
                if (MembershipCreateStatus.Success == createStatus) {
                    lastUserNameAdded = user.UserName;
                }
                else Program.ErrorMsg(this, "Failed to create user: {0}", createStatus.ToString());
            }
            catch (ProviderException x) {
                Program.ErrorMsg(this, x.Message);
            }
            catch (DataEntryException) { }
        }

        private void setError(Control c, string msg) {
            errorProvider.SetError(c, msg);
            DialogResult = DialogResult.None;
            throw new DataEntryException();
        }
    }
}