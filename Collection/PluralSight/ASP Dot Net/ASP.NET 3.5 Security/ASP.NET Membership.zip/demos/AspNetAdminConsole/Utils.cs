using System;
using System.Windows.Forms;

namespace AspNetAdminConsole {
    public static class StringUtil {
        public static string NullIfEmpty(string input) {
            if (null != input && 0 == input.Length) return null;
            return input;
        }

        public static void TrimTextBox(TextBox txt) {
            txt.Text = txt.Text.Trim();
        }
    }
}
