namespace AspNetAdminConsole {
    partial class GenerateMachineKeyForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.chkValidation = new System.Windows.Forms.CheckBox();
            this.rdoValidationMD5 = new System.Windows.Forms.RadioButton();
            this.rdoValidationSHA1 = new System.Windows.Forms.RadioButton();
            this.chkValidationIsolateApps = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkEncryption = new System.Windows.Forms.CheckBox();
            this.chkEncryptionIsolateApps = new System.Windows.Forms.CheckBox();
            this.rdoEncryptionAES = new System.Windows.Forms.RadioButton();
            this.rdoEncryption3DES = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rdoEncryptionDES = new System.Windows.Forms.RadioButton();
            this.udAESKeyLength = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udAESKeyLength)).BeginInit();
            this.SuspendLayout();
            // 
            // chkValidation
            // 
            this.chkValidation.AutoSize = true;
            this.chkValidation.Checked = true;
            this.chkValidation.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkValidation.Location = new System.Drawing.Point(10, 19);
            this.chkValidation.Name = "chkValidation";
            this.chkValidation.Size = new System.Drawing.Size(92, 17);
            this.chkValidation.TabIndex = 0;
            this.chkValidation.Text = "&Validation key";
            this.chkValidation.UseVisualStyleBackColor = true;
            // 
            // rdoValidationMD5
            // 
            this.rdoValidationMD5.AutoSize = true;
            this.rdoValidationMD5.Location = new System.Drawing.Point(6, 42);
            this.rdoValidationMD5.Name = "rdoValidationMD5";
            this.rdoValidationMD5.Size = new System.Drawing.Size(82, 17);
            this.rdoValidationMD5.TabIndex = 1;
            this.rdoValidationMD5.Text = "HMAC-&MD5";
            this.rdoValidationMD5.UseVisualStyleBackColor = true;
            // 
            // rdoValidationSHA1
            // 
            this.rdoValidationSHA1.AutoSize = true;
            this.rdoValidationSHA1.Checked = true;
            this.rdoValidationSHA1.Location = new System.Drawing.Point(6, 19);
            this.rdoValidationSHA1.Name = "rdoValidationSHA1";
            this.rdoValidationSHA1.Size = new System.Drawing.Size(163, 17);
            this.rdoValidationSHA1.TabIndex = 0;
            this.rdoValidationSHA1.TabStop = true;
            this.rdoValidationSHA1.Text = "HMAC-&SHA1 (recommended)";
            this.rdoValidationSHA1.UseVisualStyleBackColor = true;
            // 
            // chkValidationIsolateApps
            // 
            this.chkValidationIsolateApps.AutoSize = true;
            this.chkValidationIsolateApps.Location = new System.Drawing.Point(30, 42);
            this.chkValidationIsolateApps.Name = "chkValidationIsolateApps";
            this.chkValidationIsolateApps.Size = new System.Drawing.Size(213, 17);
            this.chkValidationIsolateApps.TabIndex = 1;
            this.chkValidationIsolateApps.Text = "&Derive unique keys for each application";
            this.chkValidationIsolateApps.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoValidationSHA1);
            this.groupBox1.Controls.Add(this.rdoValidationMD5);
            this.groupBox1.Location = new System.Drawing.Point(30, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(171, 68);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Validation algorithm";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkValidation);
            this.groupBox2.Controls.Add(this.groupBox1);
            this.groupBox2.Controls.Add(this.chkValidationIsolateApps);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(248, 140);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Validation";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.chkEncryption);
            this.groupBox3.Controls.Add(this.chkEncryptionIsolateApps);
            this.groupBox3.Location = new System.Drawing.Point(13, 158);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(247, 162);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Encryption / Decryption";
            // 
            // chkEncryption
            // 
            this.chkEncryption.AutoSize = true;
            this.chkEncryption.Checked = true;
            this.chkEncryption.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEncryption.Location = new System.Drawing.Point(9, 19);
            this.chkEncryption.Name = "chkEncryption";
            this.chkEncryption.Size = new System.Drawing.Size(156, 17);
            this.chkEncryption.TabIndex = 0;
            this.chkEncryption.Text = "&Encryption / decryption key";
            this.chkEncryption.UseVisualStyleBackColor = true;
            // 
            // chkEncryptionIsolateApps
            // 
            this.chkEncryptionIsolateApps.AutoSize = true;
            this.chkEncryptionIsolateApps.Location = new System.Drawing.Point(29, 42);
            this.chkEncryptionIsolateApps.Name = "chkEncryptionIsolateApps";
            this.chkEncryptionIsolateApps.Size = new System.Drawing.Size(213, 17);
            this.chkEncryptionIsolateApps.TabIndex = 1;
            this.chkEncryptionIsolateApps.Text = "Derive &unique keys for each application";
            this.chkEncryptionIsolateApps.UseVisualStyleBackColor = true;
            // 
            // rdoEncryptionAES
            // 
            this.rdoEncryptionAES.AutoSize = true;
            this.rdoEncryptionAES.Checked = true;
            this.rdoEncryptionAES.Location = new System.Drawing.Point(6, 19);
            this.rdoEncryptionAES.Name = "rdoEncryptionAES";
            this.rdoEncryptionAES.Size = new System.Drawing.Size(122, 17);
            this.rdoEncryptionAES.TabIndex = 0;
            this.rdoEncryptionAES.TabStop = true;
            this.rdoEncryptionAES.Text = "&AES (recommended)";
            this.rdoEncryptionAES.UseVisualStyleBackColor = true;
            // 
            // rdoEncryption3DES
            // 
            this.rdoEncryption3DES.AutoSize = true;
            this.rdoEncryption3DES.Location = new System.Drawing.Point(6, 42);
            this.rdoEncryption3DES.Name = "rdoEncryption3DES";
            this.rdoEncryption3DES.Size = new System.Drawing.Size(53, 17);
            this.rdoEncryption3DES.TabIndex = 1;
            this.rdoEncryption3DES.Text = "&3DES";
            this.rdoEncryption3DES.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.udAESKeyLength);
            this.groupBox4.Controls.Add(this.rdoEncryptionDES);
            this.groupBox4.Controls.Add(this.rdoEncryption3DES);
            this.groupBox4.Controls.Add(this.rdoEncryptionAES);
            this.groupBox4.Location = new System.Drawing.Point(29, 66);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(212, 89);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Encryption algorithm";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(95, 326);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "&OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // txtOutput
            // 
            this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutput.Location = new System.Drawing.Point(269, 31);
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOutput.Size = new System.Drawing.Size(388, 317);
            this.txtOutput.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(266, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Output:";
            // 
            // rdoEncryptionDES
            // 
            this.rdoEncryptionDES.AutoSize = true;
            this.rdoEncryptionDES.Location = new System.Drawing.Point(6, 65);
            this.rdoEncryptionDES.Name = "rdoEncryptionDES";
            this.rdoEncryptionDES.Size = new System.Drawing.Size(141, 17);
            this.rdoEncryptionDES.TabIndex = 2;
            this.rdoEncryptionDES.Text = "DES (not recommended)";
            this.rdoEncryptionDES.UseVisualStyleBackColor = true;
            // 
            // udAESKeyLength
            // 
            this.udAESKeyLength.Increment = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.udAESKeyLength.Location = new System.Drawing.Point(127, 18);
            this.udAESKeyLength.Maximum = new decimal(new int[] {
            256,
            0,
            0,
            0});
            this.udAESKeyLength.Minimum = new decimal(new int[] {
            128,
            0,
            0,
            0});
            this.udAESKeyLength.Name = "udAESKeyLength";
            this.udAESKeyLength.Size = new System.Drawing.Size(43, 20);
            this.udAESKeyLength.TabIndex = 3;
            this.udAESKeyLength.Value = new decimal(new int[] {
            256,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label2.Location = new System.Drawing.Point(171, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "bits";
            // 
            // GenerateMachineKeyForm
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 354);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOutput);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Name = "GenerateMachineKeyForm";
            this.Text = "Generate Random Machine Key";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udAESKeyLength)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkValidation;
        private System.Windows.Forms.RadioButton rdoValidationMD5;
        private System.Windows.Forms.RadioButton rdoValidationSHA1;
        private System.Windows.Forms.CheckBox chkValidationIsolateApps;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdoEncryption3DES;
        private System.Windows.Forms.RadioButton rdoEncryptionAES;
        private System.Windows.Forms.CheckBox chkEncryption;
        private System.Windows.Forms.CheckBox chkEncryptionIsolateApps;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdoEncryptionDES;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown udAESKeyLength;
    }
}