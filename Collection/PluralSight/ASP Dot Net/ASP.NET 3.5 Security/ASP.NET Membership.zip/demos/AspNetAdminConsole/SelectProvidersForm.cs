using System;
using System.Windows.Forms;
using System.Configuration;
using System.Web.Configuration;
using System.Web.Security;

namespace AspNetAdminConsole {
    public partial class SelectProvidersForm : Form {
        public SelectProvidersForm() {
            InitializeComponent();
        }

        public MembershipProvider MembershipProvider;
        public RoleProvider RoleProvider;

        private void SelectProvidersForm_Load(object sender, EventArgs e) {
            loadProviders();
        }

        private void btnOK_Click(object sender, EventArgs e) {
            ProviderListItem m = (ProviderListItem)cboMembershipProvider.SelectedItem;
            ProviderListItem r = (ProviderListItem)cboRoleProvider.SelectedItem;

            MembershipProvider = null;
            RoleProvider = null;

            if (null != m) MembershipProvider = (MembershipProvider)ProvidersHelper.InstantiateProvider(m.ps, typeof(MembershipProvider));
            if (null != r) RoleProvider = (RoleProvider)ProvidersHelper.InstantiateProvider(r.ps, typeof(RoleProvider));
        }

        private void loadProviders() {
            MembershipSection ms = (MembershipSection)WebConfigurationManager.GetSection("system.web/membership");
            foreach (ProviderSettings ps in ms.Providers) {
                int index = cboMembershipProvider.Items.Add(new ProviderListItem(ps, ps.Name));
                if (ps.Name == Program.Settings.LastMembershipProviderName) cboMembershipProvider.SelectedIndex = index;
            }
            RoleManagerSection rms = (RoleManagerSection)WebConfigurationManager.GetSection("system.web/roleManager");
            foreach (ProviderSettings ps in rms.Providers) {
                int index = cboRoleProvider.Items.Add(new ProviderListItem(ps, ps.Name));
                if (ps.Name == Program.Settings.LastRoleProviderName) cboRoleProvider.SelectedIndex = index;
            }
        }

        public class ProviderListItem {
            public readonly ProviderSettings ps;
            string displayName;
            public ProviderListItem(ProviderSettings ps, string displayName) {
                this.ps = ps;
                this.displayName = displayName;
            }
            public override string ToString() {
                return displayName;
            }

        }

    }
}