using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Web.Security;
using System.IO;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace AspNetAdminConsole {
    static class Program {
        public static MembershipProvider MembershipProvider;
        public static RoleProvider RoleProvider;
        public static Settings Settings;

        public const string FRIENDLY_APP_NAME = "ASP.NET Admin Console";
        const string SETTINGS_ISOLATED_FILENAME = "settings";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() {
            loadSettings();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            SelectProvidersForm spf = new SelectProvidersForm();
            if (DialogResult.OK == spf.ShowDialog()) {
                MembershipProvider = spf.MembershipProvider;
                RoleProvider = spf.RoleProvider;

                Application.Run(new MainForm());

                saveSettings();
            }
        }

        private static void saveSettings() {
            Settings.LastMembershipProviderName = (null == MembershipProvider) ? string.Empty : MembershipProvider.Name;
            Settings.LastRoleProviderName = (null == RoleProvider) ? string.Empty : RoleProvider.Name;

            using (FileStream fs = new IsolatedStorageFileStream(SETTINGS_ISOLATED_FILENAME, FileMode.Create)) {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, Settings);
            }
        }

        private static void loadSettings() {
            Settings = new Settings(); // default settings
            try {
                using (FileStream fs = new IsolatedStorageFileStream(SETTINGS_ISOLATED_FILENAME, FileMode.Open)) {
                    BinaryFormatter formatter = new BinaryFormatter();
                    Settings = (Settings)formatter.Deserialize(fs);
                }
            }
            catch (SerializationException) {}
            catch (FileNotFoundException) {}
        }

        public static void ErrorMsg(IWin32Window owner, string format, params object[] args) {
            Msg(owner, MessageBoxIcon.Error, format, args);
        }

        public static void InfoMsg(IWin32Window owner, string format, params object[] args) {
            Msg(owner, MessageBoxIcon.Information, format, args);
        }

        private static void Msg(IWin32Window owner, MessageBoxIcon icon, string format, object[] args) {
            string msg = string.Format(format, args);
            MessageBox.Show(owner, msg, FRIENDLY_APP_NAME, MessageBoxButtons.OK, icon);
        }

        public static void WaitCursor() {
            Cursor.Current = Cursors.WaitCursor;
        }

    }

    [Serializable]
    public class Settings {
        public Settings() {
            LastMembershipProviderName = string.Empty;
            LastRoleProviderName = string.Empty;
        }
        public string LastMembershipProviderName;
        public string LastRoleProviderName;
    }
}