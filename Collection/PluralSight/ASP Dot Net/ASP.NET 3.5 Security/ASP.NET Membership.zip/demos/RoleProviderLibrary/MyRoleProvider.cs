﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Security;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Xml.XPath;

namespace RoleProviderLibrary
{
    public class MyRoleProvider : RoleProvider
    {
        public static int RoleHits = 0;

        public override string[] GetRolesForUser(string userName)
        {
            // sanity check input
            if (!Regex.IsMatch(userName, "^[A-Za-z0-9]+$"))
                throw new FormatException("Invalid user name");

            // load roles.xml
            string roleFile = ConfigurationManager.AppSettings["roleFile"];
            if (string.IsNullOrEmpty(roleFile))
                throw new ApplicationException("Please configure an <appSetting> for roleFile");
            XPathNavigator rolesNav = new XPathDocument(roleFile).CreateNavigator();

            // quick search to find all roles in which the user is a member
            string xpathQuery = string.Format(
                "/roles/role/user[@name='{0}']/../@name",
                userName);
            List<string> roles = new List<string>();
            foreach (XPathNavigator roleNav in rolesNav.Select(xpathQuery))
                roles.Add(roleNav.Value);

            ++RoleHits;

            return roles.ToArray();
        }

        #region management features that I don't need
        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override string ApplicationName
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public override void CreateRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override bool IsUserInRole(string username, string roleName)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
