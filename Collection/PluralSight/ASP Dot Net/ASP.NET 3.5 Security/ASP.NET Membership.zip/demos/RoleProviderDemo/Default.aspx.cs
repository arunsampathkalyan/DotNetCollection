﻿using System;
using System.Web.UI;
using System.Web.Security;
using System.Security.Principal;
using System.Web.UI.WebControls;
using RoleProviderLibrary;

public partial class _Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblHits.Text = MyRoleProvider.RoleHits.ToString();

        ListBox lstRoles = (ListBox)myLoginView.FindControl("lstRoles");
        if (null != lstRoles)
        {
            //lstRoles.Items.Clear();
            //if (User.IsInRole("nurse"))
            //    lstRoles.Items.Add("nurse");
            //if (User.IsInRole("doctor"))
            //    lstRoles.Items.Add("doctor");

            RolePrincipal user = User as RolePrincipal;
            if (null != user)
            {
                lstRoles.DataSource = user.GetRoles();
                lstRoles.DataBind();
            }
        }
    }

    protected void Logout_Click(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Response.Redirect(Request.Path);
    }
}
