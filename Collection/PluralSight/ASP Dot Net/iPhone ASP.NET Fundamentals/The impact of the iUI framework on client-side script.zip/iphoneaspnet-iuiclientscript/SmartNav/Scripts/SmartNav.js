﻿function smartNavigation(panelId, panelUrl) {
    var thePanel = document.getElementById(panelId);
    if (thePanel)
        iui.showPage(thePanel);
    else
        iui.showPageByHref(panelUrl, null, 'GET', null, null);
};

function onPanelFocus(event) {
    var rightButton = document.getElementById('rightButton');
    if (rightButton) {
        var thePanel = event.target;
        var rightButtonText = thePanel.getAttribute('rbtnText');
        if (rightButtonText) {
            rightButton.style.display = 'inline';
            rightButton.textContent = rightButtonText;
            var rightButtonHref = thePanel.getAttribute('rbtnHref');
            if (rightButtonHref)
                rightButton.setAttribute('href', rightButtonHref);
        }
        else
            rightButton.style.display = 'none';
    }
};

function addPanelFocusHandler(event) {
    var rightButton = document.getElementById('rightButton');
    if (rightButton)
        rightButton.style.display = 'none';

    for (var thePanel = document.body.firstElementChild; thePanel; thePanel = thePanel.nextElementSibling) {
        thePanel.addEventListener('focus', onPanelFocus, false);
    };
};

function addLineToList(event) {
//    console.log('beforeinsert: ' + event.fragment.outerHTML);
    var firstPanel = event.fragment.firstElementChild;
    if (firstPanel && firstPanel.nodeName == 'UL' && firstPanel.id != 'allClassesPanel') {
        var line = document.createElement('li');
        line.innerHTML = '<a href="AllClasses1.htm">All Classes</a>';
        firstPanel.appendChild(line);
    }
};

function logAfterInsert(event) {
//    console.log('afterinsert: ' + (event.insertedNode.nodeType == 1 ?
//        event.insertedNode.outerHTML :
//        event.insertedNode.nodeValue + '(whitespace)'));
};

addEventListener('load', addPanelFocusHandler, false);

addEventListener('load',
    function () {
        document.body.addEventListener('beforeinsert', addLineToList);
        document.body.addEventListener('afterinsert', logAfterInsert);
    }, false);