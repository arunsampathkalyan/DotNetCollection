﻿function onPlayControlClick(event) {
    var videoPlayer = document.getElementById('videoPlayer');
    if (videoPlayer) 
        videoPlayer.play();

    var hourGlass = document.getElementById('hourGlass');
    if (hourGlass)
        hourGlass.style.display = 'block';
};

function onVideoPlayerPlaying(event) {
    var hourGlass = document.getElementById('hourGlass');
    if (hourGlass)
        hourGlass.style.display = 'none';
};

function onLoad(event) {
    var playControl = document.getElementById('playControl');
    if (playControl)
        playControl.addEventListener('click', onPlayControlClick, false);

    var videoPlayer = document.getElementById('videoPlayer');
    if (videoPlayer)
        videoPlayer.addEventListener('playing', onVideoPlayerPlaying, false);

    /**************************************************************************************************

    The URL referenced by the video element's src attribute refers to mobile video content from
    the Pluralsight iPhone ASP.NET course. Url's to this content are secured and expire 1 hour
    after capture. 
    To run this demo, you need to replace the video element's src attribute with a URL to any valid
    MP4 (or H.264) file. 

    */

    var warning1 = 'You need to replace the original Video "src" attribute value, it was a secured reference and has expired';
    var warning2 = 'You can replace it with any valid URL referencing an MP4 file';
    alert(warning1);
    alert(warning2);
    console.error(warning1);
    console.log(warning2);
    /************************************************************************************************ */

};

addEventListener('load', onLoad, false);