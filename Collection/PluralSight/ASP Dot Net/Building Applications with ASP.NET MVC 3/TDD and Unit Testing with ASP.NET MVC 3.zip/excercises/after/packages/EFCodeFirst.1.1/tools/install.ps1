param($installPath, $toolsPath, $package, $project)
$dte.ItemOperations.OpenFile($toolsPath + '\EFCodeFirstReadMe.txt')
