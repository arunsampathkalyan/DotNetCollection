﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OdeToFood.Tests.ReviewTests
{
    class RateResult
    {
        public int Rating { get; set; }
    }
}
