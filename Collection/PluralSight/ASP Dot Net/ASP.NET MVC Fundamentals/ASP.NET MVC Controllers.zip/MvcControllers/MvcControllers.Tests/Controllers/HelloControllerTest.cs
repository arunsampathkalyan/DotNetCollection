﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MvcControllers.Controllers;
using System.Web.Routing;
using MvcControllers.Tests.TestDoubles;

namespace MvcControllers.Tests.Controllers
{
    [TestClass]
    public class When_HelloController_Executes
    {
        [TestMethod]
        public void Writes_To_The_Log()
        {
            var logger = new FakeLogger();
            var controller = new HelloController(logger);
            //controller.Execute(new FakeRequestContext());

            Assert.IsNotNull(logger.LogResult);
            Assert.IsTrue(logger.LogResult.Length > 0);
        }
    }
}
