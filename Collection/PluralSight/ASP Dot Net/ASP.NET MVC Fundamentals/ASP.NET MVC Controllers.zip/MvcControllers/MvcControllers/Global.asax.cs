﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MvcControllers.Infrastructure;
using StructureMap;
using MvcControllers.Controllers;
using System.Web.Security;

namespace MvcControllers
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "SayHello",
                "Hello",
                new { controller = "Hello", action="SayHello", id=99 }
            );              

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );

        }

        protected void Application_Start()
        {
            RegisterRoutes(RouteTable.Routes);
            ControllerBuilder.Current.SetControllerFactory(new MyControllerFactory());
            ConfigureContainer();
        }

        private void ConfigureContainer()
        {
            StructureMapConfiguration
                .ForRequestedType<ILogger>()
                .TheDefaultIsConcreteType<SqlServerLogger>();
            StructureMapConfiguration
                .ForRequestedType<IFormsAuthentication>()
                .TheDefaultIsConcreteType<FormsAuthenticationService>();
            StructureMapConfiguration
                .ForRequestedType<IMembershipService>()
                .TheDefaultIsConcreteType<AccountMembershipService>();
            StructureMapConfiguration
                .ForRequestedType<MembershipProvider>()
                .AddInstance(Membership.Provider);
        }
    }
}