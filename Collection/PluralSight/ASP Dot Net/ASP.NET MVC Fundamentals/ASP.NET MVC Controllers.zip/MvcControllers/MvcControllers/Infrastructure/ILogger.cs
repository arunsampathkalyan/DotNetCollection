﻿using System;

namespace MvcControllers.Infrastructure
{
    public interface ILogger
    {
        void Log(string message);
    }
}
