﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcControllers.Infrastructure;

namespace MvcControllers.Controllers
{
    [Log]
    public class HelloController : Controller
    {
        public HelloController(ILogger logger)
        {
            _logger = logger;
        }

     
        public ActionResult SayHello(int id)
        {
            return View("Hello");
        }


        //public void Execute(System.Web.Routing.RequestContext requestContext)
        //{
        //    requestContext.HttpContext.Response.Write("Hello, World");
        //    _logger.Log("Message");
        //}

        ILogger _logger = null;
    }
}
