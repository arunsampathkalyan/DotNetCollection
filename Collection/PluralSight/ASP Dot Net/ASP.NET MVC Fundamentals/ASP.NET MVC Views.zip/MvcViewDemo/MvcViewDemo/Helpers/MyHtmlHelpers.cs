﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using MvcViewDemo;
using System.Web.Routing;

namespace MvcDemo
{
    public static class MyHtmlHelpers
    {
        public static TagBuilder Image(this HtmlHelper helper,
                                       string imageUrl, string alt)
        {
            if (!String.IsNullOrEmpty(imageUrl))
            {
                TagBuilder imageTag = new TagBuilder("img");
                imageTag.MergeAttribute("src", imageUrl);
                imageTag.MergeAttribute("alt", alt);
                return imageTag;
            }
            return null;
        }
    }
}
