using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcViewDemo.Models;
using MvcContrib.Pagination;

namespace MvcViewDemo.Controllers
{
    public class MovieController : Controller
    {
        //
        // GET: /Movie/

        public ActionResult Index(int? page)
        {
            var ctx = new MoviesContext();
            var movies = ctx.Movies
                            .OrderByDescending(m => m.ReleaseDate)
                            .AsPagination(page ?? 1, 10);
            return View(movies);
        }

        //
        // GET: /Movie/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /Movie/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Movie/Create

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Movie/Edit/5
 
        public ActionResult Edit(int id)
        {
            var ctx = new MoviesContext();
            var movie = ctx.Movies.Where(m => m.ID == id).First();

            return View(movie);
        }

        //
        // POST: /Movie/Edit/5
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            var ctx = new MoviesContext();
            var movie = ctx.Movies.Where(m => m.ID == id).First();

            TryUpdateModel(movie, new string[] { "Title", "ReleaseDate" }, collection.ToValueProvider());

            // validation
            if (String.IsNullOrEmpty(movie.Title))
            {
                ModelState.AddModelError("Title", "Title cannot be empty");
            }

            if (ModelState.IsValid)
            {
                ctx.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(movie);
        }
    }
}
