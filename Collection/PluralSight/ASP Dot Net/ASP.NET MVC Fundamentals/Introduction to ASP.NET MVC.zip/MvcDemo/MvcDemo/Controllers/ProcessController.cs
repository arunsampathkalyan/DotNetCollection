using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Diagnostics;

namespace MvcDemo.Controllers
{
    [Authorize]
    public class ProcessController : Controller
    {
        //
        // GET: /Process/
       
        public ViewResult List()
        {
            var processList = from p in Process.GetProcesses()
                              select p;

            ViewData.Model = processList.ToList();

            return View();
        }

        //
        // GET: /Process/Details/5

        public ActionResult Details(int id)
        {
            var process = (from p in Process.GetProcesses()
                           where p.Id == id
                           select p).Single();

           return View(process);
        }

        //
        // GET: /Process/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        // POST: /Process/Create

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Process/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Process/Edit/5

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
 
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
