﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcModelDemo.Binders
{
    public class DateTimeModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, 
                                ModelBindingContext bindingContext)
        {
            ValueProviderResult result;
            bindingContext.ValueProvider.TryGetValue(bindingContext.ModelName, out result);
            if (result == null)
            {
                return null;
            }
            bindingContext.ModelState.SetModelValue(bindingContext.ModelName, result);

            DateTime dateTimeResult;
            if (DateTime.TryParse(result.AttemptedValue, out dateTimeResult))
            {
                return dateTimeResult;
            }

            int intResult;
            if (int.TryParse(result.AttemptedValue, out intResult))
            {
                return new DateTime(intResult, 1, 1);
            }

            bindingContext.ModelState.AddModelError(bindingContext.ModelName, "Could not convert DateTime");
            return null;
        }
    }

}
