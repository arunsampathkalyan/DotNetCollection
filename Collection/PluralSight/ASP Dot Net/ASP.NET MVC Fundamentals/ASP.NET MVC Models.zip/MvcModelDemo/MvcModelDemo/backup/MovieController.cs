using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcModelDemo.Models;

namespace MvcModelDemo.Controllers
{
    public class MovieController : Controller
    {
        public ActionResult Index(string q)
        {
            using (var context = new MoviesContext())
            {
                var movies = context.MovieSet
                                    .Where(m => q == null || m.Title.StartsWith(q))
                                    .OrderByDescending(m => m.Reviews.Average(r => r.Rating))
                                    .Take(10)
                                    .Select(m => new MovieSummary
                                    {
                                        ID = m.ID,
                                        Title = m.Title,
                                        ReleaseYear = m.ReleaseDate.Year,
                                        AverageRating = m.Reviews.Average(r => r.Rating)
                                    });

                return View(movies.ToList());
            }
        }    

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Delete(int id)
        {
            using (var ctx = new MoviesContext())
            {
                var movie = ctx.MovieSet.Where(m => m.ID == id).First();
                ctx.DeleteObject(movie);
                ctx.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Details(int id)
        {
            using (var ctx = new MoviesContext())
            {
                var movie = ctx.MovieSet
                               .Include("Reviews")
                               .Where(m => m.ID == id).First();

                return View(movie);
            }
        }

        public ActionResult Create()
        {
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create([Bind(Exclude = "ID")] Movie movie)
        {
            if (ModelState.IsValid)
            {
                using (var ctx = new MoviesContext())
                {
                    ctx.AddToMovieSet(movie);
                    ctx.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            return View();
        }

        public ActionResult Edit(int id)
        {
            using (var ctx = new MoviesContext())
            {
                var movie = ctx.MovieSet.Where(m => m.ID == id).First();
                return View(movie);
            }
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection)
        {
            using (var ctx = new MoviesContext())
            {
                var movie = ctx.MovieSet.Where(m => m.ID == id).First();
                TryUpdateModel(movie, new string[] { "Title", "ReleaseDate" });
                if (ModelState.IsValid)
                {
                    ctx.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(movie);
            }
        }
    }
}
