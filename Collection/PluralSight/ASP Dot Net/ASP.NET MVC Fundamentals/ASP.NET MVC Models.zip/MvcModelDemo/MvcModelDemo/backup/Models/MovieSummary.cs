﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcModelDemo.Models
{
    public class MovieSummary
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int ReleaseYear { get; set; }
        public double? AverageRating { get; set; }
    }
}
