﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcModelDemo.Models
{

    public interface IMovieBinding
    {
        string Name { get; set; }
        DateTime HireDate { get; set; }
    }

    public class Employee : IMovieBinding
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public DateTime HireDate { get; set; }
    }
}
