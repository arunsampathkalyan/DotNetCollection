﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Models
{
    public class Instructor
    {
        public string Name { get; set; }
        public string TwitterHandle { get; set; }
        public string HtmlDescription { get; set; }
    }
   
}