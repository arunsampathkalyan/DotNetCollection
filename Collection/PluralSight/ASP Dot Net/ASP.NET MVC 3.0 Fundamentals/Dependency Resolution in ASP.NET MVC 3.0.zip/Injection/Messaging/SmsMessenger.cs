﻿namespace Injection.Messaging
{
    class SmsMessenger : IMessenger
    {
        public void SendMessage(string message)
        {
            // ...
        }
    }
}