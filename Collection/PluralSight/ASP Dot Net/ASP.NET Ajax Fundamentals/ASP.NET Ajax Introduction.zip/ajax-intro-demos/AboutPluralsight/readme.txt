AboutPluralsight demo (Module 1):

  Idea is that AJAX is used to enhance this app; if client doesn't support
AJAX/JavaScript, will fall back on standard post-back model.  First, 
lookup the instructors Joe or Fritz and it should work, other instructors
not found.  Then, to see what would happen if user doesn't support AJAX
or JavaScript, disable in IE: Tools, internet options, Security tab, 
Local intranet, Custom level, scroll way down to Scripting section,
disable Active scripting.  Now close IE, and then re-run the app --- now
app falls back on post-backs.

  When you are done, don't forget to reset IE's Local intranet back to
default level.

#################