using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page 
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}

	protected void cmdInstructorInfo_Click(object sender, EventArgs e)
	{
		if (!this.IsValid)  // make sure client-side validation wasn't bypassed:
			return;

		if (this.txtInstructorName.Value.Equals("fritz", StringComparison.CurrentCultureIgnoreCase))
		{
			this.divInstructorInfo.InnerHtml = "<ul>";
			this.divInstructorInfo.InnerHtml += "<li>hails from Maine</li>";
			this.divInstructorInfo.InnerHtml += "<li>long live the web!</li>";
			this.divInstructorInfo.InnerHtml += "<li>avid cyclist</li>";
			this.divInstructorInfo.InnerHtml += "</ul>";
		}
		else if (this.txtInstructorName.Value.Equals("joe", StringComparison.CurrentCultureIgnoreCase))
		{
			this.divInstructorInfo.InnerHtml = "<ul>";
			this.divInstructorInfo.InnerHtml += "<li>lives in Chicago</li>";
			this.divInstructorInfo.InnerHtml += "<li>long live the web, and</li>";
			this.divInstructorInfo.InnerHtml += "<li>long live the desktop!</li>";
			this.divInstructorInfo.InnerHtml += "<li>avid sailor</li>";
			this.divInstructorInfo.InnerHtml += "</ul>";
		}
		else
		{
			this.divInstructorInfo.InnerHtml = "<br /><p align='center'>Unknown instructor!<br />[via post-back]</p><br /><br />";
		}
	}

}
