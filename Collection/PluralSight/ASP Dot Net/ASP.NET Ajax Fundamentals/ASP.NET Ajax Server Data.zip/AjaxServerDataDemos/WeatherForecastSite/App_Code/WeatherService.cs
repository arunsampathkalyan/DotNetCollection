﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

[ServiceContract(Namespace = "http://www.pluralsight.com/ws/")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class WeatherService
{
  private static Random _rand = new Random();

	[OperationContract]
	public string GetForecast(string zipCode)
	{
    string forecast = "";
    switch (_rand.Next(3))
    {
      case 0:
        forecast = "Sunny and warm";
        break;
      case 1:
        forecast = "Chilly and overcast";
        break;
      case 2:
        forecast = "Hot and humid";
        break;
    }
    return forecast;
	}

	// Add more operations here and mark them with [OperationContract]
}
