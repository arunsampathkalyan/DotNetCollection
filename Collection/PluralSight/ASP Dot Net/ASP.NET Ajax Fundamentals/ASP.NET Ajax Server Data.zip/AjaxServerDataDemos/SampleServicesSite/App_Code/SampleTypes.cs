using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Web.Script.Serialization;

namespace PS.SampleTypes
{
    [DataContract]
    public class Person
    {
        [DataMember]
        public bool Married { get; set; }
        
        [DataMember]
        public int Age { get; set; }
        
        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string LastName { get; set; }
    }

    [DataContract]
    public class Company
    {
        private List<Person> _employees = new List<Person>();
        
        [DataMember]
        public List<Person> Employees
        {
          get { return _employees; }
          set { _employees = value; }
        }

        [DataMember]
        public string Name { get; set; }
    }

    [DataContract]
    public class Company2
    {
        private ArrayList _employees = new ArrayList();

        [DataMember]
        public ArrayList Employees
        {
            get { return _employees; }
            set { _employees = value; }
        }

        [DataMember]
        public string Name { get; set; }
    }
}