﻿alert("my script3 was loaded!");

if (typeof (Sys) !== 'undefined')
    Sys.Application.notifyScriptLoaded();