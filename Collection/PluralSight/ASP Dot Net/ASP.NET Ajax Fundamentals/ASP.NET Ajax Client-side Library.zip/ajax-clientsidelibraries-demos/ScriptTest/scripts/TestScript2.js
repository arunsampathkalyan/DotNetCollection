﻿alert("my script2 was loaded!");

if (typeof (Sys) !== 'undefined')
    Sys.Application.notifyScriptLoaded();