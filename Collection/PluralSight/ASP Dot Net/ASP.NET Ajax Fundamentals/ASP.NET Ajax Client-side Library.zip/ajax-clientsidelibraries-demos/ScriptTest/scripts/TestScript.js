﻿alert("my script was loaded!");

if (typeof (Sys) !== 'undefined')
    Sys.Application.notifyScriptLoaded();