﻿
Type.registerNamespace("AjaxClassBrowser");

AjaxClassBrowser.TreeView = function(associatedElement) {
    this._element = associatedElement;
    this._typeSelectedHandler = null;
}

AjaxClassBrowser.TreeView.prototype = {

    setTypeSelectedHandler : function(handler) {
        this._typeSelectedHandler = handler;
    },

    render : function(include, exclude, includeRoot, showPrivateMembers, unknowns) {
        this._element.innerHTML = '';

        if (includeRoot)  // root are the types:
					this._renderNamespace(null, this._element, showPrivateMembers, unknowns);
        
        var namespaceNames = AjaxClassBrowser.Reflection.TypeInfo.getNamespaces();
        
        for (var i = 0; i < namespaceNames.length; i++) {
						if (namespaceNames[i].startsWith("AjaxClassBrowser"))
							;  // ignore, our code
						else if (namespaceNames[i].startsWith(include) && !namespaceNames[i].startsWith(exclude))
              this._renderNamespace(namespaceNames[i], this._element, showPrivateMembers, unknowns);
            else
							;  // ignore
        }
        
        this._renderUnknowns(unknowns, this._element);
    },

    _renderNamespace : function(namespaceName, parentElem, showPrivateMembers, unknowns) {
        // Container for the namespace
        var namespaceElem = document.createElement("div");
        namespaceElem.style.whiteSpace = "nowrap";
        namespaceElem.namespaceName = namespaceName;

        // Indentation
        var indentElem = document.createElement("span");
        indentElem.innerHTML = "&nbsp;&nbsp;";
        namespaceElem.appendChild(indentElem);

        // + / - button
        var displayModeElement = document.createElement("img");
        displayModeElement.src = "Images/collapse.gif";
        displayModeElement.alt = "Expand / Collapse";
        displayModeElement.width = 16;
        displayModeElement.height = 16;
        displayModeElement.__expanded = true;
        displayModeElement.style.cursor = "pointer";
        displayModeElement.onclick = function() {
            var currentTreeNode = displayModeElement.parentNode;

            displayModeElement.src = (displayModeElement.__expanded ? "Images/expand.gif" : "Images/collapse.gif");
            displayModeElement.__expanded = !displayModeElement.__expanded;

            for (var i = 0; i < currentTreeNode.childNodes.length; i++) {
                var childElement = currentTreeNode.childNodes[i];
                if (childElement.type) {
                    childElement.style.display = (displayModeElement.__expanded ? "" : "none");
                }
            }
        }
        namespaceElem.appendChild(displayModeElement);

        // Space
        var spaceElem = document.createElement("span");
        spaceElem.innerHTML = "&nbsp;";
        namespaceElem.appendChild(spaceElem);

        // Icon
        var iconElem = document.createElement("img");
        iconElem.src = "Images/namespace.gif";
        iconElem.alt = "Namespace";
        iconElem.width = 16;
        iconElem.height = 16;
        iconElem.align = "absbottom";
        namespaceElem.appendChild(iconElem);

        // Space 2
        var spaceElem2 = document.createElement("span");
        spaceElem2.innerHTML = "&nbsp;";
        namespaceElem.appendChild(spaceElem2);

        // Namespace name
        var nameElem = document.createElement("span");
        nameElem.innerHTML = namespaceName ? namespaceName : "Top-Level";
        namespaceElem.appendChild(nameElem);

        this._renderClasses(namespaceName, namespaceElem, showPrivateMembers, unknowns);

        parentElem.appendChild(namespaceElem);
    },
    
    _renderUnknowns : function(unknowns, parentElem) {
        // Container for the namespace
        var namespaceElem = document.createElement("div");
        namespaceElem.style.whiteSpace = "nowrap";
        namespaceElem.namespaceName = "UNKNOWNS";

        // Indentation
        var indentElem = document.createElement("span");
        indentElem.innerHTML = "&nbsp;&nbsp;";
        namespaceElem.appendChild(indentElem);

        // + / - button
        var displayModeElement = document.createElement("img");
        displayModeElement.src = "Images/collapse.gif";
        displayModeElement.alt = "Expand / Collapse";
        displayModeElement.width = 16;
        displayModeElement.height = 16;
        displayModeElement.__expanded = true;
        displayModeElement.style.cursor = "pointer";
        displayModeElement.onclick = function() {
            var currentTreeNode = displayModeElement.parentNode;

            displayModeElement.src = (displayModeElement.__expanded ? "Images/expand.gif" : "Images/collapse.gif");
            displayModeElement.__expanded = !displayModeElement.__expanded;

            for (var i = 1; i < currentTreeNode.childNodes.length; i++) {
                var childElement = currentTreeNode.childNodes[i];
                if (childElement.type) {
									childElement.style.display = (displayModeElement.__expanded ? "" : "none");
								}
            }
        }
        namespaceElem.appendChild(displayModeElement);

        // Space
        var spaceElem = document.createElement("span");
        spaceElem.innerHTML = "&nbsp;";
        namespaceElem.appendChild(spaceElem);

        // Icon
        var iconElem = document.createElement("img");
        iconElem.src = "Images/unknown.gif";
        iconElem.alt = "Namespace";
        iconElem.width = 16;
        iconElem.height = 16;
        iconElem.align = "absbottom";
        namespaceElem.appendChild(iconElem);

        // Space 2
        var spaceElem2 = document.createElement("span");
        spaceElem2.innerHTML = "&nbsp;";
        namespaceElem.appendChild(spaceElem2);

        // Namespace name
        var nameElem = document.createElement("span");
        nameElem.innerHTML = "UNKNOWNS";
        namespaceElem.appendChild(nameElem);
        
        for (var i = 0; i < unknowns.length; i++) {
            var typeElem = document.createElement("div");
            typeElem.style.whiteSpace = "nowrap";

            // Icon
            var iconElem = document.createElement("img");
            iconElem.src = "Images/unknown.gif";
            iconElem.alt = "Unknown type";
            iconElem.width = 16;
            iconElem.height = 16;
            iconElem.align = "absbottom";
            iconElem.style.paddingLeft = "3em";
            typeElem.appendChild(iconElem);

            // Space
            var spaceElem = document.createElement("span");
            spaceElem.innerHTML = "&nbsp;";
            typeElem.appendChild(spaceElem);

            // Name
            var nameElement = document.createElement("span");
            //nameElement.style.paddingLeft = "3em";
            nameElement.innerHTML = unknowns[i];
            nameElement.onmouseover = Function.createCallback(function(context) {
                this.style.color = '#ff2222';
            }, this);
            nameElement.onmouseout = Function.createCallback(function(context) {
                this.style.color = '';
            }, this);
            nameElement.typeSelectedHandler = this._typeSelectedHandler;
            nameElement.onclick = function() {
                if (this.typeSelectedHandler) {
                    this.typeSelectedHandler(this.parentNode.type);
                }
            };
            nameElement.style.cursor = "pointer";
            typeElem.appendChild(nameElement);

            namespaceElem.appendChild(typeElem);
        }

        parentElem.appendChild(namespaceElem);
    },

    _renderClasses : function(namespaceName, parentElem, showPrivateMembers, unknowns) {
        var typesInNamespace = AjaxClassBrowser.Reflection.TypeInfo.getTypes(namespaceName, unknowns);

        for (var i = 0; i < typesInNamespace.length; i++) {
            var type = typesInNamespace[i].get_type();
            var typeInfo = new AjaxClassBrowser.Reflection.TypeInfo(type);
            if (typeInfo.get_isInternal() && !showPrivateMembers) {
                continue;
            }
            var typeElem = document.createElement("div");
            typeElem.style.whiteSpace = "nowrap";
            typeElem.type = type;

            // Icon
            var iconElem = document.createElement("img");
            if (typeInfo.get_isClass()) {
                iconElem.src = "Images/class.gif";
                iconElem.alt = "Class";
            }
            else {
                if (typeInfo.get_isInterface()) {
                    iconElem.src = "Images/interface.gif";
                    iconElem.alt = "Interface";
                }
                else {
                    if (typeInfo.get_isEnum() || typeInfo.get_isFlags()) {
                        iconElem.src = "Images/enum.gif";
                        iconElem.alt = "Enumeration";
                    }
                    else {
                        iconElem.src = "Images/unknown.gif";
                        iconElem.alt = "Unknown type";
                    }
                }
            }
            iconElem.width = 16;
            iconElem.height = 16;
            iconElem.align = "absbottom";
            iconElem.style.paddingLeft = "3em";
            typeElem.appendChild(iconElem);

            // Space
            var spaceElem = document.createElement("span");
            spaceElem.innerHTML = "&nbsp;";
            typeElem.appendChild(spaceElem);

            // Name
            var nameElement = document.createElement("span");
            //nameElement.style.paddingLeft = "3em";
            nameElement.innerHTML = typesInNamespace[i].get_name();
            nameElement.onmouseover = Function.createCallback(function(context) {
                this.style.color = '#ff2222';
            }, this);
            nameElement.onmouseout = Function.createCallback(function(context) {
                this.style.color = '';
            }, this);
            nameElement.typeSelectedHandler = this._typeSelectedHandler;
            nameElement.onclick = function() {
                if (this.typeSelectedHandler) {
                    this.typeSelectedHandler(this.parentNode.type);
                }
            };
            nameElement.style.cursor = "pointer";
            typeElem.appendChild(nameElement);

            parentElem.appendChild(typeElem);
        }
    }
}

AjaxClassBrowser.TreeView.registerClass('AjaxClassBrowser.TreeView');

Sys.Application.notifyScriptLoaded();

