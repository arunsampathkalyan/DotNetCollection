﻿
Type.registerNamespace("AjaxClassBrowser");


AjaxClassBrowser.ClassWriter = function(type, inNamespace, showPrivateMembers) {
    this._type = type;
    this._inNamespace = inNamespace;
    this._showPrivateMembers = showPrivateMembers;
}

AjaxClassBrowser.ClassWriter.prototype = {
    _getPrettyParameters : function(parameters) {
        var paramText = new Sys.StringBuilder();
        for (var i = 0; i < parameters.length; i++) {
            if (i > 0) {
                paramText.append(", ");
            }
            this._writeType(paramText, parameters[i].get_parameterType());
            paramText.append(" ");
            paramText.append(parameters[i].get_name());
        }
        return paramText.toString();
    },

    _writeComment : function(stringBuilder, comment) {
        stringBuilder.append('<span style="color:green;">' + comment + '</span>');
    },

    _writeKeyword : function(stringBuilder, keyword) {
        stringBuilder.append('<span style="color:blue;">' + keyword + '</span>');
    },

    _writeType : function(stringBuilder, type) {
        var typeInfo = new AjaxClassBrowser.Reflection.TypeInfo(type);
        stringBuilder.append(typeInfo.get_name());
    },

    getTypeDefinition : function() {
        var i;
        var output = new Sys.StringBuilder();
        
        // handle unknown types:
        if (this._type == null)
					return '<h3><em>unknown</em></h3><br/>(try the documentation, which is <a target=\'null\' href=\'http://ajax.asp.net/docs/\'>here</a>)';

        // Force class hierarchy to merge
        this._type.resolveInheritance();

        var rawIndent = "&nbsp;&nbsp;&nbsp;&nbsp;";
        var classIndent = "";
        var memberIndent = rawIndent;

        if (this._inNamespace) {
            // If we're in a namespace, indent one more level
            classIndent += rawIndent;
            memberIndent += rawIndent;
        }

        var typeInfo = new AjaxClassBrowser.Reflection.TypeInfo(this._type);

        if (typeInfo.get_isInternal() && !this._showPrivateMembers) {
            return '';
        }


        // List type decorations
        output.append(classIndent);

        var typeVisibility = typeInfo.get_isInternal() ? "internal" : "public";
        this._writeKeyword(output, typeVisibility);
        output.append(" ");

        var typeType;
        if (typeInfo.get_isInterface()) {
            typeType = "interface";
        }
        else {
            if (typeInfo.get_isClass()) {
                typeType = "class";
            }
            else {
                if (typeInfo.get_isEnum()) {
                    typeType = "enum";
                }
                else {
                    if (typeInfo.get_isFlags()) {
                        typeType = "flags";
                    }
                    else {
                        // Default type is class (this applies to built-in JavaScript types)
                        typeType = "class";
                    }
                }
            }
        }
        this._writeKeyword(output, typeType);
        output.append(" ");

        this._writeType(output, this._type);

        // List base class
        if (typeInfo.get_isClass()) {
            var baseType = typeInfo.get_baseType();
            if (baseType) {
                output.append(" : ");
                    this._writeType(output, baseType);
            }
        }

        // List implemented interfaces
        var interfaces = typeInfo.get_interfaces();
        if (interfaces) {
            for (i = 0; i < interfaces.length; i++) {
                output.append(", ");
                this._writeType(output, interfaces[i]);
            }
        }
        output.append(" {<br />");

        var memberVisibility;

        // Constructor
        if (typeInfo.get_isClass()) {
            output.append(memberIndent);
            this._writeComment(output, "// Constructor");
            output.append("<br />");
            output.append(memberIndent);
            memberVisibility = "public";
            this._writeKeyword(output, memberVisibility)
            output.append(" " + typeInfo.get_name() + "(");
            output.append(this._getPrettyParameters(typeInfo.get_constructor().get_parameters()));
            output.append(");<br />");
            output.append("<br />");
        }


        // Fields
        var fields = typeInfo.get_fields();
        if (fields.length > 0) {
            var firstField = true;
            for (i = 0; i < fields.length; i++) {
                if (fields[i].get_isPrivate() && !this._showPrivateMembers) {
                    continue;
                }

                if (firstField) {
                    output.append(memberIndent);
                    this._writeComment(output, "// Fields");
                    output.append("<br />");
                }
                firstField = false;

                output.append(memberIndent);
                memberVisibility = fields[i].get_isPrivate() ? "private" : "public";
                this._writeKeyword(output, memberVisibility)
                output.append(" ");
                if (fields[i].get_isStatic()) {
                    this._writeKeyword(output, "static");
                    output.append(" ");
                }
                this._writeType(output, fields[i].get_fieldType());
                output.append(" ");
                output.append(fields[i].get_name());
                output.append(";");
                output.append("<br />");
            }
            if (!firstField) {
                output.append("<br />");
            }
        }

        // Properties
        var properties = typeInfo.get_properties();
        if (properties.length > 0) {
            var firstProperty = true;
            for (i = 0; i < properties.length; i++) {
                if (properties[i].get_isPrivate() && !this._showPrivateMembers) {
                    continue;
                }

                if (firstProperty) {
                    output.append(memberIndent);
                    this._writeComment(output, "// Properties");
                    output.append("<br />");
                }
                firstProperty = false;

                output.append(memberIndent);
                memberVisibility = properties[i].get_isPrivate() ? "private" : "public";
                this._writeKeyword(output, memberVisibility)
                output.append(" ");
                if (properties[i].get_isStatic()) {
                    this._writeKeyword(output, "static");
                    output.append(" ");
                }
                if (properties[i].get_isOverride()) {
                    this._writeKeyword(output, "override");
                    output.append(" ");
                }
                this._writeType(output, properties[i].get_propertyType());
                output.append(" ");
                output.append(properties[i].get_name());
                output.append(" { ");
                if (properties[i].get_getMethod()) {
                    this._writeKeyword(output, "get");
                    output.append("; ");
                }
                if (properties[i].get_setMethod()) {
                    this._writeKeyword(output, "set");
                    output.append("; ");
                }
                output.append(" };");
                output.append("<br />");
            }
            if (!firstProperty) {
                output.append("<br />");
            }
        }

        // Events
        var events = typeInfo.get_events();
        if (events.length > 0) {
            var firstEvent = true;
            for (i = 0; i < events.length; i++) {
                if (events[i].get_isPrivate() && !this._showPrivateMembers) {
                    continue;
                }

                if (firstEvent) {
                    output.append(memberIndent);
                    this._writeComment(output, "// Events");
                    output.append("<br />");
                }
                firstEvent = false;

                output.append(memberIndent);
                memberVisibility = events[i].get_isPrivate() ? "private" : "public";
                this._writeKeyword(output, memberVisibility)
                output.append(" ");
                if (events[i].get_isStatic()) {
                    this._writeKeyword(output, "static");
                    output.append(" ");
                }
                if (events[i].get_isOverride()) {
                    this._writeKeyword(output, "override");
                    output.append(" ");
                }
                this._writeKeyword(output, "event");
                output.append(" ");
                this._writeType(output, events[i].get_eventType());
                output.append(" ");
                output.append(events[i].get_name());
                output.append(" { ");
                if (events[i].get_addMethod()) {
                    this._writeKeyword(output, "add");
                    output.append("; ");
                }
                if (events[i].get_removeMethod()) {
                    this._writeKeyword(output, "remove");
                    output.append("; ");
                }
                output.append("};");
                output.append("<br />");
            }
            if (!firstEvent) {
                output.append("<br />");
            }
        }

        // Methods
        var methods = typeInfo.get_methods();
        if (methods.length > 0) {
            var firstMethod = true;
            for (i = 0; i < methods.length; i++) {
                if (methods[i].get_isPrivate() && !this._showPrivateMembers) {
                    continue;
                }

                if (firstMethod) {
                    output.append(memberIndent);
                    this._writeComment(output, "// Methods");
                    output.append("<br />");
                }
                firstMethod = false;

                output.append(memberIndent);
                memberVisibility = methods[i].get_isPrivate() ? "private" : "public";
                this._writeKeyword(output, memberVisibility)
                output.append(" ");
                if (methods[i].get_isStatic()) {
                    this._writeKeyword(output, "static");
                    output.append(" ");
                }
                if (methods[i].get_isOverride()) {
                    this._writeKeyword(output, "override");
                    output.append(" ");
                }
                this._writeType(output, methods[i].get_returnType());
                output.append(" ");
                output.append(methods[i].get_name());
                output.append("(");
                output.append(this._getPrettyParameters(methods[i].get_parameters()));
                output.append(");");
                output.append("<br />");
            }
            if (!firstMethod) {
                output.append("<br />");
            }
        }

        output.append(classIndent + "}<br><br>");
        return output.toString();
    }
}

AjaxClassBrowser.ClassWriter.registerClass("AjaxClassBrowser.ClassWriter");

Sys.Application.notifyScriptLoaded();