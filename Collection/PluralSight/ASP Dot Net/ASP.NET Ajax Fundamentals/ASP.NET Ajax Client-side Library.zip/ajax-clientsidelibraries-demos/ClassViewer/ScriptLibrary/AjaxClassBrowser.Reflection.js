﻿
Type.registerNamespace("AjaxClassBrowser.Reflection");


AjaxClassBrowser.Reflection.MethodInfo = function(method, methodName, isPrivate, isStatic, isOverride) {
    this._methodName = methodName;
    this._method = method;
    this._isPrivate = isPrivate;
    this._isStatic = isStatic;
    this._isOverride = isOverride;

    this._returnType = null;
    this._parameters = null;
}

AjaxClassBrowser.Reflection.MethodInfo.prototype = {
    get_name : function() {
        return this._methodName;
    },

    get_parameters : function() {
        this._ensureMetaData();
        return this._parameters;
    },

    get_isStatic : function() {
        return this._isStatic;
    },

    get_isOverride : function() {
        return this._isOverride;
    },

    get_isPrivate : function() {
        return this._isPrivate;
    },

    get_returnType : function() {
        this._ensureMetaData();
        return this._returnType;
    },

    get_method : function() {
        return this._method;
    },

    _ensureMetaData : function() {
        this._returnType = Object;

        var source = this._method.toString();
        var indexOfOpen = source.indexOf("(");
        var indexOfClose = source.indexOf(")");

        this._parameters = [];

        var paramText = source.substring(indexOfOpen + 1, indexOfClose);
        if (paramText.trim().length > 0) {
            // If we find parameters, parse them out
            var parameterNames = paramText.split(',');
            for (var i = 0; i < parameterNames.length; i++) {
                var paramName = parameterNames[i].trim();
                // TODO: Make this smarter by using XML metadata
                Array.add(this._parameters, new AjaxClassBrowser.Reflection.ParameterInfo(paramName, Object));
            }
        }
    }
}

AjaxClassBrowser.Reflection.MethodInfo.registerClass('AjaxClassBrowser.Reflection.MethodInfo');



AjaxClassBrowser.Reflection.ParameterInfo = function(name, parameterType) {
    this._name = name;
    this._parameterType = parameterType;
}

AjaxClassBrowser.Reflection.ParameterInfo.prototype = {
    get_name : function() {
        return this._name;
    },

    get_parameterType : function() {
        return this._parameterType;
    }
}

AjaxClassBrowser.Reflection.ParameterInfo.registerClass('AjaxClassBrowser.Reflection.ParameterInfo');



AjaxClassBrowser.Reflection.PropertyInfo = function(propertyName, getMethod, setMethod, isPrivate, isStatic, isOverride) {
    this._propertyName = propertyName;
    this._getMethod = getMethod;
    this._setMethod = setMethod;
    this._isPrivate = isPrivate;
    this._isStatic = isStatic;
    this._isOverride = isOverride;
}

AjaxClassBrowser.Reflection.PropertyInfo.prototype = {

    get_isStatic : function() {
        return this._isStatic;
    },

    get_isOverride : function() {
        return this._isOverride;
    },

    get_isPrivate : function() {
        return this._isPrivate;
    },

    get_name : function() {
        return this._propertyName;
    },

    get_propertyType : function() {
        // TODO: Make this smarter by using XML metadata
        return Object;
    },

    get_getMethod : function() {
        return this._getMethod;
    },

    get_setMethod : function() {
        return this._setMethod;
    }
}

AjaxClassBrowser.Reflection.PropertyInfo.registerClass('AjaxClassBrowser.Reflection.PropertyInfo');


AjaxClassBrowser.Reflection.FieldInfo = function(fieldName, isPrivate, isStatic, fieldType) {
    this._fieldName = fieldName;
    this._isPrivate = isPrivate;
    this._isStatic = isStatic;
    this._fieldType = fieldType;
}

AjaxClassBrowser.Reflection.FieldInfo.prototype = {

    get_fieldType : function() {
        // TODO: Make this smarter by using XML metadata? Is there even metadata for fields?
        return this._fieldType;
    },

    get_isStatic : function() {
        return this._isStatic;
    },

    get_isPrivate : function() {
        return this._isPrivate;
    },

    get_name : function() {
        return this._fieldName;
    }
}

AjaxClassBrowser.Reflection.FieldInfo.registerClass('AjaxClassBrowser.Reflection.FieldInfo');


AjaxClassBrowser.Reflection.EventInfo = function(eventName, addMethod, removeMethod, isPrivate, isStatic, isOverride) {
    this._eventName = eventName;
    this._addMethod = addMethod;
    this._removeMethod = removeMethod;
    this._isPrivate = isPrivate;
    this._isStatic = isStatic;
    this._isOverride = isOverride;
}

AjaxClassBrowser.Reflection.EventInfo.prototype = {

    get_eventType : function() {
        // TODO: Make this smarter by using XML metadata
        return Object;
    },

    get_isStatic : function() {
        return this._isStatic;
    },

    get_isOverride : function() {
        return this._isOverride;
    },

    get_isPrivate : function() {
        return this._isPrivate;
    },

    get_name : function() {
        return this._eventName;
    },

    get_addMethod : function() {
        return this._addMethod;
    },

    get_removeMethod : function() {
        return this._removeMethod;
    }
}

AjaxClassBrowser.Reflection.EventInfo.registerClass('AjaxClassBrowser.Reflection.EventInfo');





AjaxClassBrowser.Reflection.TypeInfo = function(type) {
    this._type = type;
    type.resolveInheritance();
}

AjaxClassBrowser.Reflection.TypeInfo.prototype = {
    _ensureMetaData : function() {
        if (!this._methods) {
            // Create the metadata if it has not been done yet
            this._constructor =
                new AjaxClassBrowser.Reflection.MethodInfo(
                    this._type, this._type.getName(),
                    false /* isPrivate */, false /* isStatic */, false /* isOverride */);

            this._events = [];
            this._methods = [];
            this._properties = [];
            this._fields = [];

            var propertiesFound = [];
            var eventsFound = [];

            if (!this.get_isEnum() && !this.get_isFlags()) {
                // This is a regular class or interface

                // Static members
                for (var memberName in this._type) {
                    if (this._skipMember(memberName, propertiesFound, eventsFound)) {
                        continue;
                    }

                    var memberInstance = this._type[memberName];

                    if (memberInstance instanceof Function) {
                        var baseType = this.get_baseType();
                        var baseMethod;
                        if (baseType && (typeof(baseType[memberName]) !== "undefined")) {
                            baseMethod = baseType[memberName];
                        }
                        else {
                            baseMethod = null;
                        }
                        if (baseMethod) {
                            if (baseMethod !== memberInstance) {
                                // If we have a base method but it's different from the current one, it's an override
                                this._processMember(memberName, memberInstance, true, true, this._type, propertiesFound, eventsFound);
                            }
                        }
                        else {
                            this._processMember(memberName, memberInstance, true, false, this._type, propertiesFound, eventsFound);
                        }
                    }
                    else {
                        var fieldType = Object;
                        if (memberInstance) {
                            fieldType = Object.getType(memberInstance);
                        }
                        this._processField(memberName, true /*isStatic*/, fieldType);
                    }
                }

                // Instance members
                for (var memberName in this._type.prototype) {
                    if (this._skipMember(memberName, propertiesFound, eventsFound)) {
                        continue;
                    }

                    var memberInstance = this._type.prototype[memberName];

                    if (memberInstance instanceof Function) {
                        var baseType = this.get_baseType();

                        var baseMethod;
                        if (baseType && (typeof(baseType.prototype[memberName]) !== "undefined")) {
                            baseMethod = baseType.prototype[memberName];
                        }
                        else {
                            baseMethod = null;
                        }

                        if (baseMethod) {
                            if (baseMethod !== memberInstance) {
                                // If we have a base method but it's different from the current one, it's an override
                                this._processMember(memberName, memberInstance, false, true, this._type.prototype, propertiesFound, eventsFound);
                            }
                        }
                        else {
                            this._processMember(memberName, memberInstance, false, false, this._type.prototype, propertiesFound, eventsFound);
                        }
                    }
                    else {
                        var fieldType = Object;
                        if (memberInstance) {
                            fieldType = Object.getType(memberInstance);
                        }
                        this._processField(memberName, false /*isStatic*/, fieldType);
                    }
                }

                this._events.sort(this._memberSort);
                this._methods.sort(this._memberSort);
                this._properties.sort(this._memberSort);
                this._fields.sort(this._memberSort);
            }
            else {
                // This is either an enum or a flags
                for (var memberName in this._type.prototype) {
                    this._processField(memberName, true /*isStatic*/, Number);
                }
                // Enums and flags only have field members, no other members
                this._fields.sort(this._memberSort);
            }
        }
    },

    _memberSort : function(x, y) {
        if (x.get_name() < y.get_name()) {
            return -1;
        }
        if (x.get_name() > y.get_name()) {
            return 1;
        }
        return 0;
    },

    _processField : function(memberName, isStatic, type) {
        if (!type) {
            type = Object;
        }
        // Look for an underscore to determine if the member is private
        var isPrivate = false;
        if (memberName.startsWith("_")) {
            isPrivate = true;
        }

        Array.add(this._fields, new AjaxClassBrowser.Reflection.FieldInfo(memberName, isPrivate, isStatic, type));
    },

    _processMember : function(memberName, memberInstance, isStatic, isOverride, memberContainer, propertiesFound, eventsFound) {
        // Look for an underscore to determine if the member is private
        var isPrivate = false;
        var testMemberName = memberName;
        if (testMemberName.startsWith("_")) {
            testMemberName = testMemberName.substring(1, testMemberName.length);
            isPrivate = true;
        }

        if (testMemberName.startsWith("get_")) {
            var propertyName = testMemberName.substring(4, testMemberName.length);
            var setMethod = memberContainer["set_" + propertyName];
            Array.add(this._properties, new AjaxClassBrowser.Reflection.PropertyInfo(propertyName, memberInstance, setMethod, isPrivate, isStatic, isOverride));
            Array.add(propertiesFound, propertyName);
        }
        else if (testMemberName.startsWith("set_")) {
            var propertyName = testMemberName.substring(4, testMemberName.length);
            var getMethod = memberContainer["get_" + propertyName];
            Array.add(this._properties, new AjaxClassBrowser.Reflection.PropertyInfo(propertyName, getMethod, memberInstance, isPrivate, isStatic, isOverride));
            Array.add(propertiesFound, propertyName);
        }
        else if (testMemberName.startsWith("add_")) {
            var eventName = testMemberName.substring(4, testMemberName.length);
            var removeMethod = memberContainer["remove_" + eventName];
            Array.add(this._events, new AjaxClassBrowser.Reflection.EventInfo(eventName, memberInstance, removeMethod, isPrivate, isStatic, isOverride));
            Array.add(eventsFound, eventName);
        }
        else if (testMemberName.startsWith("remove_")) {
            var eventName = testMemberName.substring(7, testMemberName.length);
            var addMethod = memberContainer["add_" + eventName];
            Array.add(this._events, new AjaxClassBrowser.Reflection.EventInfo(eventName, addMethod, memberInstance, isPrivate, isStatic, isOverride));
            Array.add(eventsFound, eventName);
        }
        else {
            Array.add(this._methods, new AjaxClassBrowser.Reflection.MethodInfo(memberInstance, memberName, isPrivate, isStatic, isOverride));
        }
    },

    _skipMember : function(memberName, propertiesFound, eventsFound) {
        // Skip the member if we already found its corresponding get/set/add/remove member or if
        // its name is a built-in reserved word
        if (memberName === "constructor" ||
            memberName === "prototype") {
            return true;
        }
        if (memberName.startsWith("_")) {
            memberName = memberName.substring(1, memberName.length);
        }
        if (memberName.startsWith("get_") || memberName.startsWith("set_")) {
            var propertyName = memberName.substring(4, memberName.length);
            if (Array.contains(propertiesFound, propertyName)) {
                return true;
            }
        }
        if (memberName.startsWith("add_")) {
            var eventName = memberName.substring(4, memberName.length);
            if (Array.contains(eventsFound, eventName)) {
                return true;
            }
        }
        if (memberName.startsWith("remove_")) {
            var eventName = memberName.substring(7, memberName.length);
            if (Array.contains(eventsFound, eventName)) {
                return true;
            }
        }
        return false;
    },

    get_baseType : function() {
        if (this.get_isInterface()) {
            // Interfaces can't have base classes, but we return Object since
            // we have to be able to resolve methods from the base class.
            return Object;
        }
        var baseType = this._type.getBaseType();
        if (!baseType && (this._type !== Object)) {
            // Workaround for built-in types that don't have a true base class, except
            // for Object itself, which really doesn't derive from anything.
            baseType = Object;
        }
        return baseType;
    },

    get_constructor : function() {
        if (this.get_isInterface()) {
            // Interfaces can't have constructors
            return null;
        }
        this._ensureMetaData();
        return this._constructor;
    },

    get_events : function() {
        this._ensureMetaData();
        return this._events;
    },

    get_fields : function() {
        this._ensureMetaData();
        return this._fields;
    },

    get_interfaces : function() {
        return this._type.getInterfaces();
    },

    get_isClass : function() {
        return Type.isClass(this._type);
    },

    get_isEnum : function() {
        return Type.isEnum(this._type);
    },

    get_isFlags : function() {
        return Type.isFlags(this._type);
    },

    get_isInterface : function() {
        return Type.isInterface(this._type);
    },

    get_isInternal : function() {
        var indexOfLastDot = this.get_name().lastIndexOf('.');
        if (indexOfLastDot === -1) {
            return false;
        }
        var realTypeName = this.get_name().substr(indexOfLastDot + 1);
        return realTypeName.startsWith("_");
    },

    get_methods : function() {
        this._ensureMetaData();
        return this._methods;
    },

    get_name : function() {
        return this._type.getName();
    },

    get_properties : function() {
        this._ensureMetaData();
        return this._properties;
    },

    get_type : function() {
        return this._type;
    }
}

AjaxClassBrowser.Reflection.TypeInfo.getNamespaces = function() {
    var namespaces = Type.getRootNamespaces();
    var namespaceNames = [];
    for (var i = 0; i < namespaces.length; i++) {
        AjaxClassBrowser.Reflection.TypeInfo._getNamespacesRecursive(namespaces[i], namespaceNames);
    }
    return namespaceNames;
}

AjaxClassBrowser.Reflection.TypeInfo._getNamespacesRecursive = function(ns, list) {
    Array.add(list, ns.getName());
    for (var m in ns) {
        if (m && Type.isNamespace(ns[m])) {
            AjaxClassBrowser.Reflection.TypeInfo._getNamespacesRecursive(ns[m], list);
        }
    }
}

AjaxClassBrowser.Reflection.TypeInfo.getTypes = function(namespaceName, unknowns) {
    if (!namespaceName) {
        // If no namespace name is specified, return top level objects (already sorted by name)
        // We do not include the type "Type" here since its display name is Function due to aliasing
        return [
            new AjaxClassBrowser.Reflection.TypeInfo(Array),
            new AjaxClassBrowser.Reflection.TypeInfo(Boolean),
            new AjaxClassBrowser.Reflection.TypeInfo(Date),
            new AjaxClassBrowser.Reflection.TypeInfo(Error),
            new AjaxClassBrowser.Reflection.TypeInfo(Function),
            new AjaxClassBrowser.Reflection.TypeInfo(Number),
            new AjaxClassBrowser.Reflection.TypeInfo(Object),
            new AjaxClassBrowser.Reflection.TypeInfo(RegExp),
            new AjaxClassBrowser.Reflection.TypeInfo(String)
        ];
    }

    // If namespace name is specified, get list of types in the namespace and sort them
    var namespaceInstance = eval(namespaceName);
    var typeNamesInNamespace = [];
    for (var typeName in namespaceInstance) {
        var typeInstance = namespaceInstance[typeName];  
        
        if (Type.isClass(typeInstance) ||
            Type.isInterface(typeInstance) ||
            Type.isEnum(typeInstance) ||
            Type.isFlags(typeInstance)) {
            Array.add(typeNamesInNamespace, typeName);
        }
        else if (Type.isNamespace(typeInstance))
						;  // ignore
				else if (typeName.startsWith("_") || typeName.startsWith("get"))
						;  // ignore
        else {
						var tn = namespaceName + "." + typeName;
						Sys.Debug.trace("Unknown type: " + tn);
						Array.add(unknowns, tn);
				}
    }
    typeNamesInNamespace = typeNamesInNamespace.sort();

    var typesInNamespace = [];
    for (var i = 0; i < typeNamesInNamespace.length; i++) {
        Array.add(typesInNamespace, new AjaxClassBrowser.Reflection.TypeInfo(namespaceInstance[typeNamesInNamespace[i]]));
    }
    return typesInNamespace;
}

AjaxClassBrowser.Reflection.TypeInfo.registerClass('AjaxClassBrowser.Reflection.TypeInfo');

Sys.Application.notifyScriptLoaded();