This app was originally developed by Eilon Lipton, see

  http://weblogs.asp.net/leftslipper/archive/2007/02/22/asp-net-ajax-javascript-class-browser-take-3.aspx

We made some trivial changes to allow separate viewing of the Ajax 
Extensions 1.0 library vs. the Futures CTP library.  

Cheers,

  - joe and fritz
    Pluralsight LLC
    March 2007
