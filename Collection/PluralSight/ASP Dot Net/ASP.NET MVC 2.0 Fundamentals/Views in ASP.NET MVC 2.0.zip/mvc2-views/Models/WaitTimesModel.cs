namespace Mvc2Views.Models
{
    public class WaitTimesModel
    {
        public int PatientCount { get; set; }
        public int WaitTime { get; set; }
    }
}