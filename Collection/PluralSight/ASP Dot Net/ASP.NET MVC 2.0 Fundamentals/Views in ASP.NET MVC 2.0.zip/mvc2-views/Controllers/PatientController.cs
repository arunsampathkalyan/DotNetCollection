﻿using System;
using System.Linq;
using System.Web.Mvc;
using Mvc2Views.Models;

namespace Mvc2Views.Controllers
{
    public class PatientController : Controller
    {
        //
        // GET: /Patient/

        public ActionResult Index()
        {
            var model = FetchPatientData();
            return View(model);
        }

        //
        // GET: /Patient/Details/5

        public ActionResult PrescriptionDetails(string id)
        {
            var model = FetchPatientData().Prescriptions.Single(p => p.DrugName == id);
            return View(model);
        }

        //
        // GET: /Patient/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Patient/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Patient/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /Patient/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Patient/Delete/5

        public ActionResult Delete(int id)
        {
            return View();
        }

        //
        // POST: /Patient/Delete/5

        private Patient FetchPatientData()
        {
            return new Patient
            {
                Name = "Alex",
                Address = "Baltimore, MD",
                Prescriptions = new[]
                                                {
                                                    new Prescription { DrugName="Silly Pills", StartDate=new DateTime(2010, 6, 1), EndDate=new DateTime(2010, 6, 11)},
                                                    new Prescription { DrugName="Sugar Placebo", StartDate=new DateTime(2010, 7, 1), EndDate=new DateTime(2010, 7, 11)}
                                       }
            };
        }

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
