using System.Web;
using System.Web.Mvc;

namespace Mvc2Views.Helpers
{
    public static class MyHtmlExtensions
    {
        public static IHtmlString Image(this HtmlHelper helper, 
                                   string source, string altText)
        {
            string markup = string.Format("<img src='{0}' alt='{1}'/>",
                                       VirtualPathUtility.ToAbsolute(source), 
                                        altText);
            return new HtmlString(markup);
        }
    }
}