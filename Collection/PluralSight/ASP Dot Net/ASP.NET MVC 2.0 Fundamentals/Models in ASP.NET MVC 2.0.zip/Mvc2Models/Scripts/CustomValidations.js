﻿/// <reference path="MicrosoftAjax.js" />
/// <reference path="MicrosoftMvcValidation.js" />

Sys.Mvc.ValidatorRegistry.validators["minLength"] = function (rule) {

    var minimum = rule.ValidationParameters["minimum"];

    return function (value, context) {
        if (value) {
            var count = value.length;
            if (count < minimum) {
                return rule.ErrorMessage;
            }
        }
        return true;
    }
}
