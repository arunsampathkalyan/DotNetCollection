﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc2Models.Models;

namespace Mvc2Models.Controllers
{
    public class HospitalController : Controller
    {
        [ChildActionOnly]
        public PartialViewResult WaitTime()
        {
            var model = GetCurrentWaitTimes();
            if (User.IsInRole("Admin"))
            {
                return PartialView("AdminWaitTime", model);
            }
            return PartialView("WaitTime", model);
        }

        private WaitTimesModel GetCurrentWaitTimes()
        {
            return new WaitTimesModel()
                       {
                           PatientCount = 13,
                           WaitTime = 21
                       };
        }
    }
}
