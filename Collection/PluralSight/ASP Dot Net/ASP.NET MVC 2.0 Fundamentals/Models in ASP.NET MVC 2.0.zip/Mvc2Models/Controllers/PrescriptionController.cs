﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc2Models.Models;

namespace Mvc2Models.Controllers
{
    public class PrescriptionController : Controller
    {        
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Edit(int id)
        {
            var model = new PrescriptionEditModel
                            {
                                Id = id,
                                DrugName = "Silly Pills",
                                StartDate = new DateTime(2010, 2, 1),
                                NumberOfDays = 5
                            };
            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(PrescriptionEditModel model)
        {            
            if(ModelState.IsValid)
            {
                TempData["Message"] = "Prescription Saved!";
                return RedirectToAction("Index");
            }

            return View(model);   
        }
    }
}
