namespace Mvc2Models.Models
{
    public class Patient
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public Prescription[] Prescriptions { get; set; }
    }
}