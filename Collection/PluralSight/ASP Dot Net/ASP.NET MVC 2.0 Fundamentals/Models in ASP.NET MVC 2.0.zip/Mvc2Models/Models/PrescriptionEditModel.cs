using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Mvc2Views.Annotations;

namespace Mvc2Models.Models
{
    public class PrescriptionEditModel
    {
        [ScaffoldColumn(false)]
        public int Id { get; set; }                
       
        [MinLength(5, ErrorMessage="Drug Name is too short")]
        [StringLength(25)]
        [RegularExpression("S.*s")]
        [Required(ErrorMessage="You must enter a drug name")]
        [DisplayName("Drug Name")]
        public string  DrugName { get; set; }
        
        [DisplayName("Start Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:d}")]
        public DateTime StartDate { get; set; }
        
        [Range(1, 30)]
        [DisplayName("Duration (Days)")]
        public int NumberOfDays { get; set; }
    }
}