﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Mvc2Models.Models
{
    public class Prescription
    {       
        [DisplayName("Drug Name")]
        public string DrugName { get; set; }

        [DisplayName("Start")]
        [DisplayFormat(ApplyFormatInEditMode=true, 
                      DataFormatString = "{0:d}")]
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [ScaffoldColumn(false)]
        public string Instructions { get; set; }
    }
}