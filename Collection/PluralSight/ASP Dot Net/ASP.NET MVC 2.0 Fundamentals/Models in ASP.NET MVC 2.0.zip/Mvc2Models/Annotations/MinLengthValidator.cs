using System.Collections.Generic;
using System.Web.Mvc;

namespace Mvc2Views.Annotations
{
    public class MinLengthValidator : DataAnnotationsModelValidator<MinLengthAttribute>
    {
        private readonly MinLengthAttribute _attribute;

        public MinLengthValidator(ModelMetadata metadata, 
                                  ControllerContext context, 
                                   MinLengthAttribute attribute)
            : base(metadata, context, attribute)
        {
            _attribute = attribute;
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules()
        {
            var rule = new ModelClientValidationRule();
            rule.ErrorMessage = _attribute.ErrorMessage;
            rule.ValidationType = "minLength";
            rule.ValidationParameters["minimum"] = _attribute.Minimum;

            yield return rule;
        }
    }
}