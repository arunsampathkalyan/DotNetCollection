using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace Mvc2Views.Annotations
{
    public class MinLengthAttribute : ValidationAttribute
    {
        private readonly int _minimum;

        public int Minimum
        {
            get { return _minimum; }
        }

        public MinLengthAttribute(int minimum)
            : base("{0} must be at least {1} characters")
        {
            _minimum = minimum;
        }

        public override bool IsValid(object value)
        {
            var valueAsString = value as string;

            if (!string.IsNullOrEmpty(valueAsString))
            {
                if (valueAsString.Length < _minimum)
                {
                    return false;
                }
            }

            return true;
        }

        public override string FormatErrorMessage(string name)
        {
            return string.Format(CultureInfo.CurrentCulture,
                                 ErrorMessageString, name, _minimum);
        }
    }
}