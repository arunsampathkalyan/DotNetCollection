﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace news_service
{
    
    public class NewsItem
    {
        public string Title { get; set; }
        public string ArticleBody { get; set; }
    }

    [ServiceContract]
    public interface INewsService
    {
        [OperationContract]
        NewsItem[] GetNewsItems();

    }
}
