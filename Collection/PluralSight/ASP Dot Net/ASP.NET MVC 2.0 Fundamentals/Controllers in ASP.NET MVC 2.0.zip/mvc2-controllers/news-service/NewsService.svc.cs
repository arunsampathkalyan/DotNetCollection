﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

namespace news_service
{
    public class NewsService : INewsService
    {
        public NewsItem[] GetNewsItems()
        {
            Thread.Sleep(2000);

            return new NewsItem[]
                       {
                           new NewsItem(),
                           new NewsItem(), 
                           new NewsItem(), 
                           new NewsItem()
                       };
        }
    }
}
