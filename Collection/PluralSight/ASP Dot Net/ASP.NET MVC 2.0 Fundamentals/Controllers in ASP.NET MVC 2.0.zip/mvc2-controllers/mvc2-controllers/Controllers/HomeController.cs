﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using mvc2_controllers.News;

namespace Demo.Controllers
{
    [HandleError]
    public class HomeController : AsyncController
    {
        public void IndexAsync()
        {
            var client = new NewsServiceClient();
            
            client.GetNewsItemsCompleted += (sender, args) =>
            {
                AsyncManager.Parameters["news"] = args.Result;
                AsyncManager.OutstandingOperations.Decrement();
            };

            AsyncManager.OutstandingOperations.Increment();
            client.GetNewsItemsAsync();
        }
        
        public ActionResult IndexCompleted(object news)
        {
            return View(news);
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
