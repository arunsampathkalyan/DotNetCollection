using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("AcmeWebParts")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Acme")]
[assembly: AssemblyProduct("AcmeWebParts")]
[assembly: AssemblyCopyright("Copyright � Acme 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM componenets.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("168ebf89-4428-4420-a3aa-12703b911674")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

[assembly: WebResource("WingtipWebParts.images.0.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.1.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.2.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.3.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.4.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.5.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.6.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.7.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.8.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.9.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.10.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.11.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.12.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.13.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.14.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.15.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.16.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.17.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.18.gif", "image/gif")]
[assembly: WebResource("WingtipWebParts.images.19.gif", "image/gif")]
