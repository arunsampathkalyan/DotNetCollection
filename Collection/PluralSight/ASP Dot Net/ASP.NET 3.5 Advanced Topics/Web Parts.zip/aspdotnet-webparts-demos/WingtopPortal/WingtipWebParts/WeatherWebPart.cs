using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace WingtipWebParts
{

    public class WeatherWebPart : WebPart
    {


        #region Private Members


        public WeatherWebPart()
        {
            this.Title = "Local Weather Report" + ZipCode;
            this.TitleIconImageUrl = @"~\img\Weather.gif";
            this.CatalogIconImageUrl = @"~\img\Weather.gif";
        }

        #endregion

        // ************************************************************************
        // Gets and sets the zip code to populate the part
        [Personalizable]
        [WebBrowsable]
        public string ZipCode
        {
            get { return (string)(ViewState["zipcode"] ?? string.Empty); }
            set { ViewState["zipcode"] = value; }
        }

        protected override void RenderContents(HtmlTextWriter writer)
        {
            string text;

            if ((ZipCode == null) || (ZipCode.Length == 0))
            {
                writer.Write("Select a zip code by personalizing this WebPart.");
            }
            else
            {
                Forecast f = WeatherForecaster.GetForecast(ZipCode, DateTime.Now);
                string imageUrl = Page.ClientScript.GetWebResourceUrl(GetType(), string.Format("WingtipWebParts.images.{0}.gif", f.ImageIndex));
                writer.Write("<b>Current Weather Conditions</b><hr size='1' />");
                writer.Write("<table cellpadding=2 cellspacing=0 border=0><tr><td valign='middle'>");
                writer.Write("<img src='{0}' align='absmiddle'></td>", imageUrl);
                writer.Write("<td>Weather for {0}<br />{1}&#176;F</td></tr></table>", ZipCode, f.Temp);
                writer.Write("<i>{0}</i><br />", f.Text);
                writer.Write("<a href='http://www.weather.com'>More weather information</a>");
            }
        }
    }
}
