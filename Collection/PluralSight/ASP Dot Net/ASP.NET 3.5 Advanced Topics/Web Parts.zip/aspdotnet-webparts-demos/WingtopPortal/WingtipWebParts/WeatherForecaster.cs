using System;

namespace WingtipWebParts
{
    public class Forecast
    {
        public Forecast(int temp, int imageIndex, string text)
        {
            Temp = temp;
            ImageIndex = imageIndex;
            Text = text;
        }

        public int Temp;
        public int ImageIndex;
        public string Text;
    }

    public class WeatherForecaster
    {
        static Random rand = new Random();
        static Forecast[] northEastWeather =  { 
        new Forecast(22, 15, "Sunny and chilly"), 
        new Forecast(14, 12, "Partly cloudy and cold"), 
        new Forecast(33, 6, "Snow and ice"), 
        new Forecast(31, 1, "Freezing rain"), 
        new Forecast(30, 10, "Blizzard!")
      };

        static Forecast[] northWestWeather = { 
        new Forecast(41, 18, "Sunny and chilly"), 
        new Forecast(38, 13, "Partly cloudy and cold"), 
        new Forecast(55, 4, "Rain"), 
        new Forecast(54, 2, "Foggy and damp"), 
        new Forecast(50, 14, "Watch for falling leaves")
      };
        static Forecast[] southWestWeather = {
        new Forecast(66, 17, "Sunny and warm"), 
        new Forecast(60, 19, "Rain"), 
        new Forecast(55, 9, "Overcast with chance of rain"), 
        new Forecast(72, 15, "Warm"), 
        new Forecast(68, 17, "Beautiful sunny day!")
    };

        static Forecast[] southEastWeather = {
        new Forecast(66, 15, "Hot and humid"), 
        new Forecast(60, 17, "Sunny and dry"), 
        new Forecast(55, 18, "Blisteringly hot!"), 
        new Forecast(72, 19, "Steamy with chance of thundershowers"), 
        new Forecast(68, 17, "Beach weather!")
    };

        public static Forecast GetForecast(string zip, DateTime dt)
        {
            Forecast[] weather;
            switch (zip[0])
            {
                case '0':
                case '1':
                    weather = northEastWeather;
                    break;
                case '2':
                case '3':
                    weather = southEastWeather;
                    break;
                case '4':
                case '5':
                case '8':
                case '9':
                    weather = southWestWeather;
                    break;
                case '6':
                case '7':
                default:
                    weather = northWestWeather;
                    break;
            }

            return weather[rand.Next(5)];
        }

    }

}
