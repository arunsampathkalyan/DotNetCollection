using System;
using System.IO;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Hosting;
using System.Diagnostics;

namespace PS.Samples
{
    /// <summary>
    /// FileBasedPersonalziationProvider is a file-based provider for personalization that will
    /// persist the binary blob for each user to a separate file in the App_Data directory 
    /// of the local application. It inherits from PersonalizationProvider which deals with
    /// many of the provider implementation details, leaving just the actual serialization
    /// and initialization to our class.
    /// </summary>
    public class FileBasedPersonalizationProvider : PersonalizationProvider
    {
        private string _applicationName;

        public override string ApplicationName
        {
            get
            {
                if (string.IsNullOrEmpty(_applicationName))
                    _applicationName = HostingEnvironment.ApplicationVirtualPath;
                return _applicationName;
            }
            set
            {
                _applicationName = value;
            }
        }

        public override void Initialize(string name, NameValueCollection configSettings)
        {
            if (configSettings == null)
                throw new ArgumentNullException("configSettings");
            if (string.IsNullOrEmpty(name))
                name = "FileBasedPersonalizationProvider";
            if (string.IsNullOrEmpty(configSettings["description"]))
            {
                configSettings.Remove("description");
                configSettings.Add("description", "File-based personalization provider");
            }
            base.Initialize(name, configSettings);

            _applicationName = configSettings["applicationName"];
            if (_applicationName != null)
                configSettings.Remove("applicationName");            
        }

        public override PersonalizationStateInfoCollection FindState(PersonalizationScope scope,
               PersonalizationStateQuery query, int pageIndex, int pageSize, out int totalRecords)
        {
            // re-implement to retrieve data from files
            // equivalent of aspnet_PersonalizationAdministration_FindState
            //
            totalRecords = 1;
            throw new NotImplementedException();
            return null;
        }

        public override int GetCountOfState(PersonalizationScope scope, PersonalizationStateQuery query)
        {
            // re-implement to retrieve count of either user or global personalization state
            // equivalent of aspnet_PersonalizationAdministration_GetCountOfState sproc
            //
            throw new NotImplementedException();
            return -1;
        }

        public override int ResetUserState(string path, DateTime userInactiveSinceDate)
        {
            throw new NotImplementedException();
            return 0;
        }

        protected override void LoadPersonalizationBlobs(WebPartManager webPartManager, string path, 
                       string userName, ref byte[] sharedDataBlob, ref byte[] userDataBlob)
        {
            // re-implement to retrieve page settings for user and shared data
            // equivalent of aspnet_PersonalizationAllUsers_GetPageSettings
            // and aspnet_PersonalizationPerUser_GetPageSettings
            //
          string fileName;
          if (string.IsNullOrEmpty(userName))
          {
            fileName = HttpContext.Current.Server.MapPath(
                                                ConstructAllUsersDataFileName(path));
            if (File.Exists(fileName))
              sharedDataBlob = File.ReadAllBytes(fileName);

          }
          else
          {
            fileName = HttpContext.Current.Server.MapPath(
                                               ConstructUserDataFileName(userName, path));
            if (File.Exists(fileName))
              userDataBlob = File.ReadAllBytes(fileName);
          }

        }

        protected override void ResetPersonalizationBlob(WebPartManager webPartManager, string path, 
                                              string userName)
        {
            // re-implement to reset personalization data for either all users or per user
            // equivalent of aspnet_PersonalizationPerUser_ResetPageSettings
            // and aspnet_PersonalizationAllUsers_ResetPageSettings
            //
            
        }

        public override int ResetState(PersonalizationScope scope, string[] paths, string[] usernames)
        {
            // re-implement to reset state for users
            // equivalent of aspnet_PersonalizationAdministration_ResetUserState
            // and (based on scope) aspnet_PersonalizationAdministration_ResetSharedState
            //
            throw new NotImplementedException();
            return -1;
        }

        protected override void SavePersonalizationBlob(WebPartManager webPartManager, string path, 
                                  string userName, byte[] dataBlob)
        {
            // re-implement to save state for user (or all users based on whether username=null
            // equivalent of aspnet_PersonalizationPerUser_SetPageSettings
            // and aspnet_PersonalizationAllUsers_SetPageSettings
            //

            string fileName;
            if (string.IsNullOrEmpty(userName))
                fileName = ConstructAllUsersDataFileName(path);
            else
                fileName = ConstructUserDataFileName(userName, path);

            File.WriteAllBytes(HttpContext.Current.Server.MapPath(fileName), dataBlob);
        }

        private string ConstructAllUsersDataFileName(string path)
        {
            string pathConvertedToFileName = path.Replace('/', '_');
            pathConvertedToFileName = pathConvertedToFileName.Replace('~', '_');
            pathConvertedToFileName = pathConvertedToFileName.Replace('.', '_');

            return "~/App_Data/allusers" + pathConvertedToFileName + ".bin";
        }

        private string ConstructUserDataFileName(string user, string path)
        {
            string pathConvertedToFileName = path.Replace('/', '_');
            pathConvertedToFileName = pathConvertedToFileName.Replace('~', '_');
            pathConvertedToFileName = pathConvertedToFileName.Replace('.', '_');

            return "~/App_Data/" + user + pathConvertedToFileName + ".bin";
        }
    }

}