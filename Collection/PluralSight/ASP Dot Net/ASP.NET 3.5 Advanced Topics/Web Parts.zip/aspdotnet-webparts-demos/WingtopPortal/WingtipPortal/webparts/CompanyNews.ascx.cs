using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


public partial class CompanyNews : WebPartBase
{

protected bool _HR = true;
[ Personalizable(PersonalizationScope.User), 
  WebBrowsable, 
  WebDisplayName("Show HR News"),
  WebDescription("Use this property to show/hide HR news")]
public bool HR {
  get { return _HR; }
  set { _HR = value; }
}

  protected bool _Sales = true;
  [ Personalizable(PersonalizationScope.User), 
    WebBrowsable,
    WebDisplayName("Show Sales News"), 
    WebDescription("Use this property to show/hide sales news")]
  public bool Sales  {
    get { return _Sales; }
    set { _Sales = value; }
  }

  protected bool _Technology = true;
  [ Personalizable(PersonalizationScope.User), 
    WebBrowsable,
    WebDisplayName("Show Technology News"),
    WebDescription("Use this property to show/hide tech news")]
  public bool Technology  {
    get { return _Technology; }
    set { _Technology = value; }
  }

  public enum TimeframeEnum {
    Today,
    Week,
    Month
  }

  protected TimeframeEnum _Timeframe = TimeframeEnum.Month;
  [ Personalizable(PersonalizationScope.Shared), 
    WebBrowsable,
    WebDisplayName("Select a news timeframe"),
    WebDescription("Use this property to set timeframe")]
  public TimeframeEnum Timeframe {
    get { return _Timeframe; }
    set { _Timeframe = value; }
  }

  protected void Page_PreRender(object sender, EventArgs e)
  {
    // hide/show news controls
    lblSalesNews.Visible = Sales;
    lblTechNews.Visible = Technology;
    lblHRNews.Visible = HR;

    // assign web part title
    switch (Timeframe)
    {
      case TimeframeEnum.Today:
        this.Title = "News for " + DateTime.Now.ToString("MMMM d, yyyy");
        break;
      case TimeframeEnum.Week:
        DateTime day = DateTime.Today;
        while (day.DayOfWeek != DayOfWeek.Monday) {
          day = day.AddDays(-1);
        }
        this.Title = "News for the week of " + day.ToShortDateString();
        break;
      case TimeframeEnum.Month:
        this.Title = "News for " + DateTime.Today.ToString("MMMM yyyy");
        break;
    }
  }
}
