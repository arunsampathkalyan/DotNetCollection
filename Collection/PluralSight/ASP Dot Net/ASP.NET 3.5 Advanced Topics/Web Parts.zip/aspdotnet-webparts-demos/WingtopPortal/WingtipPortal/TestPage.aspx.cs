using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class TestPage : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {

  
  }
  protected void cmdAddWebParts_Click(object sender, EventArgs e)
  {
    //WebPart wp1 = new WingtipWebParts.HelloWorld();
    //WebPartManager1.AddWebPart(wp1, WebPartZone1, 0);

    Control uc = this.LoadControl(@"webparts\CompanyNews.ascx");
    uc.ID = "wp2";
    WebPart wp2 = WebPartManager1.CreateWebPart(uc);
    WebPartManager1.AddWebPart(wp2, WebPartZone1, 1);

	//Calendar cal = new Calendar();
	//cal.ID = "ca";
	//WebPart wp3 = WebPartManager1.CreateWebPart(cal);
	//WebPartManager1.AddWebPart(wp3, WebPartZone1, 2);


  }
  protected void cmdRemoveWebPart_Click(object sender, EventArgs e)
  {   
    foreach (WebPart wp in WebPartManager1.WebParts) {
      WebPartManager1.DeleteWebPart(wp);
    }
  }

  protected void cmdBrowseMode_Click(object sender, EventArgs e)
  {
    WebPartManager1.DisplayMode = WebPartManager.BrowseDisplayMode;
  }

  protected void cmdEditMode_Click(object sender, EventArgs e)
  {
    WebPartManager1.DisplayMode = WebPartManager.EditDisplayMode;
  }
  protected void cmdDesignMode_Click(object sender, EventArgs e)
  {
    WebPartManager1.DisplayMode = WebPartManager.DesignDisplayMode;
  }
  protected void cmdToggleScope_Click(object sender, EventArgs e)
  {
    WebPartManager1.Personalization.ToggleScope();
  }
  protected void cmdCatalogMode_Click(object sender, EventArgs e)
  {
    WebPartManager1.DisplayMode = WebPartManager.CatalogDisplayMode;
  }
}
