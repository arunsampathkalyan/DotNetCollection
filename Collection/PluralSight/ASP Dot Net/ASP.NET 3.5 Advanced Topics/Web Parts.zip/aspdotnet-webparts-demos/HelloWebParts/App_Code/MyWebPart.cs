﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI;

namespace PS
{
    public class MyWebPart : WebPart
    {
        public MyWebPart()
        {
            this.Title = "My web part";
            this.TitleUrl = "http://pluralsight.com";
        }

        [ Personalizable, WebBrowsable, 
          WebDisplayName("My Text"), WebDescription("Enter text to display") ]
        public string MyText 
        {
            get { return (string)(ViewState["MyText"] ?? "Hello from my Web Part!"); }
            set { ViewState["MyText"] = value; }
        }

        protected override void RenderContents(System.Web.UI.HtmlTextWriter writer)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.H2);
            writer.Write(MyText);
            writer.RenderEndTag();
            base.RenderContents(writer);
        }
    }
}
