﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        //browse
        _wpm.DisplayMode = WebPartManager.BrowseDisplayMode;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        // design
        _wpm.DisplayMode = WebPartManager.DesignDisplayMode;
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        _wpm.DisplayMode = WebPartManager.EditDisplayMode;
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        _wpm.DisplayMode = WebPartManager.CatalogDisplayMode;
    }
}
