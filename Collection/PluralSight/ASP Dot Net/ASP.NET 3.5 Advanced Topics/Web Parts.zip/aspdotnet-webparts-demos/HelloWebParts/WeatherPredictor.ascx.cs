﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class WeatherPredictor : UserControl, IWebPart
{
    static Random _rand = new Random();

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void _predictButton_Click(object sender, EventArgs e)
    {
        switch (_rand.Next(3))
        {
            case 0:
                _resultLabel.Text = "Sunny and warm!";
                break;
            case 1:
                _resultLabel.Text = "Rainy and cold";
                break;
            case 2:
                _resultLabel.Text = "Overcast with chance of showers";
                break;

        }
    }

    #region IWebPart Members

    public string CatalogIconImageUrl
    {
        get { return "";}
        set { }
    }

    public string Description
    {
        get { return ""; }
        set { }
    }

    public string Subtitle
    {
        get { return ""; }
    }

    public string Title
    {
        get { return "My User Control Web Part"; }
        set { }
    }

    public string TitleIconImageUrl
    {
        get { return ""; }
        set { }
    }

    public string TitleUrl
    {
        get { return ""; }
        set { }
    }

    #endregion
}
