﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PS
{
    public interface IPersonalInfo
    {
        string Name { get; }
        string Country { get; }
    }
}