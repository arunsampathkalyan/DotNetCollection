﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using PS;

public partial class MyInfoWebPart : UserControl, IWebPart, IPersonalInfo
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Display personal info in label controls
        _nameLabel.Text = Name;
        _countryLabel.Text = Country;
    }

    [ConnectionProvider("Personal Info Provider")]
    public IPersonalInfo GetPersonalInfoProvider()
    {
        return this;
    }

    #region IPersonalInfo Members

    [WebBrowsable, Personalizable, WebDisplayName("Name")]
    public string Name
    {
        get { return (string)(ViewState["Name"] ?? ""); }
        set { ViewState["Name"] = value; }
    }

    [WebBrowsable, Personalizable, WebDisplayName("Country")]
    public string Country
    {
        get { return (string)(ViewState["Country"] ?? ""); }
        set { ViewState["Country"] = value;  }
    }

    #endregion

    public string CatalogIconImageUrl
    {
        get { return ""; }
        set { }
    }

    public string Description
    {
        get { return ""; }
        set { }
    }

    public string Subtitle
    {
        get { return ""; }
    }

    public string Title
    {
        get { return "My info part"; }
        set { }
    }

    public string TitleIconImageUrl
    {
        get { return ""; }
        set { }
    }

    public string TitleUrl
    {
        get { return ""; }
        set { }
    }

}
