﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PS;
using System.Web.UI.WebControls.WebParts;

public partial class WeatherWebPart : UserControl, IWebPart
{
    static Random _rand = new Random();
    IPersonalInfo _personalInfoProvider;

    protected void Page_Load(object sender, EventArgs e)
    {
        switch (_rand.Next(3))
        {
            case 0:
                _weatherReportLabel.Text = "Sunny and warm";
                break;
            case 1:
                _weatherReportLabel.Text = "Rain and wind";
                break;
            case 2:
                _weatherReportLabel.Text = "Overcast with chance of showers";
                break;
        }

    }

    protected override void OnPreRender(EventArgs e)
    {
        if (_personalInfoProvider != null)
        {
            _nameLabel.Text = _personalInfoProvider.Name;
            _countryLabel.Text = _personalInfoProvider.Country;
        }
        
        base.OnPreRender(e);
    }

    [ConnectionConsumer("Personal Info Consumer")]
    public void RegisterPersonalInfoProvider(IPersonalInfo pip)
    {
        _personalInfoProvider = pip;
    }

    public string CatalogIconImageUrl
    {
        get { return ""; }
        set { }
    }

    public string Description
    {
        get { return ""; }
        set { }
    }

    public string Subtitle
    {
        get { return ""; }
    }

    public string Title
    {
        get { return "Weather Web Part"; }
        set { }
    }

    public string TitleIconImageUrl
    {
        get { return ""; }
        set { }
    }

    public string TitleUrl
    {
        get { return ""; }
        set { }
    }

}
