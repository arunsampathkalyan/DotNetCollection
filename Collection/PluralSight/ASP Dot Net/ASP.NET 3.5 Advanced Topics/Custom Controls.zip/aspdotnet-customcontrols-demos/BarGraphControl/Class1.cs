﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pluralsight
{
    public class BarGraphControl : Control
    {
        public string Title
        {
            get { return (string)(ViewState["title"] ?? ""); }

            set { ViewState["title"] = value; }
        }

        private List<Pair> Items
        {
            get
            {
                List<Pair> ret;
                if (ViewState["items"] == null)
                {
                    ret = new List<Pair>();
                    ViewState["items"] = ret;
                }
                else
                    ret = (List<Pair>)ViewState["items"];
                return ret;
            }
        }

        public void AddItem(string name, int val)
        {
            Items.Add(new Pair(name, val));
        }

        protected override void Render(HtmlTextWriter writer)
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Width, "100%");
            writer.RenderBeginTag(HtmlTextWriterTag.Table); //<table>

            foreach (Pair p in Items)
            {
                writer.RenderBeginTag(HtmlTextWriterTag.Tr); //<tr>

                writer.AddAttribute(HtmlTextWriterAttribute.Align, "right");
                writer.AddAttribute(HtmlTextWriterAttribute.Width, "10%");
                writer.RenderBeginTag(HtmlTextWriterTag.Td); //<td>
                writer.Write(p.First.ToString());
                writer.RenderEndTag(); // </td>

                writer.RenderBeginTag(HtmlTextWriterTag.Td); //<td>
                // if we are rendering with an html 3.2 - compliant text writer, 
                // the client browser probably doesn't support spans with styles
                // so render asterisks instead
                if (Page.Request.Browser.TagWriter == typeof(Html32TextWriter))
                {
                    for (int i = 0; i < (int)p.Second / 10; i++)
                        writer.Write("*");
                }
                else
                {
                    writer.AddStyleAttribute(HtmlTextWriterStyle.Width, p.Second.ToString());
                    writer.AddStyleAttribute(HtmlTextWriterStyle.BackgroundColor, "green");
                    writer.RenderBeginTag(HtmlTextWriterTag.Span); // <span>
                    writer.RenderEndTag(); // </span>
                }

                writer.RenderEndTag(); // </td>
                writer.RenderEndTag(); // </tr>
            }

            writer.RenderEndTag(); //</table>

            writer.RenderBeginTag(HtmlTextWriterTag.Strong); // <strong>
            writer.RenderBeginTag(HtmlTextWriterTag.Center); // <center>
            writer.Write(Title);
            writer.RenderEndTag();                           // </strong>
            writer.RenderEndTag();                           // </center>


            base.Render(writer);
        }

    }
}
