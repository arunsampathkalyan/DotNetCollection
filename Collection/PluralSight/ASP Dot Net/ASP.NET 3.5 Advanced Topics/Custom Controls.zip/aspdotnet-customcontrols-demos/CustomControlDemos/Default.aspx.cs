﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Calc1.FontSize = FontUnit.Small;
        }

        _calcPanel.Controls.Add(LoadControl("~/calc.ascx"));
        _calcPanel.Controls.Add(LoadControl("~/calc.ascx"));
    }

    protected void OnEnterName(object sender, EventArgs e)
    {
        messageLabel.Text =
            string.Format("Hi, {0}, how are you?", 
                        nameTextBox.Text);
    }

    protected void OnMagicNumberCalculated(object sender, EventArgs e)
    {
        _messageLabel.Text = "MAGIC NUMBER CALCULATED!!!";
    }
  
}
