﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Calc : UserControl
{
    public event EventHandler MagicNumber;

    public string TitleText 
    {
        get { return (string)(ViewState["TitleText"] ?? "My Calculator"); }
        set { ViewState["TitleText"] = value;  }
    }

    public FontUnit FontSize 
    {
        get { return (FontUnit)ViewState["FontSize"]; }
        set { ViewState["FontSize"] = value; }
    }

    public Calc()
    {
        FontSize = FontUnit.Medium;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        _titleText.Text = TitleText;

        _titleText.Font.Size = FontSize;
        _result.Font.Size = FontSize;
        _x.Font.Size = FontSize;
        _y.Font.Size = FontSize;
        _calcButton.Font.Size = FontSize;
    }

    protected void _calcButton_Click(object sender, EventArgs e)
    {
        int x = int.Parse(_x.Text);
        int y = int.Parse(_y.Text);

        int res = x + y;
        if (res == 42 && MagicNumber != null)
            MagicNumber(this, EventArgs.Empty);

        _result.Text = res.ToString();
    }
}
