﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BarGraphClient : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            _barGraphControl.AddItem("Val 1", 100);
            _barGraphControl.AddItem("Val 2", 200);
            _barGraphControl.AddItem("Val 3", 300);
            _barGraphControl.AddItem("Val 4", 400);
            _barGraphControl.AddItem("Val 5", 500);
        }
    }
}
