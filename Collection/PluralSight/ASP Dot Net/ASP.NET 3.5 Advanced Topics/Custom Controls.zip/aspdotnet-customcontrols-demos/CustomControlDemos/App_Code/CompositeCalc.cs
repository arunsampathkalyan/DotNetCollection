﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;

namespace Pluralsight
{
    public class CompositeCalc : Control, INamingContainer // CompositeControl
    {
        Label _titleText;
        TextBox _x;
        TextBox _y;
        Button _calcButton;
        Label _result;

        protected override void CreateChildControls()
        {
            _titleText = new Label();
            _x = new TextBox();
            _y = new TextBox();
            _calcButton = new Button();
            _result = new Label();

            Controls.Add(new LiteralControl("<fieldset><legend>"));
            Controls.Add(_titleText);
            Controls.Add(new LiteralControl("</legend>"));
            Controls.Add(_x);
            Controls.Add(new LiteralControl(" + "));
            Controls.Add(_y);
            Controls.Add(new LiteralControl(" = "));
            Controls.Add(_result);
            Controls.Add(new LiteralControl("<br />"));
            Controls.Add(_calcButton);

            _calcButton.Click += new EventHandler(_calcButton_Click);
            _calcButton.Text = "Calculate!";

            _titleText.Text = TitleText;

            _titleText.Font.Size = FontSize;
            _result.Font.Size = FontSize;
            _x.Font.Size = FontSize;
            _y.Font.Size = FontSize;
            _calcButton.Font.Size = FontSize;

            base.CreateChildControls();
        }

        void _calcButton_Click(object sender, EventArgs e)
        {
            int x = int.Parse(_x.Text);
            int y = int.Parse(_y.Text);

            int res = x + y;
            if (res == 42 && MagicNumber != null)
                MagicNumber(this, EventArgs.Empty);

            _result.Text = res.ToString();
        }

        public event EventHandler MagicNumber;

        public string TitleText
        {
            get { return (string)(ViewState["TitleText"] ?? "My Calculator"); }
            set { ViewState["TitleText"] = value; }
        }

        public FontUnit FontSize
        {
            get { return (FontUnit)ViewState["FontSize"]; }
            set { ViewState["FontSize"] = value; }
        }

        public CompositeCalc()
        {
            FontSize = FontUnit.Medium;
        }
    }
}
