﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace Pluralsight
{
    public class MyCustomControl : Control
    {
        protected override void OnInit(EventArgs e)
        {
            Page.ClientScript.RegisterClientScriptBlock(GetType(), "MyCustomControl_Script",
                 "function MyCustomControl_SayHi(txt) { alert(txt); }", true);
            base.OnInit(e);
        }
        protected override void Render(HtmlTextWriter writer)
        {            
            writer.AddStyleAttribute(HtmlTextWriterStyle.BackgroundColor, "Cornsilk");
            writer.AddAttribute(HtmlTextWriterAttribute.Onclick, "MyCustomControl_SayHi('hi there!');");

            writer.RenderBeginTag(HtmlTextWriterTag.H2); // <h2>
            if (HasControls())
            {
                writer.Write(((LiteralControl)Controls[0]).Text);
            }
            else
                writer.Write("Hello from my control!");
            writer.RenderEndTag(); // </h2>

            writer.Write("ID={0} UniqueID={1} ClientID={2}", ID, UniqueID, ClientID);

            base.Render(writer);
        }
    }
}
