using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

[assembly: WebResource("StopLightControl.YellowOn.jpg", "image/jpg")]
[assembly: WebResource("StopLightControl.YellowDim.jpg", "image/jpg")]
[assembly: WebResource("StopLightControl.GreenOn.jpg", "image/jpg")]
[assembly: WebResource("StopLightControl.GreenDim.jpg", "image/jpg")]
[assembly: WebResource("StopLightControl.RedOn.jpg", "image/jpg")]
[assembly: WebResource("StopLightControl.RedDim.jpg", "image/jpg")]

namespace PS.AspDotNet2.CustomControls
{
  public enum StopLightColor
  { red, yellow, green }

  public class StopLightControl : CompositeControl
  {
    private ImageButton redLightImageButton;
    private ImageButton yellowLightImageButton;
    private ImageButton greenLightImageButton;
    private StopLightColor lightColor = StopLightColor.red;

    public event EventHandler LightChanged;

    public StopLightColor LightColor
    {
      get
      {
        return lightColor;
      }
      set
      {
        if (value != LightColor)
        {
          if (LightChanged != null)
            LightChanged(this, EventArgs.Empty);

          lightColor = value;
          SetImageUrls();
        }
      }
    }

    public string Title
    {
      get
      {
        return (string)ViewState["title"] ?? "Default title";
      }
      set
      {
        ViewState["title"] = value;
      }
    }

    protected override void CreateChildControls()
    {
      yellowLightImageButton = new ImageButton();
      redLightImageButton = new ImageButton();
      greenLightImageButton = new ImageButton();

      yellowLightImageButton.Click += delegate { LightColor = StopLightColor.yellow; };
      redLightImageButton.Click += delegate { LightColor = StopLightColor.red; };
      greenLightImageButton.Click += delegate { LightColor = StopLightColor.green; };

      Controls.Add(new LiteralControl("<div>"));
      Controls.Add(redLightImageButton);
      Controls.Add(new LiteralControl("<br />"));
      Controls.Add(yellowLightImageButton);
      Controls.Add(new LiteralControl("<br />"));
      Controls.Add(greenLightImageButton);
      Controls.Add(new LiteralControl("<br />"));
      Controls.Add(new LiteralControl(Title));
      Controls.Add(new LiteralControl("</div>"));

      SetImageUrls();

      base.CreateChildControls();
    }

    private void SetImageUrls()
    {

      if (LightColor == StopLightColor.yellow)
        yellowLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.YellowOn.jpg");
      else
        yellowLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.YellowDim.jpg");

      if (LightColor == StopLightColor.red)
        redLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.RedOn.jpg");
      else
        redLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.RedDim.jpg");

      if (LightColor == StopLightColor.green)
        greenLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.GreenOn.jpg");
      else
        greenLightImageButton.ImageUrl = Page.ClientScript.GetWebResourceUrl(GetType(),
                                                                "StopLightControl.GreenDim.jpg");
    }

    protected override void OnInit(EventArgs e)
    {
      Page.RegisterRequiresControlState(this);
      base.OnInit(e);
    }

    protected override void LoadControlState(
                        object savedState)
    {
      object[] rgState = (object[])savedState;
      base.LoadControlState(rgState[0]);
      lightColor = (StopLightColor)rgState[1];
    }

    protected override object SaveControlState()
    {
      object[] rgState = new object[2];
      rgState[0] = base.SaveControlState();
      rgState[1] = lightColor;
      return rgState;
    }


  }
}
