﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Pluralsight
{
    public class MyWebControl : WebControl
    {
        protected override void RenderContents(HtmlTextWriter writer)
        {
            writer.Write("Hello from my web control!");
            base.RenderContents(writer);
        }
    }
}
