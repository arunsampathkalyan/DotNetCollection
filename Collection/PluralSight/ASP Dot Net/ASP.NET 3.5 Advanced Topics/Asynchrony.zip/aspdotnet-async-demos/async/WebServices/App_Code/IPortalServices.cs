﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace PS
{
    [ServiceContract(Namespace="http://www.pluralsight.com/ws")]
    public interface IPortalServices
    {
        [OperationContract]
        string GetWeatherReport(string zipcode);

        [OperationContract]
        StockQuote[] GetStockQuotes(string[] symbols);

        [OperationContract]
        string[] GetNewsHeadlines();
   }

    public class StockQuote
    {
        public string Symbol { get; set; }
        public double Value  { get; set; }
    }

}