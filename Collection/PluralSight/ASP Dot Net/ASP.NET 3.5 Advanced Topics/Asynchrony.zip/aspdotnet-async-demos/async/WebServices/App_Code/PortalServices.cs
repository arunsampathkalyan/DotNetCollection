﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

namespace PS
{
    public class PortalServices : IPortalServices
    {
        private static Random _rand = new Random();

        public string GetWeatherReport(string zipcode) 
        {
            // Sleep for 3 seconds to artificially lengthen request
            //
            Thread.Sleep(3000);

            switch (_rand.Next(3))
            {
                case 0:
                    return "Sunny and warm";
                case 1:
                    return "Rain";
                case 2:
                    return "Snow showers";
                default:
                    return "Cold with frozen rain";
            }
        }

        public StockQuote[] GetStockQuotes(string[] symbols)
        {
            // Sleep for 3 seconds to artificially lengthen request
            //
            Thread.Sleep(3000);

            StockQuote[] ret = new StockQuote[symbols.Length];
            Random rand = new Random(Environment.TickCount);
            for (int i=0; i<symbols.Length; i++)
                ret[i] = new StockQuote { Symbol = symbols[i], Value = rand.Next(1200) / 10.0 };
            return ret;
        }
        
        public string[] GetNewsHeadlines()
        {
            // Sleep for 3 seconds to artificially lengthen request
            //
            Thread.Sleep(3000);

            string[] ret = new string[10];

            // grab 10 news titles from the list, starting at some random location
            // less than 10 from the end
            int startIndex = (new Random(Environment.TickCount)).Next(_news.Length-10);
            for (int i=startIndex, j=0; i<startIndex+10; i++, j++)
            {
                ret[j] = _news[i];
            }

            return ret;
        }

        #region data
        static string[] _news = new string[]
        {   "Golden Globe nominations announced",
            "Navy mom surprises son, 8, in class",
            "'Redneck' tips on saving water",
            "Pretty robot slaps men who get fresh",
            "Baby on 'Nevermind' all grown up",
            "'Dancing lights' draw thousands to frozen north",
            "Web 2.0 entrepreneur cashes out just in time",
            "Feeling lonely? Genes might be at fault",
            "The worst seasons by teams in sports history",
            "Sony Set To Launch Online Virtual World",
            "US students showing an increase in mathematic aptitude",
            "NASA Confirms CO2 On Distant Planet, Life To Be Found?",
            "Advisory Panel Weighs Conflict on Asthma Drugs",
            "Boston Power: Green Laptops Today, Electric Cars Tomorrow?",
            "Panel Criticizes US Effort on Nanomaterial Risks",
            "Devices Such as MP3 Players May Pose Hearing Risks",
            "IPhone developer laments glut of free and cheap apps",
            "Should cybersecurity be managed from the White House?",
            "Tons Of Michael Jackson Crap About To Be Auctioned Off",
            "Ricky Martin livin' la vida dada",
            "Six hurt in trial of drug",
            "Culling of chicken to begin Thur. in W. India"
        };
        #endregion
    }
}