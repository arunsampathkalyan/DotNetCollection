using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.ComponentModel;

public class SqlOperation
{
    public readonly SqlConnection Connection;
    public readonly SqlCommand Command;

    public SqlOperation(SqlConnection conn, SqlCommand cmd)
    {
        Connection = conn;
        Command = cmd;
    }

    public void Complete()
    {
        Command.Dispose();
        Connection.Dispose();
    }
}