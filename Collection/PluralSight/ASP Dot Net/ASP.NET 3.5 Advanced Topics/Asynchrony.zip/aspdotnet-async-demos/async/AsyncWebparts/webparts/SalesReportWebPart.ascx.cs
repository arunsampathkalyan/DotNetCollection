using System;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class webparts_SalesReportWebPart : WebPartBase
{
    // Local variables to store connection and command for async
    // data retrieval
    //
    SqlConnection _conn;
    SqlCommand    _cmd;

    public webparts_SalesReportWebPart()
    {
        this.Title = "Sales Report";
        this.Description = "Sales Report Web Part";
        this.Caption = "Sales Report";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string dsn = ConfigurationManager.ConnectionStrings["salesDsn"].ConnectionString;
        string sql = "WAITFOR DELAY '00:00:03' SELECT [id], [quarter], [year], [amount], [projected] FROM [sales] WHERE year=@year";

        if (Page.IsAsync)
        {
            // Append async attribute to connection string
            //
            dsn += ";async=true";

            _conn = new SqlConnection(dsn);
            _cmd = new SqlCommand(sql, _conn);
            _conn.Open();
            _cmd.Parameters.AddWithValue("@year", int.Parse(_yearTextBox.Text));

            // Launch data request asynchronously using page async task
            //
            PageAsyncTask salesDataTask = new PageAsyncTask(
                    new BeginEventHandler(BeginGetSalesData),
                    new EndEventHandler(EndGetSalesData),
                    new EndEventHandler(GetSalesDataTimeout),
                    null, true);
            Page.RegisterAsyncTask(salesDataTask);
        }
        else
        {
            using (SqlConnection conn = new SqlConnection(dsn))
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@year", int.Parse(_yearTextBox.Text));
                conn.Open();
                _salesGrid.DataSource = cmd.ExecuteReader();
                _salesGrid.DataBind();
            }
        }
    }

    IAsyncResult BeginGetSalesData(object src, EventArgs e, AsyncCallback cb, object state)
    {
        return _cmd.BeginExecuteReader(cb, state);
    }

    void EndGetSalesData(IAsyncResult ar)
    {
        _salesGrid.DataSource = _cmd.EndExecuteReader(ar);

        _salesGrid.DataBind();

        _conn.Close();

        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("sales: " + AppDomain.GetCurrentThreadId().ToString());
    }

    void GetSalesDataTimeout(IAsyncResult ar)
    {
        // operation timed out, so just clean up by closing connection
        if (_conn.State == ConnectionState.Open)
            _conn.Close();

        _messageLabel.Text = "Query timed out...";
    }

    public override void Dispose()
    {
        // Clean up connection if for some reason it wasn't closed
        //
        if (_conn != null && _conn.State == ConnectionState.Open)
            _conn.Close();

        base.Dispose();
    }

}
