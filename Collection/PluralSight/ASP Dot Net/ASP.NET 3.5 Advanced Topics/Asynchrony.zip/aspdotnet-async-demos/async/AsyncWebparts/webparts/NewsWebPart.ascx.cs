using System;
using System.Reflection;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using localhost;

public partial class webparts_NewsWebPart : WebPartBase
{
    public webparts_NewsWebPart()
    {
        this.Title = "News Headlines";
        this.Description = "News Headlines Web Part";
        this.Caption = "News Headlines";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        // Instantiate web service proxy for retrieving data
        //
        PortalServices ps = new PortalServices();

        // If page has async enabled, invoke web service asynchronously
        // and harvest results in callback.
        //
        if (Page.IsAsync)
        {
            ps.GetNewsHeadlinesCompleted += 
                new GetNewsHeadlinesCompletedEventHandler(ps_GetNewsHeadlinesCompleted);
            ps.GetNewsHeadlinesAsync();
        }
        else
        {
            // If not async, perform direct databinding
            //
            _newsHeadlines.DataSource = ps.GetNewsHeadlines();
            _newsHeadlines.DataBind();
        }
    }

    // This callback is only invoked if the async web service model
    // was used.
    //
    void ps_GetNewsHeadlinesCompleted(object sender, GetNewsHeadlinesCompletedEventArgs e)
    {
        _newsHeadlines.DataSource = e.Result;
        _newsHeadlines.DataBind();
  
        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("news: " + AppDomain.GetCurrentThreadId().ToString());
    }
}
