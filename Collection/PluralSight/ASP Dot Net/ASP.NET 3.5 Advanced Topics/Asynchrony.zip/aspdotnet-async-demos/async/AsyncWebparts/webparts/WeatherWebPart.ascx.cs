using System;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using localhost;

public partial class webparts_WeatherWebPart : WebPartBase
{
    public webparts_WeatherWebPart()
    {
        this.Title = "Weather Forecast";
        this.Description = "Weather Forecast Web Part";
        this.Caption = "Weather Forecast";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        PortalServices ps = new PortalServices();

        if (Page.IsAsync)
        {
            ps.GetWeatherReportCompleted += 
                new GetWeatherReportCompletedEventHandler(ps_GetWeatherReportCompleted);
        }
        else
            _weatherLabel.Text = ps.GetWeatherReport("04090");
    }

    // This callback is only invoked if the async web service model
    // was used.
    //
    void ps_GetWeatherReportCompleted(object sender, GetWeatherReportCompletedEventArgs e)
    {
        _weatherLabel.Text = e.Result;
        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("weather: " + AppDomain.GetCurrentThreadId().ToString());
    }

}
