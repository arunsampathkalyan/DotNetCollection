using System;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using localhost;

public partial class webparts_StockQuoteWebPart : WebPartBase
{
    public webparts_StockQuoteWebPart()
    {
        this.Title = "Stock Quotes";
        this.Description = "Stock Quotes Web Part";
        this.Caption = "Stock Quotes";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        string[] stocks = new string[] {"GM", "C", "SNV", "XL", "YUM"};

        // Instantiate web service proxy for retrieving data
        //
        PortalServices ps = new PortalServices();

        // If page has async enabled, invoke web service asynchronously
        // and harvest results in callback.
        //
        if (Page.IsAsync)
        {
            ps.GetStockQuotesCompleted += 
                new GetStockQuotesCompletedEventHandler(ps_GetStockQuotesCompleted);
            ps.GetStockQuotesAsync(stocks);
        }
        else
        {
            // If not async, perform direct databinding
            //
            _stocksGrid.DataSource = ps.GetStockQuotes(stocks);
            _stocksGrid.DataBind();
        }
    }

    // This callback is only invoked if the async web service model
    // was used.
    //
    void  ps_GetStockQuotesCompleted(object sender, GetStockQuotesCompletedEventArgs e)
    {
        _stocksGrid.DataSource = e.Result;
        _stocksGrid.DataBind();

        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("stock: " + AppDomain.GetCurrentThreadId().ToString());
    }
}
