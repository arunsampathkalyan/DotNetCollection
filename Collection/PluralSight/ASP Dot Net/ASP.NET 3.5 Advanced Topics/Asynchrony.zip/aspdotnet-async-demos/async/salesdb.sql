/******************************/
/**** Drop/Create Database  ***/
/******************************/
IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'samplesales')
  DROP DATABASE samplesales
GO

CREATE DATABASE samplesales
GO

USE samplesales
GO

--Grant Network Service account access and dataread/write permissions (For Win2k3 installations)
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = 'NT Authority\Network Service')
  EXEC sp_grantlogin 'NT Authority\Network Service'
IF NOT EXISTS (SELECT * FROM dbo.sysusers WHERE name = 'NT Authority\Network Service')
  EXEC sp_grantdbaccess 'NT Authority\Network Service'

EXEC sp_addrolemember N'db_datareader', 'NT Authority\Network Service'
EXEC sp_addrolemember N'db_datawriter', 'NT Authority\Network Service'
GO

CREATE TABLE sales (
  id            INT IDENTITY(1,1) NOT NULL PRIMARY KEY CLUSTERED,
  quarter       TINYINT NOT NULL,
  year          INT NOT NULL,
  amount        MONEY NOT NULL,
  projected     MONEY NOT NULL  
)
GO  

INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (1, 2002, 300000, 250000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (2, 2002, 150000, 250000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (3, 2002, 400000, 250000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (4, 2002, 100000, 250000)

INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (1, 2003, 400000, 350000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (2, 2003, 250000, 350000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (3, 2003, 500000, 350000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (4, 2003, 200000, 350000)

INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (1, 2004, 500000, 450000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (2, 2004, 350000, 450000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (3, 2004, 600000, 450000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (4, 2004, 300000, 450000)

INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (1, 2005, 700000, 550000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (2, 2005, 450000, 550000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (3, 2005, 700000, 550000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (4, 2005, 400000, 550000)

INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (1, 2006, 800000, 650000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (2, 2006, 550000, 650000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (3, 2006, 900000, 650000)
INSERT INTO sales (quarter, year, amount, projected) 
	VALUES (4, 2006, 500000, 650000)

