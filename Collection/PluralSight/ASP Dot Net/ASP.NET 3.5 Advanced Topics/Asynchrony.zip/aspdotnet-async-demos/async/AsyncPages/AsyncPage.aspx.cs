using System;
using System.ComponentModel;
using System.Reflection;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AsyncPage : System.Web.UI.Page
{
    protected override void OnPreInit(EventArgs e)
    {
        Context.Items["startTime"] = DateTime.Now;
        List<string> threads = new List<string>();
        threads.Add("main: " + AppDomain.GetCurrentThreadId().ToString());

        Context.Items["threads"] = threads;

        base.OnPreInit(e);
    }

    protected override void OnPreRenderComplete(EventArgs e)
    {
        DateTime startTime = (DateTime)Context.Items["startTime"];
        TimeSpan delta = DateTime.Now - startTime;
        _durationLabel.Text = string.Format("<h5>Time taken: {0:f2} seconds</h5>", 
                   delta.TotalMilliseconds/1000.0 );

        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("main2: " + AppDomain.GetCurrentThreadId().ToString());

        _threadIdsList.DataSource = threads;
        _threadIdsList.DataBind();

        base.OnPreRenderComplete(e);
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
}
