using System;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PS;

public partial class controls_StockQuoteControl : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] stocks = new string[] {"MSFT", "IBM", "SUNW", "GOOG", "ORCL"};

        // Instantiate web service proxy for retrieving data
        //
        PortalServicesClient ps = new PortalServicesClient();

        if (Page.IsAsync)
        {
            // Invoke web service asynchronously and harvest results in callback.
            //
            ps.GetStockQuotesCompleted += new EventHandler<GetStockQuotesCompletedEventArgs>(ps_GetStockQuotesCompleted);
            ps.GetStockQuotesAsync(stocks);
        }
        else
        {
            // Synchronous binding
            //
            _stocksGrid.DataSource = ps.GetStockQuotes(stocks);
            _stocksGrid.DataBind();
        }
    }

    // This callback is invoked when the async web service completes
    //
    void  ps_GetStockQuotesCompleted(object sender, GetStockQuotesCompletedEventArgs e)
    {
        _stocksGrid.DataSource = e.Result;
        _stocksGrid.DataBind();

        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("stock: " + AppDomain.GetCurrentThreadId().ToString());
    }
}
