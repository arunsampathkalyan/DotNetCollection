using System;
using System.Reflection;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PS;

public partial class controls_NewsControl : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Instantiate web service proxy for retrieving data
        //
        PortalServicesClient ps = new PortalServicesClient();

        if (Page.IsAsync)
        {
            // Invoke web service asynchronously
            // and harvest results in callback.
            //
            ps.GetNewsHeadlinesCompleted += ps_GetNewsHeadlinesCompleted;
            ps.GetNewsHeadlinesAsync();
        }
        else
        {
            // synchronous retrieval
            _newsHeadlines.DataSource = ps.GetNewsHeadlines();
            _newsHeadlines.DataBind();
        }
    }

    // This callback is invoked if when the async web service completes
    //
    void ps_GetNewsHeadlinesCompleted(object sender, GetNewsHeadlinesCompletedEventArgs e)
    {
        _newsHeadlines.DataSource = e.Result;
        _newsHeadlines.DataBind();
  
        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("news: " + AppDomain.GetCurrentThreadId().ToString());
    }
}
