using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class SynchronousPage : System.Web.UI.Page
{
    protected override void OnPreInit(EventArgs e)
    {
        Context.Items["startTime"] = DateTime.Now;

        base.OnPreInit(e);
    }

    protected override void OnPreRenderComplete(EventArgs e)
    {
        DateTime startTime = (DateTime)Context.Items["startTime"];
        TimeSpan delta = DateTime.Now - startTime;
        Response.Output.Write("<h5>Time taken: {0:f2} seconds</h5>", delta.TotalMilliseconds/1000.0);
        base.OnPreRenderComplete(e);
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
