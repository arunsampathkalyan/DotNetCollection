using System;
using System.Reflection;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using PS;

public partial class controls_WeatherControl : UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PortalServicesClient ps = new PortalServicesClient();

        if (Page.IsAsync)
        {
            // Launch asynchronous web service call
            ps.GetWeatherReportCompleted += new EventHandler<GetWeatherReportCompletedEventArgs>(ps_GetWeatherReportCompleted);
            ps.GetWeatherReportAsync("04090");
        }
        else
        {
            // Synchronous call
            _weatherLabel.Text = ps.GetWeatherReport("04090");
        }
    }

    // This callback is only invoked if the async web service model
    // was used.
    //
    void ps_GetWeatherReportCompleted(object sender, GetWeatherReportCompletedEventArgs e)
    {
        _weatherLabel.Text = e.Result;
        List<string> threads = Context.Items["threads"] as List<string>;
        threads.Add("weather: " + AppDomain.GetCurrentThreadId().ToString());
    }

}
