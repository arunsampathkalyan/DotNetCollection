﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PS;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PortalServicesClient client = new PortalServicesClient();
        //_newsBulletedList.DataSource = client.GetNewsHeadlines();
        client.GetNewsHeadlinesCompleted += 
            new EventHandler<GetNewsHeadlinesCompletedEventArgs>(client_GetNewsHeadlinesCompleted);
        client.GetNewsHeadlinesAsync();
    }

    void client_GetNewsHeadlinesCompleted(object sender, GetNewsHeadlinesCompletedEventArgs e)
    {
        _newsBulletedList.DataSource = e.Result;
        _newsBulletedList.DataBind();
    }
}
