using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Compilation;
using System.CodeDom;

namespace PS
{

    public class TimeExpressionBuilder : ExpressionBuilder
    {
        public override CodeExpression GetCodeExpression(
            BoundPropertyEntry entry, object parsedData,
            ExpressionBuilderContext context)
        {
            string param = entry.Expression;
            if (param == "shorttime")
                return new CodePrimitiveExpression
                    (DateTime.Now.ToShortTimeString());
            else if (param == "longtime")
                return new CodePrimitiveExpression
                    (DateTime.Now.ToLongTimeString());
            else if (param == "shortdate")
                return new CodePrimitiveExpression
                    (DateTime.Now.ToShortDateString());
            else if (param == "longdate")
                return new CodePrimitiveExpression
                    (DateTime.Now.ToLongDateString());
            else
                throw new InvalidOperationException
                    ("Use $ Time:shorttime or $ Time:longtime or $Time:shortdate or $Time:longdate");
        }
    }

}