﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PS
{
    public class CsvHandler : IHttpHandler
    {

        #region IHttpHandler Members

        public bool IsReusable
        {
            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/csv";
            context.Response.Write("1, 2, 3, 4 \r\n 5, 6, 7, 8");
        }

        #endregion
    }

}