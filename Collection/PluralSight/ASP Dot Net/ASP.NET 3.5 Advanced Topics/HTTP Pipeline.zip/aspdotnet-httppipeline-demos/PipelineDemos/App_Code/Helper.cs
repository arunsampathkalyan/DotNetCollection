﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PS
{
    public static class Helper
    {
        public static void WriteToResponse()
        {
            HttpContext.Current.Response.Write("<h2>Hi from the helper class</h2>");
        }
    }

}