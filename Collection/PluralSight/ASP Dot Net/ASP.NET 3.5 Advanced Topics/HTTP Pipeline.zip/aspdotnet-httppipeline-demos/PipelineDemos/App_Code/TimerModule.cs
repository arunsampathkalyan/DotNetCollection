﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PS
{
    public class TimerModule : IHttpModule
    {
        #region IHttpModule Members

        public void Dispose()
        {
            
        }

        public void Init(HttpApplication app)
        {
            app.BeginRequest += new EventHandler(app_BeginRequest);
            app.EndRequest += new EventHandler(app_EndRequest);
        }

        void app_BeginRequest(object sender, EventArgs e)
        {
            HttpApplication app = sender as HttpApplication;

            app.Context.Items["timerModuleStartTime"] = DateTime.Now;
        }

        void app_EndRequest(object sender, EventArgs e)
        {
            HttpApplication app = sender as HttpApplication;

            DateTime t = (DateTime)app.Context.Items["timerModuleStartTime"];
            TimeSpan delta = DateTime.Now - t;
            app.Response.Write("<h5>This page took " +
              delta.TotalMilliseconds +
            "ms to process</h5>");       
        }


        #endregion
    }

}