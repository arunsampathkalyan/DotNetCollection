﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TimeTracker.Models
{
    public class TimeTrackerRepository
    {
        TimeTrackerDbContext _Context = new TimeTrackerDbContext();

        public List<Employee> GetEmployees()
        {
            return (from e in _Context.Employees
                    orderby e.LastName
                    select e).ToList();

            //Lambda
            //return _Context.Employees.OrderBy(e => e.LastName).ToList();
        }

        public int GetEmployeeCount()
        {
            return _Context.Employees.Count();
        }

        public List<TimeCard> GetTimeCardsByDate(DateTime submissionDate)
        {
            return (from tc in _Context.TimeCards
                    where tc.SubmissionDate == submissionDate
                    orderby tc.ID
                    select tc).ToList();
        }

        public List<TimeCard> GetEmployeeTimeCards(int id)
        {
            return (from e in _Context.Employees
                    where e.ID == id
                    select e.TimeCards).SingleOrDefault();
        }


    }
}