using System;
using System.Collections.Generic;
using System.Linq;
using Data;

/// <summary>
/// Summary description for BAL
/// </summary>
public class BAL
{
    public List<String> GetCountries()
    {
        return null;
    }

    public List<Customer> GetCustomersByCountry(string country)
    {
        return null;
    }

    public Customer GetCustomer(string custID)
    {
        return null;
    }

}
