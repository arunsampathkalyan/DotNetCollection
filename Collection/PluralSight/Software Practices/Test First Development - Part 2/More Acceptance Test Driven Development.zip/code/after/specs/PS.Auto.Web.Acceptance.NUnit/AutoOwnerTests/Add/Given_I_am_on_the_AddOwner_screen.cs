﻿
using Moq;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerTests.Add
{
    public class Given_I_am_on_the_AddOwner_screen : GWT
    {
        protected Mock<IAddOwnerView> _mockView;
        protected AddOwnerPresenter _presenter;

        protected string _firstName;
        protected string _lastName;

        protected override void Given()
        {
            _firstName = string.Empty;
            _lastName = string.Empty;

            _mockView = new Mock<IAddOwnerView>();
            _presenter = new AddOwnerPresenter(_mockView.Object);
        }
    }
}
