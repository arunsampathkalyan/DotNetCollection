﻿using NUnit.Framework;

namespace PS.Auto.Web.Acceptance.NUnit
{
    public class GWT
    {
        [SetUp]
        public void MainSetup()
        {
            Given();
            When();
        }

        [TearDown]
        protected void MainTeardown()
        {
            CleanUp();
        }

        protected virtual void When()
        {
        }

        protected virtual void Given()
        {
        }

        protected virtual void CleanUp()
        {
        }
    }
}