﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using StoryQ;

namespace PS.Auto.Web.StoryQ.AutoOwnerStories
{
    [TestClass]
    public class DeleteOwnerStory
    {
        OwnerRepository _ownerRepository;
        IOwner _owner;
        Mock<IEditOwnerView> _mockView;
        EditOwnerPresenter _presenter;

        [TestMethod]
        public void DeleteOwner()
        {
            new Story("Delete Owner")
                .InOrderTo("groom the list of automobile owners")
                .AsA("List Owner")
                .IWant("to delete an existing Auto Owner from the List")
                
                .WithScenario("Happy Path")
                    .Given(IAmEditingAnAutoOwner)
                    .When(IPressDelete)
                    .Then(TheAutoOwnerIsRemovedFromTheSystem)
                        .And(IAmReturnedToTheMainOwnerList)
                
                .WithScenario("Already Gone")
                    .Given(IAmEditingAnAutoOwner)
                    .When(IPressDelete)
                        .And(TheAutoOwnerHasAlreadyBeenDeleted)
                    .Then(IReceiveNoErrorMessage)
                        .And(IAmReturnedToTheMainOwnerList)

                .ExecuteWithReport();
        }

        void IAmEditingAnAutoOwner()
        {
            InsertOwner();
            _mockView = new Mock<IEditOwnerView>();
            _presenter = new EditOwnerPresenter(_mockView.Object, _owner.Id);
        }

        void InsertOwner()
        {
            _ownerRepository = new OwnerRepository();
            var owner = new Owner()
                            {
                                FirstName = "Marge", 
                                LastName = "Simpson"
                            };
            _owner = _ownerRepository.Save(owner);
        }

        void IPressDelete()
        {
            _presenter.Delete();
        }

        void TheAutoOwnerIsRemovedFromTheSystem()
        {
            var owner = _ownerRepository.FindById(_owner.Id);
            Assert.IsNull(owner);
        }

        void IAmReturnedToTheMainOwnerList()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }

        void TheAutoOwnerHasAlreadyBeenDeleted()
        {
            _ownerRepository.Delete(_owner);
        }

        void IReceiveNoErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()), Times.Never());
        }
    }
}