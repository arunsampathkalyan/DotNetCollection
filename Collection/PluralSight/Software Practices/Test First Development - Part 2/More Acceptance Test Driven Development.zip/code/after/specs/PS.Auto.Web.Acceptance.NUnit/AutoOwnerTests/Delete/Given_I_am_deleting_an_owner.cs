﻿using Moq;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerTests.Delete
{
    public class Given_I_am_deleting_an_owner : GWT
    {
        protected Mock<IEditOwnerView> _mockView;
        protected IOwner _owner;
        protected OwnerRepository _ownerRepository;
        protected EditOwnerPresenter _presenter;


        protected override void Given()
        {
            Init();
            _mockView = new Mock<IEditOwnerView>();
            _presenter = new EditOwnerPresenter(_mockView.Object, _owner.Id);
        }

        public void Init()
        {
            var newOwner = new Owner
                               {
                                   FirstName = "Homer",
                                   LastName = "Simpson"
                               };

            _ownerRepository = new OwnerRepository();
            _owner = _ownerRepository.Save(newOwner);
        }

        protected override void When()
        {
            _presenter.Delete();
        }
    }
}
