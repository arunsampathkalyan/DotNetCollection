﻿using Moq;
using NUnit.Framework;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerTests.Delete
{
    [Category("Delete Auto Owner")]
    public class AlreadyGone : Given_I_am_deleting_an_owner
    {
        protected override void Given()
        {
            base.Given();
            _ownerRepository.Delete(_owner);
        }

        [Test]
        public void I_receive_no_error_message()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()), Times.Never());
        }

        [Test]
        public void I_am_returned_to_the_main_Owner_List()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }
    }
}