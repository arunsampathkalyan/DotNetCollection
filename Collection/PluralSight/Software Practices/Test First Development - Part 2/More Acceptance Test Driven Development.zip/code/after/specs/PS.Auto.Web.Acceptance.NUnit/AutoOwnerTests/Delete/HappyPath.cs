﻿using Moq;
using NUnit.Framework;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerTests.Delete
{
    [Category("Delete Auto Owner")]
    public class HappyPath : Given_I_am_deleting_an_owner
    {
        [Test]
        public void Then_the_owner_is_removed_from_the_list()
        {
            var owner = _ownerRepository.FindById(_owner.Id);
            Assert.IsNull(owner);
        }

        [Test]
        public void I_am_returned_to_the_main_Owner_List()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }
    }
}