
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 01/18/2011 22:21:09
-- Generated from EDMX file: C:\projects\PS_SVN\psod\david-starr\test_first_development_1\tfd-06-isolation\code\before\AutoWeb.Data\VehicleModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Automobiles_dev];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_ManufacturerModelSpec]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ModelSpecs] DROP CONSTRAINT [FK_ManufacturerModelSpec];
GO
IF OBJECT_ID(N'[dbo].[FK_VehicleModelSpec]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ModelSpecs] DROP CONSTRAINT [FK_VehicleModelSpec];
GO
IF OBJECT_ID(N'[dbo].[FK_AutoOwnerVehicle]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Vehicles] DROP CONSTRAINT [FK_AutoOwnerVehicle];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[AutoOwners]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AutoOwners];
GO
IF OBJECT_ID(N'[dbo].[Manufacturers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Manufacturers];
GO
IF OBJECT_ID(N'[dbo].[ModelSpecs]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ModelSpecs];
GO
IF OBJECT_ID(N'[dbo].[Vehicles]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Vehicles];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'AutoOwners'
CREATE TABLE [dbo].[AutoOwners] (
    [FirstName] nvarchar(max)  NOT NULL,
    [LastName] nvarchar(max)  NOT NULL,
    [Id] int IDENTITY(1,1) NOT NULL
);
GO

-- Creating table 'Manufacturers'
CREATE TABLE [dbo].[Manufacturers] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Country] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'ModelSpecs'
CREATE TABLE [dbo].[ModelSpecs] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Engine] nvarchar(max)  NOT NULL,
    [Manufacturer_Id] int  NOT NULL,
    [Vehicle_Id] int  NOT NULL
);
GO

-- Creating table 'Vehicles'
CREATE TABLE [dbo].[Vehicles] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [PetName] nvarchar(max)  NOT NULL,
    [Color] nvarchar(max)  NOT NULL,
    [AutoOwner_Id] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'AutoOwners'
ALTER TABLE [dbo].[AutoOwners]
ADD CONSTRAINT [PK_AutoOwners]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Manufacturers'
ALTER TABLE [dbo].[Manufacturers]
ADD CONSTRAINT [PK_Manufacturers]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ModelSpecs'
ALTER TABLE [dbo].[ModelSpecs]
ADD CONSTRAINT [PK_ModelSpecs]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Vehicles'
ALTER TABLE [dbo].[Vehicles]
ADD CONSTRAINT [PK_Vehicles]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Manufacturer_Id] in table 'ModelSpecs'
ALTER TABLE [dbo].[ModelSpecs]
ADD CONSTRAINT [FK_ManufacturerModelSpec]
    FOREIGN KEY ([Manufacturer_Id])
    REFERENCES [dbo].[Manufacturers]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_ManufacturerModelSpec'
CREATE INDEX [IX_FK_ManufacturerModelSpec]
ON [dbo].[ModelSpecs]
    ([Manufacturer_Id]);
GO

-- Creating foreign key on [Vehicle_Id] in table 'ModelSpecs'
ALTER TABLE [dbo].[ModelSpecs]
ADD CONSTRAINT [FK_VehicleModelSpec]
    FOREIGN KEY ([Vehicle_Id])
    REFERENCES [dbo].[Vehicles]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_VehicleModelSpec'
CREATE INDEX [IX_FK_VehicleModelSpec]
ON [dbo].[ModelSpecs]
    ([Vehicle_Id]);
GO

-- Creating foreign key on [AutoOwner_Id] in table 'Vehicles'
ALTER TABLE [dbo].[Vehicles]
ADD CONSTRAINT [FK_AutoOwnerVehicle]
    FOREIGN KEY ([AutoOwner_Id])
    REFERENCES [dbo].[AutoOwners]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_AutoOwnerVehicle'
CREATE INDEX [IX_FK_AutoOwnerVehicle]
ON [dbo].[Vehicles]
    ([AutoOwner_Id]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------