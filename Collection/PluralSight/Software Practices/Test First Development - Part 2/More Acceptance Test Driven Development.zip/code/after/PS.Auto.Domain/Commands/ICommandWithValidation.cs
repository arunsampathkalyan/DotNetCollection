﻿
namespace PS.Auto.Domain.Commands
{
    public interface ICommandWithValidation : ICommand
    {
        CommandValidationResult Validate();
        void ExecuteIfValid();
    }
}