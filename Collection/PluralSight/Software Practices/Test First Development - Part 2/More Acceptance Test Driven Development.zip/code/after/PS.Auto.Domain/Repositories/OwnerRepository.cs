﻿using System;
using System.Collections.Generic;
using System.Linq;
using PS.Auto.Data;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories.Mapping;
using AutoOwner = PS.Auto.Data.AutoOwner;

namespace PS.Auto.Domain.Repositories
{
    public class OwnerRepository : IOwnerRepository, IDisposable
    {
        readonly IVehicleModelContainer _context;
        readonly OwnerMapper _ownerMapper;

        public OwnerRepository()
            : this(new VehicleModelContainer(),  new OwnerMapper())
        {
            
        }

        public OwnerRepository(IVehicleModelContainer context, OwnerMapper ownerMapper)
        {
            _context = context;
            _ownerMapper = ownerMapper;
        }


        public IOwner FindById(int id)
        {
            AutoOwner autoOwnerEntity;

            using (var context = new VehicleModelContainer())
            {
                autoOwnerEntity = context.AutoOwners.FirstOrDefault(ao => ao.Id == id);
            }

            if (autoOwnerEntity == null)
                return null;

            return _ownerMapper.From(autoOwnerEntity);
        }

        public IEnumerable<IOwner> FindByName(string firstName, string lastName)
        {
            using (var context = new VehicleModelContainer())
            {
                var query = from ao in context.AutoOwners
                            where   
                                ao.FirstName == firstName &&
                                ao.LastName == lastName
                            select ao;

                return _ownerMapper.From(query);
            }
        }

        public IOwner Save(IOwner owner)
        {
            var existingEntity = FindById(owner.Id);
            
            if (existingEntity != null)
                return UpdateExistingEntity(owner);
            
            return AddNewEntity(owner);
        }

        IOwner AddNewEntity(IOwner owner)
        {
            AutoOwner autoOwnerEntity;
            
            using (var context = new VehicleModelContainer())
            {
                autoOwnerEntity = context.AutoOwners.CreateObject();
                autoOwnerEntity.FirstName = owner.FirstName;
                autoOwnerEntity.LastName = owner.LastName;

                context.AutoOwners.AddObject(autoOwnerEntity);
                context.SaveChanges();
            }

            return _ownerMapper.From(autoOwnerEntity);
        }

        IOwner UpdateExistingEntity(IOwner owner)
        {
            AutoOwner autoOwnerEntity;

            using (var context = new VehicleModelContainer())
            {
                autoOwnerEntity = context.AutoOwners.First(ao => ao.Id == owner.Id);
                autoOwnerEntity.FirstName = owner.FirstName;
                autoOwnerEntity.LastName = owner.LastName;
                context.SaveChanges();
            }

            return _ownerMapper.From(autoOwnerEntity);
        }

        public IEnumerable<IOwner> GetAll()
        {
            using (var context = new VehicleModelContainer())
            {
                var query = from ao in context.AutoOwners
                            select ao;

                return _ownerMapper.From(query.ToList());
            }
        }

        public void  Delete(IOwner owner)
        {
            using (var context = new VehicleModelContainer())
            {
                var ownerEntity = context.AutoOwners.FirstOrDefault(o => o.Id == owner.Id);

                if (ownerEntity == null)
                    return;

                context.AutoOwners.DeleteObject(ownerEntity);
                context.SaveChanges();
            }
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
