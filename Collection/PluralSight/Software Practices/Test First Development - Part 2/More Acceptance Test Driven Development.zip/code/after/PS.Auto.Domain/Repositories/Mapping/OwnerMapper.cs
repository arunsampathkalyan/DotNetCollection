﻿
using System.Collections.Generic;
using System.Linq;
using PS.Auto.Data;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Repositories.Mapping
{
    public class OwnerMapper
    {
        public IEnumerable<IOwner> From(IEnumerable<Data.AutoOwner> ownerEntities)
        {
            IList<IOwner> owners = new List<IOwner>();

            foreach (var autoOwnerEntity in ownerEntities.ToList())
            {
                var owner = new Owner()
                {
                    Id = autoOwnerEntity.Id,
                    FirstName = autoOwnerEntity.FirstName,
                    LastName = autoOwnerEntity.LastName
                };
                owners.Add(owner);
            }

            return owners;
        }

        public Data.AutoOwner From(IOwner owner)
        {
            return new Data.AutoOwner()
            {
                FirstName = owner.FirstName,
                LastName = owner.LastName
            };
        }
        
        public IOwner From(Data.AutoOwner autoOwnerEntity)
        {
            return new Owner()
            {
                Id = autoOwnerEntity.Id,
                FirstName = autoOwnerEntity.FirstName,
                LastName = autoOwnerEntity.LastName
            };
        }
    }
}
