﻿using System;

namespace PS.Auto.Domain.Commands
{
    public class CommandFactory : ICommandFactory
    {
        public T CreateCommand<T>() where T : ICommand
        {
            return (T) Activator.CreateInstance(typeof(T));
        }
    }
}