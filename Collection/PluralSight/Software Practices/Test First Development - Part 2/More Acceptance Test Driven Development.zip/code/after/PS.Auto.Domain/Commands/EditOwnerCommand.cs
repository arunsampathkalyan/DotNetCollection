﻿using PS.Auto.Domain.Repositories;

namespace PS.Auto.Domain.Commands
{
    public class EditOwnerCommand : CommandWithValidationBase
    {
        readonly IOwnerRepository _ownerRepository;

        public EditOwnerCommand()
            :this(new OwnerRepository())
        {}

        public EditOwnerCommand(IOwnerRepository ownerRepository)
        {
            _ownerRepository = ownerRepository;
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override void Execute()
        {
            var owner = _ownerRepository.FindById(Id);
                owner.FirstName = FirstName;
                owner.LastName = LastName;

            _ownerRepository.Save(owner);
        }

        public override CommandValidationResult Validate()
        {
            ValidateId();
            ValidateFirstName();
            ValidateLastName();
            ValidateOwnerRepository();

            return base.Validate();
        }

        void ValidateId()
        {
            if (Id < 0)
                AddValidationError("The Owner's ID is invalid: " + Id);
        }

        void ValidateOwnerRepository()
        {
            if(_ownerRepository == null)
                AddValidationError("Owner Repository is not initialized");
        }

        void ValidateFirstName()
        {
            if(string.IsNullOrEmpty(FirstName))
                AddValidationError("Please provide a valid first name");
        }

        void ValidateLastName()
        {
            if (string.IsNullOrEmpty(LastName))
                AddValidationError("Please provide a valid last name");
        }
    }
}