﻿using PS.Auto.Domain.Commands;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Presenters
{
    public class AddOwnerPresenter
    {
        readonly IAddOwnerView _view;
        readonly ICommandFactory _commandFactory;

        public AddOwnerPresenter(IAddOwnerView view)
            :this(view, new CommandFactory())
        {
            
        }

        public AddOwnerPresenter(IAddOwnerView view, ICommandFactory commandFactory)
        {
            _view = view;
            _commandFactory = commandFactory;
        }

        public void AddNewOwner(string firstName, string lastName)
        {
            var command = _commandFactory.CreateCommand<AddOwnerCommand>();
                command.FirstName = firstName;
                command.LastName = lastName;

            var validationResult = command.Validate();

            if (!validationResult.IsValid)
            {
                _view.ShowError(validationResult.GetAsMessage("<br/>"));
                return;
            }

            command.Execute();
            _view.Redirect("~/");
        }
    }
}