﻿using System;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web
{
    public partial class AddOwner : ViewBase, IAddOwnerView
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void AddOwner_Click(object sender, EventArgs e)
        {
            string firstName = _tbFirstName.Text;
            string last = _tbLastName.Text;
            new AddOwnerPresenter(this).AddNewOwner(firstName, last);
        }

        public override void ShowError(string error)
        {
            _lblError.Text = error;
            _pnlError.Visible = true;
        }
    }
}