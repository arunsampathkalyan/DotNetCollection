﻿
namespace PS.Auto.Web.Models
{
    public class EditOwnerVM
    {
        public string Id { get; set; }
        public string First { get; set; }
        public string Last { get; set; }
    }
}