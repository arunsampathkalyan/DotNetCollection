﻿using Moq;
using NUnit.Framework;
using PS.Auto.Domain.Repositories;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerStories.Add
{
    [Category("Add Auto Owner")]
    public class HappyPath : Given_I_am_on_the_AddOwner_screen
    {

        protected override void Given()
        {
            base.Given();

            _firstName = "Homer";
            _lastName = "Simpson";
        }

        protected override void When()
        {
            _presenter.AddNewOwner(_firstName, _lastName);
        }

        [Test]
        public void Then_the_owner_is_present_in_the_db()
        {
            var ownerRepository = new OwnerRepository();
            var owner = ownerRepository.FindByName(_firstName, _lastName);
            Assert.IsNotNull(owner);
        }

        [Test]
        public void I_am_redirected_to_the_main_list_page()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }

    }
}