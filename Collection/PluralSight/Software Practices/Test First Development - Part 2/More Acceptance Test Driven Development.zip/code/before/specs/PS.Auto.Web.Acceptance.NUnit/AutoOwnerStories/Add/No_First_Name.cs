﻿using Moq;
using NUnit.Framework;

namespace PS.Auto.Web.Acceptance.NUnit.AutoOwnerStories.Add
{
    [Category("Add Auto Owner")]
    public class No_First_Name : Given_I_am_on_the_AddOwner_screen
    {
        protected override void Given()
        {
            base.Given();

            _firstName = string.Empty;
            _lastName = "Griffin";
        }

        protected override void When()
        {
            _presenter.AddNewOwner(_firstName, _lastName);
        }

        [Test]
        public void I_get_an_error_message()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()));
        }
    }
}