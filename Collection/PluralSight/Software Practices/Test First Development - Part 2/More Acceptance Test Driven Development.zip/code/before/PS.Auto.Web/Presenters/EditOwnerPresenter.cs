﻿using PS.Auto.Domain.Commands;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Models.Mappers;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Presenters
{
    public class EditOwnerPresenter
    {
        readonly IEditOwnerView _view;
        readonly int _ownerId;
        readonly IOwnerRepository _ownerRepository;
        readonly ICommandFactory _commandFactory;

        readonly EditOwnerVMMapper _vmMapper;

        public EditOwnerPresenter(IEditOwnerView view, int ownerId)
            : this(ownerId, view, new OwnerRepository(), new CommandFactory()) 
        {}

        public EditOwnerPresenter(int ownerId, IEditOwnerView view, IOwnerRepository ownerRepository, ICommandFactory commandFactory)
        {
            _view = view;
            _ownerId = ownerId;
            _ownerRepository = ownerRepository;
            _commandFactory = commandFactory;

            _vmMapper = new EditOwnerVMMapper();
        }

        public void Init()
        {
            var owner = _ownerRepository.FindById(_ownerId);
            var model = _vmMapper.From(owner);
            _view.Show(model);
        }

        public void SaveName(string first, string last)
        {
            var command = _commandFactory.CreateCommand<EditOwnerCommand>();
                command.Id = _ownerId;
                command.FirstName = first;
                command.LastName = last;

            if (!command.Validate().IsValid)
            {
                _view.ShowError(command.Validate().GetAsMessage());
                return;
            }

            command.Execute();
            
            _view.Redirect("~/");
        }

        public void Delete()
        {
//            var command = _commandFactory.CreateCommand<DeleteOwnerCommand>();
//                command.Id = _ownerId;
//            
//            if (!command.Validate().IsValid)
//            {
//                _view.ShowError(command.Validate().GetAsMessage());
//                return;
//            }
//
//            command.Execute();
//
//            _view.Redirect("~/");
        }
    }
}