﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using TechTalk.SpecFlow;

namespace PS.Auto.Web.SpecFlow.AutoOwnerStories.Delete
{
    [Binding]
    public class StepDefinitions
    {
        Mock<IEditOwnerView> _mockView;
        IOwner _owner;
        OwnerRepository _ownerRepository;
        EditOwnerPresenter _presenter;

        [BeforeScenario()]
        public void AddNewOwnerToRepository()
        {
            var newOwner = new Owner
            {
                FirstName = "Homer",
                LastName = "Simpson"
            };

            _ownerRepository = new OwnerRepository();
            _owner = _ownerRepository.Save(newOwner);
        }

        [Given(@"I am editing an Auto Owner")]
        public void GivenIAmEditingAnAutoOwner()
        {
            _mockView = new Mock<IEditOwnerView>();
            _presenter = new EditOwnerPresenter(_mockView.Object, _owner.Id);
        }

        [When(@"I press Delete")]
        public void WhenIPressDelete()
        {
            _presenter.Delete();
        }

        [When(@"the Auto Owner has already been deleted")]
        public void WhenTheAutoOwnerHasAlreadyBeenDeleted()
        {
            _ownerRepository.Delete(_owner);
        }

        [Then(@"I receive no error message")]
        public void ThenIReceiveNoErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()), Times.Never());
        }


        [Then(@"I am returned to the main Owner List")]
        public void ThenIAmReturnedToTheMainOwnerList()
        {
            _mockView.Verify(v => v.Redirect("~/"));
        }

        [Then(@"the Auto Owner is removed from the system")]
        public void ThenTheAutoOwnerIsRemovedFromTheSystem()
        {
            var foundOwner = _ownerRepository.FindById(_owner.Id);
            Assert.IsNull(foundOwner);
        }
    }
}