﻿namespace PS.Auto.Domain.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}