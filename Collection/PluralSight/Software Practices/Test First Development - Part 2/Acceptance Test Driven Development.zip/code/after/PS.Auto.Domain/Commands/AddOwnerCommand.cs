﻿using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;

namespace PS.Auto.Domain.Commands
{
    public class AddOwnerCommand : CommandWithValidationBase
    {
        readonly IOwnerRepository _ownerRepository;

        public AddOwnerCommand()
            :this(new OwnerRepository())
        {}

        public AddOwnerCommand(IOwnerRepository ownerRepository)
        {
            _ownerRepository = ownerRepository;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override void Execute()
        {
            var owner = new Owner()
                              {
                                  FirstName = FirstName,
                                  LastName = LastName
                              };

            _ownerRepository.Save(owner);
        }

        public override CommandValidationResult Validate()
        {
            ValidateFirstName();
            ValidateLastName();
            ValidateOwnerRepositry();

            return base.Validate();
        }

        void ValidateOwnerRepositry()
        {
            if(_ownerRepository == null)
                AddValidationError("Owner Repository is not initialized");
        }

        void ValidateFirstName()
        {
            if(string.IsNullOrEmpty(FirstName))
                AddValidationError("Please provide a valid first name");
        }

        void ValidateLastName()
        {
            if (string.IsNullOrEmpty(LastName))
                AddValidationError("Please provide a valid last name");
        }
    }
}