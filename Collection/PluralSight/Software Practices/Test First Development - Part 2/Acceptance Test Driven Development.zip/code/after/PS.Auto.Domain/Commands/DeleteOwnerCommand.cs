﻿using PS.Auto.Domain.Repositories;

namespace PS.Auto.Domain.Commands
{
    public class DeleteOwnerCommand : CommandWithValidationBase
    {
        readonly IOwnerRepository _ownerRepository;

        public DeleteOwnerCommand()
            : this (new OwnerRepository())
        {}

        public DeleteOwnerCommand(IOwnerRepository ownerRepository)
        {
            _ownerRepository = ownerRepository;
        }

        public override void Execute()
        {
            var owner = _ownerRepository.FindById(Id);
            if (owner == null)
                return;

            _ownerRepository.Delete(owner);
        }

        public int Id { get; set; }

        public override CommandValidationResult Validate()
        {
            ValidateId();
            return base.Validate();
        }

        void ValidateId()
        {
            if(Id < 0)
                AddValidationError("Invalid ID during delete operation");
        }
    }
}