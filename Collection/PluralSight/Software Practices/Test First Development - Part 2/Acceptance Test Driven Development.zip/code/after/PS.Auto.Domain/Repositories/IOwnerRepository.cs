﻿using System.Collections.Generic;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Repositories
{
    public interface IOwnerRepository
    {
        IOwner FindById(int id);
        IEnumerable<IOwner> FindByName(string firstName, string lastName);
        IOwner Save(IOwner owner);
        IEnumerable<IOwner> GetAll();
        void Delete(IOwner owner);
    }
}