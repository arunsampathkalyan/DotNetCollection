﻿namespace PS.Auto.Domain.Commands
{
    public interface ICommandFactory 
    {
        T CreateCommand<T>() where T : ICommand;
    }
}