﻿
using PS.Auto.Domain.Entities;

namespace PS.Auto.Web.Models.Mappers
{
    public class EditOwnerVMMapper
    {
        public EditOwnerVM From(IOwner owner)
        {
            return new EditOwnerVM
            {
                Id = owner.Id.ToString(),
                First = owner.FirstName,
                Last = owner.LastName
            };
        }

    }
}