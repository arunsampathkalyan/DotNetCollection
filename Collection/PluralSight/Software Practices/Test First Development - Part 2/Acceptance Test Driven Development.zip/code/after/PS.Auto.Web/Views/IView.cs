﻿namespace PS.Auto.Web.Views
{
    public interface IView
    {
        void ShowError(string error);
        void Redirect(string url);
    }
}