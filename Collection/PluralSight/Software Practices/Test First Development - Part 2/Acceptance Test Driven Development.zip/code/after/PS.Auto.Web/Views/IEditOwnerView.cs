﻿
using PS.Auto.Web.Models;

namespace PS.Auto.Web.Views
{
    public interface IEditOwnerView : IView
    {
        void Show(EditOwnerVM viewModel);
    }
}