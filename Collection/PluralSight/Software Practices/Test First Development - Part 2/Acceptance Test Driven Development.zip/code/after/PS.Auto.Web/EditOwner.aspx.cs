﻿using System;
using PS.Auto.Web.Models;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web
{
    public partial class EditOwner : ViewBase, IEditOwnerView
    {
        EditOwnerPresenter _presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var ownerId = int.Parse(Request.QueryString["id"]);
                CreatePresenter(ownerId).Init();
            }
        }

        EditOwnerPresenter CreatePresenter(int ownerId)
        {
            return new EditOwnerPresenter(this, ownerId);
        }

        public override void ShowError(string error)
        {
            _lblError.Text = error;
            _pnlError.Visible = true;
        }

        public void Show(EditOwnerVM viewModel)
        {
            _hdnId.Value = viewModel.Id;
            _tbFirstName.Text = viewModel.First;
            _tbLastName.Text = viewModel.Last;
        }

        protected void Save_OnClick(object sender, EventArgs e)
        {
            var id = int.Parse(_hdnId.Value);
            var first = _tbFirstName.Text;
            var last = _tbLastName.Text;

            CreatePresenter(id).SaveName(first, last);
        }

        protected void Delete_OnClick(object sender, EventArgs e)
        {
            var id = int.Parse(_hdnId.Value);
            CreatePresenter(id).Delete();
        }
    }
}