﻿
using PS.Auto.Web.Models;

namespace PS.Auto.Web.Views
{
    public interface IDefaultView : IView
    {
        void Show(DefaultVM model);
        
    }
}