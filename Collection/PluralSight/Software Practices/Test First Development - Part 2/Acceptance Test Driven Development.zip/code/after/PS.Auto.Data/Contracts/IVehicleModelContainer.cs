﻿using System.Data.Objects;

namespace PS.Auto.Data
{
    public interface IVehicleModelContainer
    {
        ObjectSet<AutoOwner> AutoOwners { get; }
        ObjectSet<Manufacturer> Manufacturers { get; }
        ObjectSet<ModelSpec> ModelSpecs { get; }
        ObjectSet<Vehicle> Vehicles { get; }
        int SaveChanges();
        void Dispose();
    }

    public partial class VehicleModelContainer : IVehicleModelContainer
    {

    }
}