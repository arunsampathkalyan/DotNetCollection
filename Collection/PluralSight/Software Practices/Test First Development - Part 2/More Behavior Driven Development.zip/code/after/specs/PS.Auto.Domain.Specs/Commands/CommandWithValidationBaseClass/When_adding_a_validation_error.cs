﻿
using Machine.Specifications;

namespace PS.Auto.Domain.Specs.Commands.CommandWithValidationBaseClass
{
    public class When_adding_a_validation_error 
        : When_a_command_is_newly_instantiated
    {
        Because of = () => _command.AddError();

        It Should_be_invalid = () =>
                               _command.Validate().IsValid.ShouldBeFalse();
        
        
    }
}