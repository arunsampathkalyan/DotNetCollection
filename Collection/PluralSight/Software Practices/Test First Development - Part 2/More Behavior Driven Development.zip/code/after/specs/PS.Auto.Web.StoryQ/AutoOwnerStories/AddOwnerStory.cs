﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using StoryQ;

namespace PS.Auto.Web.StoryQ.AutoOwnerStories
{
    [TestClass]
    public class AddOwnerStory
    {
        Mock<IAddOwnerView> _mockView;
        AddOwnerPresenter _presenter;
        string _firstName;
        string _lastName;
        IDataContext _ownerRepository;

        [TestInitialize]
        public void Init()
        {
            DataHelper.DeleteAllCurrentOwners();
            _ownerRepository = new SqlDataContext();
        }

        [TestCleanup]
        public void CleanUp()
        {
            DataHelper.DeleteAllCurrentOwners();
        }

        [TestMethod]
        public void AddOwner()
        {
            new Story("Add Owner")

                .InOrderTo("manage a list of Auto Owners")
                .AsA("list Administrator")
                .IWant("to add a new Auto Owner")

                .WithScenario("Happy Path")
                    .Given(IAmOnTheAddOwnerScreen)
                        .And(IHaveEnteredAValidFirstName)
                        .And(IHaveEnteredAValidLastName)
                    .When(IPressAdd)
                    .Then(TheNewOwnerIsPresentInTheDatabase)
                        .And(IAmRedirectedToTheMainListPage)

                .WithScenario("no first name")
                    .Given(IAmOnTheAddOwnerScreen)
                        .And(IHaveNotEnteredAFirstName)
                        .And(IHaveEnteredAValidLastName)
                    .When(IPressAdd)
                    .Then(IGetAnErrorMessage)

                .WithScenario("no last name")
                    .Given(IAmOnTheAddOwnerScreen)
                        .And(IHaveEnteredAValidFirstName)
                        .And(IHaveNotEnteredALastName)
                    .When(IPressAdd)
                    .Then(IGetAnErrorMessage)

                .ExecuteWithReport();
        }

    
        void IGetAnErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()));
        }

        void IAmRedirectedToTheMainListPage()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }

        void TheNewOwnerIsPresentInTheDatabase()
        {
            var owner = _ownerRepository.AutoOwners.FirstOrDefault(ao => ao.FirstName == _firstName && ao.LastName == _lastName);
            Assert.IsNotNull(owner);
        }

        void IPressAdd()
        {
            _presenter.AddNewOwner(_firstName, _lastName);
        }

        void IHaveEnteredAValidLastName()
        {
            _firstName = "Peter";
        }

        void IHaveEnteredAValidFirstName()
        {
            _lastName = "Griffin";
        }

        void IHaveNotEnteredALastName(){}

        void IHaveNotEnteredAFirstName(){}
        
        void IAmOnTheAddOwnerScreen()
        {
            _firstName = string.Empty;
            _lastName = string.Empty;

            _mockView = new Mock<IAddOwnerView>();
            _presenter = new AddOwnerPresenter(_mockView.Object);
        }
    }
}
