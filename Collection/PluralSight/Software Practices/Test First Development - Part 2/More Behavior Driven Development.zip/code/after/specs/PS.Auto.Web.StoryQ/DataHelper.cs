﻿
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;

namespace PS.Auto.Web.StoryQ
{
    public static class DataHelper
    {
        static readonly IDataContext _dataContext;
        static int _ownerCounter = 0;

        static DataHelper()
        {
            _dataContext = new SqlDataContext();
        }

        public static void DeleteAllCurrentOwners()
        {
            var currentOwners = _dataContext.AutoOwners;
            foreach (var currentOwner in currentOwners)
            {
                _dataContext.AutoOwners.DeleteObject(currentOwner);
            }
            _dataContext.Commit();    
        }

        public static int InsertNewOwner()
        {
            var owner = new AutoOwner()
            {
                FirstName = "Marge" + _ownerCounter,
                LastName = "Simpson" + _ownerCounter
            };
            _ownerCounter++;
            
            _dataContext.AutoOwners.AddObject(owner);
            _dataContext.Commit();

            return owner.Id;
        }

    }
}
