﻿using Machine.Specifications;
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Specs.Commands.DeleteOwner
{
    public class When_the_Id_is_negative_1 : With_a_command
    {
        Establish context = () => _command.Id = -1;

        Because of = () => _validationResult = _command.Validate();

        It Should_be_an_invalid_command = () =>
                                          _validationResult.IsValid.ShouldBeFalse();

        static ICommandValidationResult _validationResult;
    }
}