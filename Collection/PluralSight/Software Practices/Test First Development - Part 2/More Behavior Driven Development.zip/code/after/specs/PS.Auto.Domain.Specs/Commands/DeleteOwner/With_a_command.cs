﻿using Machine.Specifications;
using PS.Auto.Domain.Commands;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Specs.Commands.DeleteOwner
{
    public class With_a_command
    {
        Establish context = () =>
        {
            _fakeDataContext = new FakeDataContext();
            _owner = Mother.CreateAutoOwnerWithId();

            _command = new DeleteOwnerCommand(_fakeDataContext)
                           {
                               Id = _owner.Id
                           };

        };

        protected static DeleteOwnerCommand _command;
        protected static AutoOwner _owner;
        protected static FakeDataContext _fakeDataContext;
    }
}
