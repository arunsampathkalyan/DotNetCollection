﻿using Machine.Specifications;
using Moq;
using PS.Auto.Domain.Commands;
using PS.Auto.DomainContracts.Commands;
using It = Machine.Specifications.It;

namespace PS.Auto.Web.Specs.Presenters.EditOwner
{
    public class When_calling_Delete_on_EditOwnerPresenter 
        : With_a_new_EditOwnerPresenter
    {

        Establish context = () =>
        {
            _mockCommand = new Mock<IDeleteOwnerCommand>();
            _mockCommand.Setup(c => c.Validate())
                .Returns(new CommandValidationResult());

            _mockCommandFactory.Setup(f => f.CreateDeleteOwnerCommand())
                .Returns(_mockCommand.Object);
        };

        Because of = () => _presenter.Delete();

        It Should_call_redirect_on_the_view = () => 
            _mockView.Verify(v => v.Redirect(Moq.It.IsAny<string>()));

        It Should_execute_the_corrent_command = () =>
            _mockCommand.Verify(c => c.Execute());

        static Mock<IDeleteOwnerCommand> _mockCommand;
    }
}