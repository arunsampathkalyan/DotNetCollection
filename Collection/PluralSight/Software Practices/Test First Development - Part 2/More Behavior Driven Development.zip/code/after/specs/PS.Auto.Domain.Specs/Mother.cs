﻿
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Specs
{
    public static class Mother
    {
        static int counter = 0;

        public static AutoOwner CreateWithNoId()
        {
            return new AutoOwner()
            {
                FirstName = "Peter",
                LastName = "Griffin" + counter++
            };
        }

        public static AutoOwner CreateAutoOwnerWithId()
        {
            var autoOwner = CreateWithNoId();
            autoOwner.Id = 99 + counter;

            return autoOwner;
        }
    }
}
