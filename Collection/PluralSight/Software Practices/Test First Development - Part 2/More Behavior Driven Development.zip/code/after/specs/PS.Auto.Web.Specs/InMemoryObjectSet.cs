﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Linq.Expressions;

namespace PS.Auto.Web.Specs
{
    public class InMemoryObjectSet<T> : IObjectSet<T> where T : class
    {
        readonly IQueryable<T> _queryableSet;
        readonly HashSet<T> _entitySet;

        public InMemoryObjectSet()
            : this(Enumerable.Empty<T>())
        { }

        public InMemoryObjectSet(IEnumerable<T> entities)
        {
            _entitySet = new HashSet<T>();

            foreach (T entity in entities)
            {
                _entitySet.Add(entity);
            }

            _queryableSet = _entitySet.AsQueryable();
        }

        public void AddObject(T entity)
        {
            _entitySet.Add(entity);
        }

        public void Attach(T entity)
        {
            _entitySet.Add(entity);
        }

        public void DeleteObject(T entity)
        {
            _entitySet.Remove(entity);
        }

        public void Detach(T entity)
        {
            _entitySet.Remove(entity);
        }

        public Type ElementType
        {
            get { return _queryableSet.ElementType; }
        }

        public Expression Expression
        {
            get { return _queryableSet.Expression; }
        }

        public IQueryProvider Provider
        {
            get { return _queryableSet.Provider; }
        }

        public IEnumerator<T> GetEnumerator()
        {
            return _entitySet.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
