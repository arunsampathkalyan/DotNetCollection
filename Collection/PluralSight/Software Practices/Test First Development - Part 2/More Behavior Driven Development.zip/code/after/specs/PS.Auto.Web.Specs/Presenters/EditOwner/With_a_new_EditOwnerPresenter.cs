﻿using Machine.Specifications;
using Moq;
using PS.Auto.Domain.Entities;
using PS.Auto.DomainContracts.Commands;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Specs.Presenters.EditOwner
{
    public class With_a_new_EditOwnerPresenter
    {
        protected static Mock<IEditOwnerView> _mockView;
        protected static Mock<ICommandFactory> _mockCommandFactory;

        
        protected static AutoOwner _owner;
//        protected static FakeDataContext _fakeDataContext;

        protected static EditOwnerPresenter _presenter;

        Establish context = () =>
        {
            _mockView = new Mock<IEditOwnerView>();
//            _fakeDataContext = new FakeDataContext();
            _mockCommandFactory = new Mock<ICommandFactory>();
            _owner = Mother.CreateAutoOwnerWithId();

            _presenter = new EditOwnerPresenter(_owner.Id, 
                                                _mockView.Object, 
                                                null,
                                                _mockCommandFactory.Object);
        };

        
    }
}
