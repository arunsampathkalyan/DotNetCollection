﻿using Machine.Specifications;
using PS.Auto.Domain.Commands;
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Specs.Commands.DeleteOwner
{
    public class When_the_IDataContext_is_null
    {
        Establish context = () => _command = new DeleteOwnerCommand(null);

        Because of = () => _validationResult = _command.Validate();

        It Should_be_an_invalid_command = () =>
            _validationResult.IsValid.ShouldBeFalse();

        It Should_provide_an_error_message_that_isnt_empty = () =>
            _validationResult.GetAsMessage().ShouldNotBeEmpty();

        It Should_provide_an_error_message_that_isnt_null = () =>
            _validationResult.GetAsMessage().ShouldNotBeEmpty();

        
        static DeleteOwnerCommand _command;
        static ICommandValidationResult _validationResult;
    }
}