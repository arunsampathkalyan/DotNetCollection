﻿using System.Linq;
using Machine.Specifications;

namespace PS.Auto.Domain.Specs.Commands.DeleteOwner
{
    public class When_executing_a_valid_DeleteOwnerCommand : With_a_command
    {
        Establish context = () => 
                            _fakeDataContext.AutoOwners.AddObject(_owner);

        Because of = () => _command.Execute();

        It Should_delete_the_owner_from_the_repo = () =>
                                                   ShouldExtensionMethods.ShouldBeNull(_fakeDataContext.AutoOwners.FirstOrDefault(o => o.Id == _owner.Id));

        It Should_be_a_valid_command = () =>
                                       _command.Validate().IsValid.ShouldBeTrue();

        It Should_commit_the_DataContext = () => _fakeDataContext.Committed.ShouldEqual(true);
    }
}