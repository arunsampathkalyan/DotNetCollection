﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using StoryQ;

namespace PS.Auto.Web.StoryQ.AutoOwnerStories
{
    [TestClass]
    public class DeleteOwnerStory
    {
        IDataContext _dataContext;
        int _ownerId;
        Mock<IEditOwnerView> _mockView;
        EditOwnerPresenter _presenter;

        [TestInitialize]
        public void Init()
        {
            DataHelper.DeleteAllCurrentOwners();
            _dataContext = new SqlDataContext();
            _ownerId = DataHelper.InsertNewOwner();
        }

        [TestCleanup]
        public void Dispose()
        {
            DataHelper.DeleteAllCurrentOwners();
        }

        [TestMethod]
        public void DeleteOwner()
        {
            new Story("Delete Owner")
                .InOrderTo("groom the list of automobile owners")
                .AsA("List Owner")
                .IWant("to delete an existing Auto Owner from the List")
                
                .WithScenario("Happy Path")
                    .Given(IAmEditingAnAutoOwner)
                    .When(IPressDelete)
                    .Then(TheAutoOwnerIsRemovedFromTheSystem)
                        .And(IAmReturnedToTheMainOwnerList)
                
                .WithScenario("Already Gone")
                    .Given(IAmEditingAnAutoOwner)
                    .When(IPressDelete)
                        .And(TheAutoOwnerHasAlreadyBeenDeleted)
                    .Then(IReceiveNoErrorMessage)
                        .And(IAmReturnedToTheMainOwnerList)

                .ExecuteWithReport();
        }

        void IAmEditingAnAutoOwner()
        {
            _mockView = new Mock<IEditOwnerView>();
            _presenter = new EditOwnerPresenter(_mockView.Object, _ownerId);
        }


        void IPressDelete()
        {
            _presenter.Delete();
        }

        void TheAutoOwnerIsRemovedFromTheSystem()
        {
            var owner = new SqlDataContext().AutoOwners.FirstOrDefault(ao => ao.Id == _ownerId);
            Assert.IsNull(owner);
        }

        void IAmReturnedToTheMainOwnerList()
        {
            _mockView.Verify(v => v.Redirect(It.IsAny<string>()));
        }

        void TheAutoOwnerHasAlreadyBeenDeleted()
        {
            DataHelper.DeleteAllCurrentOwners();
        }

        void IReceiveNoErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()), Times.Never());
        }
    }
}