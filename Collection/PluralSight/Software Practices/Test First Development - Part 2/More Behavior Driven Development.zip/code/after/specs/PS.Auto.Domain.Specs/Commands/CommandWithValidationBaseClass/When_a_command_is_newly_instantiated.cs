﻿using Machine.Specifications;

namespace PS.Auto.Domain.Specs.Commands.CommandWithValidationBaseClass
{
    public class When_a_command_is_newly_instantiated
    {
        Establish context = () => _command = new FakeCommandBase();

        It Is_valid = () => 
            _command.Validate().IsValid.ShouldBeTrue();

        protected static FakeCommandBase _command;
    }
}
