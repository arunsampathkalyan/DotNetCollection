﻿using System.Web;

namespace PS.Auto.Web.Views
{
    public abstract class ViewBase : System.Web.UI.Page, IView
    {
        public abstract void ShowError(string error);

        public void Redirect(string url)
        {
            HttpContext.Current.Response.Redirect(url, true);
        }
    }
}