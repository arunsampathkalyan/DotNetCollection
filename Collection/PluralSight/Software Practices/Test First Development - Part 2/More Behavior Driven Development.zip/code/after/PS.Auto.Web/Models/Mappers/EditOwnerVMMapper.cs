﻿
using System;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Web.Models.Mappers
{
    public class EditOwnerVMMapper
    {
        public EditOwnerVM From(AutoOwner owner)
        {
            if (owner == null) 
                throw new ArgumentNullException("owner");

            return new EditOwnerVM
            {
                Id = owner.Id.ToString(),
                First = owner.FirstName,
                Last = owner.LastName
            };
        }
    }
}