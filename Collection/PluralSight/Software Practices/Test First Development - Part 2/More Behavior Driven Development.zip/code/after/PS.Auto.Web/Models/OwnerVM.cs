﻿
namespace PS.Auto.Web.Models
{
    public class OwnerVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}