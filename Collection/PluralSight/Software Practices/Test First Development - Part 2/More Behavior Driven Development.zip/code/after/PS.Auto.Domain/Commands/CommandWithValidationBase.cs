﻿
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Commands
{
    public abstract class CommandWithValidationBase : ICommandWithValidation
    {
        readonly CommandValidationResult _validationResult;

        protected CommandWithValidationBase()
        {
            _validationResult = new CommandValidationResult();
        }

        public abstract void Execute();

        public virtual ICommandValidationResult Validate()
        {
            return _validationResult;
        }

        public void ExecuteIfValid()
        {
            if(_validationResult.IsValid)
                Execute();
        }

        protected void AddValidationError(string errorMessage)
        {
            _validationResult.AddError(errorMessage);
        }
    }
}