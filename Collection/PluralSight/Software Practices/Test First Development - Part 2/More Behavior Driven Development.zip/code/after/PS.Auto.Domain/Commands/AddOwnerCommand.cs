﻿using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Commands
{
    public class AddOwnerCommand : CommandWithValidationBase, IAddOwnerCommand
    {
        readonly IDataContext _dataContext;

        public AddOwnerCommand()
            :this(new SqlDataContext())
        {}

        public AddOwnerCommand(IDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override void Execute()
        {
            var owner = new AutoOwner()
                              {
                                  FirstName = FirstName,
                                  LastName = LastName
                              };

            _dataContext.AutoOwners.AddObject(owner);
            _dataContext.Commit();
        }

        public override ICommandValidationResult Validate()
        {
            ValidateFirstName();
            ValidateLastName();
            ValidateDataDataContext();

            return base.Validate();
        }

        void ValidateDataDataContext()
        {
            if(_dataContext == null)
                AddValidationError("Data Access Unit of Work is not initialized");
        }

        void ValidateFirstName()
        {
            if(string.IsNullOrEmpty(FirstName))
                AddValidationError("Please provide a valid first name");
        }

        void ValidateLastName()
        {
            if (string.IsNullOrEmpty(LastName))
                AddValidationError("Please provide a valid last name");
        }
    }
}