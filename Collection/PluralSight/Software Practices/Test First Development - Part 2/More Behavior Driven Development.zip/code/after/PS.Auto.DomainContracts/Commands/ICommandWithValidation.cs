﻿
namespace PS.Auto.DomainContracts.Commands
{
    public interface ICommandWithValidation : ICommand
    {
        ICommandValidationResult Validate();
        void ExecuteIfValid();
    }
}