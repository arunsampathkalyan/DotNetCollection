﻿namespace PS.Auto.DomainContracts.Commands
{
    public interface IDeleteOwnerCommand : ICommandWithValidation
    {
        int Id { get; set; }
    }
}