﻿namespace PS.Auto.DomainContracts.Commands
{
    public interface ICommandValidationResult
    {
        bool IsValid { get; }
        string GetAsMessage();
        string GetAsMessage(string delimiter);
    }
}