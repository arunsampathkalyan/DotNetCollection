﻿namespace PS.Auto.DomainContracts.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}