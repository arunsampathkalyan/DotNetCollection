﻿using System.Linq;
using Machine.Specifications;

namespace PS.Auto.Web.Specs.Presenters.EditOwner
{
    public class When_calling_Delete_on_EditOwnerPresenter 
        : With_a_new_EditOwnerPresenter
    {

        Establish context = AddOwnerToFakeRepository;

        
        Because of = () => _presenter.Delete();

        It Should_call_redirect_on_the_view = () => 
            _mockView.Verify(v => v.Redirect(Moq.It.IsAny<string>()));

        It Should_delete_the_owner_from_the_repo = () =>
            _fakeDataContext
                .AutoOwners
                .FirstOrDefault(ao => ao.Id == _owner.Id)
                .ShouldBeNull();

        
        static void AddOwnerToFakeRepository()
        {
            _fakeDataContext.AutoOwners.AddObject(_owner);
            _fakeDataContext
                .AutoOwners
                .FirstOrDefault(ao => ao.Id == _owner.Id)
                .ShouldNotBeNull();
        }
    }
}