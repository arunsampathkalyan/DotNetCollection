﻿namespace PS.Auto.DomainContracts.Commands
{
    public interface ICommandFactory 
    {
        IEditOwnerCommand CreateEditOwnerCommand();
        IAddOwnerCommand  CreateAddOwnerCommand();
    }
}