﻿namespace PS.Auto.DomainContracts.Commands
{
    public interface IAddOwnerCommand : ICommandWithValidation
    {
        string FirstName { get; set; }
        string LastName { get; set; }
    }
}