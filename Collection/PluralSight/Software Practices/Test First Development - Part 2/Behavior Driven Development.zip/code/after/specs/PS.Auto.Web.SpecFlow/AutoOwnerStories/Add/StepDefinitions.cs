﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using TechTalk.SpecFlow;

namespace PS.Auto.Web.SpecFlow.AutoOwnerStories.Add
{
    [Binding]
    public class StepDefinitions
    {
        Mock<IAddOwnerView> _mockView;
        AddOwnerPresenter _presenter;
        string _firstName;
        string _lastName;
        SqlDataContext _ownerRepository;

        [BeforeScenario()]
        public void Init()
        {
            DataHelper.DeleteAllCurrentOwners();
            _ownerRepository = new SqlDataContext();
        }

        [AfterScenario()]
        public void CleanUp()
        {
            DataHelper.DeleteAllCurrentOwners();
        }


        [Given(@"I am on the Add Owner Screen")]
        public void GivenIAmOnTheAddOwnerScreen()
        {
            _mockView = new Mock<IAddOwnerView>();
            _presenter = new AddOwnerPresenter(_mockView.Object);
        }

        [Given(@"I have entered a valid first name")]
        public void GivenIHaveEnteredAValidFirstName()
        {
            _firstName = "Homer";
        }

        [Given(@"I have entered a valid last name")]
        public void GivenIHaveEnteredAValifLastName()
        {
            _lastName = "Simpson";
        }

        [Given(@"I have not entered a last name")]
        public void GivenIHaveNotEnteredALastName()
        {
            _lastName = string.Empty;
        }

        [Given(@"I have not entered a first name")]
        public void GivenIHaveNotEnteredAFirstName()
        {
            _firstName = string.Empty;
        }


        [Then(@"I get an error message")]
        public void ThenIGetAnErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()));
        }

        [Then(@"I am redirected to the main list page")]
        public void ThenIAmRedirectedToTheMainListPage()
        {
            _mockView.Verify(v => v.Redirect("~/"));
        }

        [Then(@"the new owner is present in the database")]
        public void ThenTheNewOwnerIsPresentInTheDatabase()
        {
            var owner = _ownerRepository.AutoOwners.FirstOrDefault(o => o.FirstName == _firstName && o.LastName == _lastName);
            Assert.IsNotNull(owner);
        }

        [When(@"I press Add")]
        public void WhenIPressAdd()
        {
            _presenter.AddNewOwner(_firstName, _lastName);
        }
    }
}
