﻿using Machine.Specifications;

namespace PS.Auto.Domain.Specs.Commands.DeleteOwner
{
    public class When_the_owner_is_not_in_the_repo : With_a_command
    {
        Because of = () => _command.Execute();

        It Should_still_be_a_valid_command = () =>
                                             _command.Validate().IsValid.ShouldBeTrue();

        It Should_execute_with_an_exception = () => _command.Execute();
    }
}