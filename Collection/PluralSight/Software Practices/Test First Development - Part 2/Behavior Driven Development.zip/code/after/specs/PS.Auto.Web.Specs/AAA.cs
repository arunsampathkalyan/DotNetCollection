﻿
using NUnit.Framework;

namespace PS.Auto.Web.Specs
{
    public class AAA
    {
        [SetUp]
        public void MainSetup()
        {
            Arrange();
            Act();
        }

        [TearDown]
        protected void MainTeardown()
        {
            CleanUp();
        }

        protected virtual void Act() { }
        protected virtual void Arrange() { }
        protected virtual void CleanUp() { }
    }
}
