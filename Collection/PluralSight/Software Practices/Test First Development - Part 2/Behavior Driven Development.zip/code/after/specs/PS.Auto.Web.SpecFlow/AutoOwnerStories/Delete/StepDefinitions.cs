﻿using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using PS.Auto.Domain.Repositories;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;
using TechTalk.SpecFlow;

namespace PS.Auto.Web.SpecFlow.AutoOwnerStories.Delete
{
    [Binding]
    public class StepDefinitions
    {
        Mock<IEditOwnerView> _mockView;
        int _ownerId;
        SqlDataContext _dataContext;
        EditOwnerPresenter _presenter;

        [BeforeScenario()]
        public void Init()
        {
            DataHelper.DeleteAllCurrentOwners();
            _ownerId = DataHelper.InsertNewOwner().Id;
        }

        [AfterScenario()]
        public void CleanUp()
        {
            DataHelper.DeleteAllCurrentOwners();
        }

        [Given(@"I am editing an Auto Owner")]
        public void GivenIAmEditingAnAutoOwner()
        {
            _mockView = new Mock<IEditOwnerView>();
            _presenter = new EditOwnerPresenter(_mockView.Object, _ownerId);
        }

        [When(@"I press Delete")]
        public void WhenIPressDelete()
        {
            _presenter.Delete();
        }

        [When(@"the Auto Owner has already been deleted")]
        public void WhenTheAutoOwnerHasAlreadyBeenDeleted()
        {
            DataHelper.DeleteAllCurrentOwners();
        }

        [Then(@"I receive no error message")]
        public void ThenIReceiveNoErrorMessage()
        {
            _mockView.Verify(v => v.ShowError(It.IsAny<string>()), Times.Never());
        }


        [Then(@"I am returned to the main Owner List")]
        public void ThenIAmReturnedToTheMainOwnerList()
        {
            _mockView.Verify(v => v.Redirect("~/"));
        }

        [Then(@"the Auto Owner is removed from the system")]
        public void ThenTheAutoOwnerIsRemovedFromTheSystem()
        {
            var foundOwner = new SqlDataContext().AutoOwners.FirstOrDefault(ao => ao.Id == _ownerId);
            Assert.IsNull(foundOwner);
        }
    }
}