﻿using System.Data.Objects;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;

namespace PS.Auto.Web.Specs
{
    public class FakeDataContext : IDataContext
    {
        public FakeDataContext()
        {
            Committed = false;

            AutoOwners = new InMemoryObjectSet<AutoOwner>();
        }

        public bool Committed { get; set; }

        public IObjectSet<AutoOwner> AutoOwners { get; set; }

        public void Commit()
        {
            Committed = true;
        }
    }
}
