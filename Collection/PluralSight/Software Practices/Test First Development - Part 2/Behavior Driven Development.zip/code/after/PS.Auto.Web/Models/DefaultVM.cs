﻿using System.Collections.Generic;

namespace PS.Auto.Web.Models
{
    public class DefaultVM
    {
        public DefaultVM()
        {
            Owners = new List<OwnerVM>();
        }

        public IEnumerable<OwnerVM> Owners { get; set; }
    }
}