﻿namespace PS.Auto.Web.Views
{
    public interface IAddOwnerView : IView
    {
        
    }
}