﻿using System;
using PS.Auto.Web.Models;
using PS.Auto.Web.Presenters;
using PS.Auto.Web.Views;

namespace PS.Auto.Web
{
    public partial class _Default : ViewBase, IDefaultView
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CreatePresenter().Init();
        }

        public void Show(DefaultVM model)
        {
            _ownersRepeater.DataSource = model.Owners;
            _ownersRepeater.DataBind();
        }

        protected void AddNewOwner_Click(object sender, EventArgs e)
        {
            CreatePresenter().AddNewOwner();
        }

        private DefaultPresenter CreatePresenter()
        {
            return new DefaultPresenter(this);
        }

        public override void ShowError(string error)
        {
            throw new NotImplementedException();
        }
    }
}