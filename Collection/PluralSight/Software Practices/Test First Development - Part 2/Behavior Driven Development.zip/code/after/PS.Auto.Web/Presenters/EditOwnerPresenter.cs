﻿using System.Linq;
using PS.Auto.Domain.Commands;
using PS.Auto.Domain.Repositories;
using PS.Auto.DomainContracts.Commands;
using PS.Auto.Web.Models.Mappers;
using PS.Auto.Web.Views;

namespace PS.Auto.Web.Presenters
{
    public class EditOwnerPresenter
    {
        readonly IEditOwnerView _view;
        readonly int _ownerId;
        readonly IDataContext _dataContext;
        readonly ICommandFactory _commandFactory;

        readonly EditOwnerVMMapper _vmMapper;

        public EditOwnerPresenter(IEditOwnerView view, int ownerId)
            : this(ownerId, view, new SqlDataContext(), new CommandFactory()) 
        {}

        public EditOwnerPresenter(int ownerId, IEditOwnerView view, IDataContext dataContext, ICommandFactory commandFactory)
        {
            _view = view;
            _ownerId = ownerId;
            _dataContext = dataContext;
            _commandFactory = commandFactory;

            _vmMapper = new EditOwnerVMMapper();
        }

        public void Init()
        {
            var owner = _dataContext.AutoOwners.FirstOrDefault(ao => ao.Id == _ownerId);
            if (owner == null)
            {
                _view.ShowError("Auto Owner not found.");
                return;
            }

            var model = _vmMapper.From(owner);
            _view.Show(model);
        }

        public void SaveName(string first, string last)
        {
            var command = _commandFactory.CreateEditOwnerCommand();
                command.Id = _ownerId;
                command.FirstName = first;
                command.LastName = last;

            if (!command.Validate().IsValid)
            {
                _view.ShowError(command.Validate().GetAsMessage());
                return;
            }

            command.Execute();
            
            _view.Redirect("~/");
        }

        public void Delete()
        {
            var command = new DeleteOwnerCommand(_dataContext);
                command.Id = _ownerId;

            if (!command.Validate().IsValid)
            {
                _view.ShowError(command.Validate().GetAsMessage());
                return;
            }

            command.Execute();
            
            _view.Redirect("~/");
        }
    }
}