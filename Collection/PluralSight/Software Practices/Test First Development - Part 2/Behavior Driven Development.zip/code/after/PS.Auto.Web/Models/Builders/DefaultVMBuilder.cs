﻿using System.Collections;
using System.Collections.Generic;
using AutoMapper;
using PS.Auto.Domain.Entities;
using PS.Auto.Domain.Repositories;

namespace PS.Auto.Web.Models.Builders
{
    public class DefaultVMBuilder
    {
        readonly IDataContext _dataContext;

        public DefaultVMBuilder()
            :this(new SqlDataContext())
        {
            
        }

        public DefaultVMBuilder(IDataContext dataContext)
        {
            _dataContext = dataContext;

            Mapper.CreateMap<AutoOwner, OwnerVM>()
                .ForMember(vm => vm.Name, ao => ao.MapFrom(d => d.GetFullName()));

        }

        public DefaultVM CreateModel()
        {
            var autoOwners = _dataContext.AutoOwners;

            IList<OwnerVM> ownerVms = new List<OwnerVM>();
            foreach (var autoOwner in autoOwners)
            {
                var vm = Mapper.Map<AutoOwner, OwnerVM>(autoOwner);
                ownerVms.Add(vm);
            }

            var model = new DefaultVM
                            {
                                Owners = ownerVms
                            };

            return model;
        }
    }
}