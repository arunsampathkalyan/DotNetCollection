﻿using System.Configuration;
using System.Data.Objects;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Repositories
{
    public class SqlDataContext : IDataContext
    {
        public SqlDataContext()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["VehicleModelContainer"].ConnectionString;

            _context = new ObjectContext(connectionString);
            _context.ContextOptions.LazyLoadingEnabled = true;
        }


        public IObjectSet<AutoOwner> AutoOwners
        {
            get
            {
                if(_autoOwners == null)
                    _autoOwners = _context.CreateObjectSet<AutoOwner>();

                return _autoOwners;
            }
        }

        public void Commit()
        {
            _context.SaveChanges();
        }

        IObjectSet<AutoOwner> _autoOwners = null;
        readonly ObjectContext _context;
    }
}
