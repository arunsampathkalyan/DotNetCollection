﻿using System.Linq;
using PS.Auto.Domain.Repositories;
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Commands
{
    public class DeleteOwnerCommand : CommandWithValidationBase, IDeleteOwnerCommand
    {
        readonly IDataContext _dataContext;

        public DeleteOwnerCommand()
            : this(new SqlDataContext())
        {
            
        }

        public DeleteOwnerCommand(IDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public int Id { get; set;}

        public override void Execute()
        {
            var owner = _dataContext.AutoOwners.FirstOrDefault(o => o.Id == Id);
            _dataContext.AutoOwners.DeleteObject(owner);

        }

        public override ICommandValidationResult Validate()
        {
            ValidateDataContext();
            
            if(Id < 0)
                AddValidationError("Invalid Id");

            return base.Validate();
        }

        void ValidateDataContext()
        {
            if(_dataContext == null)
                base.AddValidationError("DataContext was not initialized");
        }
    }
}