﻿using System.Linq;
using PS.Auto.Domain.Repositories;
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Commands
{
    public class EditOwnerCommand : CommandWithValidationBase, IEditOwnerCommand
    {
        readonly IDataContext _dataContext;

        public EditOwnerCommand()
            : this(new SqlDataContext())
        {}

        public EditOwnerCommand(IDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override void Execute()
        {
            var owner = _dataContext.AutoOwners.FirstOrDefault(ao => ao.Id == Id);
                owner.FirstName = FirstName;
                owner.LastName = LastName;

            _dataContext.Commit();
        }

        public override ICommandValidationResult Validate()
        {
            ValidateId();
            ValidateFirstName();
            ValidateLastName();
            ValidateDataDataContext();

            return base.Validate();
        }

        void ValidateId()
        {
            if (Id < 0)
                AddValidationError("The Owner's ID is invalid: " + Id);
        }

        void ValidateDataDataContext()
        {
            if(_dataContext == null)
                AddValidationError("Data Unit of Work is not initialized");
        }

        void ValidateFirstName()
        {
            if(string.IsNullOrEmpty(FirstName))
                AddValidationError("Please provide a valid first name");
        }

        void ValidateLastName()
        {
            if (string.IsNullOrEmpty(LastName))
                AddValidationError("Please provide a valid last name");
        }
    }
}