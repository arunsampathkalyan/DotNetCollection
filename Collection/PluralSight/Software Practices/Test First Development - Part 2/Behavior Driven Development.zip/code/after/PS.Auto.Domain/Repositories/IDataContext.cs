﻿using System.Data.Objects;
using PS.Auto.Domain.Entities;

namespace PS.Auto.Domain.Repositories
{
    public interface IDataContext
    {
        IObjectSet<AutoOwner> AutoOwners { get; }
        void Commit();
    }
}