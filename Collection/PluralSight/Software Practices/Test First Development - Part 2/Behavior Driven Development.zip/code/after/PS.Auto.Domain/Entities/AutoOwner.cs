﻿
namespace PS.Auto.Domain.Entities
{
    public partial class AutoOwner
    {
        public string GetFullName()
        {
            return FirstName + " " + LastName;
        }
    }
}
