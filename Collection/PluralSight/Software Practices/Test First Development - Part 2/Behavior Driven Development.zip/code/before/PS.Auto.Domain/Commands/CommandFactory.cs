﻿
using PS.Auto.DomainContracts.Commands;

namespace PS.Auto.Domain.Commands
{
    public class CommandFactory : ICommandFactory
    {
        public IEditOwnerCommand CreateEditOwnerCommand()
        {
            return new EditOwnerCommand();
        }

        public IAddOwnerCommand CreateAddOwnerCommand()
        {
            return new AddOwnerCommand();
        }

    }
}