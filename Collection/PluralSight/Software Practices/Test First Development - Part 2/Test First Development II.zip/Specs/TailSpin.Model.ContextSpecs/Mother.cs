using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tailspin.Model;

namespace TailSpin.Model.ContextSpecs
{
    public static class Mother
    {
        public static Product MakeProduct()
        {
            return new Product(Guid.NewGuid().ToString(), "A Fake Product", "A Fake Product Blurb", true, (decimal) 4.0)
            {
                Price = (decimal) 10.01,
            };
        }
    }
}
