using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.ContextSpecs.CartSpecs
{
    [TestClass]
    public class When_clearing_the_cart 
        : Context_2_different_products_are_in_the_cart
    {
        protected override void BecauseOf()
        {
            _shoppingCart.ClearItems();
        }

        [TestMethod]
        public void Then_the_cart_is_empty()
        {
            Assert.AreEqual(0, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_the_cart_subTotal_is_0()
        {
            Assert.AreEqual(0, _shoppingCart.SubTotal);
        }
    }
}