using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.ContextSpecs.CartSpecs
{
    [TestClass]
    public class When_adding_product_with_0_quantity
        : Context_2_different_products_are_in_the_cart
    {
        private int _totalItemsBeforeAdd;
        private decimal _subTotalBeforeAdd;

        protected override void SetContext()
        {
            base.SetContext();
            _subTotalBeforeAdd = _shoppingCart.SubTotal;
            _totalItemsBeforeAdd = _shoppingCart.TotalItems;
        }

        protected override void BecauseOf()
        {
            base.BecauseOf();
            _shoppingCart.AddItem(_2ndProduct, 0);
        }

        [TestMethod]
        public void Then_item_count_does_not_change()
        {
            Assert.AreEqual(_totalItemsBeforeAdd, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_subTotal_does_not_change()
        {
            Assert.AreEqual(_subTotalBeforeAdd, _shoppingCart.SubTotal);
        }

    }
}