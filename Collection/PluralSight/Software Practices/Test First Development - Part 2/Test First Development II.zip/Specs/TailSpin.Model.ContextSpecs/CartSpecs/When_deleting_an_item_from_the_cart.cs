using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.ContextSpecs.CartSpecs
{
    [TestClass]
    public class When_deleting_an_item_from_the_cart: Context_2_different_products_are_in_the_cart
    {
        protected override void BecauseOf()
        {
            _shoppingCart.RemoveItem(_1stProduct);
        }

        [TestMethod]
        public void Then_other_items_are_still_in_the_cart()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_2ndProduct));
        }


        [TestMethod]
        public void Then_the_cart_Item_Count_is_still_correct()
        {
            Assert.AreEqual(1, _shoppingCart.TotalItems);
        }
    }
}