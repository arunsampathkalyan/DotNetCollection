using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.ContextSpecs.CartSpecs
{
    public class Context_2_different_products_are_in_the_cart 
        : Context_1_product_in_cart
    {
        protected Product _2ndProduct;

        protected override void SetContext()
        {
            base.SetContext();

            _2ndProduct = Mother.MakeProduct();
            _shoppingCart.AddItem(_2ndProduct, 1, DateTime.Now.AddSeconds(1));
        }
    }

    [TestClass]
    public class When_2_different_items_are_in_the_cart
        : Context_2_different_products_are_in_the_cart
    {
        [TestMethod]
        public void Then_there_should_be_2_items_in_the_cart()
        {
            Assert.AreEqual(2, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_cart_subtotal_should_be_sum_of_2_items()
        {
            Assert.AreEqual(_1stProduct.Price + _2ndProduct.Price, _shoppingCart.SubTotal);
        }

        [TestMethod]
        public void Then_both_prducts_can_be_retrieved_from_cart()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_1stProduct.SKU).Product);
            Assert.IsNotNull(_shoppingCart.FindItem(_2ndProduct.SKU).Product);
        }
    }

}