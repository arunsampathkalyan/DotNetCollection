using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.ContextSpecs.CartSpecs
{
    [TestClass]
    public class When_adjusting_items_in_cart_to_0
        : Context_1_product_in_cart
    {

        protected override void BecauseOf()
        {
            base.BecauseOf();
            _shoppingCart.AdjustQuantity(_1stProduct, 0);
        }

        [TestMethod]
        public void Then_the_total_items_in_cart_should_be_0()
        {
            Assert.AreEqual(0, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_the_cart_subTotal_should_be_0()
        {
            Assert.AreEqual(0, _shoppingCart.SubTotal);
        }
    }
}