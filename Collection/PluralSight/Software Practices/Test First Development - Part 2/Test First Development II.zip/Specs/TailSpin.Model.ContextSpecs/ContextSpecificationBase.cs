using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.ContextSpecs
{
    [TestClass]
    public class ContextSpecificationBase
    {
        [TestInitialize]
        public void MainSetup()
        {
            SetContext();
            BecauseOf();
        }

        [TestCleanup]
        public void MainTeardown()
        {
            CleanUp();
        }

        protected virtual void SetContext() { }
        protected virtual void BecauseOf() { }

        protected virtual void CleanUp() { }
    }
}