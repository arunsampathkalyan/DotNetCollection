using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    [TestClass]
    public class When_adjusting_items_in_cart_to_10
        : Context_1_product_in_cart
    {

        protected override void Act()
        {
            base.Act();
            _shoppingCart.AdjustQuantity(_1stProduct, 10);
        }

        [TestMethod]
        public void Then_the_total_items_in_cart_should_increase_accordingly()
        {
            Assert.AreEqual(10, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_the_cart_subTotal_should_increase_accordingly()
        {
            Assert.AreEqual(_1stProduct.Price * 10, _shoppingCart.SubTotal);
        }
    }
}