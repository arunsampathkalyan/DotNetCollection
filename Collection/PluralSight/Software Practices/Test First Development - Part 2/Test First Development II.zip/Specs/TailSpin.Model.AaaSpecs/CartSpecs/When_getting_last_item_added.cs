using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    [TestClass]
    public class When_getting_last_item_added
        : Context_2_different_products_are_in_the_cart
    {
        private ShoppingCartItem _itemLastAdded;
        
        protected override void Act()
        {
            base.Act();
            _itemLastAdded = _shoppingCart.ItemLastAdded;
        }

        [TestMethod]
        public void Then_the_correct_item_is_returned()
        {
            Assert.AreEqual(_itemLastAdded.Product.SKU, _2ndProduct.SKU);
        }
    }
}