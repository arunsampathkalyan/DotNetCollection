﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    public class Context_2_of_the_same_products_are_in_the_cart 
        : Context_1_product_in_cart
    {
        protected override void Arrange()
        {
            base.Arrange();
            _shoppingCart.AddItem(_1stProduct, 1, DateTime.Now.AddSeconds(1));
        }
    }

    [TestClass]
    public class When_2_of_the_same_products_are_in_the_cart
        : Context_2_of_the_same_products_are_in_the_cart
    {
        [TestMethod]
        public void Then_cart_should_contain_2_items()
        {
            Assert.AreEqual(2, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_cart_subTotal_should_be_2X_product_price()
        {
            Assert.AreEqual(2 * _1stProduct.Price, _shoppingCart.SubTotal);
        }

        [TestMethod]
        public void Then_the_products_may_be_retrieved()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_1stProduct.SKU));
        }
    }

}