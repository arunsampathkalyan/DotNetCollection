using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    [TestClass]
    public class When_retrieving_existing_cart_item_by_SKU 
        : Context_1_product_in_cart
    {
        private ShoppingCartItem _foundItem;

        protected override void Act()
        {
            _foundItem = _shoppingCart.FindItem(_1stProduct.SKU);
        }

        [TestMethod]
        public void Then_the_correct_item_is_returned()
        {
            Assert.AreEqual(_foundItem.Product.SKU, _1stProduct.SKU);
        }
    }
}