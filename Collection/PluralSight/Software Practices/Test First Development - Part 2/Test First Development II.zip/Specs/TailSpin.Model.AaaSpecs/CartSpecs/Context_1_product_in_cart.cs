using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    public class Context_1_product_in_cart 
        : AAA
    {
        protected Product _1stProduct;
        protected ShoppingCart _shoppingCart;

        protected override void Arrange()
        {
            _1stProduct = Mother.MakeProduct();
            
            _shoppingCart = new ShoppingCart("Test Cart");
            _shoppingCart.AddItem(_1stProduct);
        }
    }

    [TestClass]
    public class When_a_product_is_added_to_the_cart
        : Context_1_product_in_cart
    {
    
        [TestMethod]
        public void Then_the_cart_item_count_is_1()
        {
            Assert.AreEqual(1, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_the_cart_subtotal_matches_the_price_of_the_product()
        {
            Assert.AreEqual(_1stProduct.Price, _shoppingCart.SubTotal);
        }

        [TestMethod]
        public void Then_the_product_may_be_retrieved_from_the_cart()
        {
            Assert.AreEqual(_1stProduct.SKU, _shoppingCart.Items[0].Product.SKU);
        }
    }
}