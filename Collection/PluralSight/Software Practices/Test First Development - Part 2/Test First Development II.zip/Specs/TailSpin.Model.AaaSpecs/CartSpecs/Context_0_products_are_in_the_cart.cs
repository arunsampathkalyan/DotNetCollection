using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    public class Context_0_products_are_in_the_cart
        : AAA
    {
        protected ShoppingCart _shoppingCart;
        
        protected override void Arrange()
        {
            _shoppingCart = new ShoppingCart("Test");
        }
    }

    [TestClass]
    public class When_shopping_cart_is_empty 
        : Context_0_products_are_in_the_cart
    {
        [TestMethod]
        public void Then_0_items_are_in_cart()
        {
            Assert.AreEqual(0, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_cart_subtotal_is_0()
        {
            Assert.AreEqual(0, _shoppingCart.SubTotal);
        }

        [TestMethod]
        public void Then_cart_total_is_0()
        {
            Assert.AreEqual(0, _shoppingCart.Total);
        }

    }
}