using Microsoft.VisualStudio.TestTools.UnitTesting;
using Tailspin.Model;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    [TestClass]
    public class When_retrieving_nonexistent_cart_item_by_SKU
        : Context_1_product_in_cart
    {
        private ShoppingCartItem _foundItem;

        protected override void Act()
        {
            _foundItem = _shoppingCart.FindItem("foo");
        }

        [TestMethod]
        public void Then_the_cart_returns_null()
        {
            Assert.AreEqual(null, _foundItem);
        }
    }
}