using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TailSpin.Model.AAASpecs.CartSpecs
{
    [TestClass]
    public class When_removing_a_multi_product_from_a_cart
        : Context_2_of_the_same_products_are_in_the_cart
    {
        protected override void Act()
        {
            base.Act();

            _shoppingCart.RemoveItem(_1stProduct);
        }

        [TestMethod]
        public void Then_all_products_of_that_type_are_removed()
        {
            Assert.AreEqual(0, _shoppingCart.TotalItems);
        }

        [TestMethod]
        public void Then_cart_subtotal_should_be_0()
        {
            Assert.AreEqual(0, _shoppingCart.SubTotal);
        }
    }
}