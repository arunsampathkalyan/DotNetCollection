using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    [Subject(typeof(ShoppingCart))]
    public class When_adding_product_with_0_quantity
        : Context_2_different_products_are_in_the_cart
    {
        static int _totalItemsBeforeAdd;
        static decimal _subTotalBeforeAdd;

        Establish context = () =>
                                {
                                    _subTotalBeforeAdd = _shoppingCart.SubTotal;
                                    _totalItemsBeforeAdd = _shoppingCart.TotalItems;
                                };

        Because of = () => _shoppingCart.AddItem(_2ndProduct, 0);

        It Should_not_change_item_count = () => _shoppingCart.TotalItems.ShouldEqual(_totalItemsBeforeAdd);

        It Should_not_change_subTotal = () => _shoppingCart.SubTotal.ShouldEqual(_subTotalBeforeAdd);
    }
}