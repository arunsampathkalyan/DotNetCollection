using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    public class Context_1_product_in_cart : Context_0_products_are_in_the_cart
    {
        protected static Product _1stProduct;

        Establish context = () =>
        {
            _1stProduct = Mother.MakeProduct();
            _shoppingCart.AddItem(_1stProduct);
        };
    }

    [Subject(typeof(ShoppingCart))]
    public class When_1_item_in_cart : Context_1_product_in_cart
    {
        It Should_have_cart_item_count_of_1 = () => _shoppingCart.TotalItems.ShouldEqual(1);

        It Should_have_the_correct_cart_subTotal = () => _shoppingCart.SubTotal.ShouldEqual(_1stProduct.Price);

        It Should_may_be_retrieved_from_the_cart = () => 
            _shoppingCart.FindItem(_1stProduct.SKU).Product.ShouldNotBeNull();
    }

}