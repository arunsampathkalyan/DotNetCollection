﻿using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    public class Context_0_products_are_in_the_cart
    {
        protected static ShoppingCart _shoppingCart;

        Establish context = () => _shoppingCart = new ShoppingCart("Test");
    }

    [Subject(typeof (ShoppingCart))]
    public class When_cart_is_empty : Context_0_products_are_in_the_cart
    {
        It Should_have_0_items_in_it = () => _shoppingCart.TotalItems.ShouldEqual(0);

        It Should_have_a_subTotal_of_0 = () => _shoppingCart.SubTotal.ShouldEqual(0);

        It Should_have_a_total_of_0 = () => _shoppingCart.Total.ShouldEqual(0);
    }
}