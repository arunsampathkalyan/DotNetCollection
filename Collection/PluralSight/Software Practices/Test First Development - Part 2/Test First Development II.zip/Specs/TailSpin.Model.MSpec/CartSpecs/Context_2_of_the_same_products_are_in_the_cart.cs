using System;
using Machine.Specifications;
using Tailspin.Model;
using TailSpin.Model.MSpec.CartSpecs;

namespace TailSpin.Model.MSpec.CartSpecs
{
    public class Context_2_of_the_same_products_are_in_the_cart 
        : Context_1_product_in_cart
    {
        Establish context = () => _shoppingCart.AddItem(_1stProduct, 1, DateTime.Now.AddSeconds(1));
    }

    [Subject(typeof(ShoppingCart))]
    public class When_2_of_the_same_products_are_in_the_cart
        : Context_2_of_the_same_products_are_in_the_cart
    {
        It Should_contain_2_items = () => _shoppingCart.TotalItems.ShouldEqual(2);

        It Should_have_subTotal_of_2X_product_price = () => _shoppingCart.SubTotal.ShouldEqual(2 * _1stProduct.Price);

        It Should_be_able_to_retrieve_products = () => _shoppingCart.FindItem(_1stProduct.SKU).Product.ShouldNotBeNull();
    }
}