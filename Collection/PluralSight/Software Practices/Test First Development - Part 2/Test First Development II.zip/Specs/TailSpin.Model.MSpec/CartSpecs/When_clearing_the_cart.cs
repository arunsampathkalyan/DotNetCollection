using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    [Subject(typeof(ShoppingCart))]
    public class When_clearing_the_cart
        : Context_2_different_products_are_in_the_cart
    {
        Because of = () => _shoppingCart.ClearItems();

        It Should_be_empty = () => _shoppingCart.TotalItems.ShouldEqual(1);

        It Should_have_subTotal_0 = () => _shoppingCart.SubTotal.ShouldEqual(0);
    }
}