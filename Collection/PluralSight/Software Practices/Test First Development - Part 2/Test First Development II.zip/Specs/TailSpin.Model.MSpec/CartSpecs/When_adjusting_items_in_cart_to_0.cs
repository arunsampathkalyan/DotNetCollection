
using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    [Subject(typeof(ShoppingCart))]
    public class When_adjusting_items_in_cart_to_0
        : Context_1_product_in_cart
    {
        Because Context_2_of_the_same_products_are_in_the_cart = () => _shoppingCart.AdjustQuantity(_1stProduct, 0);

        It Should_have_0_total_items_in_cart = () => _shoppingCart.TotalItems.ShouldEqual(0);

        It Should_have_subTotal_of_0 = () => _shoppingCart.SubTotal.ShouldEqual(0);
    }
}