using System;
using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    public class Context_2_different_products_are_in_the_cart
        : Context_1_product_in_cart
    {
        protected static Product _2ndProduct;

        Establish context = () =>
        {
            _2ndProduct = Mother.MakeProduct();
            _shoppingCart.AddItem(_2ndProduct, 1, DateTime.Now.AddSeconds(1));
        };
    }

    [Subject(typeof (ShoppingCart))]
    public class When_2_different_items_are_in_the_cart
        : Context_2_different_products_are_in_the_cart
    {
        It Should_have_subtotal_of_sum_of_2_items = () => _shoppingCart.SubTotal.ShouldEqual(_1stProduct.Price + _2ndProduct.Price);

        It Should_have_2_items_in_the_cart = () => _shoppingCart.TotalItems.ShouldEqual(2);

        It Should_be_able_to_retrieve_the_products = () =>
        {
            _shoppingCart.FindItem(_1stProduct.SKU).Product.ShouldNotBeNull();
            _shoppingCart.FindItem(_2ndProduct.SKU).Product.ShouldNotBeNull();
        };
    }
}