using Machine.Specifications;
using Tailspin.Model;

namespace TailSpin.Model.MSpec.CartSpecs
{
    [Subject(typeof(ShoppingCart))]
    public class When_removing_a_multi_item_from_a_cart : Context_2_of_the_same_products_are_in_the_cart
    {
        Because of = () => _shoppingCart.RemoveItem(_1stProduct.SKU);

        It Should_remove_all_products_in_the_cart = () => _shoppingCart.TotalItems.ShouldEqual(0);

        It Should_have_a_cart_subtotal_of_0 = () => _shoppingCart.SubTotal.ShouldEqual(0);
    }
}