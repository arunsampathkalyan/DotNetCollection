using System;
using Tailspin.Model;

namespace TailSpin.Model.StoryQSpecs
{
    public static class Mother
    {
        public static Product MakeProduct()
        {
            return new Product(Guid.NewGuid().ToString(), "A Fake Product", "A Fake Product Blurb", true, (decimal) 4.0)
                       {
                           Price = (decimal) 10.01,
                           DiscountPercent = 10
                       };
        }
    }
}