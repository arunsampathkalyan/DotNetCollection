﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoryQ;
using Tailspin.Model;

namespace TailSpin.Model.StoryQSpecs.CartSpecs
{
    [TestClass]
    public class Story_RemoveItemFromShoppingCart
    {
        ShoppingCart _shoppingCart;
        Product _1stProduct;
        Product _2ndProduct;

        [TestMethod]
        public void RemoveItemFromShoppingCart()
        {
            new Story("Remove Item from Shopping Cart")
                .InOrderTo("change my mind about buying a product")
                .AsA("Customer with Products in my Cart")
                .IWant("to remove an item")

                .WithScenario("Multiple Items in Cart")
                            .Given(ACartWith2ItemsInIt)
                            .When (TheFirstItemIsRemoved)
                            .Then(The2ndItemIsStillInTheCart)
                                .And(TheCartItemCountIs1)
                                .And(TheCartSubtotalIsThePriceOfThe2ndItem)

                        .WithScenario("Single Item in Cart")
                            .Given(ACartWith1ItemInIt)
                            .When(TheItemIsRemoved)
                            .Then(TheCartItemCountIs0)
                                .And(TheCartSubtotalIs0)
                .Execute();
        }

        void ACartWith2ItemsInIt()
        {
            _shoppingCart = new ShoppingCart("Test");

            _1stProduct = Mother.MakeProduct();
            _2ndProduct = Mother.MakeProduct();

            _shoppingCart.AddItem(_1stProduct);
            _shoppingCart.AddItem(_2ndProduct);
        }


        void TheFirstItemIsRemoved()
        {
            _shoppingCart.RemoveItem(_1stProduct);
        }

        void The2ndItemIsStillInTheCart()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_2ndProduct.SKU));
        }

        void TheCartItemCountIs1()
        {
            Assert.AreEqual<int>(1, _shoppingCart.TotalItems);
        }

        void TheCartSubtotalIsThePriceOfThe2ndItem()
        {
            Assert.AreEqual(_shoppingCart.SubTotal, _1stProduct.Price);
        }

        void ACartWith1ItemInIt()
        {
            _shoppingCart = new ShoppingCart("Test");
            _1stProduct = Mother.MakeProduct();
            _shoppingCart.AddItem(_1stProduct);
        }

        void TheItemIsRemoved()
        {
            _shoppingCart.RemoveItem(_1stProduct);
        }

        void TheCartItemCountIs0()
        {
            Assert.AreEqual(0, _shoppingCart.TotalItems);
        }

        void TheCartSubtotalIs0()
        {
            Assert.AreEqual(0, _shoppingCart.SubTotal);
        }

    }
}
