using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoryQ;
using Tailspin.Model;

namespace TailSpin.Model.StoryQSpecs.CartSpecs
{
    [TestClass]
    public class Story_2_of_Same_Product_in_Cart
    {
        static ShoppingCart _shoppingCart;
        Product _product;

        [TestMethod]
        public void _2_of_Same_Product_in_Cart()
        {
            new Story("2 of Same Product in Cart")
                
                .InOrderTo("Purchase 2 of a given product")
                .AsA("Customer")
                .IWant("To add multiple products to my cart")

                .WithScenario("Cart behaves accordingly")

                .Given(AnEmptyCart)
                .When(TwoOfTheSameProductAreAddedToTheCart)
                .Then(TheCartSubTotalIsCorrect)
                    .And(TheProductsMayBeRetrieved, _product)
                    .And(ThereAre2ItemsInTheCart)

                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        void TheProductsMayBeRetrieved(Product prod)
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_product.SKU));
        }

        void ThereAre2ItemsInTheCart()
        {
            Assert.AreEqual(2, _shoppingCart.TotalItems);
        }

        void TheCartSubTotalIsCorrect()
        {
            Assert.AreEqual(_product.Price * 2, _shoppingCart.SubTotal);
        }

        void TwoOfTheSameProductAreAddedToTheCart()
        {
            _product = Mother.MakeProduct();
            _shoppingCart.AddItem(_product, 2);
        }

        void AnEmptyCart()
        {
            _shoppingCart = new ShoppingCart("Test Cart");
        }
    }
}