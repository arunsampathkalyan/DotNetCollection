using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoryQ;
using Tailspin.Model;

namespace TailSpin.Model.StoryQSpecs.CartSpecs
{
    [TestClass]
    public class Story_Adding_2_different_products_to_cart
    {
        Product _1stProduct;
        Product _2ndProduct;
        ShoppingCart _shoppingCart;

        [TestMethod]
        public void Adding_2_different_products_to_cart()
        {
            new Story("2 products")
                .InOrderTo("Purchase more than one product")
                .AsA("Customer")
                .IWant("To add 2 different products to my cart")
                
                .WithScenario("Sub Total is correct")
                    .Given(AnEmptyCart)
                    .When(When2DifferentProductsAreAddedToTheCart)
                    .Then(TheCartSubTotalIsCorrect)
                        .And(ThereAre2ItemsInTheCart)
                        .And(TheProductsMayBeRetrieved)

                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        void TheProductsMayBeRetrieved()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_1stProduct.SKU));
            Assert.IsNotNull(_shoppingCart.FindItem(_2ndProduct.SKU));
        }

        void ThereAre2ItemsInTheCart()
        {
            Assert.AreEqual(2, _shoppingCart.TotalItems);
        }

        void TheCartSubTotalIsCorrect()
        {
            Assert.AreEqual(_1stProduct.Price + _2ndProduct.Price, _shoppingCart.SubTotal);
        }

        void When2DifferentProductsAreAddedToTheCart()
        {
            _1stProduct = Mother.MakeProduct();
            _2ndProduct = Mother.MakeProduct();

            _shoppingCart.AddItem(_1stProduct);
            _shoppingCart.AddItem(_2ndProduct);
        }

        void AnEmptyCart()
        {
            _shoppingCart = new ShoppingCart("TestCart");
        }
    }
}