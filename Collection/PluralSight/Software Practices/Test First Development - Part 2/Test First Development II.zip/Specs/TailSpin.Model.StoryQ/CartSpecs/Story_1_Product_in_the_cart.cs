using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using StoryQ;
using Tailspin.Model;

namespace TailSpin.Model.StoryQSpecs.CartSpecs
{
    [TestClass]
    public class Story_1_Product_in_the_cart
    {
        static ShoppingCart _shoppingCart;
        Product _product;

        [TestMethod]
        public void _1_Product_in_the_cart()
        {
            new Story("1 Product in the cart")
                .InOrderTo("Purchase a product")
                .AsA("Customer")
                .IWant("To add a single item to my cart")
                
                .WithScenario("Adding an item")

                    .Given(AnEmptyCart)
                    .When(AProductIsAddedToTheCart)
                    .Then(TheProductMayBeRetrievedFromTheCart)
                        .And(TheCartSubTotalMatchesThePriceOfTheProduct)
                        .And(TheCartItemCountIs1)

                .ExecuteWithReport(MethodBase.GetCurrentMethod());
        }

        void TheCartSubTotalMatchesThePriceOfTheProduct()
        {
            Assert.AreEqual(_product.Price, _shoppingCart.SubTotal);
        }

        void TheCartItemCountIs1()
        {
            Assert.AreEqual(1, _shoppingCart.TotalItems);
        }

        void TheProductMayBeRetrievedFromTheCart()
        {
            Assert.IsNotNull(_shoppingCart.FindItem(_product.SKU));
        }

        void AProductIsAddedToTheCart()
        {
            _product = Mother.MakeProduct();
            _shoppingCart.AddItem(_product);
        }


        void AnEmptyCart()
        {
            _shoppingCart = new ShoppingCart("TestCart");
        }
    }
}