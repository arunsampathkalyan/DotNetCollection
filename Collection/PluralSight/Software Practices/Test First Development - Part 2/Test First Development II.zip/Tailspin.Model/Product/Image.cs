﻿using System.Runtime.Serialization;

namespace Tailspin.Model
{
    /// <summary>
    /// A class which represents a URL-based image
    /// </summary>
    [DataContract]
    public class Image
    {
        internal string _fullPhoto;
        internal string _thumbnailPhoto;

        public Image()
        {
        }

        public Image(string thumb, string full)
        {
            _thumbnailPhoto = thumb;
            _fullPhoto = full;
        }

        public string ThumbnailPhoto
        {
            get { return _thumbnailPhoto + "-thumb.jpg"; }
        }

        public string FullSizePhoto
        {
            get { return _fullPhoto + "-cart.jpg"; }
        }
    }
}