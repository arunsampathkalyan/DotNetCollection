﻿using System.Collections.Generic;

namespace Tailspin.Model
{
    public class ProductList
    {
        public ProductList(string title, IList<Product> products)
        {
            Title = title;
            Products = products;
        }

        public string Title { get; set; }
        public IList<Product> Products { get; set; }

        #region Object overrides

        public override bool Equals(object obj)
        {
            if (obj is ProductList)
            {
                var compareTo = (ProductList) obj;
                if (compareTo.Title == Title)
                {
                    return compareTo.Products == Products;
                }
            }
            return base.Equals(obj);
        }

        public override string ToString()
        {
            return Title;
        }

        public override int GetHashCode()
        {
            return Title.GetHashCode() ^ Products.GetHashCode();
        }

        #endregion
    }
}