﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class InStock : InventoryState
    {
        public InStock(Product item)
        {
            _item = item;
        }
    }
}