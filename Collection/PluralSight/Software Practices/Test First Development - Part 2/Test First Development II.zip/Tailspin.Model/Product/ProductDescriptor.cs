﻿using System.Runtime.Serialization;

namespace Tailspin.Model
{
    [DataContract]
    public class ProductDescriptor
    {
        private readonly string _body;
        private readonly bool _isDefault;
        private readonly string _languageCode = "en";
        private readonly string _title;

        public ProductDescriptor()
        {
        }

        public ProductDescriptor(string title, string body) : this(title, body, false, "en")
        {
        }

        public ProductDescriptor(string title, string body, bool isDefault, string languageCode)
        {
            _title = title;
            _body = body;
            _isDefault = isDefault;
            _languageCode = languageCode;
        }

        public string Title
        {
            get { return _title; }
        }

        public string Body
        {
            get { return _body; }
        }

        public bool IsDefault
        {
            get { return _isDefault; }
        }

        public string LanguageCode
        {
            get { return _languageCode; }
        }
    }
}