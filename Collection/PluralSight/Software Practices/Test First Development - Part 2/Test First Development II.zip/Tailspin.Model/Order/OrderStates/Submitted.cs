﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Submitted : OrderState
    {
        public Submitted()
        {
        }

        public Submitted(Order order)
            : base(order)
        {
            ID = 2;
        }


        public override void Submit()
        {
            //ignore
        }

        public override void Cancel()
        {
            _Cancel();
        }

        public override void Verify()
        {
            _Verify();
        }
    }
}