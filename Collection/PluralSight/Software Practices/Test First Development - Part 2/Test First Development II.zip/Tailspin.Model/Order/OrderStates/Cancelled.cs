﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Cancelled : OrderState
    {
        public Cancelled()
        {
        }

        public Cancelled(Order order)
            : base(order)
        {
            ID = 8;
        }

        public override void Refund()
        {
            _Refund();
        }
    }
}