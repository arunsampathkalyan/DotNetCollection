﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Refunded : OrderState
    {
        public Refunded()
        {
        }

        public Refunded(Order order) : base(order)
        {
            ID = 9;
        }

        public override void Close()
        {
            _Close();
        }
    }
}