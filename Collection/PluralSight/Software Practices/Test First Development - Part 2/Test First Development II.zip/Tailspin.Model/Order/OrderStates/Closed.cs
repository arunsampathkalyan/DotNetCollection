﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Closed : OrderState
    {
        public Closed()
        {
        }

        public Closed(Order order)
            : base(order)
        {
            ID = 10;
        }
    }
}