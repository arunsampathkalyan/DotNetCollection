﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Returned : OrderState
    {
        public Returned()
        {
        }

        public Returned(Order order)
            : base(order)
        {
            ID = 7;
            order.OnReturned(EventArgs.Empty);
        }

        public override void Cancel()
        {
            _Cancel();
            _Close();
        }

        public override void Refund()
        {
            _Refund();
            _Close();
        }

        public override void Close()
        {
            _Close();
        }
    }
}