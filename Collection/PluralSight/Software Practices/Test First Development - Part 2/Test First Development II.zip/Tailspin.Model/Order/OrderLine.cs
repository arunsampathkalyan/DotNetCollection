﻿using System;

namespace Tailspin.Model
{
    public class OrderLine
    {
        private readonly DateTime _dateAdded;
        private readonly Product _item;

        private readonly int _quantity;

        public OrderLine(DateTime dateAdded, int quantity, Product product)
        {
            _dateAdded = dateAdded;
            _quantity = quantity;
            _item = product;
        }

        public DateTime DateAdded
        {
            get { return _dateAdded; }
        }

        public int Quantity
        {
            get { return _quantity; }
        }

        public Product Item
        {
            get { return _item; }
        }

        public decimal LineTotal
        {
            get { return Item.Price*Quantity; }
        }

        public decimal LineWeightInPounds
        {
            get { return Item.WeightInPounds*Quantity; }
        }

        #region Object overrides

        public override bool Equals(object obj)
        {
            if (obj is OrderLine)
            {
                var compareTo = (OrderLine) obj;
                return compareTo.Item.SKU == Item.SKU;
            }
            else
            {
                return base.Equals(obj);
            }
        }

        public override string ToString()
        {
            return Item.Name;
        }

        public override int GetHashCode()
        {
            return Item.SKU.GetHashCode();
        }

        #endregion
    }
}