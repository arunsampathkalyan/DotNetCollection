﻿using System;
using Tailspin.Infrastructure;

namespace Tailspin.Model
{
    // foo

    [Serializable]
    public class Customer : User, IAggregateRoot
    {
        public Customer() : this(Guid.NewGuid().ToString(), "", "", "")
        {
        }

        public Customer(string userName) : this(userName, "", "", "")
        {
        }

        public Customer(string userName, string email, string first, string last, ShoppingCart cart)
            : base(userName)
        {
            FirstName = first;
            LastName = last;
            Email = email;
            LanguageCode = "en";
            Cart = cart ?? new ShoppingCart();
            UserName = userName ?? Guid.NewGuid().ToString();
        }

        public Customer(string userName, string email, string first, string last)
            : this(userName, email, first, last, null)
        {
        }

        public new string UserName { get; set; }
        public new string Email { get; set; }
        public new string FirstName { get; set; }
        public new string LastName { get; set; }
        public new string LanguageCode { get; set; }

        public new string FullName
        {
            get { return string.Format("{0} {1}", FirstName, LastName); }
        }

        public ShoppingCart Cart { get; set; }

        public override string ToString()
        {
            return FullName;
        }
        // foo
    }
}