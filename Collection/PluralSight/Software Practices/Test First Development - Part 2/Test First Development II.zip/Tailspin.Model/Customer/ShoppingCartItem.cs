﻿using System;

namespace Tailspin.Model
{
    public class ShoppingCartItem
    {
        private readonly DateTime _dateAdded = DateTime.Now;
        private readonly Product _product;
        private decimal _discount;
        private string _discountReason = "";
        private int _quantity;

        public ShoppingCartItem(Product product) : this(product, 1, DateTime.Now)
        {
        }

        public ShoppingCartItem(Product product, int quantity, DateTime dateAdded)
        {
            _product = product;
            _quantity = quantity;
            _dateAdded = dateAdded;
        }

        public int Quantity
        {
            get { return _quantity; }
        }

        public Product Product
        {
            get { return _product; }
        }

        public decimal Discount
        {
            get { return _discount; }
        }


        public string DiscountReason
        {
            get { return _discountReason; }
        }

        public DateTime DateAdded
        {
            get { return _dateAdded; }
        }


        public decimal LineTotal
        {
            get { return Product.Price*Quantity - _discount; }
        }

        public void SetDiscount(decimal amount, string reason)
        {
            _discount = amount;
            _discountReason = reason;
        }

        public void AdjustQuantity(int newQuantity)
        {
            _quantity = newQuantity;
        }
    }
}