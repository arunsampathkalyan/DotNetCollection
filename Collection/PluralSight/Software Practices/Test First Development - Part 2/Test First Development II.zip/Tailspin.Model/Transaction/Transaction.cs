﻿using System;
using System.Collections.Generic;

namespace Tailspin.Model
{
    [Serializable]
    public class Transaction
    {
        private readonly decimal _amount;
        private readonly string _authorizationCode;
        private readonly DateTime _dateExecuted;
        private readonly Guid _id;
        private readonly string _notes;

        private readonly Guid _orderID;
        private readonly string _processor;

        public Transaction(Guid orderID, decimal amount, string authCode, string processor)
            : this(Guid.NewGuid(), orderID, amount, DateTime.Now, authCode, "", processor)
        {
        }

        public Transaction(Guid id, Guid orderID, decimal amount, DateTime executed, string authCode, string notes,
                           string processor)
        {
            _id = id;
            _orderID = orderID;
            _amount = amount;
            _dateExecuted = executed;
            _authorizationCode = authCode;
            _notes = notes;
            _processor = processor;
            TransactionErrors = new List<string>();
        }

        public Guid ID
        {
            get { return _id; }
        }

        public Guid OrderID
        {
            get { return _orderID; }
        }

        public decimal Amount
        {
            get { return _amount; }
        }

        public DateTime DateExecuted
        {
            get { return _dateExecuted; }
        }

        public string AuthorizationCode
        {
            get { return _authorizationCode; }
        }

        public string Notes
        {
            get { return _notes; }
        }

        public IList<string> TransactionErrors { get; set; }

        public string Processor
        {
            get { return _processor; }
        }

        public bool IsRefund
        {
            get { return Amount <= 0; }
        }
    }
}