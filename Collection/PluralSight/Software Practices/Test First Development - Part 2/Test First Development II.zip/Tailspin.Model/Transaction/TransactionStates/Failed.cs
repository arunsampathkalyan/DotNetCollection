﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Failed : TransactionState
    {
        public Failed(Order order) : base(order)
        {
        }

        public override void Retry()
        {
            _Queue();
        }
    }
}