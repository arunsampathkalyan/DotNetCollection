﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class Succeeded : TransactionState
    {
        public Succeeded(Order order) : base(order)
        {
        }

        public override bool IsSuccess
        {
            get { return true; }
        }
    }
}