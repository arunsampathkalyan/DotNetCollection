﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public abstract class PaymentMethod
    {
        private string Name { get; set; }
        private string AccountNumber { get; set; }
        private DateTime Expiration { get; set; }
        private string VerificationCode { get; set; }
    }
}