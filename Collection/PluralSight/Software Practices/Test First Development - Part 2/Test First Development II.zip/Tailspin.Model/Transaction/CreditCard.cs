﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class CreditCard : PaymentMethod
    {
        public CreditCard()
        {
        }


        public CreditCard(string cardType, string nameOnCard, string accountNumber, int expMonth, int expYear,
                          string verificationCode)
        {
            Name = nameOnCard;
            CardType = cardType;
            AccountNumber = accountNumber;
            VerificationCode = verificationCode;
            ExpirationMonth = expMonth;
            ExpirationYear = expYear;
        }

        public string CardType { get; set; }
        public string Name { get; set; }
        public string AccountNumber { get; set; }
        public string VerificationCode { get; set; }

        public int ExpirationYear { get; set; }
        public int ExpirationMonth { get; set; }

        public DateTime Expiration
        {
            get
            {
                //sets the date to the last day of the month
                var result = new DateTime(ExpirationYear, ExpirationMonth,
                                          DateTime.DaysInMonth(ExpirationYear, ExpirationMonth));

                return result;
            }
            set { }
        }


        /// <summary>
        /// Masks the credit card using XXXXXX and appends the last 4 digits
        /// </summary>
        /// <param name="cardNumber">The credit card number</param>
        /// <returns>System.String</returns>
        public string MaskedNumber
        {
            get
            {
                string result = "****";
                if (AccountNumber.Length > 8)
                {
                    string lastFour = AccountNumber.Substring(AccountNumber.Length - 4, 4);
                    result = "**** **** **** " + lastFour;
                }
                return result;
            }
        }


        /// <summary>
        /// Validates the passed-in card, making sure that the card is not expired
        /// and that it passed the Luhn Algorigthm
        /// </summary>
        /// <param name="card">The Credit Card to validate</param>
        public bool IsValid()
        {
            return true; // implement this later
        }
    }
}