﻿using System;

namespace Tailspin.Model
{
    [Serializable]
    public class ShippingMethod
    {
        private readonly decimal _baseRate;
        private readonly string _carrier;
        private readonly int _daysToDeliver;
        private readonly int _id;
        private readonly decimal _ratePerPound;
        private readonly string _serviceName;

        public ShippingMethod(int id, string carrier, string serviceName,
                              decimal ratePerPound, int daysToDeliver, decimal baseRate)
        {
            _id = id;
            _carrier = carrier;
            _serviceName = serviceName;
            _ratePerPound = ratePerPound;
            _daysToDeliver = daysToDeliver;
            _baseRate = baseRate;
        }

        public int ID
        {
            get { return _id; }
        }

        public string Carrier
        {
            get { return _carrier; }
        }

        public string ServiceName
        {
            get { return _serviceName; }
        }

        public decimal RatePerPound
        {
            get { return _ratePerPound; }
        }

        public int DaysToDeliver
        {
            get { return _daysToDeliver; }
        }

        public string Display
        {
            get
            {
                string shippingFormat = "{0}:{1} {2}";
                return string.Format(shippingFormat, Carrier, ServiceName, Cost.ToString("C"));
            }
        }

        public decimal BaseRate
        {
            get { return _baseRate; }
        }

        //this is a placeholder field for the Shipping Service
        //to fill in
        public decimal Cost { get; set; }


        public override string ToString()
        {
            return Display;
        }
    }
}