﻿namespace Tailspin.Model
{
    public interface IShippingService
    {
        Shipment CalculateShipping(Order order);
    }
}