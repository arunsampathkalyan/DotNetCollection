﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tailspin.Infrastructure;
using Tailspin.Model;

public static class ProductExtensions
{
    public static Product Product(this IViewDataContainer pg)
    {
        Product result = null;

        if (pg.ViewData["SelectedProduct"] != null)
            result = (Product) pg.ViewData["SelectedProduct"];
        return result;
    }


    public static PagedList<Product> Products(this IViewDataContainer pg)
    {
        var result = new PagedList<Product>(new List<Product>(), 1, 1, 1);

        if (pg.ViewData["Products"] != null)
        {
            var products = (IList<Product>) pg.ViewData["Products"];
            result = new PagedList<Product>(products.ToList(), products.Count, 0, 20);
        }
        return result;
    }

    public static IList<Product> ProductList(this IViewDataContainer pg)
    {
        return (IList<Product>) pg.ViewData["Products"];
    }

    //public static LocalizedCategory Category(this IViewDataContainer pg) {
    //    var result = new LocalizedCategory();

    //    if (pg.ViewData["SelectedCategory"] != null) 
    //        result = (LocalizedCategory)pg.ViewData["SelectedCategory"];

    //    return result;
    //}
    //public static IList<LocalizedCategory> Categories(this ViewMasterPage pg) {
    //    return Categories(pg.Page as ViewPage);

    //}
    //public static IList<LocalizedCategory> Categories(this IViewDataContainer pg) {
    //    var result = new List<LocalizedCategory>();

    //    if (pg.ViewData["Categories"] != null){
    //        var categories = (IList<LocalizedCategory>)pg.ViewData["Categories"];
    //        //drop these into a grouped list
    //        result = categories.ToList();

    //    }

    //    return result;
    //}

    public static string ProductImage(this HtmlHelper helper, string image)
    {
        string linkFormat = "~/ProductImages/{0}";
        string linkUrl = string.Format(linkFormat, image);
        return VirtualPathUtility.ToAbsolute(linkUrl);
    }
}