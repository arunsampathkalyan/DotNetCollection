﻿using System;
using System.Globalization;

namespace Tailspin.Infrastructure
{
    public static class CurrencyExtensions
    {
        public static string ToLocalCurrency(this Decimal input)
        {
            return Math.Round(input, CultureInfo.CurrentCulture.NumberFormat.CurrencyDecimalDigits).ToString();
        }
    }
}