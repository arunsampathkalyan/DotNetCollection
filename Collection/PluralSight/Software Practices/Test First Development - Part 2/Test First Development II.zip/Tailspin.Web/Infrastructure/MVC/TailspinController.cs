﻿using System.Collections.Generic;
using System.Globalization;
using System.Web.Mvc;
using Tailspin.Model;

namespace Tailspin.Web
{
    public class TailspinController : Controller
    {

        
        private const int PAGE_SIZE = 20;
        private readonly ICustomerRepository _customerRepository;
        private Product _product;
        private IList<Product> _products;
        private IList<ShippingMethod> _shippingMethods;
        private string _thisUserName;

        public TailspinController()
        {
        }

        public TailspinController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
            SetCustomer(false);
        }

        public IList<ShippingMethod> ShippingMethods
        {
            get { return _shippingMethods; }
            set
            {
                _shippingMethods = value;
                ViewData["ShippingMethods"] = _shippingMethods;
            }
        }

        public ShoppingCart CurrentCart
        {
            get { return (ShoppingCart) ViewData["CurrentCart"]; }
            set { ViewData["CurrentCart"] = value; }
        }

        public Customer CurrentCustomer
        {
            get { return (Customer) ViewData["CurrentCustomer"]; }
            set { ViewData["CurrentCustomer"] = value; }
        }

        public Order NewOrder
        {
            get { return (Order) ViewData["NewOrder"]; }
            set { ViewData["NewOrder"] = value; }
        }

        public IList<Product> Products
        {
            get { return _products; }
            set
            {
                _products = value;
                ViewData["Products"] = _products;
            }
        }

        public Product SelectedProduct
        {
            get { return _product; }
            set
            {
                _product = value;
                ViewData["SelectedProduct"] = _product;
            }
        }

        public void SetCustomer(bool reset)
        {
            _thisUserName = this.GetCommerceUserName(reset);

            Customer customer = _customerRepository.GetCustomer(_thisUserName);
            if (customer == null)
            {
                customer = new Customer();
                customer.UserName = _thisUserName;

                customer.LastName = "";
                customer.Email = "";
                customer.LanguageCode = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
                customer.FirstName = "Guest";
                //save em
                //_customerRepository.AddCustomer(customer);
                this.RememberCommerceUser(_thisUserName);
            }
            CurrentCustomer = customer;
            CurrentCart = customer.Cart;
        }

        public void SaveCart()
        {
            _customerRepository.SaveCart(CurrentCart);
        }
    }
}