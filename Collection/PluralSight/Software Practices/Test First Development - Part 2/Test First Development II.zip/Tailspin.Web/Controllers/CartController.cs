using System;
using System.Web.Mvc;
using Tailspin.Model;

namespace Tailspin.Web.App.Controllers
{
    //TODO - make sure we only accept ValidTokens!
    public class CartController : TailspinController
    {
        private readonly IProductRepository _productRepository;
        private ICustomerRepository _customerRepository;

        public CartController(ICustomerRepository customerRepository,
                              IProductRepository productRepository) : base(customerRepository)
        {
            _productRepository = productRepository;
            _customerRepository = customerRepository;
        }

        public ActionResult Index()
        {
            return View();
        }

        #region Cart Actions

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult AddItem(string sku)
        {
            Product p = _productRepository.GetProduct(sku);
            if (p == null)
                throw new InvalidOperationException("Invalid SKU");
            CurrentCart.AddItem(p);
            SaveCart();
            return RedirectToAction("Show");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult RemoveItem(string id)
        {
            CurrentCart.RemoveItem(id);
            SaveCart();
            return RedirectToAction("Show");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult UpdateItem(string id)
        {
            string sQuantity = Request.Form["quantity"];

            if (!string.IsNullOrEmpty(sQuantity))
            {
                int newQuantity = 0;
                int.TryParse(sQuantity, out newQuantity);
                if (newQuantity > 0)
                {
                    CurrentCart.AdjustQuantity(id, newQuantity);
                    SaveCart();
                }
            }
            return RedirectToAction("Show");
        }

        public ActionResult Show()
        {
            //all the cart info is pulled by the base class
            return View("Cart");
        }

        #endregion
    }
}