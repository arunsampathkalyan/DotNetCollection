﻿using System.Web.Mvc;
using Tailspin.Model;

namespace Tailspin.Web.Controllers
{
    [HandleError]
    public class HomeController : TailspinController
    {
        private readonly IProductRepository _productRepository;
        private ICustomerRepository _customerRepository;

        public HomeController(ICustomerRepository customerRepository,
                              IProductRepository productRepository) : base(customerRepository)
        {
            _productRepository = productRepository;
            _customerRepository = customerRepository;
        }

        public ActionResult Index(string slug)
        {
            if (!string.IsNullOrEmpty(slug))
            {
                Products = _productRepository.GetProductCategory(slug).Products;
                return View("Listing");
            }
            else
            {
                Products = null;
                return View("Home");
            }
        }

        public ActionResult Show(string sku)
        {
            SelectedProduct = _productRepository.GetProduct(sku);
            return View("Detail");
        }

        public ActionResult About()
        {
            return View("About");
        }
    }
}