using System;
using System.Linq;
using System.Web.Mvc;
using Tailspin.Infrastructure;
using Tailspin.Model;

namespace Tailspin.Web.App.Controllers
{
    public class OrderController : TailspinController
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IOrderRepository _orderRepository;

        public OrderController(ICustomerRepository customerRepository,
                               IOrderRepository orderRepository) : base(customerRepository)
        {
            _orderRepository = orderRepository;
            _customerRepository = customerRepository;
        }

        public IOrderRepository OrderRepository
        {
            get { return _orderRepository; }
        }


        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Checkout()
        {
            //they need to have items in their cart
            if (CurrentCart.Items.Count == 0)
                return RedirectToAction("Show", "Cart");
            else
                return View("Address");
        }


        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult Address(int? id)
        {
            id = id ?? 0;
            if (id > 0)
            {
                CurrentCustomer.DefaultAddress =
                    CurrentCustomer.AddressBook.Where(x => x.AddressID == (int) id).SingleOrDefault();
            }
            return View("Shipping");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Address(Address address)
        {
            ValidateAddress(address);

            if (ModelState.IsValid)
            {
                //save the address
                address.AddressID = _customerRepository.SaveAddress(address);
                CurrentCart.ShippingAddress = address;

                //calc the tax
                CurrentCart.TaxAmount = this.CalculateTax(CurrentCart);
                CurrentCart.BillingAddress = address;

                //set the shipping methods
                ShippingMethods = this.GetShippingMethods(CurrentCart);

                //default to the first
                CurrentCart.ShippingService = ShippingMethods[0].ServiceName;
                CurrentCart.ShippingAmount = ShippingMethods[0].Cost;
                CurrentCart.ShippingMethodID = ShippingMethods[0].ID;


                //save the cart
                SaveCart();

                //send to billing
                return RedirectToAction("Finalize");
            }
            else
            {
                //let error handling pick it up
                return View();
            }
        }

        private void ValidateAddress(Address address)
        {
            // Validation logic
            if (String.IsNullOrEmpty(address.FirstName))
                ModelState.AddModelError("FirstName", "First name is required.");
            if (String.IsNullOrEmpty(address.LastName))
                ModelState.AddModelError("LastName", "Last name is required.");
            if (String.IsNullOrEmpty(address.Email))
                ModelState.AddModelError("Email", "E-mail name is required.");
            if (String.IsNullOrEmpty(address.Street1))
                ModelState.AddModelError("Street1", "Street is required.");
            if (String.IsNullOrEmpty(address.City))
                ModelState.AddModelError("City", "City is required.");
            if (String.IsNullOrEmpty(address.StateOrProvince))
                ModelState.AddModelError("StateOrProvince", "State or province is required.");
            if (String.IsNullOrEmpty(address.Zip))
                ModelState.AddModelError("Zip", "Zip code is required.");
            if (String.IsNullOrEmpty(address.Country))
                ModelState.AddModelError("Country", "Country is required.");
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Payment(CreditCard card)
        {
            //set the card
            CurrentCart.CreditCard = card;

            //create an order
            var order = new Order(CurrentCustomer, DateTime.Now.Ticks.ToString());
            TempData["CurrentOrder"] = order;

            //TODO: - check boolean
            this.ValidateOrder(order);

            //execute the payment..
            Transaction trans = this.AuthorizeCreditCard(order);


            //on success send to Receipt
            if (trans.TransactionErrors.Count == 0)
            {
                //save it down
                //_orderRepository.Save(order, trans);
                SetCustomer(true);

                return RedirectToAction("Receipt", new {id = order.ID.ToString()});
            }
            else
            {
                ViewData["ErrorMessage"] = trans.TransactionErrors[0];

                //let the View know
                return View("Finalize");
            }
        }

        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult Finalize()
        {
            ShippingMethods = this.GetShippingMethods(CurrentCart);

            CurrentCart.ShippingService = ShippingMethods[0].ServiceName;
            CurrentCart.ShippingAmount = ShippingMethods[0].Cost;
            CurrentCart.ShippingMethodID = ShippingMethods[0].ID;
            return View();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Finalize(int? id)
        {
            if (id > 0)
            {
                ShippingMethods = this.GetShippingMethods(CurrentCart);
                ShippingMethod selectedShipping = ShippingMethods.SingleOrDefault(x => x.ID == id);
                CurrentCart.ShippingService = selectedShipping.ServiceName;
                CurrentCart.ShippingMethodID = selectedShipping.ID;
                CurrentCart.ShippingAmount = selectedShipping.Cost;
            }
            return View();
        }

        public ActionResult Receipt()
        {
            return View();
        }
    }
}