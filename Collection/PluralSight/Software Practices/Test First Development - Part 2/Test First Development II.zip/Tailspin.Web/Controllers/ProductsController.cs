using System.Collections.Generic;
using System.Web.Mvc;
using Tailspin.Model;

namespace Tailspin.Web.App.Controllers
{
    public class ProductsController : TailspinController
    {
        private readonly IProductRepository _productRepository;
        private ICustomerRepository _customerRepository;

        public ProductsController(ICustomerRepository customerRepository,
                                  IProductRepository productRepository) : base(customerRepository)
        {
            _productRepository = productRepository;
            _customerRepository = customerRepository;
        }

        public ActionResult Index()
        {
            return View();
        }

        #region Products Actions

        public ActionResult FeaturedProduct()
        {
            return View("FeaturedProduct");
        }

        public ActionResult NewProducts()
        {
            return View("NewProducts", new ProductList("New Products", _productRepository.GetNewProducts()));
        }

        public ActionResult ListProducts(IList<Product> products)
        {
            return View("ProductList", new ProductList("Products in Category", products));
        }

        public ActionResult ProductCategoryMenu()
        {
            return View("Menu", _productRepository.GetProductCategories());
        }

        #endregion
    }
}