﻿using Tailspin.Admin.App.Model;

namespace Tailspin.Admin.App
{
    internal class ProductRelationship
    {
        public bool IsRelated;

        public ProductRelationship(Product product)
        {
            Product = product;
        }

        public Product Product { get; private set; }
    }
}