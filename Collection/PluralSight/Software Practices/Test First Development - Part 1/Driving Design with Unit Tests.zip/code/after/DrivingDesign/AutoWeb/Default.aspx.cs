﻿using System;
using AutoWeb.Models;
using AutoWeb.Presenters;
using AutoWeb.Views;

namespace AutoWeb
{
    public partial class _Default : System.Web.UI.Page, IDefaultView
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CreatePresenter().Init();
        }

        public void Show(DefaultViewModel viewModel)
        {
            lblAutoID.Text = viewModel.Id;
            txtAutoColor.Text = viewModel.Color;
            txtAutoManufacturer.Text = viewModel.Manufacturer;
            txtAutoModel.Text = viewModel.Model;
            txtAutoName.Text = viewModel.Name;
        }

        public void Redirect(string url)
        {
            Response.Redirect(url);
        }

        protected void Save_OnClick(object sender, EventArgs e)
        {
            var saveArgs = CreateSaveArgs();
            CreatePresenter().SaveAuto(saveArgs);
        }

        private SaveAutoArgs CreateSaveArgs()
        {
            return new SaveAutoArgs()
                       {
                           Color = txtAutoColor.Text,
                           Id = lblAutoID.Text,
                           Manufacturer = txtAutoManufacturer.Text,
                           Model = txtAutoModel.Text,
                           Name = txtAutoName.Text
                       };
        }

        private DefaultPresenter CreatePresenter()
        {
            return new DefaultPresenter(this);
        }
    }
}