﻿using System;
using AutoWeb.Presenters;

namespace Tests
{
    public static class Mother
    {
        public static SaveAutoArgs GetSaveAutoArgs()
        {
            return new SaveAutoArgs()
                       {
                           Color = "Red",
                           Id = Guid.NewGuid().ToString(),
                           Manufacturer = "Mini Cooper",
                           Model = "John Cooper Works",
                           Name = "Chili"
                       };
        }
    }
}