﻿using AutoWeb.Models;
using AutoWeb.Views;

namespace Tests.DefaultPresenter_Tests
{
    public class TestDefaultView : IDefaultView
    {
        public TestDefaultView()
        {
            ShowWasCalled = false;
            RedirectWasCalled = false;
        }

        public void Show(DefaultViewModel viewModel)
        {
            ShowWasCalled = true;    
        }

        public void Redirect(string url)
        {
            RedirectWasCalled = true;
        }

        public bool ShowWasCalled { get; set; }

        public bool RedirectWasCalled { get; set; }
    }
}