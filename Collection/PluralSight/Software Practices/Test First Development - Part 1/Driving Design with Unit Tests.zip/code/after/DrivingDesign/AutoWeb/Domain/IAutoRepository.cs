using System;

namespace AutoWeb.Domain
{
    public interface IAutoRepository
    {
        void Save(Automobile automobile);
        IAutomobile Find(Guid autoId);
    }
}