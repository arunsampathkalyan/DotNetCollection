using AutoWeb.Domain;

namespace AutoWeb.Models
{
    public interface IDefaultViewModelAssembler
    {
        DefaultViewModel From(IAutomobile auto);
    }
}