﻿using System;
using AutoWeb.Domain;

namespace AutoWeb.Presenters
{
    public class AutoAssembler : IAutoAssembler
    {
        public Automobile From(SaveAutoArgs saveArgs)
        {
            return new Automobile()
                       {
                           Color = saveArgs.Color,
                           Id = new Guid(saveArgs.Id),
                           Manufacturer = saveArgs.Manufacturer,
                           Model = saveArgs.Model,
                           Name = saveArgs.Name
                       };
        }
    }
}