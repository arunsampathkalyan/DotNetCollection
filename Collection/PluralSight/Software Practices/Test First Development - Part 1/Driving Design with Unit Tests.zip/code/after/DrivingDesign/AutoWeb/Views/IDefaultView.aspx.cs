﻿using AutoWeb.Models;

namespace AutoWeb.Views
{
    public interface IDefaultView
    {
        void Show(DefaultViewModel viewModel);
        void Redirect(string url);        
    }
}