﻿using System;
using AutoWeb.Domain;
using AutoWeb.Models;
using AutoWeb.Views;

namespace AutoWeb.Presenters
{
    public class DefaultPresenter
    {
        private readonly IDefaultView _view;
        private readonly IAutoAssembler _autoAssembler;
        private readonly IAutoRepository _autoRepository;
        private readonly IDefaultViewModelAssembler _defaultViewModelAssembler;

        public DefaultPresenter(IDefaultView view)
            : this(view, new AutoAssembler(), new AutoRepository(), new DefaultViewModelAssembler())
        {
            // this implementation would be greatly helped by an IoC (Inversion of Control) Container, 
            // which would let us automatically inject the contructor arguments.
            // using this technique with or without an IoC, you can create tests by providing your
            // own implementations of these classes.
        }

        public DefaultPresenter(IDefaultView view, IAutoAssembler autoAssembler, IAutoRepository autoRepository, IDefaultViewModelAssembler defaultViewModelAssembler)
        {
            _view = view;
            _autoAssembler = autoAssembler;
            _autoRepository = autoRepository;
            _defaultViewModelAssembler = defaultViewModelAssembler;
        }

        public void Init()
        {
            var auto = _autoRepository.Find(Guid.Empty); // pretend this is a unique Guid
            var viewModel = _defaultViewModelAssembler.From(auto);
            
            _view.Show(viewModel);
        }

        public void SaveAuto(SaveAutoArgs saveArgs)
        {
            var auto = _autoAssembler.From(saveArgs);
            _autoRepository.Save(auto);

            _view.Redirect("http://pluralsight.com");
        }

        
    }
}