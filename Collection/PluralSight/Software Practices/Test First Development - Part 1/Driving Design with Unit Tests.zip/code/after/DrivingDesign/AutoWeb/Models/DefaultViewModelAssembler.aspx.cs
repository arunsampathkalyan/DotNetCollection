﻿using AutoWeb.Domain;

namespace AutoWeb.Models
{
    public class DefaultViewModelAssembler : IDefaultViewModelAssembler
    {
        public DefaultViewModel From(IAutomobile auto)
        {
            return new DefaultViewModel()
                       {
                           Color = auto.Color,
                           Id = auto.Id.ToString(),
                           Manufacturer = auto.Manufacturer,
                           Model = auto.Model,
                           Name = auto.Name
                       };
        }
    }
}