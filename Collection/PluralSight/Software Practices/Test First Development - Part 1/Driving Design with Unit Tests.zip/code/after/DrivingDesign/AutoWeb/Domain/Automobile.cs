﻿
using System;

namespace AutoWeb.Domain
{
    public class Automobile : IAutomobile
    {
        public Guid Id { get; internal set; }
        
        public void Start()
        {
            // vroom
        }

        public void Stop()
        {
            // click
        }

        public string Name { get; internal set; }

        public string Manufacturer { get; internal set; }

        public string Color { get; internal set; }

        public string Model { get; internal set; }
    }
}