﻿using System;

namespace AutoWeb.Domain
{
    public class AutoRepository : IAutoRepository
    {
        public void Save(Automobile automobile)
        {
            // save it somewhere. probably to a database
        }

        public IAutomobile Find(Guid autoId)
        {
            return new Automobile()
                       {
                           Color = "White",
                           Id = Guid.NewGuid(),
                           Manufacturer = "Ford",
                           Model = "F-350",
                           Name = "Betsy"
                       };
        }
    }
}