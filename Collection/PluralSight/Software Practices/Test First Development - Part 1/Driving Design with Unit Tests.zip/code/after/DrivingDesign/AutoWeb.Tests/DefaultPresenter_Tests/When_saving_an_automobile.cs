﻿using AutoWeb.Presenters;
using NUnit.Framework;

namespace Tests.DefaultPresenter_Tests
{
    [Category("DefaultPresenter")]
    public class When_saving_an_automobile
    {
        private TestDefaultView _view;
        private DefaultPresenter _presenter;

        [SetUp]
        public void SetUp()
        {
            _view = new TestDefaultView();
            _presenter = new DefaultPresenter(_view);
        }

        [Test]
        public void Then_the_user_is_redirected()
        {
            var saveArgs = Mother.GetSaveAutoArgs();
            _presenter.SaveAuto(saveArgs);

            Assert.IsTrue(_view.RedirectWasCalled);
        }
    }
}