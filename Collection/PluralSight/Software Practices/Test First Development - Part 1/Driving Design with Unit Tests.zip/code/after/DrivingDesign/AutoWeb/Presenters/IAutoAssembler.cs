using AutoWeb.Domain;

namespace AutoWeb.Presenters
{
    public interface IAutoAssembler
    {
        Automobile From(SaveAutoArgs saveArgs);
    }
}