﻿using System;
using System.Web;
using AutoWeb.Domain;
using AutoWeb.Models;
using AutoWeb.Views;

namespace AutoWeb.Presenters
{
    public class DefaultPresenter
    {
        private readonly IDefaultView _view;

        public DefaultPresenter(IDefaultView view)
        {
            _view = view;
        }

        public void Init()
        {
            var viewModel = MakeDefaultViewModel();
            _view.Show(viewModel);
        }

        public void SaveAuto(SaveAutoArgs saveArgs)
        {
            var auto = CreateAutoFromSaveArgs(saveArgs);
            var autoRepository = new AutoRepository();
            autoRepository.Save(auto);

            HttpContext.Current.Response.Redirect("http://pluralsight.com");
        }

        private Automobile CreateAutoFromSaveArgs(SaveAutoArgs saveArgs)
        {
            return new Automobile()
                       {
                           Color = saveArgs.Color,
                           Id = new Guid(saveArgs.Id),
                           Manufacturer = saveArgs.Manufacturer,
                           Model = saveArgs.Model,
                           Name = saveArgs.Name
                       };
        }

        private DefaultViewModel MakeDefaultViewModel()
        {
            var autoRepository = new AutoRepository();
            var auto = autoRepository.Find(Guid.Empty);
            return new DefaultViewModel()
                       {
                           Color = auto.Color,
                           Id = auto.Id.ToString(),
                           Manufacturer = auto.Manufacturer,
                           Model = auto.Model,
                           Name = auto.Name
                       };

        }
    }
}