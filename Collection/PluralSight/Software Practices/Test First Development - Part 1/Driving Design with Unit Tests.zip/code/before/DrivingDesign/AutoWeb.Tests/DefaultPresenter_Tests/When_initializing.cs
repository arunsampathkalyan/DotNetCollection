﻿using AutoWeb.Presenters;
using NUnit.Framework;

namespace Tests.DefaultPresenter_Tests
{
    [Category("DefaultPresenter")]
    public class When_initializing
    {
        private TestDefaultView _view;
        private DefaultPresenter _presenter;

        [SetUp]
        public void SetUp()
        {
            _view = new TestDefaultView();
            _presenter = new DefaultPresenter(_view);
        }

        [Test]
        public void Then_the_view_get_shown()
        {
            _presenter.Init();
            Assert.IsTrue(_view.ShowWasCalled);
        }
    }
}
