﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Domain;

namespace MeasureIt
{
    internal interface IProcessor
    {
        IEnumerable<Measurement> LoadAndAggregateData(XDocument document);
    }

    internal abstract class ProcessorBase
    {
        public IEnumerable<Measurement> LoadAndAggregateData(XDocument document)
        {
            List<Measurement> measurements = ParseMeasurements(document);
            return AggregateMeasurements(measurements);
        }

        protected abstract IEnumerable<Measurement> AggregateMeasurements(List<Measurement> measurements);
        protected abstract List<Measurement> ParseMeasurements(XDocument document);
    }

    class Processor : ProcessorBase, IProcessor
    {
        private const int GROUP_SIZE = 2;

        protected override IEnumerable<Measurement> AggregateMeasurements(List<Measurement> measurements)
        {
            var aggregator = new MeasurementAggregator(measurements);
            var grouper = new SizeGrouper(GROUP_SIZE);
            var calculator = new AveragingCalculator();
            var result = aggregator.Aggregate(new AggregationSettings(grouper, calculator));
            return result;
        }

        protected override List<Measurement> ParseMeasurements(XDocument document)
        {
            var measurements = new List<Measurement>();

            foreach (var element in document.Element("Measurements").Elements())
            {
                var highValue = (double)element.Attribute("High");
                var lowValue = (double)element.Attribute("Low");
                var measurement = new Measurement();
                measurement.HighValue = highValue;
                measurement.LowValue = lowValue;
                measurements.Add(measurement);
            }
            return measurements;
        }
    }
}
