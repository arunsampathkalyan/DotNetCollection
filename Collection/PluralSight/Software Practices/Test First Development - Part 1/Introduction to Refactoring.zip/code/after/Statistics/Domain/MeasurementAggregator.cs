using System.Collections.Generic;

namespace Domain
{
    public class AggregationSettings
    {
        private IGrouper _grouper;
        private IAggregateCalculator _calculator;

        public AggregationSettings(IGrouper grouper, IAggregateCalculator calculator)
        {
            _grouper = grouper;
            _calculator = calculator;
        }

        public IGrouper Grouper
        {
            get { return _grouper; }
        }

        public IAggregateCalculator Calculator
        {
            get { return _calculator; }
        }
    }

    public class MeasurementAggregator
    {
        private readonly IList<Measurement> _measurements;

        public MeasurementAggregator(IList<Measurement> measurements)
        {
            _measurements = measurements;
        }

        public IEnumerable<Measurement> Aggregate(AggregationSettings aggregationSettings)
        {
            var groups = aggregationSettings.Grouper.Group(_measurements);
            foreach (var group in groups)
            {
                yield return aggregationSettings.Calculator.Aggregate(group);
            }
        }
    }
}