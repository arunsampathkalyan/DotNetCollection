﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace MeasureIt
{
    class Program
    {
        static void Main(string[] args)
        {
             //practice refactor -> rename on this code :) 

            var proc = new Processor();
            var data = proc.LoadAndAggregateData(XDocument.Load("Data.xml"));
            foreach (var d in data)
            {
                Console.WriteLine("{0} : {1}", d.LowValue, d.HighValue);
            }

        }
    }
}
