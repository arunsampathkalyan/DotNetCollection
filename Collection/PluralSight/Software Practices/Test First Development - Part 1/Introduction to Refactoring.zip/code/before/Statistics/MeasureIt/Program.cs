﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Domain;

namespace MeasureIt
{
    class Program
    {
        static void Main(string[] args)
        {
            var proc = new Processor();
            var data = proc.LoadData();
            foreach(var d in data)
            {
                Console.WriteLine("{0}:{1}", d.LowValue, d.HighValue);
            }
        }
    }
}
