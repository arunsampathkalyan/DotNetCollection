﻿namespace AutoWeb.Views
{
    public interface IAddOwnerView : IView
    {
        
    }
}