﻿using System;
using AutoWeb.Models;
using AutoWeb.Presenters;
using AutoWeb.Views;

namespace AutoWeb
{
    public partial class EditOwner : ViewBase, IEditOwnerView
    {
        EditOwnerPresenter _presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var ownerId = int.Parse(Request.QueryString["id"]);
                _presenter = new EditOwnerPresenter(this, ownerId);
                _presenter.Init();
            }
        }

        public override void ShowError(string error)
        {
            throw new NotImplementedException();
        }

        public void Show(EditOwnerVM viewModel)
        {
            _tbFirstName.Text = viewModel.First;
            _tbLastName.Text = viewModel.Last;
        }
    }
}