﻿using AutoWeb.Domain.Repositories;
using AutoWeb.Models;
using AutoWeb.Views;

namespace AutoWeb.Presenters
{
    public class EditOwnerPresenter
    {
        readonly IEditOwnerView _view;
        readonly int _ownerId;
        readonly IOwnerRepository _ownerRepository;

        public EditOwnerPresenter(IEditOwnerView view, int ownerId)
            : this(view, ownerId, new OwnerRepository()) 
        {}

        public EditOwnerPresenter(IEditOwnerView view, int ownerId, IOwnerRepository ownerRepository)
        {
            _view = view;
            _ownerId = ownerId;
            _ownerRepository = ownerRepository;
        }

        public void Init()
        {
            var owner = _ownerRepository.FindById(_ownerId);
            var model = new EditOwnerVM()
                            {
                                First = owner.FirstName,
                                Last = owner.LastName
                            };

            _view.Show(model);
        }
    }
}