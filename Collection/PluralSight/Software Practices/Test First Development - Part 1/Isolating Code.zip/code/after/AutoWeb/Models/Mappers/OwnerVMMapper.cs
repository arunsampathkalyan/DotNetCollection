﻿
using System.Collections.Generic;
using AutoWeb.Domain.Entities;

namespace AutoWeb.Models.Mappers
{
    public class OwnerVMMapper
    {
        public OwnerVM From(IOwner owner)
        {
            return new OwnerVM()
                       {
                           Id = owner.Id,
                           Name = owner.GetFullName()
                       };
        }

        public IList<OwnerVM> From(IEnumerable<IOwner> owners)
        {
            IList<OwnerVM> ownerVMs = new List<OwnerVM>();

            foreach (var owner in owners)
            {
                ownerVMs.Add(From(owner));
            }

            return ownerVMs;
        }
    }
}