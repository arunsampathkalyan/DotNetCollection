﻿using AutoWeb.Domain.Commands;
using AutoWeb.Views;

namespace AutoWeb.Presenters
{
    public class AddOwnerPresenter
    {
        readonly IAddOwnerView _view;

        public AddOwnerPresenter(IAddOwnerView view)
        {
            _view = view;
        }

        public void AddNewOwner(string firstName, string lastName)
        {
            var command = new AddNewOwnerCommand(firstName, lastName);
            var validationResult = command.Validate();

            if (!validationResult.IsValid)
            {
                _view.ShowError(validationResult.GetAsMessage("<br/>"));
                return;
            }

            command.Execute();
            _view.Redirect("~/");
        }
    }
}