﻿using System;
using AutoWeb.Models;
using AutoWeb.Presenters;
using AutoWeb.Views;

namespace AutoWeb
{
    public partial class _Default : ViewBase, IDefaultView
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            CreatePresenter().Init();
        }

        public void Show(DefaultVM model)
        {
            _ownersRepeater.DataSource = model.Owners;
            _ownersRepeater.DataBind();
        }

        protected void AddNewOwner_Click(object sender, EventArgs e)
        {
            CreatePresenter().AddNewOwner();
        }

        private DefaultPresenter CreatePresenter()
        {
            return new DefaultPresenter(this);
        }

        public override void ShowError(string error)
        {
            throw new NotImplementedException();
        }
    }
}