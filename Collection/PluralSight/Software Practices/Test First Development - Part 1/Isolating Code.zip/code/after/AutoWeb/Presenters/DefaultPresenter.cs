﻿using AutoWeb.Models.Builders;
using AutoWeb.Views;

namespace AutoWeb.Presenters
{
    public class DefaultPresenter
    {
        readonly IDefaultView _view;
        readonly DefaultVMBuilder _modelBuilder;


        public DefaultPresenter(IDefaultView view)
            :this(view, new DefaultVMBuilder())
        {}

        public DefaultPresenter(IDefaultView view, DefaultVMBuilder modelBuilder)
        {
            _view = view;
            _modelBuilder = modelBuilder;
        }

        public void Init()
        {
            var viewModel = _modelBuilder.CreateModel();
            _view.Show(viewModel);
        }

        public void AddNewOwner()
        {
            _view.Redirect("~/AddOwner.aspx");
        }
    }
}