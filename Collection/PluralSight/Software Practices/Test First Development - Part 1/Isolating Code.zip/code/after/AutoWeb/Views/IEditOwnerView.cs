﻿using AutoWeb.Models;

namespace AutoWeb.Views
{
    public interface IEditOwnerView : IView
    {
        void Show(EditOwnerVM viewModel);
    }
}