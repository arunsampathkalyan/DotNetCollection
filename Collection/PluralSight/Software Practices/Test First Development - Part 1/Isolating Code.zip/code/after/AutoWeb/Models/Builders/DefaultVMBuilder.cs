﻿
using AutoWeb.Domain.Repositories;
using AutoWeb.Models.Mappers;

namespace AutoWeb.Models.Builders
{
    public class DefaultVMBuilder
    {
        readonly IOwnerRepository _ownerRepository;
        readonly OwnerVMMapper _mapper;


        public DefaultVMBuilder()
            :this(new OwnerRepository(), new OwnerVMMapper())
        {
            
        }

        public DefaultVMBuilder(IOwnerRepository ownerRepository, OwnerVMMapper mapper)
        {
            _ownerRepository = ownerRepository;
            _mapper = mapper;
        }

        public DefaultVM CreateModel()
        {
            var owners = _ownerRepository.GetAll();
            var ownerVMs = _mapper.From(owners);

            var model = new DefaultVM
                            {
                                Owners = ownerVMs
                            };

            return model;
        }
    }
}