﻿using AutoWeb.Models;

namespace AutoWeb.Views
{
    public interface IDefaultView : IView
    {
        void Show(DefaultVM model);
        
    }
}