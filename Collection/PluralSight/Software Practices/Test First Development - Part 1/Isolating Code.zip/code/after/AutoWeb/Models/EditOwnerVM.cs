﻿namespace AutoWeb.Models
{
    public class EditOwnerVM
    {
        public string First { get; set; }
        public string Last { get; set; }
    }
}