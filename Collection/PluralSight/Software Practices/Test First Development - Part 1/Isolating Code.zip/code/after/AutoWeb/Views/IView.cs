﻿namespace AutoWeb.Views
{
    public interface IView
    {
        void ShowError(string error);
        void Redirect(string url);
    }
}