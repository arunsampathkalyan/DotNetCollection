﻿using System.Collections.Generic;

namespace AutoWeb.Models
{
    public class DefaultVM
    {
        public DefaultVM()
        {
            Owners = new List<OwnerVM>();
        }

        public IList<OwnerVM> Owners { get; set; }
    }
}