﻿using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.EditPresenterTests
{
    public class When_calling_Init : With_a_new_presenter
    {
        [Test]
        public void Show_is_called_on_the_view()
        {
            _presenter.Init();
            _mockView.VerifyAll();
        }
    }
}