﻿using System.Collections.Generic;
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories;
using AutoWeb.Models.Builders;
using AutoWeb.Models.Mappers;
using AutoWeb.Presenters;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.DefaultPresenterTests
{
    public class When_initializing
    {
        private SpyDefaultView _view;
        private DefaultPresenter _presenter;
        DefaultVMBuilder _vmBuilder;
        Mock<IOwnerRepository> _moqOwnerRepository;
        IList<IOwner> _owners;

        [SetUp]
        public void SetUp()
        {
            _owners = Mother.CreateNewIOwnersWithIds();

            _moqOwnerRepository = new Mock<IOwnerRepository>();
            _moqOwnerRepository.Setup(r => r.GetAll())
                                .Returns(_owners);

            _vmBuilder = new DefaultVMBuilder(_moqOwnerRepository.Object, new OwnerVMMapper());
            _view = new SpyDefaultView();

            _presenter = new DefaultPresenter(_view, _vmBuilder);
        }

        [Test]
        public void Then_the_view_gets_shown()
        {
            _presenter.Init();
            Assert.IsTrue(_view.ShowWasCalled);
        }
    }
}
