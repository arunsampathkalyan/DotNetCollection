﻿
using System.Collections.Generic;
using AutoWeb.Domain.Entities;

namespace AutoWeb.Tests
{
    public static class Mother
    {
        static int _idCounter;

        public static IOwner CreateNewIOwnerWithId()
        {
            _idCounter++;

            return new Owner()
                       {
                           Id = _idCounter,
                           FirstName = "Homer" + _idCounter,
                           LastName = "Simpson" + _idCounter
                       };
        }

        public static IList<IOwner> CreateNewIOwnersWithIds()
        {
            var owners = new List<IOwner>
                             {
                                 CreateNewIOwnerWithId(),
                                 CreateNewIOwnerWithId(),
                                 CreateNewIOwnerWithId(),
                                 CreateNewIOwnerWithId()
                             };
            return owners;
        }
    }
}