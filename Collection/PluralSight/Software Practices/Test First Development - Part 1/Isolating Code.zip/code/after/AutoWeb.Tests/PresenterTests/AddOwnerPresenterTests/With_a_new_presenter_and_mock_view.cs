﻿using AutoWeb.Presenters;
using AutoWeb.Views;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.AddOwnerPresenterTests
{
    public class With_a_new_presenter_and_mock_view
    {
        protected AddOwnerPresenter _presenter;
        protected Mock<IAddOwnerView> _moqView;

        [SetUp]
        public void Init()
        {
            _moqView = new Mock<IAddOwnerView>();
            _presenter = new AddOwnerPresenter(_moqView.Object);
        }
    }

    public class When_adding_a_valid_new_user : With_a_new_presenter_and_mock_view
    {
        [SetUp]
        public new void Init()
        {
            _moqView.Setup(v => v.Redirect(It.IsAny<string>()));
            _presenter.AddNewOwner("Peter", "Griffin");
        }

        [Test]
        [Ignore]
        public void The_view_is_redirected()
        {
            _moqView.VerifyAll();
        }

    }
}