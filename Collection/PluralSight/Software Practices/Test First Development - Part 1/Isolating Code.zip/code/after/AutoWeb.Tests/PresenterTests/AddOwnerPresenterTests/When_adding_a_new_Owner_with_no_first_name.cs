﻿using Moq;
using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.AddOwnerPresenterTests
{
    public class When_adding_a_new_Owner_with_no_first_name : With_a_new_presenter_and_mock_view
    {
        [SetUp]
        public new void Init()
        {
            _moqView.Setup(v => v.ShowError(It.IsAny<string>()));
            _presenter.AddNewOwner(null, "Griffin");
        }

        [Test]
        public void An_error_is_shown()
        {
            _moqView.VerifyAll();
        }
    }
}
