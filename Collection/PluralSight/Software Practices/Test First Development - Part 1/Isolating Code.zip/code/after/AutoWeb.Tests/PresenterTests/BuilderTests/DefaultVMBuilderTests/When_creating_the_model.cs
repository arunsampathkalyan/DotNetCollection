﻿using System.Collections.Generic;
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories;
using AutoWeb.Models;
using AutoWeb.Models.Builders;
using AutoWeb.Models.Mappers;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.BuilderTests.DefaultVMBuilderTests
{
    public class When_creating_the_model
    {
        DefaultVMBuilder _builder;
        Mock<IOwnerRepository> _moqOwnerRepository;
        IList<IOwner> _owners;
        DefaultVM _model;


        [SetUp]
        public void Init()
        {
            _owners = Mother.CreateNewIOwnersWithIds();

            _moqOwnerRepository = new Mock<IOwnerRepository>();
            _moqOwnerRepository.Setup(r => r.GetAll())
                                .Returns(_owners);

            _builder = new DefaultVMBuilder(_moqOwnerRepository.Object, new OwnerVMMapper());
            _model = _builder.CreateModel();
        }

        [Test]
        public void The_model_has_the_correct_number_of_owners()
        {
            Assert.AreEqual(_owners.Count, _model.Owners.Count);
        }

        [Test]
        public void GetAll_was_called_on_the_repo()
        {
            _moqOwnerRepository.VerifyAll();
        }
    }
}
