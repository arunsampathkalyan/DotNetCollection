﻿using System;
using AutoWeb.Models;
using AutoWeb.Views;

namespace AutoWeb.Tests.PresenterTests.DefaultPresenterTests
{
    public class SpyDefaultView : IDefaultView
    {
        public SpyDefaultView()
        {
            ShowWasCalled = false;
        }

        public void Show(DefaultVM model)
        {
            ShowWasCalled = true;    
        }

        public void ShowError(string error)
        {
            throw new NotImplementedException();
        }

        public void Redirect(string url)
        {
            
        }

        public bool ShowWasCalled { get; set; }
    }
}