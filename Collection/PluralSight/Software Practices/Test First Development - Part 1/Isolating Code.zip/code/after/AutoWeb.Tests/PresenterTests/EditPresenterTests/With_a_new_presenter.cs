﻿using AutoWeb.Domain.Repositories;
using AutoWeb.Models;
using AutoWeb.Presenters;
using AutoWeb.Views;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Tests.PresenterTests.EditPresenterTests
{
    public class With_a_new_presenter
    {
        protected EditOwnerPresenter _presenter;
        protected Mock<IOwnerRepository> _mockRepository;
        protected Mock<IEditOwnerView> _mockView;


        [SetUp]
        public void Init()
        {
            var owner = Mother.CreateNewIOwnerWithId();

            _mockRepository = new Mock<IOwnerRepository>();

            _mockRepository.Setup(r => r.FindById(owner.Id))
                .Returns(owner);

            _mockView = new Mock<IEditOwnerView>();
            _mockView.Setup(v => v.Show(It.IsAny<EditOwnerVM>()));
            
            _presenter = new EditOwnerPresenter(_mockView.Object, owner.Id, _mockRepository.Object); 
        }
    }
}
