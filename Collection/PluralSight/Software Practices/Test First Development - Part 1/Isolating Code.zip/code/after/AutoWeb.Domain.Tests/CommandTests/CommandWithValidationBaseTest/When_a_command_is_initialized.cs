﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandWithValidationBaseTest
{
    public class When_a_command_is_initialized : With_a_command_that_validates
    {
        [Test]
        public void The_command_is_valid()
        {
            Assert.IsTrue(_command.Validate().IsValid);
        }
    }
}