﻿using System.Linq;
using AutoWeb.Domain.Entities;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.RepositoryTests.OwnerRepositoryTests
{
    [Category("Integration")]
    public class When_adding_a_new_owner 
        : With_an_empty_OwnerRepository
    {
        IOwner _newOwner;

        [SetUp]
        public new void Init()
        {
            _newOwner = Mother.MakeNewOwner();
            _ownerRepository.Save(_newOwner);
        }

        [Test]
        public void Then_a_single_owner_is_in_the_db()
        {
            Assert.AreEqual(1, _ownerRepository.GetAll().ToList().Count);
        }

        [Test]
        public void Then_the_owner_can_be_retrieved_by_firstName_lastName()
        {
            var retrievedOwner = _ownerRepository.FindByName(_newOwner.FirstName, _newOwner.LastName);
            Assert.IsNotNull(retrievedOwner);
        }
    }
}