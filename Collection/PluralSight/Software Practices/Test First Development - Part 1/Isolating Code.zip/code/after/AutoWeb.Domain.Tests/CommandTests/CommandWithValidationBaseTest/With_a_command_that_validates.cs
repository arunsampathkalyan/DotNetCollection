﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandWithValidationBaseTest
{
    public class With_a_command_that_validates
    {
        protected FakeCommandWithValidation _command;

        [SetUp]
        public void Init()
        {
            _command = new FakeCommandWithValidation();
        }
    }
}
