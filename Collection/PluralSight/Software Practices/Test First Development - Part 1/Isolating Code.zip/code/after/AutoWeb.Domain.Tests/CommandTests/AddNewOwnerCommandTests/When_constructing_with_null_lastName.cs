﻿using AutoWeb.Domain.Commands;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.AddNewOwnerCommandTests
{
    public class When_constructing_with_null_lastName
    {
        [Test]
        public void Then_construction_fails()
        {
            var command = new AddNewOwnerCommand("foo", null, new DummyOwnerRepository());
            Assert.IsFalse(command.Validate().IsValid);
        }
    }
}