﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandValidationResultTests
{
    public class When_adding_an_error : With_a_new_CommandValidationResult
    {
        string _errorMessage;

        [SetUp]
        public new void Init()
        {
            _errorMessage = "ERROR";
            _validationResult.AddError(_errorMessage);
        }

        [Test]
        public void Then_the_result_is_invalid()
        {
            Assert.IsFalse(_validationResult.IsValid);
        }

        [Test]
        public void The_error_string_ends_with_a_period()
        {
            StringAssert.EndsWith(".", _validationResult.GetAsMessage());
        }

        [Test]
        public void The_error_string_has_the_original_message()
        {
            StringAssert.StartsWith(_errorMessage, _validationResult.GetAsMessage());
        }


    }
}