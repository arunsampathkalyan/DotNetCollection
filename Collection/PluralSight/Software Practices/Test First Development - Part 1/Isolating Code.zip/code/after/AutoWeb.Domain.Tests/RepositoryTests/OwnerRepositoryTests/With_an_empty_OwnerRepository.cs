﻿using AutoWeb.Domain.Repositories;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.RepositoryTests.OwnerRepositoryTests
{
    public class With_an_empty_OwnerRepository
    {
        protected OwnerRepository _ownerRepository;

        [SetUp]
        public void Init()
        {
            _ownerRepository = new OwnerRepository();
            ClearExistingOwnersOutOfDb();
        }

        [TearDown]
        public void Dispose()
        {
            ClearExistingOwnersOutOfDb();
        }

        void ClearExistingOwnersOutOfDb()
        {
            var owners = _ownerRepository.GetAll();
            foreach (var owner in owners)
            {
                _ownerRepository.Delete(owner);
            }
        }
    }
}