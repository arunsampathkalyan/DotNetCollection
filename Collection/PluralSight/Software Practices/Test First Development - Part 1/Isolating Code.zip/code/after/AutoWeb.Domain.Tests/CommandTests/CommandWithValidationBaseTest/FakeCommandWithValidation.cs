﻿using AutoWeb.Domain.Commands;

namespace AutoWeb.Domain.Tests.CommandTests.CommandWithValidationBaseTest
{
    public class FakeCommandWithValidation : CommandWithValidationBase
    {
        public override void Execute()
        {
            ExecuteWasCalled = true;    
        }

        public bool ExecuteWasCalled { get; set; }

        internal void AddAnError()
        {
            base.AddError("SOMETHING BAD");
        }
    }
}
