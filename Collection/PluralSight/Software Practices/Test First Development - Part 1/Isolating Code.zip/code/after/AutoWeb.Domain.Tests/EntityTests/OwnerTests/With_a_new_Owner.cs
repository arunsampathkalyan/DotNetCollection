﻿using AutoWeb.Domain.Entities;

namespace AutoWeb.Domain.Tests.EntityTests.OwnerTests
{
    public class With_a_new_Owner
    {
        protected Owner _owner;

        public With_a_new_Owner()
        {
            _owner = Mother.MakeNewOwner();


        }

         
    }
}