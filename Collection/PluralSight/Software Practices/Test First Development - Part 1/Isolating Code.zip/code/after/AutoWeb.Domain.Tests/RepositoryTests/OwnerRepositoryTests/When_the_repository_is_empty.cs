﻿using System.Linq;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.RepositoryTests.OwnerRepositoryTests
{
    [TestFixture]
    public class When_the_repository_is_empty 
        : With_an_empty_OwnerRepository
    {

        [Test]
        public void There_are_no_owners_named_Scooby_Doo()
        {
            var owners = _ownerRepository.FindByName("scooby", "doo").ToList();
            Assert.AreEqual(0, owners.Count);
        }

        [Test]
        public void There_are_no_owners()
        {
            var owners = _ownerRepository.GetAll();
            Assert.AreEqual(0, owners.ToList().Count);
        }
    }
}