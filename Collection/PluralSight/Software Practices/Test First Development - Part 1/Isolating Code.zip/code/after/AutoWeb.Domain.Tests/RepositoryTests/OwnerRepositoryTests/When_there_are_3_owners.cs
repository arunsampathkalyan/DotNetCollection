﻿using System.Linq;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.RepositoryTests.OwnerRepositoryTests
{
    public class When_there_are_3_owners : With_3_owners_in_the_repo
    {
        [Test]
        public void Then_there_are_3_owners_in_the_repo()
        {
            Assert.AreEqual(3, _ownerRepository.GetAll().ToList().Count);
        }

        [Test]
        public void Then_I_can_get_Owner_1_ByName()
        {
            var owner = _ownerRepository.FindByName(_owner1.FirstName, _owner1.LastName);
            Assert.IsNotNull(owner);
        }

        [Test]
        public void Then_I_can_get_Owner_1_by_Id()
        {
            var owner = _ownerRepository.FindById(_owner1.Id);
            Assert.IsNotNull(owner);
        }

        [Test]
        public void Then_Owner_1_first_name_is_correct()
        {
            var owner = _ownerRepository.FindById(_owner1.Id);
            Assert.AreEqual(_owner1.FirstName, owner.FirstName);
        }

        [Test]
        public void Then_Owner_1_last_name_is_correct()
        {
            var owner = _ownerRepository.FindById(_owner1.Id);
            Assert.AreEqual(_owner1.LastName, owner.LastName);
        }

        [Test]
        public void Then_I_can_get_Owner_2_by_Id()
        {
            var owner = _ownerRepository.FindById(_owner2.Id);
            Assert.IsNotNull(owner);
        }

        [Test]
        public void Then_I_can_get_Owner_3_by_Id()
        {
            var owner = _ownerRepository.FindById(_owner3.Id);
            Assert.IsNotNull(owner);
        }


    }
}