﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.EntityTests.OwnerTests
{
    public class When_getting_the_full_name : With_a_new_Owner
    {
        [Test]
        public void The_fullname_is_a_well_formated_string()
        {
            Assert.AreEqual(_owner.FirstName + " " + _owner.LastName, _owner.GetFullName());
        }
    }
}
