﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories;

namespace AutoWeb.Domain.Tests.CommandTests.AddNewOwnerCommandTests
{
    public class DummyOwnerRepository : IOwnerRepository
    {
        public IOwner FindById(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOwner> FindByName(string firstName, string lastName)
        {
            throw new NotImplementedException();
        }

        public IOwner Save(IOwner owner)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IOwner> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Delete(IOwner owner)
        {
            throw new NotImplementedException();
        }
    }
}