﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandWithValidationBaseTest
{
    public class When_adding_a_validation_error : With_a_command_that_validates
    {
        [SetUp]
        public new void Init()
        {
            _command.AddAnError();
        }

        [Test]
        public void The_command_is_invalid()
        {
            Assert.IsFalse(_command.Validate().IsValid);
        }

        [Test]
        public void Then_the_command_will_not_execute()
        {
            _command.ExecuteIfValid();
            Assert.IsFalse(_command.ExecuteWasCalled);
        }
    }
}