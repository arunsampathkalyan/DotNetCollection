﻿using AutoWeb.Domain.Commands;
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.AddNewOwnerCommandTests
{
    public class With_a_new_AddNewOwnerCommand
    {
        protected AddNewOwnerCommand _command;
        protected Owner _rawOwner;
        protected Mock<IOwnerRepository> _mockOwnerRepository;

        [SetUp]
        public void Init()
        {
            _mockOwnerRepository = new Mock<IOwnerRepository>();

            _rawOwner = Mother.MakeNewOwner();
            _command = new AddNewOwnerCommand(_rawOwner.FirstName, _rawOwner.LastName, _mockOwnerRepository.Object);
        }
    }
}
