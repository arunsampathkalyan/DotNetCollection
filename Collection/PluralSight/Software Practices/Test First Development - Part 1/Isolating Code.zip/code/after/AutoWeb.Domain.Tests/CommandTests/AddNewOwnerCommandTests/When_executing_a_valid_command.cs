﻿using AutoWeb.Domain.Entities;
using Moq;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.AddNewOwnerCommandTests
{
    public class When_executing_a_valid_command : With_a_new_AddNewOwnerCommand
    {
        [SetUp]
        public new void Init()
        {
            _mockOwnerRepository.Setup(r => r.Save(It.IsAny<IOwner>()))
                .Returns(Mother.MakeNewOwner());

            _command.Execute();
        }

        [Test]
        public void Save_is_called_on_the_repository()
        {
            _mockOwnerRepository.VerifyAll();
        }

    }
}