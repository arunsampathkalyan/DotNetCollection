﻿using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandValidationResultTests
{
    public class When_the_ValidationResult_is_new : With_a_new_CommandValidationResult
    {
        [Test]
        public void The_command_is_valid()
        {
            Assert.IsTrue(_validationResult.IsValid);
        }
    }
}