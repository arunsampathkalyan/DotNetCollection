﻿
using AutoWeb.Domain.Commands;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.CommandTests.CommandValidationResultTests
{
    public class With_a_new_CommandValidationResult
    {
        protected CommandValidationResult _validationResult;

        [SetUp]
        public void Init()
        {
            _validationResult = new CommandValidationResult();
        }
    }
}
