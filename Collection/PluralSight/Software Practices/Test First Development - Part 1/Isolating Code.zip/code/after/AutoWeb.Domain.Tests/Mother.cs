﻿using AutoWeb.Domain.Entities;

namespace AutoWeb.Domain.Tests
{
    public static class Mother
    {
        static int counter = 0;

        public static Owner MakeNewOwner()
        {
            return new Owner()
                       {
                           FirstName = "Peter",
                           LastName = "Griffin" + counter++.ToString()
                       };
        }
    }
}