﻿using AutoWeb.Domain.Entities;
using NUnit.Framework;

namespace AutoWeb.Domain.Tests.RepositoryTests.OwnerRepositoryTests
{
    public class With_3_owners_in_the_repo : With_an_empty_OwnerRepository
    {
        protected IOwner _owner1;
        protected IOwner _owner2;
        protected IOwner _owner3;

        [SetUp]
        public new void Init()
        {
            _owner1 = _ownerRepository.Save(Mother.MakeNewOwner());
            _owner2 = _ownerRepository.Save(Mother.MakeNewOwner());
            _owner3 = _ownerRepository.Save(Mother.MakeNewOwner());
        }
    }
}