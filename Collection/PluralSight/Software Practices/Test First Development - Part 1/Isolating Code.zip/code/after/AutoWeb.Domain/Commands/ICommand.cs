﻿namespace AutoWeb.Domain.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}