﻿namespace AutoWeb.Domain.Entities
{
    public interface IOwner
    {
        int Id { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string GetFullName();
    }
}