﻿
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories;

namespace AutoWeb.Domain.Commands
{
    public class AddNewOwnerCommand : CommandWithValidationBase
    {
        readonly string _firstName;
        readonly string _lastName;
        readonly IOwnerRepository _ownerRepository;

        public AddNewOwnerCommand(string firstName, string lastName)
            :this(firstName, lastName, new OwnerRepository())
        {}

        public AddNewOwnerCommand(string firstName, string lastName, IOwnerRepository ownerRepository)
        {
            _firstName = firstName;
            _lastName = lastName;
            _ownerRepository = ownerRepository;
        }

        public override void Execute()
        {
            var owner = new Owner()
                              {
                                  FirstName = _firstName,
                                  LastName = _lastName
                              };

            _ownerRepository.Save(owner);
            
        }

        public override CommandValidationResult Validate()
        {
            ValidateFirstName();
            ValidateLastName();
            ValidateOwnerRepositry();

            return base.Validate();
        }

        void ValidateOwnerRepositry()
        {
            if(_ownerRepository == null)
                AddError("Owner Repository is not initialized");
        }

        void ValidateFirstName()
        {
            if(string.IsNullOrEmpty(_firstName))
                AddError("Please provide a valid first name");
        }

        void ValidateLastName()
        {
            if (string.IsNullOrEmpty(_lastName))
                AddError("Please provide a valid last name");
        }
    }
}