﻿using System.Collections.Generic;
using AutoWeb.Domain.Entities;

namespace AutoWeb.Domain.Repositories
{
    public interface IOwnerRepository
    {
        IOwner FindById(int id);
        IEnumerable<IOwner> FindByName(string firstName, string lastName);
        IOwner Save(IOwner owner);
        IEnumerable<IOwner> GetAll();
        void Delete(IOwner owner);
    }
}