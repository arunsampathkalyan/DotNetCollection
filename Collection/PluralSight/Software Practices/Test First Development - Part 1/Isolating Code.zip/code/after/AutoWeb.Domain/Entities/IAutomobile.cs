﻿using System;

namespace AutoWeb.Domain.Entities
{
    public interface IAutomobile
    {
        Guid Id { get; } 

        void Start();
        void Stop();

        string Name { get; }
        string Manufacturer { get; }
        string Color { get; }
        string Model { get; }
    }
}