﻿using System.Collections.Generic;
using System.Linq;
using AutoWeb.Data;
using AutoWeb.Domain.Entities;
using AutoWeb.Domain.Repositories.Mapping;

namespace AutoWeb.Domain.Repositories
{
    public class OwnerRepository : IOwnerRepository
    {
        readonly OwnerMapper _ownerMapper;

        public OwnerRepository()
            : this(new OwnerMapper())
        {
            
        }

        public OwnerRepository(OwnerMapper ownerMapper)
        {
            _ownerMapper = ownerMapper;
        }


        public IOwner FindById(int id)
        {
            AutoOwner autoOwnerEntity;

            using (var context = new VehicleModelContainer())
            {
                autoOwnerEntity = context.AutoOwners.FirstOrDefault(ao => ao.Id == id);
            }

            if (autoOwnerEntity == null)
                return null;

            return _ownerMapper.From(autoOwnerEntity);
        }

        public IEnumerable<IOwner> FindByName(string firstName, string lastName)
        {
            using (var context = new VehicleModelContainer())
            {
                var query = from ao in context.AutoOwners
                            where   
                                ao.FirstName == firstName &&
                                ao.LastName == lastName
                            select ao;

                return _ownerMapper.From(query);
            }

        }

        public IOwner Save(IOwner owner)
        {
            AutoOwner autoOwnerEntity;
            
            using (var context = new VehicleModelContainer())
            {
                autoOwnerEntity = context.AutoOwners.CreateObject();
                autoOwnerEntity.FirstName = owner.FirstName;
                autoOwnerEntity.LastName = owner.LastName;

                context.AutoOwners.AddObject(autoOwnerEntity);
                context.SaveChanges();
            }

            return _ownerMapper.From(autoOwnerEntity);
        }

        public IEnumerable<IOwner> GetAll()
        {
            using (var context = new VehicleModelContainer())
            {
                var query = from ao in context.AutoOwners
                            select ao;

                return _ownerMapper.From(query.ToList());
            }
        }

        public void Delete(IOwner owner)
        {
            using (var context = new VehicleModelContainer())
            {
                var ownerEntity = context.AutoOwners.First(o => o.Id == owner.Id);

                if (ownerEntity == null)
                    return;

                context.AutoOwners.DeleteObject(ownerEntity);
                context.SaveChanges();

            }
        }
    }
}
