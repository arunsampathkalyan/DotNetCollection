﻿
using System.Collections.Generic;
using System.Linq;
using AutoWeb.Data;
using AutoWeb.Domain.Entities;

namespace AutoWeb.Domain.Repositories.Mapping
{
    public class OwnerMapper
    {
        public IEnumerable<IOwner> From(IEnumerable<AutoOwner> ownerEntities)
        {
            IList<IOwner> owners = new List<IOwner>();

            foreach (var autoOwnerEntity in ownerEntities.ToList())
            {
                var owner = new Owner()
                {
                    Id = autoOwnerEntity.Id,
                    FirstName = autoOwnerEntity.FirstName,
                    LastName = autoOwnerEntity.LastName
                };
                owners.Add(owner);
            }

            return owners;
        }

        public AutoOwner From(IOwner owner)
        {
            return new AutoOwner()
            {
                FirstName = owner.FirstName,
                LastName = owner.LastName
            };
        }
        
        public IOwner From(AutoOwner autoOwnerEntity)
        {
            return new Owner()
            {
                Id = autoOwnerEntity.Id,
                FirstName = autoOwnerEntity.FirstName,
                LastName = autoOwnerEntity.LastName
            };
        }
    }
}
