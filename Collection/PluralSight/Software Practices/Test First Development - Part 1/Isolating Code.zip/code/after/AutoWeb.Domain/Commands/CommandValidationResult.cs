﻿using System.Collections.Generic;

namespace AutoWeb.Domain.Commands
{
    public class CommandValidationResult
    {
        readonly IList<string> _errors = new List<string>();

        public bool IsValid 
        { 
            get
            {
                return _errors.Count == 0;
            }
        }

        public void AddError(string errorMessage)
        {
            _errors.Add(errorMessage);
        }

        public string GetAsMessage()
        {
            return GetAsMessage(".");
        }

        public string GetAsMessage(string delimiter)
        {
            var errorMsg = string.Empty;

            foreach (var error in _errors)
            {
                errorMsg += error + delimiter;
            }

            return errorMsg;
        }
    }
}