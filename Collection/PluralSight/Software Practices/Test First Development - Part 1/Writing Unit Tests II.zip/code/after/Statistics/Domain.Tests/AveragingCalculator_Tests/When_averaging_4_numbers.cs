﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Domain.Tests.AveragingCalculator_Tests
{
    [Category("AveragingCalculator")]
    public class When_averaging_4_numbers
    {
        private AveragingCalculator _averageCalulator;
        private IList<Measurement> _measurements;
        private Measurement _result;
        
        [SetUp]
        public void Setup()
        {
            _averageCalulator = new AveragingCalculator();
            _measurements = Mother.Get4Measurements();
            _result = _averageCalulator.Aggregate(_measurements);
        }

        [Test]
        public void Then_the_high_average_is_correct()
        {
            var expectedAverage = AverageHigh(_measurements);
            Assert.AreEqual(expectedAverage, _result.HighValue);
        }

        [Test]
        public void Then_the_low_average_is_correct()
        {
            var expectedAverage = AverageLow(_measurements);
            Assert.AreEqual(expectedAverage, _result.LowValue);
        }

        private double AverageLow(IList<Measurement> measurements)
        {
            return measurements.Sum(m => m.LowValue) / measurements.Count;
        }

        private double AverageHigh(IList<Measurement> measurements)
        {
            return measurements.Sum(m => m.HighValue)/measurements.Count;
        }
    }
}
