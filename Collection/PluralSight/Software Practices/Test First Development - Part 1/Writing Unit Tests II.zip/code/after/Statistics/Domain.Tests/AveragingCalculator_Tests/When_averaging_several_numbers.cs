﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Domain.Tests.AveragingCalculator_Tests
{
    [Category("AveragingCalculator")]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(36.0, 36.0, 36.0, 42.0, 42.0, 42.0)]
    [TestFixture(10.0, 20.0, 15.0, 42.0, 42.0, 42.0)]
    public class When_averaging_several_numbers
    {
        private readonly double _high1;
        private readonly double _high2;
        private readonly double _highAvg;
        private readonly double _low1;
        private readonly double _low2;
        private readonly double _lowAvg;
        
        private AveragingCalculator _averageCalulator;
        private IList<Measurement> _measurements;
        private Measurement _result;

        public When_averaging_several_numbers(double high1, double high2, double highAvg,
                                              double low1, double low2, double lowAvg)
        {
            _high1 = high1;
            _high2 = high2;
            _highAvg = highAvg;
            _low1 = low1;
            _low2 = low2;
            _lowAvg = lowAvg;
        }

        [SetUp]
        public void Setup()
        {
            _averageCalulator = new AveragingCalculator();
            _measurements = MakeMeasurements();
            _result = _averageCalulator.Aggregate(_measurements);
        }

        private IList<Measurement> MakeMeasurements()
        {
            return new List<Measurement>
                       {
                           new Measurement(){HighValue = _high1, LowValue = _low1},
                           new Measurement(){HighValue = _high2, LowValue = _low2},
                       };
        }

        [Test]
        public void Then_low_average_is_correct()
        {
            Assert.AreEqual(_lowAvg, _result.LowValue);
        }

        [Test]
        public void Then_high_average_is_correct()
        {
            Assert.AreEqual(_highAvg, _result.HighValue);
        }
    }
}
