namespace Domain
{
    public enum AggregationType
    {
        Mean, 
        Mode
    }
}