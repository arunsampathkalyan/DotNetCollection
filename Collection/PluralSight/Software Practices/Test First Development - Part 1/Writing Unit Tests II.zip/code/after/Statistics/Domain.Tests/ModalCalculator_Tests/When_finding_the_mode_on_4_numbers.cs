﻿
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Domain.Tests.ModalCalculator_Tests
{
    [Category("ModalCalculator")]
    public class When_finding_the_mode_on_4_measurements
    {
        private ModalCalculator _calculator;
        private IList<Measurement> _measurements;
        private Measurement _result;

        [SetUp]
        public void SetUpATest()
        {
            _calculator = new ModalCalculator();
            _measurements = Mother.Get4Measurements();
            _result = _calculator.Aggregate(_measurements);
        }

        [Test]
        public void Then_the_high_mode_is_correct()
        {
            var expectedResult = GetMode(_measurements.GroupBy(m => m.HighValue));
            Assert.AreEqual(expectedResult, _result.HighValue);
            
        }

        [Test]
        public void Then_the_low_mode_is_correct()
        {
            var expectedResult = GetMode(_measurements.GroupBy(m => m.LowValue));
            Assert.AreEqual(expectedResult, _result.LowValue);
        }

        private double GetMode(IEnumerable<IGrouping<double, Measurement>> group)
        {
            return group.OrderByDescending(g => g.Count())
                .Select(g => g.Key)
                .First();
        }
    }
}
