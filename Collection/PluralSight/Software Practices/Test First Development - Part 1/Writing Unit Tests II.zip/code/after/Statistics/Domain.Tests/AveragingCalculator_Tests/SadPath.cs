﻿
using System;
using NUnit.Framework;

namespace Domain.Tests.AveragingCalculator_Tests
{
    [Category("AveragingCalculator")]
    public class SadPath
    {
        private AveragingCalculator _averageCalulator;

        [SetUp]
        public void Setup()
        {
            _averageCalulator = new AveragingCalculator();
        }

        [Test]
        [ExpectedException(typeof(ArgumentNullException))]
        public void When_measurements_are_null()
        {
            _averageCalulator.Aggregate(null);
        }

        [Test]
        [ExpectedException(typeof(NullReferenceException))]
        public void When_a_measurement_are_null()
        {
            var measurements = Mother.Get4Measurements();
                measurements.Add(null);

            _averageCalulator.Aggregate(measurements);
        }

    }
}
