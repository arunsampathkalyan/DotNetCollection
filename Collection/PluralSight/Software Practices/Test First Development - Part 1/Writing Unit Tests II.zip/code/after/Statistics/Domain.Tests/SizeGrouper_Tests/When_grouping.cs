﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Domain.Tests.SizeGrouper_Tests
{
    [Category("SizeGrouper")]
    [TestFixture(1)]
    [TestFixture(2)]
    [TestFixture(4)]
    public class When_grouping
    {
        private IList<Measurement> _measurements;
        private SizeGrouper _sizeGrouper;
        private IEnumerable<IEnumerable<Measurement>> _groupedMeasurements;
        private readonly int _groupSize = 2;

        public When_grouping(int groupSize)
        {
            _groupSize = groupSize;
        }

        [SetUp]
        public void SetupATest()
        {
            _measurements = Mother.Get4Measurements();
            _sizeGrouper = new SizeGrouper(_groupSize);
            _groupedMeasurements = _sizeGrouper.Group(_measurements);
        }

        [Test]
        public void Then_no_grouped_measurements_are_null()
        {
            foreach (IEnumerable<Measurement> measurementGroup in _groupedMeasurements)
                CollectionAssert.AllItemsAreNotNull(measurementGroup);
        }

        [Test]
        public void Then_all_groups_are_the_correct_size()
        {
            foreach (var measurementGroup in _groupedMeasurements)
            {
                Assert.AreEqual(_groupSize, measurementGroup.Count());
            }
        }
    }
}