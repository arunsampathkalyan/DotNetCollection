﻿using System.Windows;

namespace TextBindingFormatting
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = "Text from databinding";
        }
    }
}
