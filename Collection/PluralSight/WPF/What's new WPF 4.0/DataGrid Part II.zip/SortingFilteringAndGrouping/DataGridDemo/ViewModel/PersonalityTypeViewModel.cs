﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataGridDemo.Model;

namespace DataGridDemo.ViewModel
{
    public class PersonalityTypeViewModel
    {
        private PersonalityTypeViewModel(PersonalityType type)
        {
            this.Type = type;

            this.DisplayText =
                PersonalityTypeResources.ResourceManager.GetString(
                    type.ToString() + "DisplayText");
        }

        public PersonalityType Type { get; private set; }

        public string DisplayText { get; private set; }


        private static PersonalityTypeViewModel[] _types = 
        { 
            new PersonalityTypeViewModel(PersonalityType.GlassHalfFull),
            new PersonalityTypeViewModel(PersonalityType.GlassHalfEmpty),
            new PersonalityTypeViewModel(PersonalityType.ItsYourRoundMate)
        };

        public static IList<PersonalityTypeViewModel> Types { get { return _types; } }
    }
}
