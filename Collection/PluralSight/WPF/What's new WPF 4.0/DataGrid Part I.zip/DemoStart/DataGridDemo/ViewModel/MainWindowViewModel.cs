﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using DataGridDemo.Model;

namespace DataGridDemo.ViewModel
{
    public class MainWindowViewModel
    {
        public ObservableCollection<PersonItemViewModel> People { get; private set; }

        public MainWindowViewModel()
        {
            var peopleViewModels = from person in Person.GetPeople()
                                   select new PersonItemViewModel(person);

            People = new ObservableCollection<PersonItemViewModel>(peopleViewModels);
        }
    }
}
