﻿
namespace DataGridDemo.Model
{
    public enum PersonalityType
    {
        GlassHalfFull,
        GlassHalfEmpty,
        ItsYourRoundMate
    }
}
