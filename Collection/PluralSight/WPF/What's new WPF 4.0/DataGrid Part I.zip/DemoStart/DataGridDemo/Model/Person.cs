﻿using System;
using System.Collections.Generic;

namespace DataGridDemo.Model
{
    public class Person
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public bool IsHungry { get; set; }
        public Uri Website { get; set; }
        public PersonalityType Personality { get; set; }


        public static IEnumerable<Person> GetPeople()
        {
            return new Person[]
            {
                new Person
                {
                    Id = 1,
                    FirstName = "Ian", LastName = "Griffiths",
                    Website = new Uri("http://www.interact-sw.co.uk/iangblog/"),
                    IsHungry = true,
                    Personality = PersonalityType.GlassHalfFull
                },
                new Person
                {
                    Id = 2,
                    FirstName = "Jane", LastName = "Doe",
                    Website = new Uri("http://pluralsight.com/"),
                    Personality = PersonalityType.ItsYourRoundMate
                },
                new Person
                {
                    Id = 3,
                    FirstName = "Ian", LastName = "Davis",
                    Website = new Uri("http://example.com/foo/"),
                    Personality = PersonalityType.GlassHalfFull
                },
                new Person
                {
                    Id = 4,
                    FirstName = "Ian", LastName = "Grotbags",
                    Website = new Uri("http://example.com/bar/"),
                    Personality = PersonalityType.GlassHalfFull
                },
                new Person
                {
                    Id = 42,
                    FirstName = "Arthur", LastName = "Dent",
                    Website = new Uri("http://www.h2g2.com/"),
                    IsHungry = true,
                    Personality = PersonalityType.GlassHalfEmpty
                }
            };
        }
    }
}
