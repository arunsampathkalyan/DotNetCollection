﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using DataGridDemo.Model;

namespace DataGridDemo.ViewModel
{
    public class PersonItemViewModel : NotifyPropertyChanged
    {
        private Person _model;

        public PersonItemViewModel(Person model)
        {
            _model = model;
        }

        public string FirstName
        {
            get { return _model.FirstName; }
            set { if (value != _model.FirstName) { _model.FirstName = value; OnPropertyChanged("FirstName"); } }
        }
        public string LastName
        {
            get { return _model.LastName; }
            set { if (value != _model.LastName) { _model.LastName = value; OnPropertyChanged("LastName"); } }
        }

        public bool IsHungry
        {
            get { return _model.IsHungry; }
            set { if (value != _model.IsHungry) { _model.IsHungry = value; OnPropertyChanged("IsHungry"); } }
        }

        public PersonalityType Personality
        {
            get { return _model.Personality; }
            set { if (value != _model.Personality) { _model.Personality = value; OnPropertyChanged("Personality"); } }
        }

        public Uri Website
        {
            get { return _model.Website; }
            set { if (value != _model.Website) { _model.Website = value; OnPropertyChanged("Website"); } }
        }
    }
}
