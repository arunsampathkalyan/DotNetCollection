﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using DataGridDemo.ViewModel;

namespace DataGridDemo
{
    public partial class MainWindow : Window
    {
        private MainWindowViewModel _vm;

        public MainWindow()
        {
            InitializeComponent();

            _vm = new MainWindowViewModel();
            this.DataContext = _vm;
        }

        private void Grid_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            MessageBox.Show(e.Uri.ToString(), "Navigate");

        }
    }
}
