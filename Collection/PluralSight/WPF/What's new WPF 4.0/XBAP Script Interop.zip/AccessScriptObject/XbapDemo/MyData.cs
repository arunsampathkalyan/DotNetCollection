﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace XbapDemo
{
    [ComVisible(true)]
    public class MyData
    {
        public string Name { get; set; }
        public double Age { get; set; }
    }
}
