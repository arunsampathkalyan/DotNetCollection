﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XbapDemo
{
    using System.Runtime.InteropServices;
    using System.Diagnostics;
using System.Threading;
    using System.Windows.Interop;

    [ComVisible(true)]
    public class CallbackContainer
    {
        private SynchronizationContext sync = SynchronizationContext.Current;
        public string GetMessage(dynamic arg)
        {
            sync.Post(
                delegate
                {
                    var hostScript = BrowserInteropHelper.HostScript;
                    // ...
                    // Can access script objects here via hostScript
                    // without fear of SecurityException.
                },
                null);
            return "I'll call you back...";
            //Type t = arg.GetType();
            //Debug.WriteLine(t.FullName);
            //Debug.WriteLine(t.Assembly);

            //return "Message: " + arg.Foo + ", " + arg.Bar;
        }
    }
}
