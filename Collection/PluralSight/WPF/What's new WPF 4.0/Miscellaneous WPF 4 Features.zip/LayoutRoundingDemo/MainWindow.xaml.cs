﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LayoutRoundingDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SetStripe();
            SetLayoutType();
        }

        private void OnLayoutTypeCheckChanged(object sender, RoutedEventArgs e)
        {
            if (pixelSnappingRadio != null && layoutRoundingRadio != null && layoutRoot != null)
            {
                SetLayoutType();
            }
        }

        private void SetLayoutType()
        {
            bool usePixelSnapping = pixelSnappingRadio.IsChecked == true;
            bool useLayoutRounding = layoutRoundingRadio.IsChecked == true;
            layoutRoot.SnapsToDevicePixels = usePixelSnapping;
            layoutRoot.UseLayoutRounding = useLayoutRounding;
        }

        private void OnStripeContentCheckChanged(object sender, RoutedEventArgs e)
        {
            SetStripe();
        }

        private void SetStripe()
        {
            string key = (solidStripRadio.IsChecked == true) ? "blackStripe" : "imageStripe";
            this.Resources["stripe"] = this.Resources[key];
        }
    }
}
