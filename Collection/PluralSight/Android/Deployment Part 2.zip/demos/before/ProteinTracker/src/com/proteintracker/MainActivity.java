package com.proteintracker;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	final private int RESET_DIALOG = 0;

	private OnClickListener helpButtonListener = new OnClickListener() {
		@Override
		public void onClick(View arg0) {
		}
	};
	private OnClickListener resetButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			showDialog(RESET_DIALOG);
		}
	};

	protected android.app.Dialog onCreateDialog(int id) {
		switch (id) {
		case RESET_DIALOG:
			dialog = new Dialog(this);
			dialog.setContentView(R.layout.custom_dialog);
			dialog.setTitle("Custom Dialog");
			
			TextView textView = (TextView)dialog.findViewById(R.id.textView1);
			textView.setText("Hello");
			return dialog;
		}
		
		return null;
	};
	
	private Dialog dialog = null;
	private Handler handler = new Handler()
	{
		public void handleMessage(android.os.Message msg) 
		{
			dialog.dismiss();
		}
	};
	

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Button button = (Button) findViewById(R.id.button1);
		button.setOnClickListener(helpButtonListener);

		Button resetButton = (Button) findViewById(R.id.resetButton);
		resetButton.setOnClickListener(resetButtonListener);

		registerForContextMenu(button);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.settingsMenuItem:
			Intent intent = new Intent(MainActivity.this,
					MainPreferenceActivity.class);
			startActivity(intent);

		case R.id.indexMenuItem:
			Toast.makeText(this, "Index was clicked!", 5).show();

		default:
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.contextSettingsMenuItem:
			Intent intent = new Intent(MainActivity.this,
					MainPreferenceActivity.class);
			startActivity(intent);
		default:
		}

		return super.onContextItemSelected(item);
	}
}