package com.proteintracker;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings.Secure;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.vending.licensing.AESObfuscator;
import com.android.vending.licensing.LicenseChecker;
import com.android.vending.licensing.LicenseCheckerCallback;
import com.android.vending.licensing.ServerManagedPolicy;

public class MainActivity extends Activity {

	private static final byte[] SALT = new byte[] { -20, 31, 20, -74, 33, -100,
			32, -90, -58, 104, 15, -10, 72, -34, 105, 31, 62, 35, -12, 97 };

	private static final String GOOGLE_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAphN6M1CTAcB6R2cFhklh/HZVjj95zQKfyfqp49ZlRZEMT/zvQz3PptxzGwS5SgYDnQoHC3+DZ7hFvkYmUg9DyMyp6+L6Ahknw0pKSnB01q9xL5DqjPUQXj/0vY+zzH75yycih8Q2fnmqrPR592h4KxpQBEmBtw14Ch2J8flLTRPXwrMRhmGXz0+qoqSyXPAXdcX4yiyMBZx7s4lkDJWrRTQtVH5j9L038zsEAAKLiuGc1KhUuJtAchV6ZZ6fd2J6nBNrcDoBtq8P7i9bA+t0NB3SbIK2Ed4o7OXCdu31vIXP5ASChGCwl1+i+XuSh82UlXkq6QCb6mW2OLeSOItxxQIDAQAB";; 

	final private int RESET_DIALOG = 0;

	private OnClickListener helpButtonListener = new OnClickListener() {
		@Override
		public void onClick(View arg0) {
			licenseChecker.checkAccess(licenseCheckerCallback);
		}
	};
	private OnClickListener resetButtonListener = new OnClickListener() {

		@Override
		public void onClick(View arg0) {
			showDialog(RESET_DIALOG);
		}
	};

	protected android.app.Dialog onCreateDialog(int id) {
		switch (id) {
		case RESET_DIALOG:
			dialog = new Dialog(this);
			dialog.setContentView(R.layout.custom_dialog);
			dialog.setTitle("Custom Dialog");

			TextView textView = (TextView) dialog.findViewById(R.id.textView1);
			textView.setText("Hello");
			return dialog;
		}

		return null;
	};

	private Dialog dialog = null;
	private Handler handler = new Handler() {
		// public void handleMessage(android.os.Message msg)
		// {
		// dialog.dismiss();
		// }
	};

	private LicenseCheckerCallback licenseCheckerCallback;
	private LicenseChecker licenseChecker;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		Button button = (Button) findViewById(R.id.button1);
		button.setOnClickListener(helpButtonListener);

		Button resetButton = (Button) findViewById(R.id.resetButton);
		resetButton.setOnClickListener(resetButtonListener);

		registerForContextMenu(button);

		licenseCheckerCallback = new LicenseCheckerCallbackImpl();
		
		String deviceId = Secure.getString(this.getContentResolver(), Secure.ANDROID_ID);
		
		licenseChecker = new LicenseChecker(getApplicationContext(),
				new ServerManagedPolicy(getApplicationContext(),
						new AESObfuscator(SALT, getPackageName(), deviceId)),
				GOOGLE_KEY);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.settingsMenuItem:
			Intent intent = new Intent(MainActivity.this,
					MainPreferenceActivity.class);
			startActivity(intent);

		case R.id.indexMenuItem:
			Toast.makeText(this, "Index was clicked!", 5).show();

		default:
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.contextSettingsMenuItem:
			Intent intent = new Intent(MainActivity.this,
					MainPreferenceActivity.class);
			startActivity(intent);
		default:
		}

		return super.onContextItemSelected(item);
	}

	private class LicenseCheckerCallbackImpl implements LicenseCheckerCallback {

		@Override
		public void allow() {
			if (isFinishing())
				return;

			ShowMessage("License check OK!");
		}

		@Override
		public void dontAllow() {
			if (isFinishing())
				return;

			ShowMessage("License check FAILED!");
		}

		@Override
		public void applicationError(ApplicationErrorCode errorCode) {
			// TODO Auto-generated method stub

		}

	}

	private void ShowMessage(final String message) {
		handler.post(new Runnable() {

			@Override
			public void run() {
				Toast.makeText(MainActivity.this, message, 5).show();
			}
		});
	}
}