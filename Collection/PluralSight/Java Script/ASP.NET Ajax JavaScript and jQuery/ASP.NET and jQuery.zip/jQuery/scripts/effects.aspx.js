﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("a").mouseover(function() { $(this).addClass("highlight"); })
          .mouseout(function() { $(this).removeClass("highlight"); })
          .filter(":even").addClass("evenrow").end()
          .filter(":odd").addClass("oddrow").end()
          .filter(":contains('Scott')").attr("href",
            "http://www.pluralsight.com/main/instructor.aspx?name=scott-allen");

    $(".section").hide();

    $("#menu > p").click(function() {
        $(this).next().slideToggle("slow");
    });

});