﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {

    $("a:even").addClass("evenrow");
    $("a:odd").addClass("oddrow");

    $("a:contains('Scott')").attr("href",
       "http://www.pluralsight.com/main/instructor.aspx?name=scott-allen");
});