﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("a").click(getInstructorInfo)
          .mouseover(function() { $(this).addClass("highlight"); })
          .mouseout(function() { $(this).removeClass("highlight"); })
          .filter(":even").addClass("evenrow").end()
          .filter(":odd").addClass("oddrow");

    $(".section").hide();

    $("#menu").resizable();
    $("#menu > p").click(function() {
        var section = $(this).next();
        if (section.css("display") == "none") {
            section.slideDown("slow");
        }
        else {
            section.hide("explode", { pieces: 4 }, 1000);
        }
    });

});

function getInstructorInfo(event) {
    var instructorName = $(this).text();
    $("#detail").load('getInstructorInfo.ashx?instructor=' 
                       + instructorName);
    return true;
}