﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("a").click(getInstructorInfo)
          .mouseover(function() { $(this).addClass("highlight"); })
          .mouseout(function() { $(this).removeClass("highlight"); })
          .filter(":even").addClass("evenrow").end()
          .filter(":odd").addClass("oddrow");

    $(".section").hide();

    $("#menu > p").click(function() {
        $(this).next().slideToggle("slow");
    });

    $("#log").ajaxComplete(function(event, xhr, options) { $(this).append("complete <br/>"); })
             .ajaxError(function(event, xhr, options) { $(this).append("error <br/>"); })
             .ajaxSend(function(event, xhr, options) { $(this).append("send <br/>"); })
             .ajaxStart(function(event, xhr, options) { $(this).append("start <br/>"); })
             .ajaxStop(function(event, xhr, options) { $(this).append("stop <br/>"); })
             .ajaxSuccess(function(event, xhr, options) { $(this).append("success <br/>"); });
});



function getInstructorInfo(event) {
    var instructorName = $(this).text();
    $.ajax(
        {
            type: "POST",                                           // POST by default
            url: "InstructorInfoService.svc/GetInstructorInfo",     // svc endpoint
            data: '{ "name": "' + instructorName + '" }',           // json format
            timeout: 5000,                                          // ms
            contentType: "application/json",                        // accept header
            dataFilter: parseJson,
            success: onSuccess                
        });
}

function parseJson(data, type) {
    var dateRegEx = new RegExp('(^|[^\\\\])\\"\\\\/Date\\((-?[0-9]+)(?:[a-zA-Z]|(?:\\+|-)[0-9]{4})?\\)\\\\/\\"', 'g');
    var exp = data.replace(dateRegEx, "$1new Date($2)");
    var result = eval('(' + exp + ')');
    return result.d;
}

function onSuccess(instructor) {
    debugger;  
    var html = "<ul>";    
    for (var i in instructor.Traits) {
        html += "<li>" + instructor.Traits[i] + "</li>";
    }
    html += "</ul>";
    html += "<br/>Birhdate: " + instructor.BirthDate;
    $("#detail").html(html);
}