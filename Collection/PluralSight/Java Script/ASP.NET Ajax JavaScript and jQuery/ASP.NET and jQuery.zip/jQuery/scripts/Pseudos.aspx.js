﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("#menu").width(250);
    $("#menu > p").css("background-color", "#CCCC99");
    $("a").css("display", "block");
    $("a:even").css("background-color", "#EEBBEE");
    $("a:odd").css("background-color", "#CCBBCC");
    $("a:contains('Scott')").wrap("<em><b></b></em>");
    $("div:not('#menu')").css("padding-left", "10px");
});