﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

function pageLoad() {

    $('#header > b').click(function() {
        alert(this.innerHTML);
    });
    $('.content').mouseover(function() {
        this.innerHTML = 'Content replaced';
    });
}
