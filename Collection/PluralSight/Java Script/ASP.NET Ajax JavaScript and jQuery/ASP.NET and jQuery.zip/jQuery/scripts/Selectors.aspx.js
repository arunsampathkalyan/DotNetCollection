﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("#menu").width(250);
    $("#menu > p").css("background-color", "#CCCC99");
    $("a").css("display", "block");
});