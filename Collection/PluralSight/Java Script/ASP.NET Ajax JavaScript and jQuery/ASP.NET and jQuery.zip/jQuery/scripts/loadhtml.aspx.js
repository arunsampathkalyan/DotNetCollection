﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("a").click(getInstructorInfo)
          .mouseover(function() { $(this).addClass("highlight"); })
          .mouseout(function() { $(this).removeClass("highlight"); })          
          .filter(":even").addClass("evenrow").end()
          .filter(":odd").addClass("oddrow");

    $(".section").hide();

    $("#menu > p").click(function() {
        $(this).next().slideToggle("slow");
    });
});

function getInstructorInfo(event) {
    var instructorName = $(this).text();
    $("#detail").load("getInstructorInfo.ashx",
                        { "instructor": instructorName });
    return true;
}