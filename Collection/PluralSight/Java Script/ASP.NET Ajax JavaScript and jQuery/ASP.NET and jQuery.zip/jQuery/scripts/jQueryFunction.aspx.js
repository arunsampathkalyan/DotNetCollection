﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {

    $("<div>Hello, World</div>").appendTo(document.body);
    
    $("div").wrapInner("<h1></h1>");
});