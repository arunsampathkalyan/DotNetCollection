﻿/// <reference path="jquery-1.2.6-vsdoc.js" />

$(function() {
    $("a").click(getInstructorInfo)
          .mouseover(function() { $(this).addClass("highlight"); })
          .mouseout(function() { $(this).removeClass("highlight"); })
          .filter(":even").addClass("evenrow").end()
          .filter(":odd").addClass("oddrow");

    $(".section").hide();

    $("#menu > p").click(function() {
        $(this).next().slideToggle("slow");
    });

    $("#log").ajaxComplete(function(event, xhr, options) { $(this).append("complete <br/>"); })
             .ajaxError(function(event, xhr, options) { $(this).append("error <br/>"); })
             .ajaxSend(function(event, xhr, options) { $(this).append("send <br/>"); })
             .ajaxStart(function(event, xhr, options) { $(this).append("start <br/>"); })
             .ajaxStop(function(event, xhr, options) { $(this).append("stop <br/>"); })
             .ajaxSuccess(function(event, xhr, options) { $(this).append("success <br/>"); });
});



function getInstructorInfo(event) {

    var instructorName = $(this).text();
    $.ajax(
        {
            type: "POST",
            url: "getInstructorInfo.ashx",
            data: { "instructor": instructorName },
            timeout: 5000, // ms
            success: function(result) { $("#detail").html(result) },
            error: function(xhr, status, exception) {
                debugger;
                $("#detail").html(
                    "There was an error.<br/> " +
                    "Status: " + status + "<br/>" +
                    "XHR Status: " + xhr.statusText + "<br/>");
        }
    });
}



