﻿using System;
using System.Runtime.Serialization;

[DataContract]
public class Instructor
{
    [DataMember]
    public string Name { get; set; }

    [DataMember]
    public string[] Traits { get; set; }

    [DataMember]
    public DateTime BirthDate { get; set; }
}