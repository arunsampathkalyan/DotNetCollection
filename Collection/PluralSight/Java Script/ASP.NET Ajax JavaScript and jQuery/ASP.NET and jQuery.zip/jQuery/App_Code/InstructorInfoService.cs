﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public class InstructorInfoService
{
	[OperationContract]
	public Instructor GetInstructorInfo(string name)
	{       
        Instructor instructor = null;

        if (name == "Fritz")
        {
            instructor = new Instructor
            {
                Name = "Fritz",
                BirthDate = new DateTime(1979, 1, 1),
                Traits = new string[]
                {
                    "hails from Maine",
                    "long live the web!",
                    "avid cyclist"
                }
            };            
        }

         // ...

        return instructor;		
	}
}
