namespace NWMessaging.PropertySchema {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Property)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Property1", @"CustomerPONumber", @"TotalOrderAmount"})]
    public sealed class PropertySchema : Microsoft.BizTalk.TestTools.Schema.TestableSchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://NWMessaging.PropertySchema.PropertySchema"" targetNamespace=""http://NWMessaging.PropertySchema.PropertySchema"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo schema_type=""property"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Property1"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""38bf187a-ed4e-42fd-a36e-3212b0f7e916"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""CustomerPONumber"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""1b01036c-455f-493e-a804-241055937136"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""TotalOrderAmount"" type=""xs:double"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""27920f11-6b43-47f7-af64-2d58e5011cc8"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
</xs:schema>";
        
        public PropertySchema() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [3];
                _RootElements[0] = "Property1";
                _RootElements[1] = "CustomerPONumber";
                _RootElements[2] = "TotalOrderAmount";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"Property1",@"http://NWMessaging.PropertySchema.PropertySchema","string","System.String")]
    [PropertyGuidAttribute(@"38bf187a-ed4e-42fd-a36e-3212b0f7e916")]
    public sealed class Property1 : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"Property1", @"http://NWMessaging.PropertySchema.PropertySchema");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"CustomerPONumber",@"http://NWMessaging.PropertySchema.PropertySchema","string","System.String")]
    [PropertyGuidAttribute(@"1b01036c-455f-493e-a804-241055937136")]
    public sealed class CustomerPONumber : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"CustomerPONumber", @"http://NWMessaging.PropertySchema.PropertySchema");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"TotalOrderAmount",@"http://NWMessaging.PropertySchema.PropertySchema","double","System.Double")]
    [PropertyGuidAttribute(@"27920f11-6b43-47f7-af64-2d58e5011cc8")]
    public sealed class TotalOrderAmount : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"TotalOrderAmount", @"http://NWMessaging.PropertySchema.PropertySchema");
        
        private static double PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(double);
            }
        }
    }
}
