using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://www.pluralsight.com/samples/creditrating")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class CustomerRatingService : System.Web.Services.WebService
{
    public CustomerRatingService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public Rating RateCustomer (string customerid) {
        int rand = new Random().Next(1, 3);
        return (Rating)rand;
    }
    
}

public enum Rating
{
    Good=1,
    Fair=2,
    Poor=3
}
