using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;

namespace WFandWCFInterceptors
{
	public sealed partial class Workflow1: SequentialWorkflowActivity
	{
		public Workflow1()
		{
			InitializeComponent();
		}

        private int custNum;

        public int CustomerNumber
        {
            get { return custNum; }
            set { custNum = value; }
        }

        private void codeActivity1_ExecuteCode(object sender, EventArgs e)
        {
            Console.WriteLine("WF activity executing");
        }

        private void callWCFService_ExecuteCode(object sender, EventArgs e)
        {
            IBizTalkOrder channel = new
                ChannelFactory<IBizTalkOrder>("BTSSubmit"
                ).CreateChannel();

           
            StringReader reader = new StringReader(
                String.Format("<ns0:Order OrderID=\"100\" xmlns:ns0=\"http://BAMTPClient.Order\"><CustomerNumber>{0}</CustomerNumber></ns0:Order>", CustomerNumber));

            XmlReader xReader  = XmlReader.Create(reader);

            Message msg = Message.CreateMessage(MessageVersion.Default, "*", xReader);
            try
            {
                channel.SubmitMessage(msg);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                if(((IChannel)channel).State == CommunicationState.Opened)
                    ((IChannel)channel).Close();
            }
        }
	}

}
