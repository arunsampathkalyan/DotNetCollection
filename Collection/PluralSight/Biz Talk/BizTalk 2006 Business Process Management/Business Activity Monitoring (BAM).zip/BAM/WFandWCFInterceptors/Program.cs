#region Using directives

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Workflow.Runtime;
using System.Workflow.Runtime.Hosting;

#endregion

namespace WFandWCFInterceptors
{
    class Program
    {
        static void Main(string[] args)
        {
            using(WorkflowRuntime workflowRuntime = new WorkflowRuntime())
            {
                //add tracking service for interception
                Microsoft.BizTalk.Bam.Interceptors.Workflow.BamTrackingService
                    bamTracking = new Microsoft.BizTalk.Bam.Interceptors.Workflow.BamTrackingService(
                    "database=bamprimaryimport;integrated security=SSPI", 5000);
                workflowRuntime.AddService(bamTracking);


                AutoResetEvent waitHandle = new AutoResetEvent(false);
                workflowRuntime.WorkflowCompleted += delegate(object sender, WorkflowCompletedEventArgs e) {waitHandle.Set();};
                workflowRuntime.WorkflowTerminated += delegate(object sender, WorkflowTerminatedEventArgs e)
                {
                    Console.WriteLine(e.Exception.Message);
                    waitHandle.Set();
                };

                int customerNumber = new Random(DateTime.Now.Millisecond).Next(1, 10000);
                Dictionary<string, object> parms = new Dictionary<string, object>();
                parms.Add("CustomerNumber", customerNumber);

                WorkflowInstance instance = workflowRuntime.CreateWorkflow(typeof(WFandWCFInterceptors.Workflow1), parms);
                instance.Start();

                waitHandle.WaitOne();
                Console.WriteLine("Completed");
                Console.ReadLine();
            }
        }
    }
}
