using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.Bam.EventObservation;
using System.Threading;

namespace BAMClient
{
    class Program
    {
        static void Main(string[] args)
        {
            string cnn = 
                "database=biztalkmsgboxdb;integrated security=SSPI";
            string activityId = Guid.NewGuid().ToString();

            BufferedEventStream bes =
                new BufferedEventStream(cnn, 10);

            bes.BeginActivity("BAMDemo", activityId);

            bes.UpdateActivity("BAMDemo", activityId,
                "StartTime", DateTime.UtcNow);

            bes.UpdateActivity("BAMDemo", activityId,
                            "CheckPoint1", new Random().Next());

            string continuationTok = string.Concat(
                "new_", activityId);


            bes.EnableContinuation("BAMDemo", activityId,
                continuationTok);

            bes.EndActivity("BAMDemo", activityId);

            
            //next component
            bes.UpdateActivity("BAMDemo", continuationTok,
                "CheckPoint2", new Random().Next());

            bes.UpdateActivity("BAMDemo", continuationTok,
                "EndTime", DateTime.UtcNow);

            bes.EndActivity("BAMDemo", continuationTok);

            bes.Flush();

            



        }
    }
}
