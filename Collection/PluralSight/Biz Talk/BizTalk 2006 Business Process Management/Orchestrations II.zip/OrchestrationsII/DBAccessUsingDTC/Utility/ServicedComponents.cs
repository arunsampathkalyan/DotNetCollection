//---------------------------------------------------------------------
// File: ServicedComponents.cs
// 
// Summary: Data Access Layer classes for Orders and Customers 
//
// Sample: Atomic Transactions with COM+ Serviced Component in Orchestrations (BizTalk Server Sample)
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server 2006 SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Collections.Generic;
using System.EnterpriseServices;
using Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Utility;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Runtime.InteropServices;

[assembly: ApplicationName("DBAccessUsingDTCApp")]
[assembly: ApplicationActivation(ActivationOption.Library)]
[assembly: ApplicationAccessControl(false)]

namespace Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Utility
{
    [Transaction(TransactionOption.Required)]
    [ComVisible(true)]
    public class CustomersDAL : ServicedComponent
    {

        /// <summary>
        /// Insert Customers
        /// </summary>        
        /// <param name="customerID">Customer ID</param>
        /// <param name="customerName">Customer Name</param>
        [AutoComplete(true)]
        public void Insert(string customerID, string customerName)
        {
            IConfigurationSource source = ConfigureSourceHelper.CreateSSOConfigurationStore(customerDBName);
            Database customerDB = null;
            DatabaseProviderFactory factory = null;
            DbCommand insertCmd = null;
            try
            {
                factory = new DatabaseProviderFactory(source);
                customerDB = factory.Create(customerDBName);
                insertCmd = customerDB.GetSqlStringCommand("INSERT CUSTOMERS (CustomerID, CustomerName) VALUES (@CustomerID, @CustomerName)");
                customerDB.AddInParameter(insertCmd, "@CustomerID", DbType.String, customerID);
                customerDB.AddInParameter(insertCmd, "@CustomerName", DbType.String, customerName);
                customerDB.ExecuteNonQuery(insertCmd);
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message);
                throw;
            }
            finally
            {
                if (null != insertCmd)
                    insertCmd.Dispose();
            }
        }
        private string customerDBName = "DBAccessUsingDTCApp.CustomerDB";
    }

    [Transaction(TransactionOption.Required)]
    [ComVisible(true)]
    public class OrdersDAL : ServicedComponent
    {

        /// <summary>
        /// Insert Orders
        /// </summary>        
        /// <param name="orderID">Order ID</param>
        /// <param name="customerID">Customer ID</param>
        /// <param name="customerID">Order Type</param>        
        [AutoComplete(true)]
        public void Insert(string orderID, string customerID, string orderType)
        {
            IConfigurationSource source = ConfigureSourceHelper.CreateSSOConfigurationStore(orderDBName);
            Database orderDB = null;
            DatabaseProviderFactory factory = null;
            DbCommand insertCmd = null;
            try
            {
                source = ConfigureSourceHelper.CreateSSOConfigurationStore(orderDBName);
                factory = new DatabaseProviderFactory(source);
                orderDB = factory.Create(orderDBName);
                insertCmd = orderDB.GetSqlStringCommand("INSERT ORDERS (OrderID, CustomerID, OrderType) VALUES (@OrderID, @CustomerID, @OrderType)");
                orderDB.AddInParameter(insertCmd, "@OrderID", DbType.String, orderID);
                orderDB.AddInParameter(insertCmd, "@CustomerID", DbType.String, customerID);
                orderDB.AddInParameter(insertCmd, "@OrderType", DbType.String, orderType);
                orderDB.ExecuteNonQuery(insertCmd);
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message);
                throw;
            }
            finally
            {
                if (null != insertCmd)
                    insertCmd.Dispose();
            }
        }
        private string orderDBName = "DBAccessUsingDTCApp.OrderDB";
    }
}
