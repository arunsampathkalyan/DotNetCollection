//---------------------------------------------------------------------
// File: ConfigureSourceHelper.cs
// 
// Summary: ConfigureSourceHelper class for creating a configuration source object including the configuration data populated from SSO
//
// Sample: Atomic Transactions with COM+ Serviced Component in Orchestrations (BizTalk Server Sample) 
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server 2006 SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;

using System.Xml.Serialization;
using System.IO;

namespace Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Utility
{
    public static class ConfigureSourceHelper
    {
        /// <summary>
        /// It creates a configuration source object for the configration data in SSO
        /// </summary>        
        /// <param name="appName">The name of the affiliate application to represent the configuration container to access</param>
        /// <returns>
        ///  The configuration source object containing connectionStrings section popuplted from SSO.
        /// </returns>
        public static IConfigurationSource CreateSSOConfigurationStore(string appName)
        {
            ConnectionStringSettings conStrSettings = null;
            ConnectionStringsSection connStrSection = null;
            try
            {
                if (null == dictionaryConfigSource)
                {
                    dictionaryConfigSource = new DictionaryConfigurationSource();
                }
                if (!dictionaryConfigSource.Contains("connectionStrings"))
                {
                    dictionaryConfigSource.Add("connectionStrings", new ConnectionStringsSection());
                }
                connStrSection = (ConnectionStringsSection)dictionaryConfigSource.GetSection("connectionStrings");
                System.Diagnostics.Trace.Assert(null != connStrSection);

                conStrSettings = connStrSection.ConnectionStrings[appName];
                if (null == conStrSettings)
                {
                    conStrSettings = new ConnectionStringSettings();
                    conStrSettings.Name = appName;
                    connStrSection.ConnectionStrings.Add(conStrSettings);
                }
                conStrSettings.ProviderName = SSOConfigHelper.Read(appName, "providerName");
                conStrSettings.ConnectionString = SSOConfigHelper.Read(appName, "connectionString");
            }
            catch (Exception e)
            {
                System.Diagnostics.Trace.WriteLine(e.Message);
                throw;
            }
            return dictionaryConfigSource;
        }
        private static DictionaryConfigurationSource dictionaryConfigSource = null;
    }
}
