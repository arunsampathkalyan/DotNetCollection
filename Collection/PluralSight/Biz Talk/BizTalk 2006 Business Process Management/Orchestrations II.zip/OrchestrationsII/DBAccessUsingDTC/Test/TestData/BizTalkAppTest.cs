//---------------------------------------------------------------------
// File: BizTalkAppTest.cs
// 
// Summary: BizTalkAppTest class for testing the orchestrations containing the atomic shapes
//
// Sample: Atomic Transactions with COM+ Serviced Component in Orchestrations (BizTalk Server Sample)  
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server 2006 SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Services.BizTalkApplicationFramework.BizUnit;

namespace Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Test
{

    [TestClass]
    public class BizTalkAppTest
    {
        /// <summary>
        /// It runs a valid test for the orchestration, OneAtomicTx, which contains one atomic shape with two insert operations.
        /// </summary>  
        [TestMethod]
        public void OneAtomicTxValidTest()
        {
            BizUnit bizUnit = new BizUnit(@"..\..\..\Test\TestCases\OneAtomicTxValidTest.xml");
            bizUnit.RunTest();
        }

        /// <summary>
        /// It runs an invalid test for the orchestration, OneAtomicTx, which contains one atomic shape with two insert operations.
        /// The second insert operation is expected to fail due to the violation of PRIMARY KEY constraint, and then it is rolled back.
        /// </summary> 
        [TestMethod]
        [ExpectedException(typeof(System.IndexOutOfRangeException),
            "The service instance must be suspended because the serviced compnent tried to insert a recored having a duplicate public key")]
        public void OneAtomicTxInvalidTest()
        {
            BizUnit bizUnit = new BizUnit(@"..\..\..\Test\TestCases\OneAtomicTxInvalidTest.xml");
            bizUnit.RunTest();
        }

        /// <summary>
        /// It runs an invalid test for the orchestration, TwoAtomicTx, which contains two atomic shapes: one insert operation per an atomic shape.
        /// The second insert operation is expected to fail due to the violation of PRIMARY KEY constraint, but it isn't rolled back.
        /// </summary> 
        [TestMethod]
        public void TwoAtomicTxInvalidTest()
        {
            BizUnit bizUnit = new BizUnit(@"..\..\..\Test\TestCases\TwoAtomicTxInvalidTest.xml");
            bizUnit.RunTest();
        }
    }
}
