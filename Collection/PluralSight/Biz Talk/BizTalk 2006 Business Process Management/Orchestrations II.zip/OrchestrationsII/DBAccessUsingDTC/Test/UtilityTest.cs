//---------------------------------------------------------------------
// File: SSOConfigHelperTest.cs
// 
// Summary: SSOConfigHelperTest class for testing SSOConfigHelper class
//
// Sample: SSO as Configuration Store (BizTalk Server Sample)   
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server 2006 SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Utility;
using Microsoft.Practices.EnterpriseLibrary.Common.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace Microsoft.Samples.BizTalk.Orchestrations.DBAccessUsingDTC.Test
{
    [TestClass]
    public class UtilityTest
    {

        /// <summary>
        /// It tests the database connection to the sample databases.
        /// </summary>  
        [TestMethod]
        public void DBConnectTest()
        {
            IConfigurationSource source = ConfigureSourceHelper.CreateSSOConfigurationStore(customerDBName);            

            DatabaseProviderFactory factory = new DatabaseProviderFactory(source);
            Database dataBase = factory.Create(customerDBName);
            dataBase.CreateConnection().Open();
            dataBase.CreateConnection().Close();
  
            source = ConfigureSourceHelper.CreateSSOConfigurationStore(orderDBName);
            factory = new DatabaseProviderFactory(source);
            dataBase = factory.Create(orderDBName);
            dataBase.CreateConnection().Open();
            dataBase.CreateConnection().Close();
        }

        /// <summary>
        /// It tests valid database insert operations to the sample databases.
        /// </summary> 
        [TestMethod]
        public void ComSvcInsertValidTest()
        {        
            // Initialize Test 
            DatabaseCleanup();

            // Run Test
            CustomersDAL customersDAL = new CustomersDAL();
            OrdersDAL ordersDAL = new OrdersDAL();
            customersDAL.Insert("1", "Young Jun Hong");
            ordersDAL.Insert("1", "1", "BASIC");
        }

        /// <summary>
        /// It tests invalid database insert operations to the sample database.
        /// </summary>         
        [TestMethod]
        [ExpectedException(typeof(System.Data.SqlClient.SqlException))]
        public void CompSvcInvalidTest()
        {
            // Initialize Test 
            DatabaseCleanup();

            // Run Test
            CustomersDAL customersDAL = new CustomersDAL();
            OrdersDAL ordersDAL = new OrdersDAL();

            customersDAL.Insert("1", "Young Jun Hong");
            ordersDAL.Insert("1", "1", "BASIC");
            ordersDAL.Insert("1", "1", "BASIC"); // Tries to insert a recored having a duplicate primary key.
        }

        /// <summary>
        /// It cleans up the sample databases.
        /// </summary> 
        private void DatabaseCleanup()
        {
            IConfigurationSource source = ConfigureSourceHelper.CreateSSOConfigurationStore(customerDBName);
            DatabaseProviderFactory factory = new DatabaseProviderFactory(source);
            Database dataBase = factory.Create(customerDBName);
            dataBase.ExecuteNonQuery(dataBase.GetSqlStringCommand("DELETE CUSTOMERS"));

            source = ConfigureSourceHelper.CreateSSOConfigurationStore(orderDBName);
            dataBase = factory.Create(orderDBName);
            dataBase.ExecuteNonQuery(dataBase.GetSqlStringCommand("DELETE ORDERS"));
        }
        private string customerDBName = "DBAccessUsingDTCApp.CustomerDB";
        private string orderDBName = "DBAccessUsingDTCApp.OrderDB";
    }
}
