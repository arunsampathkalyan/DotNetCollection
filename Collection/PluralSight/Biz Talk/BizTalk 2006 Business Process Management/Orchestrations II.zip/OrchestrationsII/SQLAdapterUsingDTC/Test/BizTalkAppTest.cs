//---------------------------------------------------------------------
// File: BizTalkAppTest.cs
// 
// Summary: BizTalkAppTest class for testing the orchestrations demonstrating how to use a transactional adapter, SQL Adapter, in an atomic scope
//
// Sample: Using SQL Adapter with Atomic Transactions in Orchestrations (BizTalk Server Sample)
//
//---------------------------------------------------------------------
// This file is part of the Microsoft BizTalk Server 2006 SDK
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// This source code is intended only as a supplement to Microsoft BizTalk
// Server 2006 release and/or on-line documentation. See these other
// materials for detailed information regarding Microsoft code samples.
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
// PURPOSE.
//---------------------------------------------------------------------

using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Services.BizTalkApplicationFramework.BizUnit;

namespace Microsoft.Samples.BizTalk.Orchestrations.SQLAdapterUsingDTC.Test
{
    [TestClass]
    public class BizTalkAppTest
    {
        /// <summary>
        /// It runs a valid test for the SQLAdapterAtomicTx orchestration.
        /// </summary>  
        [TestMethod]
        public void SqlAdapterValidTest()
        {
            BizUnit bizUnit = new BizUnit(@"..\..\..\Test\TestCases\SQLAdapterValidTest.xml");
            bizUnit.RunTest();
        }
        /// <summary>
        /// It runs an invalid test for the SQLAdapterAtomicTx orchestration. 
        /// The order insertion operation through the SQL Adapter fails due to the violation of PRIMARY KEY constraint, and the first insert operation is rolled back.
        /// </summary>  
        [TestMethod]
        [ExpectedException(typeof(System.IndexOutOfRangeException),
            "The service instance must be suspended because the serviced compnent tried to insert a recored having a duplicate public key")]
        public void SqlAdapterInvalidTest()
        {
            BizUnit bizUnit = new BizUnit(@"..\..\..\Test\TestCases\SQLAdapterInvalidTest.xml");
            bizUnit.RunTest();
        }
    }
}
