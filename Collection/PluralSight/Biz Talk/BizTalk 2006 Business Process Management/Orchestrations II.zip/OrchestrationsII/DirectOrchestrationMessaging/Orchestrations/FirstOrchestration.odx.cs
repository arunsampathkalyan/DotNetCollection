
#pragma warning disable 162

namespace Orchestrations
{

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SharedSend",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_PurchaseOrder), 
            typeof(Orchestrations.__messagetype_Schemas_Invoice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class SharedPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public SharedPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public SharedPortType(SharedPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            SharedPortType p = new SharedPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo SharedSend = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SharedSend",
            System.Web.Services.Description.OperationFlow.RequestResponse,
            typeof(SharedPortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            typeof(__messagetype_Schemas_Invoice),
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "SharedSend" ] = SharedSend;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_ShippingAdvice__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.ShippingAdvice _schema = new Schemas.ShippingAdvice();

        public __Schemas_ShippingAdvice__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.ShippingAdvice",
        new System.Type[]{
            typeof(Schemas.ShippingAdvice)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_ShippingAdvice__)
        },
        0,
        @"http://Schemas.ShippingAdvice#Shipping"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_ShippingAdvice : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_ShippingAdvice__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_ShippingAdvice__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_ShippingAdvice(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_PurchaseOrder)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class InitiatePortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public InitiatePortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public InitiatePortType(InitiatePortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            InitiatePortType p = new InitiatePortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(InitiatePortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SendInvoiceOut",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_Invoice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SendShipNoticeOut",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_ShippingAdvice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "SendPOReport",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_PurchaseOrder)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class ReportPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public ReportPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public ReportPortType(ReportPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            ReportPortType p = new ReportPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo SendInvoiceOut = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SendInvoiceOut",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(ReportPortType),
            typeof(__messagetype_Schemas_Invoice),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public Microsoft.XLANGs.Core.OperationInfo SendShipNoticeOut = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SendShipNoticeOut",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(ReportPortType),
            typeof(__messagetype_Schemas_ShippingAdvice),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public Microsoft.XLANGs.Core.OperationInfo SendPOReport = new Microsoft.XLANGs.Core.OperationInfo
        (
            "SendPOReport",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(ReportPortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "SendInvoiceOut" ] = SendInvoiceOut;
                h[ "SendShipNoticeOut" ] = SendShipNoticeOut;
                h[ "SendPOReport" ] = SendPOReport;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_ShippingAdvice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class ShippingPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public ShippingPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public ShippingPortType(ShippingPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            ShippingPortType p = new ShippingPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(ShippingPortType),
            typeof(__messagetype_Schemas_ShippingAdvice),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_PurchaseOrder)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class DirectBindMessageBoxSendPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public DirectBindMessageBoxSendPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public DirectBindMessageBoxSendPortType(DirectBindMessageBoxSendPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            DirectBindMessageBoxSendPortType p = new DirectBindMessageBoxSendPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(DirectBindMessageBoxSendPortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }
    [Microsoft.XLANGs.BaseTypes.CorrelationTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        new string[] {
            "Schemas.OrderID"
        }
    )]
    sealed internal class OrderIDCorrelationType : Microsoft.XLANGs.Core.CorrelationType
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        private static Microsoft.XLANGs.BaseTypes.PropertyBase[] _properties = new Microsoft.XLANGs.BaseTypes.PropertyBase[] {
            new Schemas.OrderID()
         };
        public override Microsoft.XLANGs.BaseTypes.PropertyBase[] Properties { get { return _properties; } }
        public static Microsoft.XLANGs.BaseTypes.PropertyBase[] PropertiesList { get { return _properties; } }
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(Orchestrations.__messagetype_Schemas_PurchaseOrder)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class DirectBindMessagePortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public DirectBindMessagePortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public DirectBindMessagePortType(DirectBindMessagePortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            DirectBindMessagePortType p = new DirectBindMessagePortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(DirectBindMessagePortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }
    //#line 440 "D:\demos\orchestrationsII\DirectOrchestrationMessaging\Orchestrations\FirstOrchestration.odx"
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        0, "InitiatePort", "Operation_1", -1, -1, true
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(Orchestrations.InitiatePortType),
            typeof(Orchestrations.SharedPortType),
            typeof(Orchestrations.ReportPortType),
            typeof(Orchestrations.ShippingPortType),
            typeof(Orchestrations.DirectBindMessageBoxSendPortType)
        },
        new System.String[] {
            "InitiatePort",
            "DirectSharedPort",
            "ReportPort",
            "ShippingReceivePort",
            "DirectBindMessageBoxSendPort"
        },
        new System.Type[] {
            null,
            null,
            null,
            null,
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eNone
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class FirstOrchestration : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = false;
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eHasRequestResponse
,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy()
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(FirstOrchestration));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return true; } }

        internal bool IsExeced = false;

        static FirstOrchestration()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1)
            };

            _Locks = 0;
            _rootContext = new __FirstOrchestration_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        public FirstOrchestration(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "FirstOrchestration", tracker)
        {
            ConstructorHelper();
        }

        public FirstOrchestration(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent)
            : base(callIndex, instanceId, parent, "FirstOrchestration")
        {
            ConstructorHelper();
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>efa2b458-023c-4999-afb7-acc44511272f</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>2bd5bd7e-0c51-49d0-9ebb-4f72f820bb91</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_PO</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>b112f2f4-2b91-4181-9575-7e2222581049</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_POToDirectPort</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>7dbee708-fe1e-4255-b932-b4efd4fd0fc5</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_InvoiceFromDirectPort</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>e71c2769-aeb8-4dce-a08a-f55685801ccd</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_InvoiceOut</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>DelayShape</shapeType>      <ShapeID>db951977-b335-45a7-be6d-a21130c3e232</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Delay_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ExecShape</shapeType>      <ShapeID>8c67e6f5-b9bf-4d4e-89c3-be62221b271b</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>StartThirdOrchestration</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>ParameterShape</shapeType>      <ShapeID>5d20a873-66a5-4222-b8a8-62ff67a846a4</ShapeID>      <ParentLink>InvokeStatement_Parameter</ParentLink>                <shapeText>OrderCorrelation</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ParameterShape</shapeType>      <ShapeID>7c6f3ec5-34d4-4f4f-8923-62f43c14357b</ShapeID>      <ParentLink>InvokeStatement_Parameter</ParentLink>                <shapeText>InvoiceMessage</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ParameterShape</shapeType>      <ShapeID>96e8f973-7d8f-4b3f-87d7-57a350e210d6</ShapeID>      <ParentLink>InvokeStatement_Parameter</ParentLink>                <shapeText>ShippingReceivePort</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>DelayShape</shapeType>      <ShapeID>4d0c284d-a010-41c1-a892-067140da716a</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Delay_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>de58ad53-8f84-41a8-9675-a19745afc7f5</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_ShipNotice</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>7c15c356-dc7f-4967-aa8a-7909bab9a38a</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_ShipNoticeReport</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>037b5cd5-65b0-4459-9a95-6dd3105316fa</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_POToThirdOrchestration</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'FirstOrchestration'</ActionName><IsAtomic>0</IsAtomic><Line>440</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
</TrkMetadata>

<TrkMetadata>
<Line>459</Line><Position>22</Position><ShapeID>'2bd5bd7e-0c51-49d0-9ebb-4f72f820bb91'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>461</Line><Position>13</Position><ShapeID>'b112f2f4-2b91-4181-9575-7e2222581049'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>463</Line><Position>13</Position><ShapeID>'7dbee708-fe1e-4255-b932-b4efd4fd0fc5'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>465</Line><Position>13</Position><ShapeID>'e71c2769-aeb8-4dce-a08a-f55685801ccd'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>467</Line><Position>13</Position><ShapeID>'db951977-b335-45a7-be6d-a21130c3e232'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>469</Line><Position>52</Position><ShapeID>'8c67e6f5-b9bf-4d4e-89c3-be62221b271b'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>In</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>471</Line><Position>13</Position><ShapeID>'4d0c284d-a010-41c1-a892-067140da716a'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>473</Line><Position>13</Position><ShapeID>'de58ad53-8f84-41a8-9675-a19745afc7f5'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.ShippingAdvice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>475</Line><Position>13</Position><ShapeID>'7c15c356-dc7f-4967-aa8a-7909bab9a38a'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.ShippingAdvice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>477</Line><Position>13</Position><ShapeID>'037b5cd5-65b0-4459-9a95-6dd3105316fa'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='1f9cafdc-9606-4e76-91b8-7de2cac8af12' LowerBound='1.1' HigherBound='93.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='Orchestrations' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='PortType' OID='3cc6d809-17f1-4b93-8f8e-0b2293cabb6a' ParentLink='Module_PortType' LowerBound='4.1' HigherBound='11.1'>
            <om:Property Name='Synchronous' Value='True' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='SharedPortType' />
            <om:Property Name='Signal' Value='True' />
            <om:Element Type='OperationDeclaration' OID='9f6e87b8-4d37-40b2-9a7d-04173cd8bd41' ParentLink='PortType_OperationDeclaration' LowerBound='6.1' HigherBound='10.1'>
                <om:Property Name='OperationType' Value='RequestResponse' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SharedSend' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='e031a5ee-635a-4035-a2db-3a5520ed91f9' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='8.13' HigherBound='8.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='MessageRef' OID='e5465a79-b744-4c93-a136-4a11bf9a70bf' ParentLink='OperationDeclaration_ResponseMessageRef' LowerBound='8.36' HigherBound='8.51'>
                    <om:Property Name='Ref' Value='Schemas.Invoice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Response' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='9a294089-1761-4e7d-b80b-2efabae7fc2c' ParentLink='Module_PortType' LowerBound='11.1' HigherBound='18.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='InitiatePortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='927290e1-c972-43b4-844b-d5281f649e6a' ParentLink='PortType_OperationDeclaration' LowerBound='13.1' HigherBound='17.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='3234a6ef-3208-4ac0-aadb-9784d3de2c1d' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='15.13' HigherBound='15.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='116044d5-f346-4ba7-bff8-a5c45647e10c' ParentLink='Module_PortType' LowerBound='18.1' HigherBound='33.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='ReportPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='644ddf93-202e-4c09-bea0-9374bf120e5e' ParentLink='PortType_OperationDeclaration' LowerBound='20.1' HigherBound='24.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SendInvoiceOut' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='8015b5df-8e8b-4a8e-adba-4dba6babe742' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='22.13' HigherBound='22.28'>
                    <om:Property Name='Ref' Value='Schemas.Invoice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='OperationDeclaration' OID='532f7069-6854-43fd-b162-51129dcab884' ParentLink='PortType_OperationDeclaration' LowerBound='24.1' HigherBound='28.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SendShipNoticeOut' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='30004c6b-51ff-41b2-87a4-faf0aab684bc' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='26.13' HigherBound='26.35'>
                    <om:Property Name='Ref' Value='Schemas.ShippingAdvice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
            <om:Element Type='OperationDeclaration' OID='ec3a53b9-e4a8-4bae-a59e-ab1b46cd9cc3' ParentLink='PortType_OperationDeclaration' LowerBound='28.1' HigherBound='32.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SendPOReport' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='MessageRef' OID='44f5e19b-ebad-4b7f-9d30-d486a9d32318' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='30.13' HigherBound='30.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='8c51ec56-a64b-4c35-a1f0-f37082d0f6ef' ParentLink='Module_PortType' LowerBound='33.1' HigherBound='40.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='ShippingPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='5da2b087-5dc0-44d6-a428-a41b0a844315' ParentLink='PortType_OperationDeclaration' LowerBound='35.1' HigherBound='39.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='41008a7c-241f-4ef9-bf38-de7f7c4cad78' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='37.13' HigherBound='37.35'>
                    <om:Property Name='Ref' Value='Schemas.ShippingAdvice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='78001ce5-3c62-4665-b7ee-d7020e9d0455' ParentLink='Module_PortType' LowerBound='40.1' HigherBound='47.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='DirectBindMessageBoxSendPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='9e7dac39-842d-4d56-b558-7fd6d7ab40d3' ParentLink='PortType_OperationDeclaration' LowerBound='42.1' HigherBound='46.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='de5f4c98-2877-4a5e-84b0-914b77b38a57' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='44.13' HigherBound='44.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='ServiceDeclaration' OID='df1503b0-c7df-4efe-a3c6-b10e35189279' ParentLink='Module_ServiceDeclaration' LowerBound='51.1' HigherBound='92.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='FirstOrchestration' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='CorrelationDeclaration' OID='196ce17b-1669-49b4-a1ef-b56f10d51329' ParentLink='ServiceDeclaration_CorrelationDeclaration' LowerBound='64.1' HigherBound='65.1'>
                <om:Property Name='Type' Value='Orchestrations.OrderIDCorrelationType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='OrderCorrelation' />
                <om:Property Name='Signal' Value='True' />
                <om:Element Type='StatementRef' OID='ab9ed9b4-d2ce-4681-a5d3-2c61f6987f9d' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='75.67' HigherBound='75.94'>
                    <om:Property Name='Initializes' Value='True' />
                    <om:Property Name='Ref' Value='7dbee708-fe1e-4255-b932-b4efd4fd0fc5' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_1' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
                <om:Element Type='StatementRef' OID='bbeaec0f-2dd5-4fa6-a652-b9271e4b17f2' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='89.72' HigherBound='89.88'>
                    <om:Property Name='Initializes' Value='False' />
                    <om:Property Name='Ref' Value='037b5cd5-65b0-4459-9a95-6dd3105316fa' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StatementRef_2' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='2647e5b0-acef-4d3a-8a9d-2f0b7a2a6d4f' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='65.1' HigherBound='66.1'>
                <om:Property Name='Type' Value='Schemas.PurchaseOrder' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='aab1b963-b476-42f7-b29c-1f8422d10c55' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='66.1' HigherBound='67.1'>
                <om:Property Name='Type' Value='Schemas.Invoice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InvoiceMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='e34a18c0-c3bb-4ae2-8dc3-18314bffc93d' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='67.1' HigherBound='68.1'>
                <om:Property Name='Type' Value='Schemas.ShippingAdvice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ShippingMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='ServiceBody' OID='efa2b458-023c-4999-afb7-acc44511272f' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='Receive' OID='2bd5bd7e-0c51-49d0-9ebb-4f72f820bb91' ParentLink='ServiceBody_Statement' LowerBound='70.1' HigherBound='72.1'>
                    <om:Property Name='Activate' Value='True' />
                    <om:Property Name='PortName' Value='InitiatePort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_PO' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='b112f2f4-2b91-4181-9575-7e2222581049' ParentLink='ServiceBody_Statement' LowerBound='72.1' HigherBound='74.1'>
                    <om:Property Name='PortName' Value='DirectSharedPort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='SharedSend' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_POToDirectPort' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Receive' OID='7dbee708-fe1e-4255-b932-b4efd4fd0fc5' ParentLink='ServiceBody_Statement' LowerBound='74.1' HigherBound='76.1'>
                    <om:Property Name='Activate' Value='False' />
                    <om:Property Name='PortName' Value='DirectSharedPort' />
                    <om:Property Name='MessageName' Value='InvoiceMessage' />
                    <om:Property Name='OperationName' Value='SharedSend' />
                    <om:Property Name='OperationMessageName' Value='Response' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_InvoiceFromDirectPort' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='e71c2769-aeb8-4dce-a08a-f55685801ccd' ParentLink='ServiceBody_Statement' LowerBound='76.1' HigherBound='78.1'>
                    <om:Property Name='PortName' Value='ReportPort' />
                    <om:Property Name='MessageName' Value='InvoiceMessage' />
                    <om:Property Name='OperationName' Value='SendInvoiceOut' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_InvoiceOut' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Delay' OID='db951977-b335-45a7-be6d-a21130c3e232' ParentLink='ServiceBody_Statement' LowerBound='78.1' HigherBound='80.1'>
                    <om:Property Name='Timeout' Value='new System.TimeSpan(0,0,30);' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Delay_1' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Exec' OID='8c67e6f5-b9bf-4d4e-89c3-be62221b271b' ParentLink='ServiceBody_Statement' LowerBound='80.1' HigherBound='82.1'>
                    <om:Property Name='Invokee' Value='Orchestrations.ThirdOrchestration' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='StartThirdOrchestration' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='Parameter' OID='5d20a873-66a5-4222-b8a8-62ff67a846a4' ParentLink='InvokeStatement_Parameter'>
                        <om:Property Name='Direction' Value='In' />
                        <om:Property Name='Name' Value='OrderCorrelation' />
                        <om:Property Name='Type' Value='Orchestrations.OrderIDCorrelationType' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                    <om:Element Type='Parameter' OID='7c6f3ec5-34d4-4f4f-8923-62f43c14357b' ParentLink='InvokeStatement_Parameter'>
                        <om:Property Name='Direction' Value='In' />
                        <om:Property Name='Name' Value='InvoiceMessage' />
                        <om:Property Name='Type' Value='Schemas.Invoice' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                    <om:Element Type='Parameter' OID='96e8f973-7d8f-4b3f-87d7-57a350e210d6' ParentLink='InvokeStatement_Parameter'>
                        <om:Property Name='Direction' Value='In' />
                        <om:Property Name='Name' Value='ShippingReceivePort' />
                        <om:Property Name='Type' Value='Orchestrations.ShippingPortType' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='Delay' OID='4d0c284d-a010-41c1-a892-067140da716a' ParentLink='ServiceBody_Statement' LowerBound='82.1' HigherBound='84.1'>
                    <om:Property Name='Timeout' Value='new System.TimeSpan(0,0,30);' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Delay_2' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Receive' OID='de58ad53-8f84-41a8-9675-a19745afc7f5' ParentLink='ServiceBody_Statement' LowerBound='84.1' HigherBound='86.1'>
                    <om:Property Name='Activate' Value='False' />
                    <om:Property Name='PortName' Value='ShippingReceivePort' />
                    <om:Property Name='MessageName' Value='ShippingMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_ShipNotice' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='7c15c356-dc7f-4967-aa8a-7909bab9a38a' ParentLink='ServiceBody_Statement' LowerBound='86.1' HigherBound='88.1'>
                    <om:Property Name='PortName' Value='ReportPort' />
                    <om:Property Name='MessageName' Value='ShippingMessage' />
                    <om:Property Name='OperationName' Value='SendShipNoticeOut' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_ShipNoticeReport' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='037b5cd5-65b0-4459-9a95-6dd3105316fa' ParentLink='ServiceBody_Statement' LowerBound='88.1' HigherBound='90.1'>
                    <om:Property Name='PortName' Value='DirectBindMessageBoxSendPort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_POToThirdOrchestration' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='af7a47c7-50af-4c17-9579-639fdc77f565' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='54.1' HigherBound='56.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.SharedPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='DirectSharedPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='DirectBindingAttribute' OID='31b3d6f2-a52f-4a33-8aa7-b11aa926f59e' ParentLink='PortDeclaration_CLRAttribute' LowerBound='54.1' HigherBound='55.1'>
                    <om:Property Name='PartnerPort' Value='SharedPortReceive' />
                    <om:Property Name='PartnerService' Value='Orchestrations.SecondOrchestration' />
                    <om:Property Name='DirectBindingType' Value='PartnerPort' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='314c2f52-ed21-486f-9e1a-5eac1311d408' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='56.1' HigherBound='58.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.InitiatePortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InitiatePort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='7877e694-5d5b-469c-bed5-fe61aacbf475' ParentLink='PortDeclaration_CLRAttribute' LowerBound='56.1' HigherBound='57.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='f5cafbf5-ab00-4b8b-99bb-4686b97d5830' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='58.1' HigherBound='60.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.ReportPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ReportPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='61490f3e-7e52-411d-a0c1-c04e788b4b0d' ParentLink='PortDeclaration_CLRAttribute' LowerBound='58.1' HigherBound='59.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='da596e5b-ce9c-4931-b499-f31339350683' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='60.1' HigherBound='62.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.ShippingPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ShippingReceivePort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='DirectBindingAttribute' OID='1f42976c-f66f-46b7-84e6-c4a80816dcca' ParentLink='PortDeclaration_CLRAttribute' LowerBound='60.1' HigherBound='61.1'>
                    <om:Property Name='DirectBindingType' Value='SelfCorrelating' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='2b64df44-55a4-4131-b6e1-6c5e54f6c6fd' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='62.1' HigherBound='64.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.DirectBindMessageBoxSendPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='DirectBindMessageBoxSendPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='DirectBindingAttribute' OID='a1a94cbf-8b45-47c5-9cb0-8fa147bab083' ParentLink='PortDeclaration_CLRAttribute' LowerBound='62.1' HigherBound='63.1'>
                    <om:Property Name='DirectBindingType' Value='MessageBox' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='CorrelationType' OID='eaf533c5-98f7-4848-9aa2-90b2f763e30f' ParentLink='Module_CorrelationType' LowerBound='47.1' HigherBound='51.1'>
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='OrderIDCorrelationType' />
            <om:Property Name='Signal' Value='True' />
            <om:Element Type='PropertyRef' OID='abb0991d-3c58-4fa2-898e-8131adfc0f9f' ParentLink='CorrelationType_PropertyRef' LowerBound='49.9' HigherBound='49.24'>
                <om:Property Name='Ref' Value='Schemas.OrderID' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='PropertyRef_1' />
                <om:Property Name='Signal' Value='False' />
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __FirstOrchestration_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __FirstOrchestration_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "FirstOrchestration")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                FirstOrchestration __svc__ = (FirstOrchestration)_service;
                __FirstOrchestration_root_0 __ctx0__ = (__FirstOrchestration_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.DirectBindMessageBoxSendPort != null)
                {
                    __svc__.DirectBindMessageBoxSendPort.Close(this, null);
                    __svc__.DirectBindMessageBoxSendPort = null;
                }
                if (__svc__.ShippingReceivePort != null)
                {
                    __svc__.ShippingReceivePort.Close(this, null);
                    __svc__.ShippingReceivePort = null;
                }
                if (__svc__.ReportPort != null)
                {
                    __svc__.ReportPort.Close(this, null);
                    __svc__.ReportPort = null;
                }
                if (__svc__.InitiatePort != null)
                {
                    __svc__.InitiatePort.Close(this, null);
                    __svc__.InitiatePort = null;
                }
                if (__svc__.DirectSharedPort != null)
                {
                    __svc__.DirectSharedPort.Close(this, null);
                    __svc__.DirectSharedPort = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper1;
            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper2;
        }


        [System.SerializableAttribute]
        public class __FirstOrchestration_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __FirstOrchestration_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "FirstOrchestration")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                FirstOrchestration __svc__ = (FirstOrchestration)_service;
                __FirstOrchestration_root_0 __ctx0__ = (__FirstOrchestration_root_0)(__svc__._stateMgrs[0]);
                __FirstOrchestration_1 __ctx1__ = (__FirstOrchestration_1)(__svc__._stateMgrs[1]);

                if (__ctx0__ != null && __ctx0__.__subWrapper2 != null)
                {
                    __ctx0__.__subWrapper2.Destroy(__svc__, __ctx0__);
                    __ctx0__.__subWrapper2 = null;
                }
                if (__ctx0__ != null && __ctx0__.__subWrapper1 != null)
                {
                    __ctx0__.__subWrapper1.Destroy(__svc__, __ctx0__);
                    __ctx0__.__subWrapper1 = null;
                }
                if (__ctx1__ != null && __ctx1__.__OrderCorrelation != null)
                    __ctx1__.__OrderCorrelation = null;
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("POMessage")]
            public __messagetype_Schemas_PurchaseOrder __POMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("InvoiceMessage")]
            public __messagetype_Schemas_Invoice __InvoiceMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("ShippingMessage")]
            public __messagetype_Schemas_ShippingAdvice __ShippingMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("OrderCorrelation")]
            internal Microsoft.XLANGs.Core.Correlation __OrderCorrelation;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = new Microsoft.XLANGs.Core.CorrelationType[] { new OrderIDCorrelationType() };
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return null;
            }
        }

        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("InitiatePort")]
        internal InitiatePortType InitiatePort;
        [Microsoft.XLANGs.BaseTypes.DirectBindingAttribute(typeof(SecondOrchestration), "SharedPortReceive")]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("DirectSharedPort")]
        internal SharedPortType DirectSharedPort;
        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("ReportPort")]
        internal ReportPortType ReportPort;
        [Microsoft.XLANGs.BaseTypes.DirectBindingAttribute(Microsoft.XLANGs.BaseTypes.DirectBindingAttribute.SelfCorrelating.On)]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("ShippingReceivePort")]
        internal ShippingPortType ShippingReceivePort;
        [Microsoft.XLANGs.BaseTypes.DirectBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("DirectBindMessageBoxSendPort")]
        internal DirectBindMessageBoxSendPortType DirectBindMessageBoxSendPort;
        System.Guid __timeout0__;
        System.Guid __timeout1__;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {InitiatePortType.Operation_1},
                                               typeof(FirstOrchestration).GetField("InitiatePort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(FirstOrchestration), "InitiatePort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {SharedPortType.SharedSend},
                                               typeof(FirstOrchestration).GetField("DirectSharedPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(FirstOrchestration), "DirectSharedPort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {ReportPortType.SendInvoiceOut, ReportPortType.SendShipNoticeOut, ReportPortType.SendPOReport},
                                               typeof(FirstOrchestration).GetField("ReportPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(FirstOrchestration), "ReportPort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {ShippingPortType.Operation_1},
                                               typeof(FirstOrchestration).GetField("ShippingReceivePort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(FirstOrchestration), "ShippingReceivePort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {DirectBindMessageBoxSendPortType.Operation_1},
                                               typeof(FirstOrchestration).GetField("DirectBindMessageBoxSendPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(FirstOrchestration), "DirectBindMessageBoxSendPort"),
                                               null)
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[0].Name] = _portInfo[0];
                h[_portInfo[1].Name] = _portInfo[1];
                h[_portInfo[2].Name] = _portInfo[2];
                h[_portInfo[3].Name] = _portInfo[3];
                h[_portInfo[4].Name] = _portInfo[4];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    typeof(Orchestrations.ThirdOrchestration)                    
                };
            }
        }

        public static object[] StaticSubscriptionsInformation {
            get {
                return new object[1]{
                     new object[5] { _portInfo[0], 0, null , -1, true }
                };
            }
        }

        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "2bd5bd7e-0c51-49d0-9ebb-4f72f820bb91", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "2bd5bd7e-0c51-49d0-9ebb-4f72f820bb91", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "b112f2f4-2b91-4181-9575-7e2222581049", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "b112f2f4-2b91-4181-9575-7e2222581049", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "7dbee708-fe1e-4255-b932-b4efd4fd0fc5", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "7dbee708-fe1e-4255-b932-b4efd4fd0fc5", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "e71c2769-aeb8-4dce-a08a-f55685801ccd", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(8, "e71c2769-aeb8-4dce-a08a-f55685801ccd", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(9, "db951977-b335-45a7-be6d-a21130c3e232", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(10, "db951977-b335-45a7-be6d-a21130c3e232", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(11, "8c67e6f5-b9bf-4d4e-89c3-be62221b271b", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(12, "8c67e6f5-b9bf-4d4e-89c3-be62221b271b", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(13, "4d0c284d-a010-41c1-a892-067140da716a", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(14, "4d0c284d-a010-41c1-a892-067140da716a", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(15, "de58ad53-8f84-41a8-9675-a19745afc7f5", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(16, "de58ad53-8f84-41a8-9675-a19745afc7f5", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(17, "7c15c356-dc7f-4967-aa8a-7909bab9a38a", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(18, "7c15c356-dc7f-4967-aa8a-7909bab9a38a", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(19, "037b5cd5-65b0-4459-9a95-6dd3105316fa", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(20, "037b5cd5-65b0-4459-9a95-6dd3105316fa", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(21, "00000000-0000-0000-0000-000000000000", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Delay),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Delay),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Exec),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Exec),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,21,21,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,1,2,3,3,3,4,5,5,6,7,7,7,8,9,9,9,9,10,11,11,12,12,13,13,13,13,14,15,15,16,17,17,17,18,19,19,19,20,21,21,21,21,};

        public static int[][] __progressLocations = new int[2] [] {__progressLocation0,__progressLocation1};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __FirstOrchestration_root_0 __ctx0__ = (__FirstOrchestration_root_0)_stateMgrs[0];
            __FirstOrchestration_1 __ctx1__ = (__FirstOrchestration_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                DirectSharedPort = new SharedPortType(1, this);
                InitiatePort = new InitiatePortType(0, this);
                ReportPort = new ReportPortType(2, this);
                ShippingReceivePort = new ShippingPortType(3, this);
                DirectBindMessageBoxSendPort = new DirectBindMessageBoxSendPortType(4, this);
                __ctx__.PrologueCompleted = true;
                __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[0], InitiatePort, this);
                __ctx0__.__subWrapper2 = new Microsoft.XLANGs.Core.SubscriptionWrapper(0, System.Guid.Empty, ShippingReceivePort, 0, __ctx0__);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __FirstOrchestration_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __FirstOrchestration_root_0 __ctx0__ = (__FirstOrchestration_root_0)_stateMgrs[0];
            __FirstOrchestration_1 __ctx1__ = (__FirstOrchestration_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                if ( !PreProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[0],__eventData[0],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if (!InitiatePort.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__POMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                __ctx1__.__POMessage = new __messagetype_Schemas_PurchaseOrder("POMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__POMessage);
                InitiatePort.ReceiveMessage(0, __msgEnv__, __ctx1__.__POMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if (InitiatePort != null)
                {
                    InitiatePort.Close(__ctx1__, __seg__);
                    InitiatePort = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                if ( !PreProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"InitiatePort";
                    Tracker.FireEvent(__eventLocations[2],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[3],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 6;
            case 6:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 7;
            case 7:
                if ( !PreProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                DirectSharedPort.SendMessage(0, __ctx1__.__POMessage, null, null, out __ctx0__.__subWrapper1, __ctx1__, __seg__ );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 8;
            case 8:
                if ( !PreProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"DirectSharedPort";
                    Tracker.FireEvent(__eventLocations[4],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 9;
            case 9:
                if ( !PreProgressInc( __seg__, __ctx__, 10 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.__OrderCorrelation = new Microsoft.XLANGs.Core.Correlation(this, 0, 0);
                Tracker.FireEvent(__eventLocations[5],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 10;
            case 10:
                if (!DirectSharedPort.GetMessageId(__ctx0__.__subWrapper1.getSubscription(this), __seg__, __ctx1__, out __msgEnv__, _locations[0]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx0__ != null && __ctx0__.__subWrapper1 != null)
                {
                    __ctx0__.__subWrapper1.Destroy(this, __ctx0__);
                    __ctx0__.__subWrapper1 = null;
                }
                if (__ctx1__.__InvoiceMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                __ctx1__.__InvoiceMessage = new __messagetype_Schemas_Invoice("InvoiceMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__InvoiceMessage);
                DirectSharedPort.ReceiveMessage(0, __msgEnv__, __ctx1__.__InvoiceMessage, new Microsoft.XLANGs.Core.Correlation[] { __ctx1__.__OrderCorrelation }, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if (DirectSharedPort != null)
                {
                    DirectSharedPort.Close(__ctx1__, __seg__);
                    DirectSharedPort = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 11;
            case 11:
                if ( !PreProgressInc( __seg__, __ctx__, 12 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.PortName = @"DirectSharedPort";
                    Tracker.FireEvent(__eventLocations[6],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 12;
            case 12:
                if ( !PreProgressInc( __seg__, __ctx__, 13 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[7],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 13;
            case 13:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 14 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 14;
            case 14:
                if ( !PreProgressInc( __seg__, __ctx__, 15 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                ReportPort.SendMessage(0, __ctx1__.__InvoiceMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 15;
            case 15:
                if ( !PreProgressInc( __seg__, __ctx__, 16 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.PortName = @"ReportPort";
                    Tracker.FireEvent(__eventLocations[8],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 16;
            case 16:
                if ( !PreProgressInc( __seg__, __ctx__, 17 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[9],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 17;
            case 17:
                __timeout0__ = __ctx1__.PostTimeout(System.DateTime.UtcNow.Add(new System.TimeSpan(0, 0, 30)));
                if ( !PostProgressInc( __seg__, __ctx__, 18 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 18;
            case 18:
                if (!Microsoft.XLANGs.Core.PortBase.GetMessageIdForSubscription(LookupSubscription(__timeout0__) , __seg__, __ctx1__, out __msgEnv__ , _locations[1]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 19 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 19;
            case 19:
                DeleteTimeout(LookupSubscription(__timeout0__));
                if ( !PostProgressInc( __seg__, __ctx__, 20 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 20;
            case 20:
                if ( !PreProgressInc( __seg__, __ctx__, 21 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[10],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 21;
            case 21:
                if ( !PreProgressInc( __seg__, __ctx__, 22 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[11],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 22;
            case 22:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 23 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 23;
            case 23:
                if ( !PreProgressInc( __seg__, __ctx__, 24 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                ExecService(__ctx1__, typeof(Orchestrations.ThirdOrchestration), new object[] {__ctx1__.__OrderCorrelation, __ctx1__.__InvoiceMessage, ShippingReceivePort.BindingInfo});
                goto case 24;
            case 24:
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Exec);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    Tracker.FireEvent(__eventLocations[12],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 25 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 25;
            case 25:
                if ( !PreProgressInc( __seg__, __ctx__, 26 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[13],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 26;
            case 26:
                __timeout1__ = __ctx1__.PostTimeout(System.DateTime.UtcNow.Add(new System.TimeSpan(0, 0, 30)));
                if ( !PostProgressInc( __seg__, __ctx__, 27 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 27;
            case 27:
                if (!Microsoft.XLANGs.Core.PortBase.GetMessageIdForSubscription(LookupSubscription(__timeout1__) , __seg__, __ctx1__, out __msgEnv__ , _locations[2]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 28 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 28;
            case 28:
                DeleteTimeout(LookupSubscription(__timeout1__));
                if ( !PostProgressInc( __seg__, __ctx__, 29 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 29;
            case 29:
                if ( !PreProgressInc( __seg__, __ctx__, 30 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[14],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 30;
            case 30:
                if ( !PreProgressInc( __seg__, __ctx__, 31 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[15],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 31;
            case 31:
                if (!ShippingReceivePort.GetMessageId(__ctx0__.__subWrapper2.getSubscription(this), __seg__, __ctx1__, out __msgEnv__, _locations[3]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx0__ != null && __ctx0__.__subWrapper2 != null)
                {
                    __ctx0__.__subWrapper2.Destroy(this, __ctx0__);
                    __ctx0__.__subWrapper2 = null;
                }
                if (__ctx1__.__ShippingMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                __ctx1__.__ShippingMessage = new __messagetype_Schemas_ShippingAdvice("ShippingMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__ShippingMessage);
                ShippingReceivePort.ReceiveMessage(0, __msgEnv__, __ctx1__.__ShippingMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if (ShippingReceivePort != null)
                {
                    ShippingReceivePort.Close(__ctx1__, __seg__);
                    ShippingReceivePort = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 32 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 32;
            case 32:
                if ( !PreProgressInc( __seg__, __ctx__, 33 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.PortName = @"ShippingReceivePort";
                    Tracker.FireEvent(__eventLocations[16],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 33;
            case 33:
                if ( !PreProgressInc( __seg__, __ctx__, 34 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[17],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 34;
            case 34:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 35 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 35;
            case 35:
                if ( !PreProgressInc( __seg__, __ctx__, 36 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                ReportPort.SendMessage(1, __ctx1__.__ShippingMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if (ReportPort != null)
                {
                    ReportPort.Close(__ctx1__, __seg__);
                    ReportPort = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 36;
            case 36:
                if ( !PreProgressInc( __seg__, __ctx__, 37 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.PortName = @"ReportPort";
                    Tracker.FireEvent(__eventLocations[18],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 37;
            case 37:
                if ( !PreProgressInc( __seg__, __ctx__, 38 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[19],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 38;
            case 38:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 39 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 39;
            case 39:
                if ( !PreProgressInc( __seg__, __ctx__, 40 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                DirectBindMessageBoxSendPort.SendMessage(0, __ctx1__.__POMessage, null, new Microsoft.XLANGs.Core.Correlation[] { __ctx1__.__OrderCorrelation }, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.NextActivityPersists );
                if (__ctx1__ != null && __ctx1__.__OrderCorrelation != null)
                    __ctx1__.__OrderCorrelation = null;
                if (DirectBindMessageBoxSendPort != null)
                {
                    DirectBindMessageBoxSendPort.Close(__ctx1__, __seg__);
                    DirectBindMessageBoxSendPort = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 40;
            case 40:
                if ( !PreProgressInc( __seg__, __ctx__, 41 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"DirectBindMessageBoxSendPort";
                    Tracker.FireEvent(__eventLocations[20],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 41;
            case 41:
                if ( !PreProgressInc( __seg__, __ctx__, 42 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[21],__eventData[7],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 42;
            case 42:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 43 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 43;
            case 43:
                if ( !PreProgressInc( __seg__, __ctx__, 44 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 44;
            case 44:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
        private static Microsoft.XLANGs.Core.CachedObject[] _locations = new Microsoft.XLANGs.Core.CachedObject[] {
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{E06E5D3A-3A1D-4D72-BFD8-336E91E4BC66}")),
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{7D77255C-5BC8-4EDC-82AD-A2452D3DE4A5}")),
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{A4652BA3-5123-4263-A303-B52CEFA2140C}")),
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{E52270EC-8EB1-47F2-A930-EF4242AAA44B}"))
        };

    }
    //#line 107 "D:\demos\orchestrationsII\DirectOrchestrationMessaging\Orchestrations\SecondOrchestration.odx"
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        0, "SharedPortReceive", "SharedSend", -1, -1, true
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        },
        new System.Type[] {
            typeof(Orchestrations.SharedPortType)
        },
        new System.String[] {
            "SharedPortReceive"
        },
        new System.Type[] {
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eNone
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class SecondOrchestration : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = false;
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eNone,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy()
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(SecondOrchestration));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return true; } }

        internal bool IsExeced = false;

        static SecondOrchestration()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1)
            };

            _Locks = 0;
            _rootContext = new __SecondOrchestration_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        public SecondOrchestration(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "SecondOrchestration", tracker)
        {
            ConstructorHelper();
        }

        public SecondOrchestration(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent)
            : base(callIndex, instanceId, parent, "SecondOrchestration")
        {
            ConstructorHelper();
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>007c84b7-b659-4086-831a-294aab5aa13b</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>569ea366-36d8-4189-a25e-cb663b2abf4b</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_PO</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ConstructShape</shapeType>      <ShapeID>6f0dbc7c-18fd-4d41-9e7c-b582b38ba2b8</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>ConstructInvoiceMessage</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>TransformShape</shapeType>      <ShapeID>96ba8fe2-80e6-461f-afc1-4414bf52bc79</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>TransformPOToInvoice</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>4ff24daa-dae9-473e-b52e-b3ef3079078f</ShapeID>      <ParentLink>Transform_InputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>ff08c01d-d2d2-4bda-97d0-9caefe99609c</ShapeID>      <ParentLink>Transform_OutputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessageRefShape</shapeType>      <ShapeID>9ff3bc66-10eb-4ee4-b3b7-3d585e105851</ShapeID>      <ParentLink>Construct_MessageRef</ParentLink>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>11a960d2-98d8-4353-a310-b196df2609e7</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_Invoice</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'SecondOrchestration'</ActionName><IsAtomic>0</IsAtomic><Line>107</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
</TrkMetadata>

<TrkMetadata>
<Line>116</Line><Position>22</Position><ShapeID>'569ea366-36d8-4189-a25e-cb663b2abf4b'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>118</Line><Position>13</Position><ShapeID>'6f0dbc7c-18fd-4d41-9e7c-b582b38ba2b8'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>In</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>124</Line><Position>13</Position><ShapeID>'11a960d2-98d8-4353-a310-b196df2609e7'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='fa14a5d0-1f5e-463e-a689-7585d5000a56' LowerBound='1.1' HigherBound='26.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='Orchestrations' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='ServiceDeclaration' OID='dd16a6a8-62b0-43a8-81c8-52c96f36e8cd' ParentLink='Module_ServiceDeclaration' LowerBound='4.1' HigherBound='25.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='SecondOrchestration' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='ServiceBody' OID='007c84b7-b659-4086-831a-294aab5aa13b' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='Receive' OID='569ea366-36d8-4189-a25e-cb663b2abf4b' ParentLink='ServiceBody_Statement' LowerBound='13.1' HigherBound='15.1'>
                    <om:Property Name='Activate' Value='True' />
                    <om:Property Name='PortName' Value='SharedPortReceive' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='SharedSend' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_PO' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Construct' OID='6f0dbc7c-18fd-4d41-9e7c-b582b38ba2b8' ParentLink='ServiceBody_Statement' LowerBound='15.1' HigherBound='21.1'>
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='ConstructInvoiceMessage' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='Transform' OID='96ba8fe2-80e6-461f-afc1-4414bf52bc79' ParentLink='ComplexStatement_Statement' LowerBound='18.1' HigherBound='20.1'>
                        <om:Property Name='ClassName' Value='Orchestrations.TransformPOToInvoice' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='TransformPOToInvoice' />
                        <om:Property Name='Signal' Value='False' />
                        <om:Element Type='MessagePartRef' OID='4ff24daa-dae9-473e-b52e-b3ef3079078f' ParentLink='Transform_InputMessagePartRef' LowerBound='19.83' HigherBound='19.92'>
                            <om:Property Name='MessageRef' Value='POMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_1' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                        <om:Element Type='MessagePartRef' OID='ff08c01d-d2d2-4bda-97d0-9caefe99609c' ParentLink='Transform_OutputMessagePartRef' LowerBound='19.28' HigherBound='19.42'>
                            <om:Property Name='MessageRef' Value='InvoiceMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_2' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                    </om:Element>
                    <om:Element Type='MessageRef' OID='9ff3bc66-10eb-4ee4-b3b7-3d585e105851' ParentLink='Construct_MessageRef' LowerBound='16.23' HigherBound='16.37'>
                        <om:Property Name='Ref' Value='InvoiceMessage' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='Send' OID='11a960d2-98d8-4353-a310-b196df2609e7' ParentLink='ServiceBody_Statement' LowerBound='21.1' HigherBound='23.1'>
                    <om:Property Name='PortName' Value='SharedPortReceive' />
                    <om:Property Name='MessageName' Value='InvoiceMessage' />
                    <om:Property Name='OperationName' Value='SharedSend' />
                    <om:Property Name='OperationMessageName' Value='Response' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_Invoice' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='d91592e6-710c-4826-b585-3c3192b2e541' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='7.1' HigherBound='9.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.SharedPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='SharedPortReceive' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='DirectBindingAttribute' OID='d16a250d-167e-47a1-9e02-38e30a92c0c3' ParentLink='PortDeclaration_CLRAttribute' LowerBound='7.1' HigherBound='8.1'>
                    <om:Property Name='PartnerPort' Value='SharedPortReceive' />
                    <om:Property Name='PartnerService' Value='Orchestrations.SecondOrchestration' />
                    <om:Property Name='DirectBindingType' Value='PartnerPort' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='489a4894-4667-4bd1-9587-a4e3ce8d446e' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='9.1' HigherBound='10.1'>
                <om:Property Name='Type' Value='Schemas.PurchaseOrder' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='a3ae4a62-a355-4a16-ad11-a788a13baf6b' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='10.1' HigherBound='11.1'>
                <om:Property Name='Type' Value='Schemas.Invoice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InvoiceMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __SecondOrchestration_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __SecondOrchestration_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "SecondOrchestration")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                SecondOrchestration __svc__ = (SecondOrchestration)_service;
                __SecondOrchestration_root_0 __ctx0__ = (__SecondOrchestration_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.SharedPortReceive != null)
                {
                    __svc__.SharedPortReceive.Close(this, null);
                    __svc__.SharedPortReceive = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
        }


        [System.SerializableAttribute]
        public class __SecondOrchestration_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __SecondOrchestration_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "SecondOrchestration")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                SecondOrchestration __svc__ = (SecondOrchestration)_service;
                __SecondOrchestration_1 __ctx1__ = (__SecondOrchestration_1)(__svc__._stateMgrs[1]);

                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("POMessage")]
            public __messagetype_Schemas_PurchaseOrder __POMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("InvoiceMessage")]
            public __messagetype_Schemas_Invoice __InvoiceMessage;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = null;
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return null;
            }
        }

        [Microsoft.XLANGs.BaseTypes.DirectBindingAttribute(typeof(SecondOrchestration), "SharedPortReceive")]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("SharedPortReceive")]
        internal SharedPortType SharedPortReceive;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {SharedPortType.SharedSend},
                                               typeof(SecondOrchestration).GetField("SharedPortReceive", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(SecondOrchestration), "SharedPortReceive"),
                                               null)
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[0].Name] = _portInfo[0];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static object[] StaticSubscriptionsInformation {
            get {
                return new object[1]{
                     new object[5] { _portInfo[0], 0, null , -1, true }
                };
            }
        }

        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "569ea366-36d8-4189-a25e-cb663b2abf4b", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "569ea366-36d8-4189-a25e-cb663b2abf4b", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "6f0dbc7c-18fd-4d41-9e7c-b582b38ba2b8", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "6f0dbc7c-18fd-4d41-9e7c-b582b38ba2b8", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "11a960d2-98d8-4353-a310-b196df2609e7", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "11a960d2-98d8-4353-a310-b196df2609e7", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "00000000-0000-0000-0000-000000000000", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Construct),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,7,7,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,1,2,3,3,4,5,5,5,6,7,7,7,7,};

        public static int[][] __progressLocations = new int[2] [] {__progressLocation0,__progressLocation1};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __SecondOrchestration_1 __ctx1__ = (__SecondOrchestration_1)_stateMgrs[1];
            __SecondOrchestration_root_0 __ctx0__ = (__SecondOrchestration_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                SharedPortReceive = new SharedPortType(0, this);
                __ctx__.PrologueCompleted = true;
                __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[0], SharedPortReceive, this);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __SecondOrchestration_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __SecondOrchestration_1 __ctx1__ = (__SecondOrchestration_1)_stateMgrs[1];
            __SecondOrchestration_root_0 __ctx0__ = (__SecondOrchestration_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                if ( !PreProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[0],__eventData[0],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if (!SharedPortReceive.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__POMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                __ctx1__.__POMessage = new __messagetype_Schemas_PurchaseOrder("POMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__POMessage);
                SharedPortReceive.ReceiveMessage(0, __msgEnv__, __ctx1__.__POMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                if ( !PreProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"SharedPortReceive";
                    Tracker.FireEvent(__eventLocations[2],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[3],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 6;
            case 6:
                {
                    __messagetype_Schemas_Invoice __InvoiceMessage = new __messagetype_Schemas_Invoice("InvoiceMessage", __ctx1__);

                    ApplyTransform(typeof(Orchestrations.TransformPOToInvoice), new object[] {__InvoiceMessage.part}, new object[] {__ctx1__.__POMessage.part});

                    if (__ctx1__.__InvoiceMessage != null)
                        __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = __InvoiceMessage;
                    __ctx1__.RefMessage(__ctx1__.__InvoiceMessage);
                }
                __ctx1__.__InvoiceMessage.ConstructionCompleteEvent(true);
                if ( !PostProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 7;
            case 7:
                if ( !PreProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Construct);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    Tracker.FireEvent(__eventLocations[4],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 8;
            case 8:
                if ( !PreProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[5],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 9;
            case 9:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 10 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 10;
            case 10:
                if ( !PreProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                SharedPortReceive.SendMessage(0, __ctx1__.__InvoiceMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.NextActivityPersists );
                if (SharedPortReceive != null)
                {
                    SharedPortReceive.Close(__ctx1__, __seg__);
                    SharedPortReceive = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingResp) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingResp;
                goto case 11;
            case 11:
                if ( !PreProgressInc( __seg__, __ctx__, 12 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.PortName = @"SharedPortReceive";
                    Tracker.FireEvent(__eventLocations[6],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 12;
            case 12:
                if ( !PreProgressInc( __seg__, __ctx__, 13 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[7],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 13;
            case 13:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 14 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 14;
            case 14:
                if ( !PreProgressInc( __seg__, __ctx__, 15 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 15;
            case 15:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
    }
    //#line 205 "D:\demos\orchestrationsII\DirectOrchestrationMessaging\Orchestrations\ThirdOrchestration.odx"
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(Orchestrations.ShippingPortType),
            typeof(Orchestrations.DirectBindMessagePortType),
            typeof(Orchestrations.ReportPortType)
        },
        new System.String[] {
            "ShippingPortHandle",
            "DirectBindMessageBoxPort",
            "POReportPort"
        },
        new System.Type[] {
            null,
            null,
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eCallable|Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eExecable
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class ThirdOrchestration : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = true;
        [ Microsoft.XLANGs.BaseTypes.ServiceConvoyAttribute(
            0, 
            "Orchestrations.__messagetype_Schemas_PurchaseOrder", 
            new System.Int32[] {
                0
            },
            new System.Boolean[] {
                false
            }
        )]
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eNone,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy(
            [ Microsoft.XLANGs.BaseTypes.ServiceParameterAttribute(Microsoft.XLANGs.BaseTypes.EXLangSParameter.eCorrelation, "") ] Orchestrations.OrderIDCorrelationType OrderCorrelation,
            [ Microsoft.XLANGs.BaseTypes.ServiceParameterAttribute(Microsoft.XLANGs.BaseTypes.EXLangSParameter.eMessage, "") ] Schemas.Invoice InvoiceMessage,
            [ Microsoft.XLANGs.BaseTypes.ServiceParameterAttribute(Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses, "") ] Orchestrations.ShippingPortType ShippingPortHandle)
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(ThirdOrchestration));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return false; } }

        internal bool IsExeced = false;

        static ThirdOrchestration()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1)
            };

            _Locks = 0;
            _rootContext = new __ThirdOrchestration_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        [System.SerializableAttribute]
        public class BodyCallSite : Microsoft.BizTalk.XLANGs.BTXEngine.BTXCallSite
        {
            internal DirectBindMessagePortType DirectBindMessageBoxPort;
            internal Microsoft.XLANGs.Core.Subscription subscription0;

            public override Microsoft.XLANGs.Core.PortInfo[] PortInformation { get { return ThirdOrchestration._portInfo; } }

            public override System.Guid ServiceId { get { return ThirdOrchestration._serviceId; } }

            public BodyCallSite(Microsoft.XLANGs.Core.Context ctx, Microsoft.XLANGs.Core.CallSite.ConvoyMap[] convoyMap, Microsoft.XLANGs.Core.PortBase ShippingPortHandle)
                : base( convoyMap )
            {
                DirectBindMessageBoxPort = new DirectBindMessagePortType(1, this);
                int[] convoyIndices = new int[1];
                convoyIndices[0] = ComputeConvoySet(new int[] { 0 });
                if (convoyIndices[0] >= 0)
                {
                    ConvoyMap c = convoyMap[convoyIndices[0]];
                    subscription0 = new Microsoft.XLANGs.Core.Subscription(1 - c.CorrelationParamNums.Length, c.ConvoyId, DirectBindMessageBoxPort, 0, ctx);
                }
                else
                {
                    subscription0 = new Microsoft.XLANGs.Core.Subscription(1, System.Guid.Empty, DirectBindMessageBoxPort, 0, ctx);
                }

                _correlationParams = new Microsoft.XLANGs.Core.CallSite.CorrelationParam[] {
                      new Microsoft.XLANGs.Core.CallSite.CorrelationParam(new Microsoft.XLANGs.Core.CorrelationClient[] { subscription0 })
                };

                if (convoyIndices[0] >= 0)
                {
                    ConvoyMap c = convoyMap[convoyIndices[0]];
                    for (int i = 0; i < c.CorrelationParamNums.Length; ++i)
                        _correlationParams[c.CorrelationParamNums[i]].RemoveClient(subscription0);
                }
            }

            public override void Destroy(Microsoft.XLANGs.Core.Context ctx)
            {
                subscription0.Destroy(ctx);
            }
        }

        public ThirdOrchestration(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent, BodyCallSite callSite)
            : base(callIndex, instanceId, parent, "ThirdOrchestration")
        {
            ConstructorHelper();
            __ThirdOrchestration_root_0 __ctx0__ = (__ThirdOrchestration_root_0)_stateMgrs[0];

            this.DirectBindMessageBoxPort = callSite.DirectBindMessageBoxPort;
            __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(callSite.subscription0, true);
        }

        public ThirdOrchestration(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "ThirdOrchestration", tracker)
        {
            ConstructorHelper();
            IsExeced = true;
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>beb8fb01-1a67-4fe0-aea1-06e7902ed353</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>CorrelationDeclarationShape</shapeType>      <ShapeID>3b4f86f4-b225-4e00-8c2f-b12e698cdd6d</ShapeID>      <ParentLink>ServiceBody_Declaration</ParentLink>                <shapeText>OrderCorrelation</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>StatementRefShape</shapeType>      <ShapeID>5ae6f64c-6a99-48e1-a73a-43b793bd8891</ShapeID>      <ParentLink>CorrelationDeclaration_StatementRef</ParentLink>                <shapeText>StatementRef_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessageDeclarationShape</shapeType>      <ShapeID>7fc79946-0499-49e5-bfa0-d17ac2c777cb</ShapeID>      <ParentLink>ServiceBody_Declaration</ParentLink>                <shapeText>InvoiceMessage</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>PortDeclarationShape</shapeType>      <ShapeID>44482687-e984-45ed-a0c1-e45ff1ca9dc7</ShapeID>      <ParentLink>ServiceBody_Declaration</ParentLink>                <shapeText>ShippingPortHandle</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>LogicalBindingAttributeShape</shapeType>      <ShapeID>1bfe8a87-fd15-4a92-849b-6859a44eddaf</ShapeID>      <ParentLink>PortDeclaration_CLRAttribute</ParentLink>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ConstructShape</shapeType>      <ShapeID>9d329477-928f-42c3-b067-58aa2b462298</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>ConstructShippingMessage</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>TransformShape</shapeType>      <ShapeID>7b249cba-4f58-4679-9e5a-29f7ea5308fa</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Transform_InvoiceToShippingNotice</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>7410da7d-094f-4efd-857d-10a9eb30d167</ShapeID>      <ParentLink>Transform_InputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>37f08f86-bddf-4f73-9d4f-2efdf722ee5f</ShapeID>      <ParentLink>Transform_OutputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessageRefShape</shapeType>      <ShapeID>5965489c-9968-420d-b8fd-6e78de891651</ShapeID>      <ParentLink>Construct_MessageRef</ParentLink>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>DelayShape</shapeType>      <ShapeID>69568d78-73c4-4a88-96c2-55ef1e3427e5</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Delay_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>86fb0a76-1f79-4e67-a506-851a153c825b</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_ShippingDirectlyToCallingOrchPort</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>DelayShape</shapeType>      <ShapeID>f6326969-4e80-4643-ad9a-e1fc619080f7</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Delay_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>a82a217f-7646-42ff-997f-08ef3c2e8097</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_POFromFirstOrchestration</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>462025c1-fc48-46f9-b764-9c35077cb4af</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_POReport</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'ThirdOrchestration'</ActionName><IsAtomic>0</IsAtomic><Line>205</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>In</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>216</Line><Position>13</Position><ShapeID>'9d329477-928f-42c3-b067-58aa2b462298'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.ShippingAdvice</schema><direction>Out</direction></MsgInfo>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>In</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>222</Line><Position>13</Position><ShapeID>'69568d78-73c4-4a88-96c2-55ef1e3427e5'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>224</Line><Position>13</Position><ShapeID>'86fb0a76-1f79-4e67-a506-851a153c825b'</ShapeID>
<Messages>
	<MsgInfo><name>ShippingMessage</name><part>part</part><schema>Schemas.ShippingAdvice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>226</Line><Position>13</Position><ShapeID>'f6326969-4e80-4643-ad9a-e1fc619080f7'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>228</Line><Position>13</Position><ShapeID>'a82a217f-7646-42ff-997f-08ef3c2e8097'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>230</Line><Position>13</Position><ShapeID>'462025c1-fc48-46f9-b764-9c35077cb4af'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='92a61ad8-fb8b-4c17-baf2-47019a988314' LowerBound='1.1' HigherBound='41.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='Orchestrations' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='PortType' OID='90be2835-2c86-4e24-9c71-70f66cbc00a9' ParentLink='Module_PortType' LowerBound='4.1' HigherBound='11.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='DirectBindMessagePortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='aa6eee85-531c-4e1f-a25f-880f1cf51792' ParentLink='PortType_OperationDeclaration' LowerBound='6.1' HigherBound='10.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='42153fef-c591-4660-83f3-452e9c3be167' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='8.13' HigherBound='8.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='ServiceDeclaration' OID='03b7502c-ef0c-427f-b0b2-8fde431e6c7d' ParentLink='Module_ServiceDeclaration' LowerBound='11.1' HigherBound='40.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='True' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='ThirdOrchestration' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='MessageDeclaration' OID='b52fc29d-d5c0-4598-9049-0cb27e09be30' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='18.1' HigherBound='19.1'>
                <om:Property Name='Type' Value='Schemas.PurchaseOrder' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='e15a24fc-0f3a-4da0-a9c3-34a127def0b9' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='19.1' HigherBound='20.1'>
                <om:Property Name='Type' Value='Schemas.ShippingAdvice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ShippingMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='ServiceBody' OID='beb8fb01-1a67-4fe0-aea1-06e7902ed353' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='CorrelationDeclaration' OID='3b4f86f4-b225-4e00-8c2f-b12e698cdd6d' ParentLink='ServiceBody_Declaration' LowerBound='20.15' HigherBound='20.66'>
                    <om:Property Name='Type' Value='Orchestrations.OrderIDCorrelationType' />
                    <om:Property Name='ParamDirection' Value='In' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='OrderCorrelation' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='StatementRef' OID='5ae6f64c-6a99-48e1-a73a-43b793bd8891' ParentLink='CorrelationDeclaration_StatementRef' LowerBound='35.71' HigherBound='35.87'>
                        <om:Property Name='Initializes' Value='False' />
                        <om:Property Name='Ref' Value='a82a217f-7646-42ff-997f-08ef3c2e8097' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='StatementRef_2' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='MessageDeclaration' OID='7fc79946-0499-49e5-bfa0-d17ac2c777cb' ParentLink='ServiceBody_Declaration' LowerBound='20.68' HigherBound='20.106'>
                    <om:Property Name='Type' Value='Schemas.Invoice' />
                    <om:Property Name='ParamDirection' Value='In' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='InvoiceMessage' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='PortDeclaration' OID='44482687-e984-45ed-a0c1-e45ff1ca9dc7' ParentLink='ServiceBody_Declaration' LowerBound='20.108' HigherBound='20.153'>
                    <om:Property Name='PortModifier' Value='Uses' />
                    <om:Property Name='Orientation' Value='Unbound' />
                    <om:Property Name='PortIndex' Value='0' />
                    <om:Property Name='IsWebPort' Value='False' />
                    <om:Property Name='OrderedDelivery' Value='False' />
                    <om:Property Name='DeliveryNotification' Value='None' />
                    <om:Property Name='Type' Value='Orchestrations.ShippingPortType' />
                    <om:Property Name='ParamDirection' Value='In' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='ShippingPortHandle' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='LogicalBindingAttribute' OID='1bfe8a87-fd15-4a92-849b-6859a44eddaf' ParentLink='PortDeclaration_CLRAttribute'>
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='Construct' OID='9d329477-928f-42c3-b067-58aa2b462298' ParentLink='ServiceBody_Statement' LowerBound='22.1' HigherBound='28.1'>
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='ConstructShippingMessage' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='Transform' OID='7b249cba-4f58-4679-9e5a-29f7ea5308fa' ParentLink='ComplexStatement_Statement' LowerBound='25.1' HigherBound='27.1'>
                        <om:Property Name='ClassName' Value='Orchestrations.Transform_InvoiceToShippingNotice' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='Transform_InvoiceToShippingNotice' />
                        <om:Property Name='Signal' Value='False' />
                        <om:Element Type='MessagePartRef' OID='7410da7d-094f-4efd-857d-10a9eb30d167' ParentLink='Transform_InputMessagePartRef' LowerBound='26.97' HigherBound='26.111'>
                            <om:Property Name='MessageRef' Value='InvoiceMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_1' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                        <om:Element Type='MessagePartRef' OID='37f08f86-bddf-4f73-9d4f-2efdf722ee5f' ParentLink='Transform_OutputMessagePartRef' LowerBound='26.28' HigherBound='26.43'>
                            <om:Property Name='MessageRef' Value='ShippingMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_2' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                    </om:Element>
                    <om:Element Type='MessageRef' OID='5965489c-9968-420d-b8fd-6e78de891651' ParentLink='Construct_MessageRef' LowerBound='23.23' HigherBound='23.38'>
                        <om:Property Name='Ref' Value='ShippingMessage' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='Delay' OID='69568d78-73c4-4a88-96c2-55ef1e3427e5' ParentLink='ServiceBody_Statement' LowerBound='28.1' HigherBound='30.1'>
                    <om:Property Name='Timeout' Value='new System.TimeSpan(0,0,30);' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Delay_1' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='86fb0a76-1f79-4e67-a506-851a153c825b' ParentLink='ServiceBody_Statement' LowerBound='30.1' HigherBound='32.1'>
                    <om:Property Name='PortName' Value='ShippingPortHandle' />
                    <om:Property Name='MessageName' Value='ShippingMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_ShippingDirectlyToCallingOrchPort' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Delay' OID='f6326969-4e80-4643-ad9a-e1fc619080f7' ParentLink='ServiceBody_Statement' LowerBound='32.1' HigherBound='34.1'>
                    <om:Property Name='Timeout' Value='new System.TimeSpan(0,0,30);' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Delay_2' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Receive' OID='a82a217f-7646-42ff-997f-08ef3c2e8097' ParentLink='ServiceBody_Statement' LowerBound='34.1' HigherBound='36.1'>
                    <om:Property Name='Activate' Value='False' />
                    <om:Property Name='PortName' Value='DirectBindMessageBoxPort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_POFromFirstOrchestration' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='462025c1-fc48-46f9-b764-9c35077cb4af' ParentLink='ServiceBody_Statement' LowerBound='36.1' HigherBound='38.1'>
                    <om:Property Name='PortName' Value='POReportPort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='SendPOReport' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_POReport' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='a65d6467-751b-4dd0-95bc-de1c3b57b77b' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='14.1' HigherBound='16.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.DirectBindMessagePortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='DirectBindMessageBoxPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='DirectBindingAttribute' OID='1d7fa763-144f-48e3-9bcc-bd55992c0f81' ParentLink='PortDeclaration_CLRAttribute' LowerBound='14.1' HigherBound='15.1'>
                    <om:Property Name='DirectBindingType' Value='MessageBox' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='eaa5721a-8251-44ab-91b0-58ea365c4d3b' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='16.1' HigherBound='18.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='Orchestrations.ReportPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POReportPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='3393fa12-8965-432b-a0c8-3090a09c77a5' ParentLink='PortDeclaration_CLRAttribute' LowerBound='16.1' HigherBound='17.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __ThirdOrchestration_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __ThirdOrchestration_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "ThirdOrchestration")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                ThirdOrchestration __svc__ = (ThirdOrchestration)_service;
                __ThirdOrchestration_root_0 __ctx0__ = (__ThirdOrchestration_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.DirectBindMessageBoxPort != null)
                {
                    __svc__.DirectBindMessageBoxPort.Close(this, null);
                    __svc__.DirectBindMessageBoxPort = null;
                }
                if (__svc__.POReportPort != null)
                {
                    __svc__.POReportPort.Close(this, null);
                    __svc__.POReportPort = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
        }


        [System.SerializableAttribute]
        public class __ThirdOrchestration_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __ThirdOrchestration_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "ThirdOrchestration")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                ThirdOrchestration __svc__ = (ThirdOrchestration)_service;
                __ThirdOrchestration_root_0 __ctx0__ = (__ThirdOrchestration_root_0)(__svc__._stateMgrs[0]);
                __ThirdOrchestration_1 __ctx1__ = (__ThirdOrchestration_1)(__svc__._stateMgrs[1]);

                if (__ctx0__ != null && __ctx0__.__subWrapper0 != null)
                {
                    __ctx0__.__subWrapper0.Destroy(__svc__, __ctx0__);
                    __ctx0__.__subWrapper0 = null;
                }
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("POMessage")]
            public __messagetype_Schemas_PurchaseOrder __POMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("ShippingMessage")]
            public __messagetype_Schemas_ShippingAdvice __ShippingMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("InvoiceMessage")]
            public __messagetype_Schemas_Invoice __InvoiceMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("OrderCorrelation")]
            internal Microsoft.XLANGs.Core.Correlation __OrderCorrelation;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = new Microsoft.XLANGs.Core.CorrelationType[] { new OrderIDCorrelationType() };
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return null;
            }
        }

        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("ShippingPortHandle")]
        internal ShippingPortType ShippingPortHandle;
        [Microsoft.XLANGs.BaseTypes.DirectBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("DirectBindMessageBoxPort")]
        internal DirectBindMessagePortType DirectBindMessageBoxPort;
        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("POReportPort")]
        internal ReportPortType POReportPort;
        System.Guid __timeout0__;
        System.Guid __timeout1__;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {ShippingPortType.Operation_1},
                                               typeof(ThirdOrchestration).GetField("ShippingPortHandle", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(ThirdOrchestration), "ShippingPortHandle"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {DirectBindMessagePortType.Operation_1},
                                               typeof(ThirdOrchestration).GetField("DirectBindMessageBoxPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(ThirdOrchestration), "DirectBindMessageBoxPort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {ReportPortType.SendInvoiceOut, ReportPortType.SendShipNoticeOut, ReportPortType.SendPOReport},
                                               typeof(ThirdOrchestration).GetField("POReportPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(ThirdOrchestration), "POReportPort"),
                                               null)
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[1].Name] = _portInfo[1];
                h[_portInfo[2].Name] = _portInfo[2];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }


        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "9d329477-928f-42c3-b067-58aa2b462298", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "9d329477-928f-42c3-b067-58aa2b462298", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "69568d78-73c4-4a88-96c2-55ef1e3427e5", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "69568d78-73c4-4a88-96c2-55ef1e3427e5", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "86fb0a76-1f79-4e67-a506-851a153c825b", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "86fb0a76-1f79-4e67-a506-851a153c825b", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(8, "f6326969-4e80-4643-ad9a-e1fc619080f7", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(9, "f6326969-4e80-4643-ad9a-e1fc619080f7", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(10, "a82a217f-7646-42ff-997f-08ef3c2e8097", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(11, "a82a217f-7646-42ff-997f-08ef3c2e8097", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(12, "462025c1-fc48-46f9-b764-9c35077cb4af", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(13, "462025c1-fc48-46f9-b764-9c35077cb4af", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Construct),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Delay),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Delay),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,1,1,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,2,2,3,4,4,4,4,5,6,6,6,7,8,8,8,8,9,10,10,11,12,12,12,13,1,1,1,1,};

        public static int[][] __progressLocations = new int[2] [] {__progressLocation0,__progressLocation1};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __ThirdOrchestration_root_0 __ctx0__ = (__ThirdOrchestration_root_0)_stateMgrs[0];
            __ThirdOrchestration_1 __ctx1__ = (__ThirdOrchestration_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                if (DirectBindMessageBoxPort == null)
                    DirectBindMessageBoxPort = new DirectBindMessagePortType(1, this);
                POReportPort = new ReportPortType(2, this);
                ShippingPortHandle = new ShippingPortType(0, this);
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __ThirdOrchestration_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __ThirdOrchestration_root_0 __ctx0__ = (__ThirdOrchestration_root_0)_stateMgrs[0];
            __ThirdOrchestration_1 __ctx1__ = (__ThirdOrchestration_1)_stateMgrs[1];

            switch (__seg__.Progress)
            {
            case 0:
                if (__ctx0__.__subWrapper0 == null)
                    __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(1, System.Guid.Empty, DirectBindMessageBoxPort, 0, __ctx0__);
                __ctx1__.__InvoiceMessage = new __messagetype_Schemas_Invoice("InvoiceMessage", __ctx1__);
                __ctx1__.__InvoiceMessage.CopyFrom((Microsoft.XLANGs.Core.XMessage)Args[1]);
                __ctx1__.RefMessage(__ctx1__.__InvoiceMessage);
                __ctx1__.__InvoiceMessage.ConstructionCompleteEvent();
                ShippingPortHandle.BindingInfo = Args[2];
                __ctx1__.__OrderCorrelation = (Microsoft.XLANGs.Core.Correlation)Args[0];
                if (IsExeced)
                    __ctx1__.__OrderCorrelation.InitializeSubscriptions(new Microsoft.XLANGs.Core.Subscription[] { __ctx0__.__subWrapper0.getSubscription(this) }, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if ( !PreProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[2],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 4;
            case 4:
                {
                    __messagetype_Schemas_ShippingAdvice __ShippingMessage = new __messagetype_Schemas_ShippingAdvice("ShippingMessage", __ctx1__);

                    ApplyTransform(typeof(Orchestrations.Transform_InvoiceToShippingNotice), new object[] {__ShippingMessage.part}, new object[] {__ctx1__.__InvoiceMessage.part});

                    if (__ctx1__.__ShippingMessage != null)
                        __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = __ShippingMessage;
                    __ctx1__.RefMessage(__ctx1__.__ShippingMessage);
                }
                __ctx1__.__ShippingMessage.ConstructionCompleteEvent(true);
                if ( !PostProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Construct);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    Tracker.FireEvent(__eventLocations[3],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 6;
            case 6:
                if ( !PreProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[4],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 7;
            case 7:
                __timeout0__ = __ctx1__.PostTimeout(System.DateTime.UtcNow.Add(new System.TimeSpan(0, 0, 30)));
                if ( !PostProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 8;
            case 8:
                if (!Microsoft.XLANGs.Core.PortBase.GetMessageIdForSubscription(LookupSubscription(__timeout0__) , __seg__, __ctx1__, out __msgEnv__ , _locations[0]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 9;
            case 9:
                DeleteTimeout(LookupSubscription(__timeout0__));
                if ( !PostProgressInc( __seg__, __ctx__, 10 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 10;
            case 10:
                if ( !PreProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[5],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 11;
            case 11:
                if ( !PreProgressInc( __seg__, __ctx__, 12 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[6],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 12;
            case 12:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 13 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 13;
            case 13:
                if ( !PreProgressInc( __seg__, __ctx__, 14 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                ShippingPortHandle.SendMessage(0, __ctx1__.__ShippingMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 14;
            case 14:
                if ( !PreProgressInc( __seg__, __ctx__, 15 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__ShippingMessage);
                    __edata.PortName = @"ShippingPortHandle";
                    Tracker.FireEvent(__eventLocations[7],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__ShippingMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__ShippingMessage);
                    __ctx1__.__ShippingMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 15;
            case 15:
                if ( !PreProgressInc( __seg__, __ctx__, 16 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[8],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 16;
            case 16:
                __timeout1__ = __ctx1__.PostTimeout(System.DateTime.UtcNow.Add(new System.TimeSpan(0, 0, 30)));
                if ( !PostProgressInc( __seg__, __ctx__, 17 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 17;
            case 17:
                if (!Microsoft.XLANGs.Core.PortBase.GetMessageIdForSubscription(LookupSubscription(__timeout1__) , __seg__, __ctx1__, out __msgEnv__ , _locations[1]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 18 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 18;
            case 18:
                DeleteTimeout(LookupSubscription(__timeout1__));
                if ( !PostProgressInc( __seg__, __ctx__, 19 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 19;
            case 19:
                if ( !PreProgressInc( __seg__, __ctx__, 20 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[9],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 20;
            case 20:
                if ( !PreProgressInc( __seg__, __ctx__, 21 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[10],__eventData[6],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 21;
            case 21:
                if (!DirectBindMessageBoxPort.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__, _locations[2]))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx0__ != null && __ctx0__.__subWrapper0 != null)
                {
                    __ctx0__.__subWrapper0.Destroy(this, __ctx0__);
                    __ctx0__.__subWrapper0 = null;
                }
                if (__ctx1__.__POMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                __ctx1__.__POMessage = new __messagetype_Schemas_PurchaseOrder("POMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__POMessage);
                DirectBindMessageBoxPort.ReceiveMessage(0, __msgEnv__, __ctx1__.__POMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if (DirectBindMessageBoxPort != null)
                {
                    DirectBindMessageBoxPort.Close(__ctx1__, __seg__);
                    DirectBindMessageBoxPort = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 22 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 22;
            case 22:
                if ( !PreProgressInc( __seg__, __ctx__, 23 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"DirectBindMessageBoxPort";
                    Tracker.FireEvent(__eventLocations[11],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 23;
            case 23:
                if ( !PreProgressInc( __seg__, __ctx__, 24 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[12],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 24;
            case 24:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 25 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 25;
            case 25:
                if ( !PreProgressInc( __seg__, __ctx__, 26 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                POReportPort.SendMessage(2, __ctx1__.__POMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.NextActivityPersists );
                if (POReportPort != null)
                {
                    POReportPort.Close(__ctx1__, __seg__);
                    POReportPort = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 26;
            case 26:
                if ( !PreProgressInc( __seg__, __ctx__, 27 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"POReportPort";
                    Tracker.FireEvent(__eventLocations[13],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 27;
            case 27:
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    Tracker.FireEvent(__eventLocations[0],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 28 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 28;
            case 28:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 29 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 29;
            case 29:
                if ( !PreProgressInc( __seg__, __ctx__, 30 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 30;
            case 30:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
        private static Microsoft.XLANGs.Core.CachedObject[] _locations = new Microsoft.XLANGs.Core.CachedObject[] {
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{99696A79-F8CC-423A-A9E5-1556D00DCDC2}")),
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{3B32538C-11C7-407B-A5E6-2FC275B17FE6}")),
            new Microsoft.XLANGs.Core.CachedObject(new System.Guid("{D3A09857-8DF1-49A9-9433-22723EDECBE0}"))
        };

    }

    [System.SerializableAttribute]
    sealed public class __Schemas_PurchaseOrder__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.PurchaseOrder _schema = new Schemas.PurchaseOrder();

        public __Schemas_PurchaseOrder__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.PurchaseOrder",
        new System.Type[]{
            typeof(Schemas.PurchaseOrder)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_PurchaseOrder__)
        },
        0,
        @"http://Schemas.PurchaseOrder#PO"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_PurchaseOrder : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_PurchaseOrder__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_PurchaseOrder__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_PurchaseOrder(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_Invoice__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.Invoice _schema = new Schemas.Invoice();

        public __Schemas_Invoice__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.Invoice",
        new System.Type[]{
            typeof(Schemas.Invoice)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_Invoice__)
        },
        0,
        @"http://Schemas.Invoice#Invoice"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_Invoice : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_Invoice__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_Invoice__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_Invoice(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed public class _MODULE_PROXY_ { }
}
