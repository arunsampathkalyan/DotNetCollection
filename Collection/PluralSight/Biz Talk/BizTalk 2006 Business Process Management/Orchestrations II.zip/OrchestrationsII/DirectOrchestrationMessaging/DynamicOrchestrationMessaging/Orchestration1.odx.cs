
#pragma warning disable 162

namespace DynamicOrchestrationMessaging
{

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(DynamicOrchestrationMessaging.__messagetype_Schemas_Invoice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class DynamicPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public DynamicPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public DynamicPortType(DynamicPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            DynamicPortType p = new DynamicPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(DynamicPortType),
            typeof(__messagetype_Schemas_Invoice),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(DynamicOrchestrationMessaging.__messagetype_Schemas_PurchaseOrder)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal, "")]
    [System.SerializableAttribute]
    sealed internal class POReceivePortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public POReceivePortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public POReceivePortType(POReceivePortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            POReceivePortType p = new POReceivePortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(POReceivePortType),
            typeof(__messagetype_Schemas_PurchaseOrder),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.PortTypeOperationAttribute(
        "Operation_1",
        new System.Type[]{
            typeof(DynamicOrchestrationMessaging.__messagetype_Schemas_Invoice)
        },
        new string[]{
        }
    )]
    [Microsoft.XLANGs.BaseTypes.PortTypeAttribute(Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic, "")]
    [System.SerializableAttribute]
    sealed public class RoleLinkPortType : Microsoft.BizTalk.XLANGs.BTXEngine.BTXPortBase
    {
        public RoleLinkPortType(int portInfo, Microsoft.XLANGs.Core.IServiceProxy s)
            : base(portInfo, s)
        { }
        public RoleLinkPortType(RoleLinkPortType p)
            : base(p)
        { }

        public override Microsoft.XLANGs.Core.PortBase Clone()
        {
            RoleLinkPortType p = new RoleLinkPortType(this);
            return p;
        }

        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic;
        #region port reflection support
        static public Microsoft.XLANGs.Core.OperationInfo Operation_1 = new Microsoft.XLANGs.Core.OperationInfo
        (
            "Operation_1",
            System.Web.Services.Description.OperationFlow.OneWay,
            typeof(RoleLinkPortType),
            typeof(__messagetype_Schemas_Invoice),
            null,
            new System.Type[]{},
            new string[]{}
        );
        static public System.Collections.Hashtable OperationsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[ "Operation_1" ] = Operation_1;
                return h;
            }
        }
        #endregion // port reflection support
    }

    [Microsoft.XLANGs.BaseTypes.ServiceLinkTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceLinkTypeRoleAttribute(
        "Provider",
        new System.Type[] {
            typeof(DynamicOrchestrationMessaging.RoleLinkPortType)
        }
    )]
    sealed internal class ReceiverRoleLinkType : Microsoft.XLANGs.Core.ServiceLinkType
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        sealed public class Provider : Microsoft.XLANGs.Core.Role
        {
            static private System.Type[] _portTypes = new System.Type[] {
                typeof(DynamicOrchestrationMessaging.RoleLinkPortType)
            };
            public override System.Type[] PortTypes { get { return _portTypes; } }
            static public System.Type[] PortTypesList { get { return _portTypes; } }
        }
    }
    //#line 277 "D:\demos\orchestrationsII\DirectOrchestrationMessaging\DynamicOrchestrationMessaging\Orchestration1.odx"
    [Microsoft.XLANGs.BaseTypes.StaticSubscriptionAttribute(
        0, "POReceivePort", "Operation_1", -1, -1, true
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eDynamic,
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.ePort|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(DynamicOrchestrationMessaging.POReceivePortType),
            typeof(DynamicOrchestrationMessaging.DynamicPortType),
            typeof(DynamicOrchestrationMessaging.RoleLinkPortType)
        },
        new System.String[] {
            "POReceivePort",
            "FirstDynamicPort",
            "__ReceiverRoleLink_RoleLinkPortType"
        },
        new System.Type[] {
            null,
            null,
            typeof(DynamicOrchestrationMessaging.ReceiverRoleLinkType.Provider)
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServicePortsAttribute(
        new Microsoft.XLANGs.BaseTypes.EXLangSParameter[] {
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eServiceLink|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses
        },
        new System.Type[] {
            typeof(DynamicOrchestrationMessaging.ReceiverRoleLinkType.Provider)
        },
        new System.String[] {
            "ReceiverRoleLink"
        },
        new System.Type[] {
            null
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceCallTreeAttribute(
        new System.Type[] {
        },
        new System.Type[] {
        },
        new System.Type[] {
        }
    )]
    [Microsoft.XLANGs.BaseTypes.ServiceAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal,
        Microsoft.XLANGs.BaseTypes.EXLangSServiceInfo.eNone
    )]
    [System.SerializableAttribute]
    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed internal class Orchestration1 : Microsoft.BizTalk.XLANGs.BTXEngine.BTXService
    {
        public static readonly Microsoft.XLANGs.BaseTypes.EXLangSAccess __access = Microsoft.XLANGs.BaseTypes.EXLangSAccess.eInternal;
        public static readonly bool __execable = false;
        [Microsoft.XLANGs.BaseTypes.CallCompensationAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSCallCompensationInfo.eNone,
            new System.String[] {
            },
            new System.String[] {
            }
        )]
        public static void __bodyProxy()
        {
        }
        private static System.Guid _serviceId = Microsoft.XLANGs.Core.HashHelper.HashServiceType(typeof(Orchestration1));
        private static volatile System.Guid[] _activationSubIds;

        private static new object _lockIdentity = new object();

        public static System.Guid UUID { get { return _serviceId; } }
        public override System.Guid ServiceId { get { return UUID; } }

        protected override System.Guid[] ActivationSubGuids
        {
            get { return _activationSubIds; }
            set { _activationSubIds = value; }
        }

        protected override object StaleStateLock
        {
            get { return _lockIdentity; }
        }

        protected override bool HasActivation { get { return true; } }

        internal bool IsExeced = false;

        static Orchestration1()
        {
            Microsoft.BizTalk.XLANGs.BTXEngine.BTXService.CacheStaticState( _serviceId );
        }

        private void ConstructorHelper()
        {
            _segments = new Microsoft.XLANGs.Core.Segment[] {
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment0), 0, 0, 0),
                new Microsoft.XLANGs.Core.Segment( new Microsoft.XLANGs.Core.Segment.SegmentCode(this.segment1), 1, 1, 1)
            };

            _Locks = 1;
            _rootContext = new __Orchestration1_root_0(this);
            _stateMgrs = new Microsoft.XLANGs.Core.IStateManager[2];
            _stateMgrs[0] = _rootContext;
            FinalConstruct();
        }

        public Orchestration1(System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXSession session, Microsoft.BizTalk.XLANGs.BTXEngine.BTXEvents tracker)
            : base(instanceId, session, "Orchestration1", tracker)
        {
            ConstructorHelper();
        }

        public Orchestration1(int callIndex, System.Guid instanceId, Microsoft.BizTalk.XLANGs.BTXEngine.BTXService parent)
            : base(callIndex, instanceId, parent, "Orchestration1")
        {
            ConstructorHelper();
        }

        private const string _symInfo = @"
<XsymFile>
<ProcessFlow xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>      <shapeType>RootShape</shapeType>      <ShapeID>97a141da-a9a8-4fe7-9c76-46a96bff2080</ShapeID>      
<children>                          
<ShapeInfo>      <shapeType>ReceiveShape</shapeType>      <ShapeID>19c17b70-ff52-4619-85fb-8d897026a228</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Receive_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>ConstructShape</shapeType>      <ShapeID>5e42e0f7-790a-47d8-9b89-ea5671483022</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>ConstructMessage_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>TransformShape</shapeType>      <ShapeID>45b2249f-dc54-40b7-931d-add80049081a</ShapeID>      <ParentLink>ComplexStatement_Statement</ParentLink>                <shapeText>Transform_1</shapeText>                  
<children>                          
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>abd875b2-11b4-4f55-80fc-350bf68a1917</ShapeID>      <ParentLink>Transform_InputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessagePartRefShape</shapeType>      <ShapeID>770abfdd-c654-4597-b237-688177fb9ed0</ShapeID>      <ParentLink>Transform_OutputMessagePartRef</ParentLink>                <shapeText>MessagePartReference_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>MessageRefShape</shapeType>      <ShapeID>60de0b9d-6aad-4413-83c4-ebb45e588419</ShapeID>      <ParentLink>Construct_MessageRef</ParentLink>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>VariableAssignmentShape</shapeType>      <ShapeID>1beee5d4-da95-48fd-9bb8-0ee6da1c926b</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Expression_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>8836e1fb-2cda-49f5-aa21-21d3a75eb5ff</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_1</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>VariableAssignmentShape</shapeType>      <ShapeID>5a381e89-4fba-4ecd-87c1-a1f07da74462</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Expression_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                            
<ShapeInfo>      <shapeType>SendShape</shapeType>      <ShapeID>66a946b0-a801-4d97-a191-67b591c1cc7d</ShapeID>      <ParentLink>ServiceBody_Statement</ParentLink>                <shapeText>Send_2</shapeText>                  
<children>                </children>
  </ShapeInfo>
                  </children>
  </ProcessFlow>
<Metadata>

<TrkMetadata>
<ActionName>'Orchestration1'</ActionName><IsAtomic>0</IsAtomic><Line>277</Line><Position>14</Position><ShapeID>'e211a116-cb8b-44e7-a052-0de295aa0001'</ShapeID>
</TrkMetadata>

<TrkMetadata>
<Line>291</Line><Position>22</Position><ShapeID>'19c17b70-ff52-4619-85fb-8d897026a228'</ShapeID>
<Messages>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>293</Line><Position>13</Position><ShapeID>'5e42e0f7-790a-47d8-9b89-ea5671483022'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
	<MsgInfo><name>POMessage</name><part>part</part><schema>Schemas.PurchaseOrder</schema><direction>In</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>299</Line><Position>66</Position><ShapeID>'1beee5d4-da95-48fd-9bb8-0ee6da1c926b'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>301</Line><Position>13</Position><ShapeID>'8836e1fb-2cda-49f5-aa21-21d3a75eb5ff'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>303</Line><Position>75</Position><ShapeID>'5a381e89-4fba-4ecd-87c1-a1f07da74462'</ShapeID>
<Messages>
</Messages>
</TrkMetadata>

<TrkMetadata>
<Line>305</Line><Position>13</Position><ShapeID>'66a946b0-a801-4d97-a191-67b591c1cc7d'</ShapeID>
<Messages>
	<MsgInfo><name>InvoiceMessage</name><part>part</part><schema>Schemas.Invoice</schema><direction>Out</direction></MsgInfo>
</Messages>
</TrkMetadata>
</Metadata>
</XsymFile>";

        public override string odXml { get { return _symODXML; } }

        private const string _symODXML = @"
<?xml version='1.0' encoding='utf-8' standalone='yes'?>
<om:MetaModel MajorVersion='1' MinorVersion='3' Core='2b131234-7959-458d-834f-2dc0769ce683' ScheduleModel='66366196-361d-448d-976f-cab5e87496d2' xmlns:om='http://schemas.microsoft.com/BizTalk/2003/DesignerData'>
    <om:Element Type='Module' OID='d3bbcb89-8b96-48ad-b77b-1a87d9713bd0' LowerBound='1.1' HigherBound='65.1'>
        <om:Property Name='ReportToAnalyst' Value='True' />
        <om:Property Name='Name' Value='DynamicOrchestrationMessaging' />
        <om:Property Name='Signal' Value='False' />
        <om:Element Type='PortType' OID='46b385bc-26e6-450b-8730-da3ffefe3fe8' ParentLink='Module_PortType' LowerBound='4.1' HigherBound='11.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='DynamicPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='5f261ea6-8d96-4daa-b57e-7f2b8f4b7984' ParentLink='PortType_OperationDeclaration' LowerBound='6.1' HigherBound='10.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='5373fcdf-9edc-4d15-97b8-5087f225d747' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='8.13' HigherBound='8.28'>
                    <om:Property Name='Ref' Value='Schemas.Invoice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='a8f31464-0381-4416-afa5-03c50f1b5d9c' ParentLink='Module_PortType' LowerBound='11.1' HigherBound='18.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='POReceivePortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='e74d8ef3-ab7c-4d40-ab5f-ab80ba45a43b' ParentLink='PortType_OperationDeclaration' LowerBound='13.1' HigherBound='17.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='7daad169-c67f-439b-bf18-910b8e4180fb' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='15.13' HigherBound='15.34'>
                    <om:Property Name='Ref' Value='Schemas.PurchaseOrder' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='PortType' OID='8eb115dd-a863-4532-9c8e-d07599df10ee' ParentLink='Module_PortType' LowerBound='18.1' HigherBound='25.1'>
            <om:Property Name='Synchronous' Value='False' />
            <om:Property Name='TypeModifier' Value='Public' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='RoleLinkPortType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='OperationDeclaration' OID='6c96d85d-be49-45ef-b9b1-697a5066b02e' ParentLink='PortType_OperationDeclaration' LowerBound='20.1' HigherBound='24.1'>
                <om:Property Name='OperationType' Value='OneWay' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Operation_1' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='MessageRef' OID='4c8342cf-603d-432b-9a9f-4e3687b48c26' ParentLink='OperationDeclaration_RequestMessageRef' LowerBound='22.13' HigherBound='22.28'>
                    <om:Property Name='Ref' Value='Schemas.Invoice' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Request' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='ServiceDeclaration' OID='924723f6-3817-4fbc-a065-1b939a2c8627' ParentLink='Module_ServiceDeclaration' LowerBound='32.1' HigherBound='64.1'>
            <om:Property Name='InitializedTransactionType' Value='False' />
            <om:Property Name='IsInvokable' Value='False' />
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='Orchestration1' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='ServiceLinkDeclaration' OID='f2865ad0-62e9-4ca8-876e-047e4f5ea87a' ParentLink='ServiceDeclaration_ServiceLinkDeclaration' LowerBound='35.1' HigherBound='36.1'>
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='RoleName' Value='Provider' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='DynamicOrchestrationMessaging.ReceiverRoleLinkType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ReceiverRoleLink' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='30c3d32f-6721-40ac-a003-6914d7d23dd0' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='40.1' HigherBound='41.1'>
                <om:Property Name='Type' Value='Schemas.PurchaseOrder' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='140c5e83-d58c-4268-bb1c-c2af97e80f56' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='41.1' HigherBound='42.1'>
                <om:Property Name='Type' Value='Schemas.Invoice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='InvoiceMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='0cbda078-f563-4e19-abab-e706404b8579' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='42.1' HigherBound='43.1'>
                <om:Property Name='Type' Value='Schemas.Invoice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Invoice2' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='MessageDeclaration' OID='8b3c289a-0781-4012-88e2-dcedde709fd2' ParentLink='ServiceDeclaration_MessageDeclaration' LowerBound='43.1' HigherBound='44.1'>
                <om:Property Name='Type' Value='Schemas.ShippingAdvice' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='ShippingMessage' />
                <om:Property Name='Signal' Value='True' />
            </om:Element>
            <om:Element Type='ServiceBody' OID='97a141da-a9a8-4fe7-9c76-46a96bff2080' ParentLink='ServiceDeclaration_ServiceBody'>
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='Receive' OID='19c17b70-ff52-4619-85fb-8d897026a228' ParentLink='ServiceBody_Statement' LowerBound='46.1' HigherBound='48.1'>
                    <om:Property Name='Activate' Value='True' />
                    <om:Property Name='PortName' Value='POReceivePort' />
                    <om:Property Name='MessageName' Value='POMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Receive_1' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Construct' OID='5e42e0f7-790a-47d8-9b89-ea5671483022' ParentLink='ServiceBody_Statement' LowerBound='48.1' HigherBound='54.1'>
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='ConstructMessage_1' />
                    <om:Property Name='Signal' Value='True' />
                    <om:Element Type='Transform' OID='45b2249f-dc54-40b7-931d-add80049081a' ParentLink='ComplexStatement_Statement' LowerBound='51.1' HigherBound='53.1'>
                        <om:Property Name='ClassName' Value='Orchestrations.TransformPOToInvoice' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Name' Value='Transform_1' />
                        <om:Property Name='Signal' Value='True' />
                        <om:Element Type='MessagePartRef' OID='abd875b2-11b4-4f55-80fc-350bf68a1917' ParentLink='Transform_InputMessagePartRef' LowerBound='52.83' HigherBound='52.92'>
                            <om:Property Name='MessageRef' Value='POMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_1' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                        <om:Element Type='MessagePartRef' OID='770abfdd-c654-4597-b237-688177fb9ed0' ParentLink='Transform_OutputMessagePartRef' LowerBound='52.28' HigherBound='52.42'>
                            <om:Property Name='MessageRef' Value='InvoiceMessage' />
                            <om:Property Name='ReportToAnalyst' Value='True' />
                            <om:Property Name='Name' Value='MessagePartReference_2' />
                            <om:Property Name='Signal' Value='False' />
                        </om:Element>
                    </om:Element>
                    <om:Element Type='MessageRef' OID='60de0b9d-6aad-4413-83c4-ebb45e588419' ParentLink='Construct_MessageRef' LowerBound='49.23' HigherBound='49.37'>
                        <om:Property Name='Ref' Value='InvoiceMessage' />
                        <om:Property Name='ReportToAnalyst' Value='True' />
                        <om:Property Name='Signal' Value='False' />
                    </om:Element>
                </om:Element>
                <om:Element Type='VariableAssignment' OID='1beee5d4-da95-48fd-9bb8-0ee6da1c926b' ParentLink='ServiceBody_Statement' LowerBound='54.1' HigherBound='56.1'>
                    <om:Property Name='Expression' Value='FirstDynamicPort(Microsoft.XLANGs.BaseTypes.Address) = &quot;FILE://c:\\demos\\output\\orchbinding_dynamic\\dynamicmessaging.txt&quot;;' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Expression_1' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
                <om:Element Type='Send' OID='8836e1fb-2cda-49f5-aa21-21d3a75eb5ff' ParentLink='ServiceBody_Statement' LowerBound='56.1' HigherBound='58.1'>
                    <om:Property Name='PortName' Value='FirstDynamicPort' />
                    <om:Property Name='MessageName' Value='InvoiceMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_1' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='VariableAssignment' OID='5a381e89-4fba-4ecd-87c1-a1f07da74462' ParentLink='ServiceBody_Statement' LowerBound='58.1' HigherBound='60.1'>
                    <om:Property Name='Expression' Value='ReceiverRoleLink(Microsoft.XLANGs.BaseTypes.DestinationParty) = new Microsoft.XLANGs.BaseTypes.Party(&quot;TechEd&quot;, &quot;ConferenceName&quot;);' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Expression_2' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
                <om:Element Type='Send' OID='66a946b0-a801-4d97-a191-67b591c1cc7d' ParentLink='ServiceBody_Statement' LowerBound='60.1' HigherBound='62.1'>
                    <om:Property Name='MessageName' Value='InvoiceMessage' />
                    <om:Property Name='OperationName' Value='Operation_1' />
                    <om:Property Name='OperationMessageName' Value='Request' />
                    <om:Property Name='ServiceLinkName' Value='ReceiverRoleLink' />
                    <om:Property Name='ServiceLinkPortTypeName' Value='DynamicOrchestrationMessaging.RoleLinkPortType' />
                    <om:Property Name='ServiceLinkRoleName' Value='Provider' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='Send_2' />
                    <om:Property Name='Signal' Value='True' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='3e640589-04bd-46fd-a849-1614b1ad7c88' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='36.1' HigherBound='38.1'>
                <om:Property Name='PortModifier' Value='Uses' />
                <om:Property Name='Orientation' Value='Right' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='DynamicOrchestrationMessaging.DynamicPortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='FirstDynamicPort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='PhysicalBindingAttribute' OID='9ceb1766-8110-4afd-8689-df3c58d22ed3' ParentLink='PortDeclaration_CLRAttribute' LowerBound='36.1' HigherBound='37.1'>
                    <om:Property Name='InPipeline' Value='Microsoft.BizTalk.DefaultPipelines.XMLReceive' />
                    <om:Property Name='OutPipeline' Value='Microsoft.BizTalk.DefaultPipelines.XMLTransmit' />
                    <om:Property Name='TransportType' Value='HTTP' />
                    <om:Property Name='URI' Value='http://tempURI' />
                    <om:Property Name='IsDynamic' Value='True' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
            <om:Element Type='PortDeclaration' OID='29f89ddd-985e-419d-9f3b-864cca854786' ParentLink='ServiceDeclaration_PortDeclaration' LowerBound='38.1' HigherBound='40.1'>
                <om:Property Name='PortModifier' Value='Implements' />
                <om:Property Name='Orientation' Value='Left' />
                <om:Property Name='PortIndex' Value='-1' />
                <om:Property Name='IsWebPort' Value='False' />
                <om:Property Name='OrderedDelivery' Value='False' />
                <om:Property Name='DeliveryNotification' Value='None' />
                <om:Property Name='Type' Value='DynamicOrchestrationMessaging.POReceivePortType' />
                <om:Property Name='ParamDirection' Value='In' />
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='POReceivePort' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='LogicalBindingAttribute' OID='925b67b6-17cc-46e8-aa7d-1e204b3bff27' ParentLink='PortDeclaration_CLRAttribute' LowerBound='38.1' HigherBound='39.1'>
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
        <om:Element Type='ServiceLinkType' OID='bfe84e9d-b340-45ff-9d75-9ea595c2ae23' ParentLink='Module_ServiceLinkType' LowerBound='25.1' HigherBound='32.1'>
            <om:Property Name='TypeModifier' Value='Internal' />
            <om:Property Name='ReportToAnalyst' Value='True' />
            <om:Property Name='Name' Value='ReceiverRoleLinkType' />
            <om:Property Name='Signal' Value='False' />
            <om:Element Type='RoleDeclaration' OID='d872cad6-7b31-4a7c-b03a-04c782334ec8' ParentLink='ServiceLinkType_RoleDeclaration' LowerBound='27.1' HigherBound='31.1'>
                <om:Property Name='ReportToAnalyst' Value='True' />
                <om:Property Name='Name' Value='Provider' />
                <om:Property Name='Signal' Value='False' />
                <om:Element Type='PortTypeRef' OID='a771ed56-8f4e-4b3a-b74e-1cb9600d1529' ParentLink='RoleDeclaration_PortTypeRef' LowerBound='29.13' HigherBound='29.29'>
                    <om:Property Name='Ref' Value='DynamicOrchestrationMessaging.RoleLinkPortType' />
                    <om:Property Name='ReportToAnalyst' Value='True' />
                    <om:Property Name='Name' Value='PortTypeRef_1' />
                    <om:Property Name='Signal' Value='False' />
                </om:Element>
            </om:Element>
        </om:Element>
    </om:Element>
</om:MetaModel>
";

        [System.SerializableAttribute]
        public class __Orchestration1_root_0 : Microsoft.XLANGs.Core.ServiceContext
        {
            public __Orchestration1_root_0(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "Orchestration1")
            {
            }

            public override int Index { get { return 0; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[0]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[0]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                Orchestration1 __svc__ = (Orchestration1)_service;
                __Orchestration1_root_0 __ctx0__ = (__Orchestration1_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.__ReceiverRoleLink_RoleLinkPortType != null)
                {
                    __svc__.__ReceiverRoleLink_RoleLinkPortType.Close(this, null);
                    __svc__.__ReceiverRoleLink_RoleLinkPortType = null;
                }
                if (__svc__.POReceivePort != null)
                {
                    __svc__.POReceivePort.Close(this, null);
                    __svc__.POReceivePort = null;
                }
                base.Finally();
            }

            internal Microsoft.XLANGs.Core.SubscriptionWrapper __subWrapper0;
        }


        [System.SerializableAttribute]
        public class __Orchestration1_1 : Microsoft.XLANGs.Core.ExceptionHandlingContext
        {
            public __Orchestration1_1(Microsoft.XLANGs.Core.Service svc)
                : base(svc, "Orchestration1")
            {
            }

            public override int Index { get { return 1; } }

            public override bool CombineParentCommit { get { return true; } }

            public override Microsoft.XLANGs.Core.Segment InitialSegment
            {
                get { return _service._segments[1]; }
            }
            public override Microsoft.XLANGs.Core.Segment FinalSegment
            {
                get { return _service._segments[1]; }
            }

            public override int CompensationSegment { get { return -1; } }
            public override bool OnError()
            {
                Finally();
                return false;
            }

            public override void Finally()
            {
                Orchestration1 __svc__ = (Orchestration1)_service;
                __Orchestration1_1 __ctx1__ = (__Orchestration1_1)(__svc__._stateMgrs[1]);
                __Orchestration1_root_0 __ctx0__ = (__Orchestration1_root_0)(__svc__._stateMgrs[0]);

                if (__svc__.FirstDynamicPort != null)
                {
                    __svc__.FirstDynamicPort.Close(this, null);
                    __svc__.FirstDynamicPort = null;
                }
                if (__ctx1__ != null) __ctx1__.ReceiverRoleLink = null;
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                base.Finally();
            }

            [Microsoft.XLANGs.Core.UserVariableAttribute("ReceiverRoleLink")]
            internal Microsoft.XLANGs.Core.ServiceLink ReceiverRoleLink;
            [Microsoft.XLANGs.Core.UserVariableAttribute("POMessage")]
            public __messagetype_Schemas_PurchaseOrder __POMessage;
            [Microsoft.XLANGs.Core.UserVariableAttribute("InvoiceMessage")]
            public __messagetype_Schemas_Invoice __InvoiceMessage;
        }

        private static Microsoft.XLANGs.Core.CorrelationType[] _correlationTypes = null;
        public override Microsoft.XLANGs.Core.CorrelationType[] CorrelationTypes { get { return _correlationTypes; } }

        private static System.Guid[] _convoySetIds;

        public override System.Guid[] ConvoySetGuids
        {
            get { return _convoySetIds; }
            set { _convoySetIds = value; }
        }

        public static object[] StaticConvoySetInformation
        {
            get {
                return null;
            }
        }

        [Microsoft.XLANGs.BaseTypes.LogicalBindingAttribute()]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eImplements
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("POReceivePort")]
        internal POReceivePortType POReceivePort;
        [Microsoft.XLANGs.BaseTypes.PhysicalBindingAttribute(typeof(Microsoft.BizTalk.DefaultPipelines.XMLTransmit))]
        [Microsoft.XLANGs.BaseTypes.PortAttribute(
            Microsoft.XLANGs.BaseTypes.EXLangSParameter.eUses|Microsoft.XLANGs.BaseTypes.EXLangSParameter.eDynamic
        )]
        [Microsoft.XLANGs.Core.UserVariableAttribute("FirstDynamicPort")]
        internal DynamicPortType FirstDynamicPort;  // lock index = 0
        [Microsoft.XLANGs.Core.UserVariableAttribute("__ReceiverRoleLink_RoleLinkPortType")]
        internal RoleLinkPortType __ReceiverRoleLink_RoleLinkPortType;

        public static Microsoft.XLANGs.Core.PortInfo[] _portInfo = new Microsoft.XLANGs.Core.PortInfo[] {
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {POReceivePortType.Operation_1},
                                               typeof(Orchestration1).GetField("POReceivePort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.implements,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(Orchestration1), "POReceivePort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {DynamicPortType.Operation_1},
                                               typeof(Orchestration1).GetField("FirstDynamicPort", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               true,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(Orchestration1), "FirstDynamicPort"),
                                               null),
            new Microsoft.XLANGs.Core.PortInfo(new Microsoft.XLANGs.Core.OperationInfo[] {RoleLinkPortType.Operation_1},
                                               typeof(Orchestration1).GetField("__ReceiverRoleLink_RoleLinkPortType", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance),
                                               Microsoft.XLANGs.BaseTypes.Polarity.uses,
                                               false,
                                               Microsoft.XLANGs.Core.HashHelper.HashPort(typeof(Orchestration1), "__ReceiverRoleLink_RoleLinkPortType"),
                                               typeof(ReceiverRoleLinkType.Provider))
        };

        public override Microsoft.XLANGs.Core.PortInfo[] PortInformation
        {
            get { return _portInfo; }
        }

        static public System.Collections.Hashtable PortsInformation
        {
            get
            {
                System.Collections.Hashtable h = new System.Collections.Hashtable();
                h[_portInfo[0].Name] = _portInfo[0];
                h[_portInfo[1].Name] = _portInfo[1];
                h[_portInfo[2].Name] = _portInfo[2];
                return h;
            }
        }

        public static System.Type[] InvokedServicesTypes
        {
            get
            {
                return new System.Type[] {
                    // type of each service invoked by this service
                };
            }
        }

        public static System.Type[] CalledServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static System.Type[] ExecedServicesTypes
        {
            get
            {
                return new System.Type[] {
                };
            }
        }

        public static object[] StaticSubscriptionsInformation {
            get {
                return new object[1]{
                     new object[5] { _portInfo[0], 0, null , -1, true }
                };
            }
        }

        public static Microsoft.XLANGs.RuntimeTypes.Location[] __eventLocations = new Microsoft.XLANGs.RuntimeTypes.Location[] {
            new Microsoft.XLANGs.RuntimeTypes.Location(0, "00000000-0000-0000-0000-000000000000", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(1, "19c17b70-ff52-4619-85fb-8d897026a228", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(2, "19c17b70-ff52-4619-85fb-8d897026a228", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(3, "5e42e0f7-790a-47d8-9b89-ea5671483022", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(4, "5e42e0f7-790a-47d8-9b89-ea5671483022", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(5, "1beee5d4-da95-48fd-9bb8-0ee6da1c926b", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(6, "1beee5d4-da95-48fd-9bb8-0ee6da1c926b", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(7, "8836e1fb-2cda-49f5-aa21-21d3a75eb5ff", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(8, "8836e1fb-2cda-49f5-aa21-21d3a75eb5ff", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(9, "5a381e89-4fba-4ecd-87c1-a1f07da74462", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(10, "5a381e89-4fba-4ecd-87c1-a1f07da74462", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(11, "66a946b0-a801-4d97-a191-67b591c1cc7d", 1, true),
            new Microsoft.XLANGs.RuntimeTypes.Location(12, "66a946b0-a801-4d97-a191-67b591c1cc7d", 1, false),
            new Microsoft.XLANGs.RuntimeTypes.Location(13, "00000000-0000-0000-0000-000000000000", 1, false)
        };

        public override Microsoft.XLANGs.RuntimeTypes.Location[] EventLocations
        {
            get { return __eventLocations; }
        }

        public static Microsoft.XLANGs.RuntimeTypes.EventData[] __eventData = new Microsoft.XLANGs.RuntimeTypes.EventData[] {
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Body),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Receive),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Construct),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Expression),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Expression),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.Start | Microsoft.XLANGs.RuntimeTypes.Operation.Send),
            new Microsoft.XLANGs.RuntimeTypes.EventData( Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Body)
        };

        public static int[] __progressLocation0 = new int[] { 0,0,0,13,13,};
        public static int[] __progressLocation1 = new int[] { 0,0,1,1,2,3,3,4,5,5,6,7,7,7,8,9,9,10,11,11,11,12,13,13,13,13,};

        public static int[][] __progressLocations = new int[2] [] {__progressLocation0,__progressLocation1};
        public override int[][] ProgressLocations {get {return __progressLocations;} }

        public Microsoft.XLANGs.Core.StopConditions segment0(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[0];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[0];
            __Orchestration1_1 __ctx1__ = (__Orchestration1_1)_stateMgrs[1];
            __Orchestration1_root_0 __ctx0__ = (__Orchestration1_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                FirstDynamicPort = new DynamicPortType(1, this);
                POReceivePort = new POReceivePortType(0, this);
                __ReceiverRoleLink_RoleLinkPortType = new RoleLinkPortType(2, this);
                __ctx__.PrologueCompleted = true;
                __ctx0__.__subWrapper0 = new Microsoft.XLANGs.Core.SubscriptionWrapper(ActivationSubGuids[0], POReceivePort, this);
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.Initialized) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.Initialized;
                goto case 1;
            case 1:
                __ctx1__ = new __Orchestration1_1(this);
                _stateMgrs[1] = __ctx1__;
                if ( !PostProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 2;
            case 2:
                __ctx0__.StartContext(__seg__, __ctx1__);
                if ( !PostProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                return Microsoft.XLANGs.Core.StopConditions.Blocked;
            case 3:
                if (!__ctx0__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                __ctx1__.Finally();
                ServiceDone(__seg__, (Microsoft.XLANGs.Core.Context)_stateMgrs[0]);
                __ctx0__.OnCommit();
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }

        public Microsoft.XLANGs.Core.StopConditions segment1(Microsoft.XLANGs.Core.StopConditions stopOn)
        {
            Microsoft.XLANGs.Core.Envelope __msgEnv__ = null;
            Microsoft.XLANGs.Core.Segment __seg__ = _segments[1];
            Microsoft.XLANGs.Core.Context __ctx__ = (Microsoft.XLANGs.Core.Context)_stateMgrs[1];
            __Orchestration1_1 __ctx1__ = (__Orchestration1_1)_stateMgrs[1];
            __Orchestration1_root_0 __ctx0__ = (__Orchestration1_root_0)_stateMgrs[0];

            switch (__seg__.Progress)
            {
            case 0:
                __ctx__.PrologueCompleted = true;
                if ( !PostProgressInc( __seg__, __ctx__, 1 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 1;
            case 1:
                if ( !PreProgressInc( __seg__, __ctx__, 2 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[0],__eventData[0],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 2;
            case 2:
                if ( !PreProgressInc( __seg__, __ctx__, 3 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[1],__eventData[1],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 3;
            case 3:
                if (!POReceivePort.GetMessageId(__ctx0__.__subWrapper0.getSubscription(this), __seg__, __ctx1__, out __msgEnv__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if (__ctx1__.__POMessage != null)
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                __ctx1__.__POMessage = new __messagetype_Schemas_PurchaseOrder("POMessage", __ctx1__);
                __ctx1__.RefMessage(__ctx1__.__POMessage);
                POReceivePort.ReceiveMessage(0, __msgEnv__, __ctx1__.__POMessage, null, (Microsoft.XLANGs.Core.Context)_stateMgrs[1], __seg__);
                if (POReceivePort != null)
                {
                    POReceivePort.Close(__ctx1__, __seg__);
                    POReceivePort = null;
                }
                if ( !PostProgressInc( __seg__, __ctx__, 4 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 4;
            case 4:
                if ( !PreProgressInc( __seg__, __ctx__, 5 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Receive);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    __edata.PortName = @"POReceivePort";
                    Tracker.FireEvent(__eventLocations[2],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 5;
            case 5:
                if ( !PreProgressInc( __seg__, __ctx__, 6 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[3],__eventData[2],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 6;
            case 6:
                {
                    __messagetype_Schemas_Invoice __InvoiceMessage = new __messagetype_Schemas_Invoice("InvoiceMessage", __ctx1__);

                    ApplyTransform(typeof(Orchestrations.TransformPOToInvoice), new object[] {__InvoiceMessage.part}, new object[] {__ctx1__.__POMessage.part});

                    if (__ctx1__.__InvoiceMessage != null)
                        __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = __InvoiceMessage;
                    __ctx1__.RefMessage(__ctx1__.__InvoiceMessage);
                }
                __ctx1__.__InvoiceMessage.ConstructionCompleteEvent(true);
                if ( !PostProgressInc( __seg__, __ctx__, 7 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 7;
            case 7:
                if ( !PreProgressInc( __seg__, __ctx__, 8 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Construct);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.Messages.Add(__ctx1__.__POMessage);
                    Tracker.FireEvent(__eventLocations[4],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__POMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__POMessage);
                    __ctx1__.__POMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 8;
            case 8:
                if ( !PreProgressInc( __seg__, __ctx__, 9 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[5],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 9;
            case 9:
                FirstDynamicPort.SetPropertyValue(typeof(Microsoft.XLANGs.BaseTypes.Address), "FILE://c:\\demos\\output\\orchbinding_dynamic\\dynamicmessaging.txt");
                if ( !PostProgressInc( __seg__, __ctx__, 10 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 10;
            case 10:
                if ( !PreProgressInc( __seg__, __ctx__, 11 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[6],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 11;
            case 11:
                if ( !PreProgressInc( __seg__, __ctx__, 12 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[7],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 12;
            case 12:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 13 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 13;
            case 13:
                if ( !PreProgressInc( __seg__, __ctx__, 14 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                FirstDynamicPort.SendMessage(0, __ctx1__.__InvoiceMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.None );
                if (FirstDynamicPort != null)
                {
                    FirstDynamicPort.Close(__ctx1__, __seg__);
                    FirstDynamicPort = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 14;
            case 14:
                if ( !PreProgressInc( __seg__, __ctx__, 15 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.PortName = @"FirstDynamicPort";
                    Tracker.FireEvent(__eventLocations[8],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 15;
            case 15:
                if ( !PreProgressInc( __seg__, __ctx__, 16 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[9],__eventData[3],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 16;
            case 16:
                __ctx1__.ReceiverRoleLink = new Microsoft.XLANGs.Core.ServiceLink(
                    new Microsoft.XLANGs.Core.PortBase[] {
                        __ReceiverRoleLink_RoleLinkPortType
                    });
                __ctx1__.ReceiverRoleLink.SetPropertyValue(typeof(Microsoft.XLANGs.BaseTypes.DestinationParty), new Microsoft.XLANGs.BaseTypes.Party("TechEd", "ConferenceName"));
                if ( !PostProgressInc( __seg__, __ctx__, 17 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 17;
            case 17:
                if ( !PreProgressInc( __seg__, __ctx__, 18 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[10],__eventData[4],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 18;
            case 18:
                if ( !PreProgressInc( __seg__, __ctx__, 19 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[11],__eventData[5],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 19;
            case 19:
                if (!__ctx1__.PrepareToPendingCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 20 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 20;
            case 20:
                if ( !PreProgressInc( __seg__, __ctx__, 21 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.ReceiverRoleLink[0].SendMessage(0, __ctx1__.__InvoiceMessage, null, null, __ctx1__, __seg__ , Microsoft.XLANGs.Core.ActivityFlags.NextActivityPersists );
                if (__ctx1__ != null) __ctx1__.ReceiverRoleLink = null;
                if (__ReceiverRoleLink_RoleLinkPortType != null)
                {
                    __ReceiverRoleLink_RoleLinkPortType.Close(__ctx1__, __seg__);
                    __ReceiverRoleLink_RoleLinkPortType = null;
                }
                if ((stopOn & Microsoft.XLANGs.Core.StopConditions.OutgoingRqst) != 0)
                    return Microsoft.XLANGs.Core.StopConditions.OutgoingRqst;
                goto case 21;
            case 21:
                if ( !PreProgressInc( __seg__, __ctx__, 22 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                {
                    Microsoft.XLANGs.RuntimeTypes.EventData __edata = new Microsoft.XLANGs.RuntimeTypes.EventData(Microsoft.XLANGs.RuntimeTypes.Operation.End | Microsoft.XLANGs.RuntimeTypes.Operation.Send);
                    __edata.Messages.Add(__ctx1__.__InvoiceMessage);
                    __edata.PortName = @"__ReceiverRoleLink_RoleLinkPortType";
                    Tracker.FireEvent(__eventLocations[12],__edata,_stateMgrs[1].TrackDataStream );
                }
                if (__ctx1__ != null && __ctx1__.__InvoiceMessage != null)
                {
                    __ctx1__.UnrefMessage(__ctx1__.__InvoiceMessage);
                    __ctx1__.__InvoiceMessage = null;
                }
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 22;
            case 22:
                if ( !PreProgressInc( __seg__, __ctx__, 23 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                Tracker.FireEvent(__eventLocations[13],__eventData[6],_stateMgrs[1].TrackDataStream );
                if (IsDebugged)
                    return Microsoft.XLANGs.Core.StopConditions.InBreakpoint;
                goto case 23;
            case 23:
                if (!__ctx1__.CleanupAndPrepareToCommit(__seg__))
                    return Microsoft.XLANGs.Core.StopConditions.Blocked;
                if ( !PostProgressInc( __seg__, __ctx__, 24 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                goto case 24;
            case 24:
                if ( !PreProgressInc( __seg__, __ctx__, 25 ) )
                    return Microsoft.XLANGs.Core.StopConditions.Paused;
                __ctx1__.OnCommit();
                goto case 25;
            case 25:
                __seg__.SegmentDone();
                _segments[0].PredecessorDone(this);
                break;
            }
            return Microsoft.XLANGs.Core.StopConditions.Completed;
        }
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_Invoice__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.Invoice _schema = new Schemas.Invoice();

        public __Schemas_Invoice__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.Invoice",
        new System.Type[]{
            typeof(Schemas.Invoice)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_Invoice__)
        },
        0,
        @"http://Schemas.Invoice#Invoice"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_Invoice : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_Invoice__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_Invoice__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_Invoice(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_PurchaseOrder__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.PurchaseOrder _schema = new Schemas.PurchaseOrder();

        public __Schemas_PurchaseOrder__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.PurchaseOrder",
        new System.Type[]{
            typeof(Schemas.PurchaseOrder)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_PurchaseOrder__)
        },
        0,
        @"http://Schemas.PurchaseOrder#PO"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_PurchaseOrder : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_PurchaseOrder__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_PurchaseOrder__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_PurchaseOrder(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [System.SerializableAttribute]
    sealed public class __Schemas_ShippingAdvice__ : Microsoft.XLANGs.Core.XSDPart
    {
        private static Schemas.ShippingAdvice _schema = new Schemas.ShippingAdvice();

        public __Schemas_ShippingAdvice__(Microsoft.XLANGs.Core.XMessage msg, string name, int index) : base(msg, name, index) { }

        
        #region part reflection support
        public static Microsoft.XLANGs.BaseTypes.SchemaBase PartSchema { get { return (Microsoft.XLANGs.BaseTypes.SchemaBase)_schema; } }
        #endregion // part reflection support
    }

    [Microsoft.XLANGs.BaseTypes.MessageTypeAttribute(
        Microsoft.XLANGs.BaseTypes.EXLangSAccess.ePublic,
        Microsoft.XLANGs.BaseTypes.EXLangSMessageInfo.eThirdKind,
        "Schemas.ShippingAdvice",
        new System.Type[]{
            typeof(Schemas.ShippingAdvice)
        },
        new string[]{
            "part"
        },
        new System.Type[]{
            typeof(__Schemas_ShippingAdvice__)
        },
        0,
        @"http://Schemas.ShippingAdvice#Shipping"
    )]
    [System.SerializableAttribute]
    sealed public class __messagetype_Schemas_ShippingAdvice : Microsoft.BizTalk.XLANGs.BTXEngine.BTXMessage
    {
        public __Schemas_ShippingAdvice__ part;

        private void __CreatePartWrappers()
        {
            part = new __Schemas_ShippingAdvice__(this, "part", 0);
            this.AddPart("part", 0, part);
        }

        public __messagetype_Schemas_ShippingAdvice(string msgName, Microsoft.XLANGs.Core.Context ctx) : base(msgName, ctx)
        {
            __CreatePartWrappers();
        }
    }

    [Microsoft.XLANGs.BaseTypes.BPELExportableAttribute(false)]
    sealed public class _MODULE_PROXY_ { }
}
