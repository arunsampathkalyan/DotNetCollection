Orchestration Direct/dynamic Binding Options Sample
This sample is provided as-is with no warranties implied or given.  
The sample code is provided as a learning tool only.  

Matt Milner
matt@pluralsight.com

http://www.pluralsight.com/matt
http://www.pluralsight.com/blogs/matt

This sample demonstrates several ways of send and receiving messages directly between 
multiple orchestrations with or without actually calling the orchestration.  In addition, the 
dynamic orchestration messaging shows dynamic ports and role links for more flexibility
in messaging.  

Orchestrations
-----------------------------
First Orchestration - initiates the activity in the process by receiving a PO from a 
receive location.  It then uses a shared port to communicate with the second orchestration 
to get an invoice for the PO it just received demonstrating direct binding with a partner 
orchestration using a port on the partner orchestration. 

Next, the first orchestration starts the Third Orchestration and then waits for it to send a message 
on a port that was passed as a parameter to the third orchestration demonstrating a self-correlating direct port.

Finally, the first orchestration sends a message directly to the message box by using direct binding and 
the message is routed to the third orchestrationg based on a correlation set which was passed in as a parameter 
from this first orchestration.  

Second Orchestration - This orchestration receives an activating PO message from the first orchestration 
through a direct binding using defined shared ports and then returns an invoice message on this same 
port back to the calling instance of the first orchestration.  

Third Orchestration - This orchestration is started by the First Orchestration and provided a 
port and correlation set as parameters.  The port is then used to send a shipping notice back 
to the first orchestration using a self-correlated direct port.  Next, a PO is received using 
direct bindign to the message box and following the correlation set passed in.  

Schemas
------------------------------
PurchaseOrder, Invoice, and ShippingAdvice are all simple schemas representing business documents 
in the system.  

PurchasingProperties is the property schema which contains the promoted property definitions 
used in correlating messages.

Setup
------------------------------
Create a folder named "ports" on the root of the C: drive.
Create an OrchDirect folder under C:\ports and give the biztalk service user full control access.
Create a DynamicMessaging folder under c:\ports and give the biztalk service user full control access.  
Create a Microsoft folder under c:\ports and give the biztalk service user full control access.
Build and deploy the solution

Using the Admin tool in BTS 2006, import the binding file "BindingFile.xml" into the 
"DynamicOrchestration" application.

Start the "DynamicOrchestration" application.

Make sure the default BizTalk host instance is started.  
Copy the initiatemessage.xml file into the c:\ports\orchdirect folder to test the direct messagging.  
Copy the initiatemessage.xml file into the c:\ports\dynamicmessaging folder to test the dynamic messagging. 
 
Result for direct messaging: you should see three new messages get written to the c:\ports\OrchDirect folder with a .txt extension.
  One will be the PO, one the invoice, and one the shipping notice. 
Result for dynamic messaging: you should see a message written to the c:\ports\microsoft folder for the role link and the file 
	dynamicmessaging.txt written to the c:\ports folder.  
 
  
Notes
-------------------------------
To use a different folder for your send and receive locations, simply edit the binding file before importing.
However, for the dynamic messaging example, the ports are statically defined in the orchestration.  So, 
you can either edit the orchestration before deploying, or change the port configuration in the admin tool 
after you have deployed the orchestration. 

There are 30 second delays in the first and third orchestration which allow you to use the 
Admin tool to search for subscriptions to see the specific subscriptions that get created for the different 
types of messaging.