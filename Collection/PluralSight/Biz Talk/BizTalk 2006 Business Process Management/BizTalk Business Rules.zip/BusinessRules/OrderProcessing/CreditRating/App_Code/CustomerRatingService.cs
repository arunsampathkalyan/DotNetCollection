using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using BusinessRules;
using Microsoft.RuleEngine;
using System.Xml;

[WebService(Namespace = "http://www.pluralsight.com/samples/creditrating")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class CustomerRatingService : System.Web.Services.WebService
{
    public CustomerRatingService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public CreditRating RateCustomer(string customerid)
    {
        Policy p = new Policy("CustomerCreditRatingPolicy");
        CustomerCreditRating rating = new CustomerCreditRating();
        XmlDocument doc = new XmlDocument();
        doc.LoadXml(String.Format("<ns0:Order xmlns:ns0=\"http://pluralsight.com/abts/order/internal\" xmlns:common=\"http://pluralsight.com/abts/common\">  <OrderDate>2008-01-24T13:28:55</OrderDate>  <CustomerID>{0}</CustomerID></ns0:Order>", customerid));

        TypedXmlDocument typedxml = new TypedXmlDocument("OrderProcessing.Schemas.OrderInternal", doc);

        p.Execute(rating, typedxml);

        return rating.Rating;
    }
    
}


