using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.RuleEngine;

namespace BusinessRules
{
    public class RuleFactCreator : IFactCreator
    {
        

        public object[] CreateFacts(RuleSetInfo ruleSetInfo)
        {
            switch (ruleSetInfo.Name)
            {
                case "OrderValidationPolicy":
                    return new object[] { new OrderValidationResult() };
                    break;
                case "CustomerCreditRatingPolicy":
                    return new object[] { new CustomerCreditRating() };
                    break;
                default:
                    return null;
                    break;
            }
        }

        public Type[] GetFactTypes(RuleSetInfo ruleSetInfo)
        {
            switch (ruleSetInfo.Name)
            {
                case "OrderValidationPolicy":
                    return new Type[] { typeof(OrderValidationResult) };
                    break;
                case "CustomerCreditRatingPolicy":
                    return new Type[] { typeof(CustomerCreditRating) };
                    break;
                default:
                    return new Type[0];
                    break;
            }
           
        }

        
    }
}
