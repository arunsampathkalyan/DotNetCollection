using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRules
{
    public class OrderValidationResult
    {
        private bool _itemPrices;

        public bool ItemPricesValid
        {
            get { return _itemPrices; }
            set { _itemPrices = value; }
        }

    }

    [Serializable]
    public class CustomerCreditRating
    {
        private CreditRating _rating;

        public CreditRating Rating
        {
            get { return _rating; }
            set { _rating = value; }
        }

    }

    [Serializable]
    public enum CreditRating
    {
        Good = 1,
        Fair = 2,
        Poor = 3
    }
}
