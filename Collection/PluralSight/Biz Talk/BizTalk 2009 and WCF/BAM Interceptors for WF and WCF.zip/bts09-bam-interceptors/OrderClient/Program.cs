﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace OrderClient
{
    class Program
    {
        static void Main(string[] args)
        {

            if (args.Length != 1)
            {
                Console.WriteLine("usage: OrderClient <samplefile.xml>");
                return;
            }

            Orders.OrderServiceClient proxy =
                new OrderClient.Orders.OrderServiceClient();
            proxy.Open();
            Orders.InternalOrder order = null;

            XmlSerializer ser = new XmlSerializer(typeof(Orders.InternalOrder));
            using (var file = File.OpenRead(args[0]))
            {
                order = (Orders.InternalOrder)ser.Deserialize(file);
            }
            try
            {
                proxy.SubmitOrder(order);
            }
            finally
            {
                if (proxy.State == System.ServiceModel.CommunicationState.Opened)
                    proxy.Close();
                else
                    proxy.Abort();
            }
            Console.WriteLine("Submitted order to BizTalk");
        }
    }
}
