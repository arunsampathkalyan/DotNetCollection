﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;
using Microsoft.BizTalk.Bam.Interceptors.Workflow;
using System.Workflow.Runtime;
using System.Threading;

namespace BillingApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            using (FileSystemWatcher watcher = new FileSystemWatcher("c:\\ports\\billingdept\\", "*.xml"))
            {
                watcher.Created += new FileSystemEventHandler(watcher_Created);
                watcher.EnableRaisingEvents = true;
                Console.WriteLine("Billing Machine 5000 is online and processing");
                Console.ReadLine();
            }
        }

        static void watcher_Created(object sender, FileSystemEventArgs e)
        {
            int orderNumber;
            double orderTotal;

            ManualResetEvent waitHandle = new ManualResetEvent(false);

            //let the file get completely written
            Thread.Sleep(500);
           //get values from file
            XElement billingDoc = XElement.Load(e.FullPath);
            orderNumber = (int)billingDoc.Descendants("OrderIdentifier").First();
            orderTotal = (double)billingDoc.Descendants("Total").First();

            using (WorkflowRuntime runtime = new WorkflowRuntime())
            {
                #region handlers

                runtime.WorkflowCompleted += (o, wce) =>
                {
                    Console.WriteLine("workflow completed");
                    waitHandle.Set();
                };
                runtime.ServicesExceptionNotHandled += (o, snhe) =>
                    {
                        Console.WriteLine(snhe.Exception.Message);
                    };

                runtime.WorkflowTerminated += (o, wte) =>
                    {
                        Console.WriteLine(wte.Exception.Message);
                        waitHandle.Set();
                    };
                #endregion handlers

                runtime.AddService(new BamTrackingService(
                    "server=.;database=BamprimaryImport;integrated security=SSPI",
                    60000));

                var wf = runtime.CreateWorkflow(
                    typeof(BillingWorkflows.BillingProcess),
                    new Dictionary<string, object>
                    {
                        {"OrderID", orderNumber},
                        {"OrderAmount", orderTotal}
                    });
                wf.Start();

                waitHandle.WaitOne();


            }
            
            Console.WriteLine("Order {0} found with total {1}", orderNumber, orderTotal);
        }
    }
}
