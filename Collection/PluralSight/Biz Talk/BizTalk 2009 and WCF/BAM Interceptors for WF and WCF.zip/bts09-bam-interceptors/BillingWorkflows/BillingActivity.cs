﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Workflow.ComponentModel;

namespace BillingWorkflows
{
	public class BillingActivity : Activity
	{
        public static DependencyProperty OrderTotalAmountProperty = DependencyProperty.Register("OrderTotalAmount", typeof(double), typeof(BillingActivity));

        [System.ComponentModel.DescriptionAttribute("OrderTotalAmount")]
        [System.ComponentModel.CategoryAttribute("OrderTotalAmount Category")]
        [System.ComponentModel.BrowsableAttribute(true)]
        [System.ComponentModel.DesignerSerializationVisibilityAttribute(System.ComponentModel.DesignerSerializationVisibility.Visible)]
        public double OrderTotalAmount
        {
            get
            {
                return ((double)(base.GetValue(BillingActivity.OrderTotalAmountProperty)));
            }
            set
            {
                base.SetValue(BillingActivity.OrderTotalAmountProperty, value);
            }
        }
	}
}
