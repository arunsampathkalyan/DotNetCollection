﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var proxy = new btsOrdersSvc.BTSOrdersClient();
            proxy.SubmitOrder(new ConsoleApplication1.btsOrdersSvc.Order
            {
                 CustomerID = "Milner",
                  OrderID = "5"
            });
        }
    }
}
