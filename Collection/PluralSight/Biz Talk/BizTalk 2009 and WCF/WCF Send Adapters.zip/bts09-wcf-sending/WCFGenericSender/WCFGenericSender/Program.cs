﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Xml;
using System.ServiceModel;

namespace WCFGenericSender
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                PrintUsage();
                return;
            }

            string fileName = args[0];

            Message msg = Message.CreateMessage(MessageVersion.Default, "*", XmlReader.Create(fileName));

            IUniversalTwoWayContract proxy =
                new ChannelFactory<IUniversalTwoWayContract>(
                    new NetTcpBinding(), "net.tcp://localhost:808/OrderService").CreateChannel();
            Console.WriteLine("Sending message to the service.");

            Message reply = proxy.SubmitMessage(msg);

            if (!reply.IsFault)
            {
                Console.WriteLine(reply.GetReaderAtBodyContents().ReadOuterXml());
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Fault message received in reply");
                
                Console.WriteLine(reply.GetReaderAtBodyContents().ReadOuterXml());
                Console.ResetColor();
            }
            
            Console.ReadLine();
        }

       
        private static void PrintUsage()
        {
            Console.WriteLine("Usage: WCFGenericSender.exe <Message File Name>");
            Console.ReadLine();
        }
    }

    [ServiceContract]
    public interface IUniversalOneWayContract
    {
        [OperationContract(IsOneWay=true, Action="*")]
        void SubmitMessage(Message msg);
    }

    [ServiceContract]
    public interface IUniversalTwoWayContract
    {
        [OperationContract(IsOneWay = false, Action = "*", ReplyAction="*")]
        Message SubmitMessage(Message msg);
    }
}
