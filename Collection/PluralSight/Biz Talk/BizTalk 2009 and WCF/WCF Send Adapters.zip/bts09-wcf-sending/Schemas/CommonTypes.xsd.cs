namespace Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Address", @"BillTo", @"ShipTo", @"Item", @"LineItem"})]
    public sealed class CommonTypes : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/abts/common"" targetNamespace=""http://pluralsight.com/abts/common"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:complexType name=""AddressType"">
    <xs:sequence>
      <xs:element name=""Addressee"" type=""xs:string"" />
      <xs:element name=""Line1"" type=""xs:string"" />
      <xs:element name=""Line2"" type=""xs:string"" />
      <xs:element name=""City"" type=""xs:string"" />
      <xs:element name=""Region"" type=""xs:string"" />
      <xs:element name=""PostalCode"" type=""xs:string"" />
      <xs:element name=""Country"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
  <xs:complexType name=""ItemType"">
    <xs:sequence>
      <xs:element name=""ProductID"" type=""xs:string"" />
      <xs:element name=""ProductName"" type=""xs:string"" />
      <xs:element name=""UnitPrice"" type=""xs:double"" />
    </xs:sequence>
  </xs:complexType>
  <xs:complexType name=""LineItemType"">
    <xs:complexContent mixed=""false"">
      <xs:extension base=""ItemType"">
        <xs:sequence>
          <xs:element name=""Quantity"" type=""xs:positiveInteger"" />
          <xs:element name=""ExtendedPrice"" type=""xs:double"" />
        </xs:sequence>
      </xs:extension>
    </xs:complexContent>
  </xs:complexType>
  <xs:element name=""Address"" type=""AddressType"" />
  <xs:element name=""BillTo"" type=""AddressType"" />
  <xs:element name=""ShipTo"" type=""AddressType"" />
  <xs:element name=""Item"" type=""ItemType"" />
  <xs:element name=""LineItem"" type=""LineItemType"" />
  <xs:attribute name=""timestamp"" type=""xs:dateTime"" />
</xs:schema>";
        
        public CommonTypes() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [5];
                _RootElements[0] = "Address";
                _RootElements[1] = "BillTo";
                _RootElements[2] = "ShipTo";
                _RootElements[3] = "Item";
                _RootElements[4] = "LineItem";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://pluralsight.com/abts/common",@"Address")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"Address"})]
        public sealed class Address : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public Address() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "Address";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/abts/common",@"BillTo")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"BillTo"})]
        public sealed class BillTo : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public BillTo() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "BillTo";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/abts/common",@"ShipTo")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"ShipTo"})]
        public sealed class ShipTo : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public ShipTo() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "ShipTo";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/abts/common",@"Item")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"Item"})]
        public sealed class Item : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public Item() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "Item";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/abts/common",@"LineItem")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"LineItem"})]
        public sealed class LineItem : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public LineItem() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "LineItem";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}
