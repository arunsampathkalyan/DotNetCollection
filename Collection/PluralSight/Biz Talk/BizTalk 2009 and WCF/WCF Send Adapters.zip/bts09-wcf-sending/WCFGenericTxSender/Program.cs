﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Xml;
using System.ServiceModel;
using System.Transactions;

namespace WCFGenericTxSender
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                PrintUsage();
                return;
            }

            string fileName = args[0];

            //create message from file
            Message msg = Message.CreateMessage(MessageVersion.Default, "*", 
                XmlReader.Create(fileName));
            
            //add custom soap header
            msg.Headers.Add(
                MessageHeader.CreateHeader("customerID", 
                "http://www.pluralsight.com/demos/bts/", 
                "gates"));

            //create transaction aware binding
            NetTcpBinding tcpTxBinding = new NetTcpBinding();
            tcpTxBinding.TransactionFlow = true;
            tcpTxBinding.TransactionProtocol = TransactionProtocol.OleTransactions;

            //create proxy enabled for transaction flow
            IUniversalOneWayTxContract proxy =
                new ChannelFactory<IUniversalOneWayTxContract>(
                    tcpTxBinding, 
                    "net.tcp://localhost:808/OrderService").CreateChannel();
            
            //create tx on the client
            using (TransactionScope txScope = new TransactionScope())
            {
                //submit message to BizTalk
                proxy.SubmitMessage(msg);
                Console.WriteLine("Message sent to the service.");
                

                //make decision to commit or abort
                Console.WriteLine("(c)ommit or (a)bort?");

                char response = Console.ReadKey().KeyChar;
                if (response == 'c')
                {
                    txScope.Complete();
                    Console.WriteLine("\nCommitting transaction");
                }
                else
                {
                    Console.WriteLine("\nAborting");
                }
            }
        }


        private static void PrintUsage()
        {
            Console.WriteLine("Usage: WCFGenericSender.exe <Message File Name>");
            Console.ReadLine();
        }
    }

    [ServiceContract]
    public interface IUniversalOneWayContract
    {
        [OperationContract(IsOneWay = true, Action = "*")]
        void SubmitMessage(Message msg);
    }
    [ServiceContract]
    public interface IUniversalOneWayTxContract
    {
        [OperationContract(IsOneWay = false, Action = "*")]
        [TransactionFlow(TransactionFlowOption.Allowed)]
        void SubmitMessage(Message msg);
    }

    [ServiceContract]
    public interface IUniversalTwoWayContract
    {
        [OperationContract(IsOneWay = false, Action = "*", ReplyAction = "*")]
        Message SubmitMessage(Message msg);
    }
}
