using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Description;
using System.Security.Cryptography.X509Certificates;
using System.Linq;

namespace TaxCalculationService
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host =
                new ServiceHost(typeof(TaxService),
                new Uri("http://localhost:9973/Services/TaxService"),
                new Uri("net.tcp://localhost:9974/Services/TaxService"));

            ServiceMetadataBehavior meta =
                new ServiceMetadataBehavior();
            meta.HttpGetEnabled = true;
            host.Description.Behaviors.Add(meta);


            host.AddServiceEndpoint("TaxCalculationService.ITaxService",
                new BasicHttpBinding(),
                "");
            
            ServiceCredentials cred = new ServiceCredentials();
            cred.ServiceCertificate.Certificate = GetServerCertificate();

            host.Description.Behaviors.Add(cred);
                
            
            var tcp = new NetTcpBinding(SecurityMode.TransportWithMessageCredential);
            tcp.Security.Message.ClientCredentialType = MessageCredentialType.UserName;
            
            host.AddServiceEndpoint("TaxCalculationService.ITaxService",
               tcp,
               "");
            

            host.Open();
            foreach(ServiceEndpoint ep in host.Description.Endpoints)
                Console.WriteLine("Listening on {0}", ep.Address.Uri);

            Console.ReadLine();
        }

        private static X509Certificate2 GetServerCertificate()
        {
            var store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadOnly);
            var certs = store.Certificates.Find(X509FindType.FindBySubjectName, "PS-BTS", false);
            if (certs != null && certs.Count >= 1)
                return certs[0];
            else
                return null;
        }
    }

    [ServiceContract(Namespace="http://pluralsight.com/projects/taxes")]
    public interface ITaxService
    {
        [OperationContract]
        TaxCalculationResult ComputeTax(TaxRequest request);
    }

    public class TaxService : ITaxService
    {

        #region ITaxService Members

        public TaxCalculationResult ComputeTax(TaxRequest request)
        {
            TaxCalculationResult result = new TaxCalculationResult();
            result.TaxAmount = request.TotalAmount * .07m;
            if (ServiceSecurityContext.Current != null)
            {
                Console.WriteLine("operation invoked by: {0}", ServiceSecurityContext.Current.PrimaryIdentity.Name);
            }

            if (OperationContext.Current != null)
            {
                var headerIndex = OperationContext.Current.IncomingMessageHeaders.FindHeader("CustomerID", "http://www.pluralsight.com/demos/bts/");
                if (headerIndex >= 0)
                    Console.WriteLine("CustomerID from custom SOAP header: {0}", OperationContext.Current.IncomingMessageHeaders.GetHeader<string>(headerIndex));
            }

            return result;
        }

        #endregion
    }

    [DataContract(Namespace = "http://pluralsight.com/projects/taxes")]
    public class TaxCalculationResult
    {
        private decimal taxAmount;

        [DataMember]
        public decimal TaxAmount
        {
            get { return taxAmount; }
            set { taxAmount = value; }
        }

    }

    [DataContract(Namespace = "http://pluralsight.com/projects/taxes")]
    public class TaxRequest
    {
        private string cust;

        [DataMember]
        public string CustomerID
        {
            get { return cust; }
            set { cust = value; }
        }

        private decimal amount;

        [DataMember]
        public decimal TotalAmount
        {
            get { return amount; }
            set { amount = value; }
        }

    }
}
