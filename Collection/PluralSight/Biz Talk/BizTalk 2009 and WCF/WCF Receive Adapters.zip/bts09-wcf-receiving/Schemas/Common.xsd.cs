namespace Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/ABTS/Schemas",@"Address")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Address"})]
    public sealed class Common : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/ABTS/Schemas"" targetNamespace=""http://pluralsight.com/ABTS/Schemas"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""Address"" type=""AddressType"" />
  <xs:complexType name=""AddressType"">
    <xs:sequence>
      <xs:element name=""Line1"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""Line2"" type=""xs:string"" />
      <xs:element name=""City"" type=""xs:string"" />
      <xs:element name=""State"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:length value=""2"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:element>
      <xs:element name=""Zip"">
        <xs:simpleType>
          <xs:restriction base=""xs:string"">
            <xs:pattern value=""\d{5}-\d{4}"" />
          </xs:restriction>
        </xs:simpleType>
      </xs:element>
    </xs:sequence>
    <xs:attribute name=""AddressType"">
      <xs:simpleType>
        <xs:restriction base=""xs:string"">
          <xs:enumeration value=""Shipping"" />
          <xs:enumeration value=""Billing"" />
        </xs:restriction>
      </xs:simpleType>
    </xs:attribute>
  </xs:complexType>
</xs:schema>";
        
        public Common() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Address";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
