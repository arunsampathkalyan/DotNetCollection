namespace Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Schemas.ExternalOrder",@"Order")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Order"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.Common", typeof(Schemas.Common))]
    public sealed class ExternalOrder : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:common=""http://pluralsight.com/ABTS/Schemas"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://Schemas.ExternalOrder"" targetNamespace=""http://Schemas.ExternalOrder"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Schemas.Common"" namespace=""http://pluralsight.com/ABTS/Schemas"" />
  <xs:annotation>
    <xs:appinfo>
      <b:references>
        <b:reference targetNamespace=""http://pluralsight.com/ABTS/Schemas"" />
      </b:references>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Order"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element name=""Addresses"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Address"" type=""common:AddressType"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Items"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""ProductID"" type=""xs:string"" />
                    <xs:element name=""Price"" type=""xs:decimal"" />
                    <xs:element name=""Qty"" type=""xs:integer"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
      <xs:attribute name=""OrderID"" type=""xs:string"" />
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public ExternalOrder() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Order";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
