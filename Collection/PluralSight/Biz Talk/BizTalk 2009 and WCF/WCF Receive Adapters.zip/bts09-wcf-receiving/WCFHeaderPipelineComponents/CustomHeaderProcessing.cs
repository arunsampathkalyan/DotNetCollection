﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.BizTalk.Component.Interop;
using System.Xml;
using System.Xml.Linq;


namespace WCFHeaderPipelineComponents
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Any)]
    public class CustomHeaderProcessing : IComponent, IBaseComponent
    {
        #region IComponent Members

        public Microsoft.BizTalk.Message.Interop.IBaseMessage Execute(IPipelineContext pContext, Microsoft.BizTalk.Message.Interop.IBaseMessage pInMsg)
        {
            var headerProp = new WCF.InboundHeaders();
            
            object rawHeader = pInMsg.Context.Read(headerProp.Name.Name, headerProp.Name.Namespace);
            XNamespace ns = "http://www.pluralsight.com/demos/bts/";

            var rootElement = XElement.Parse(rawHeader.ToString());
            var myHeader = rootElement.Descendants(ns + "customerID").FirstOrDefault();
            if (myHeader != null)
            {
                pInMsg.Context.Promote("CustomerID", "http://Schemas.OrderProps", myHeader.Value);
            }
            return pInMsg;           
        }

        #endregion

        #region IBaseComponent Members

        public string Description
        {
            get { return "Sample component to read WCF soap headers"; }
        }

        public string Name
        {
            get { return "CustomWCFSOAPHeaderSample"; }
        }

        public string Version
        {
            get { return "1.0"; }
        }

        #endregion
    }
}
