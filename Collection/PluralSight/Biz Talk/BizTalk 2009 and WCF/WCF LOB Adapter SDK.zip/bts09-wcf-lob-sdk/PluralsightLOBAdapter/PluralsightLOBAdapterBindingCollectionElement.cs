/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterBindingCollectionElement.cs
/// Description :  Binding Collection Element class which implements the StandardBindingCollectionElement
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Configuration;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Pluralsight.LOB
{
    /// <summary>
    /// Initializes a new instance of the PluralsightLOBAdapterBindingCollectionElement class
    /// </summary>
    public class PluralsightLOBAdapterBindingCollectionElement : StandardBindingCollectionElement<PluralsightLOBAdapterBinding,
        PluralsightLOBAdapterBindingElement>
    {
    }
}

