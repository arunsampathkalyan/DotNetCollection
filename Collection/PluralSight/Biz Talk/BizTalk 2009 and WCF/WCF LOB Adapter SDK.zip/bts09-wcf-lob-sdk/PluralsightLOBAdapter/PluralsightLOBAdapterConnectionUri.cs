/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterConnectionUri.cs
/// Description :  This is the class for representing an adapter connection uri
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Pluralsight.LOB
{
    /// <summary>
    /// This is the class for building the PluralsightLOBAdapterConnectionUri
    /// </summary>
    public class PluralsightLOBAdapterConnectionUri : ConnectionUri
    {

        #region Custom Generated Fields

        private string dataDirectory = null;

        #endregion Custom Generated Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the ConnectionUri class
        /// </summary>
        public PluralsightLOBAdapterConnectionUri() { }

        /// <summary>
        /// Initializes a new instance of the ConnectionUri class with a Uri object
        /// </summary>
        public PluralsightLOBAdapterConnectionUri(Uri uri)
            : base()
        {
            this.Uri = uri;
        }

        #endregion Constructors

        #region Custom Generated Properties

        public string DataDirectory
        {
            get
            {
                return this.dataDirectory;
            }
            set
            {
                this.dataDirectory = value;
            }
        }

        #endregion Custom Generated Properties

        #region ConnectionUri Members

        /// <summary>
        /// Getter and Setter for the Uri
        /// </summary>
        public override Uri Uri
        {
            get
            {
                return new Uri("ps://" + DataDirectory);
            }
            set
            {
                dataDirectory = value.AbsolutePath;
            }
        }

        #endregion ConnectionUri Members

    }
}