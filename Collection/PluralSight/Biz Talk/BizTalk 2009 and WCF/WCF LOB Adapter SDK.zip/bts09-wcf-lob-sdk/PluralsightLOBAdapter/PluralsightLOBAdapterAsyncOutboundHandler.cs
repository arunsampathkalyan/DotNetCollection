/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterAsyncOutboundHandler.cs
/// Description :  This class implements an interface for asynchronously sending data.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
using System.Xml.Linq;
using System.Linq;
using System.ServiceModel;
using System.Xml;
using System.IO;

#endregion

namespace Pluralsight.LOB
{
    public class PluralsightLOBAdapterAsyncOutboundHandler : PluralsightLOBAdapterHandlerBase, IAsyncOutboundHandler
    {
        /// <summary>
        /// Initializes a new instance of the PluralsightLOBAdapterAsyncOutboundHandler class
        /// </summary>
        public PluralsightLOBAdapterAsyncOutboundHandler(PluralsightLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IAsyncOutboundHandler Members

        /// <summary>
        /// Sends the request message to the target system
        /// </summary>
        public Message Execute(Message message, TimeSpan timeout)
        {
            switch (message.Headers.Action)
            {
                case "getCourses":
                    return CreateCourseListMessage(message.Version, message.Headers.Action);
                case "getInstructors":
                    return CreateInstructorListMessage(message.Version, message.Headers.Action);
                default:
                    return Message.CreateMessage(
                        message.Version,
                        MessageFault.CreateFault(FaultCode.CreateSenderFaultCode("InvalidRequest", "urn:Pluralsight"), new FaultReason("No such operation")),
                    message.Headers.Action + "/response");
            }
        }

        private Message CreateInstructorListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as PluralsightLOBAdapterConnectionUri;
            string instructorFile = System.IO.Path.Combine(uri.DataDirectory, "Instructors.xml");

            XElement root = XElement.Load(instructorFile);
            var instructors = from i in root.Elements("instructor")
                              select i.Value;

            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb,
                new XmlWriterSettings { OmitXmlDeclaration = true, Indent = true });
            writer.WriteStartElement("GetInstructorsResponse", "urn:pluralsight");
            writer.WriteStartElement("GetInstructorsResult");
            foreach (var item in instructors)
            {
                writer.WriteElementString("string", "http://schemas.microsoft.com/2003/10/Serialization/Arrays", item);
            }

            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Flush();

            XmlReader reader = XmlReader.Create(new StringReader(sb.ToString()));


            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", reader);

            return replyMessage;

        }

        private Message CreateCourseListMessage(MessageVersion messageVersion, string action)
        {
            var uri = Connection.ConnectionFactory.Uri as PluralsightLOBAdapterConnectionUri;
            string courseFile = System.IO.Path.Combine(uri.DataDirectory, "Courses.xml");

            XElement root = XElement.Load(courseFile);
            var courses = from i in root.Elements("course")
                              select i.Value;
            StringBuilder sb = new StringBuilder();
            XmlWriter writer = XmlWriter.Create(sb,
                new XmlWriterSettings { OmitXmlDeclaration = true, Indent = true });
            writer.WriteStartElement("GetCoursesResponse", "urn:pluralsight");
            writer.WriteStartElement("GetCoursesResult");
            foreach (var item in courses)
            {
                writer.WriteElementString("string", "http://schemas.microsoft.com/2003/10/Serialization/Arrays", item);
            }

            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Flush();

            XmlReader reader = XmlReader.Create(new StringReader(sb.ToString()));


            var replyMessage = Message.CreateMessage(messageVersion,
                action + "/response", reader);

            return replyMessage;
        }



        /// <summary>
        /// Asynchronously sends the request message to the target system
        /// </summary>
        public IAsyncResult BeginExecute(Message message, TimeSpan timeout, AsyncCallback callback, object state)
        {
            //
            //TODO: Implement BeginExecute
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Ends the asynchronous send operation
        /// </summary>
        public Message EndExecute(IAsyncResult result)
        {
            //
            //TODO: Implement EndExecute
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        #endregion IAsyncOutboundHandler Members
    }
}
