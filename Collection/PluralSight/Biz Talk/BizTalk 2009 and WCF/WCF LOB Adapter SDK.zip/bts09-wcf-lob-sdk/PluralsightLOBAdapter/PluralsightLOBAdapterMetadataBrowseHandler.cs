/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterMetadataBrowseHandler.cs
/// Description :  This class is used while performing a connection-based browse for metadata from the target system.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Pluralsight.LOB
{
    public class PluralsightLOBAdapterMetadataBrowseHandler : PluralsightLOBAdapterHandlerBase, IMetadataBrowseHandler
    {
        /// <summary>
        /// Initializes a new instance of the PluralsightLOBAdapterMetadataBrowseHandler class
        /// </summary>
        public PluralsightLOBAdapterMetadataBrowseHandler(PluralsightLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataBrowseHandler Members

        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes from the target system.
        /// The browse will return nodes starting from the childStartIndex in the path provided in absoluteName, and the number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or throw a timeout exception.
        /// If absoluteName is null or an empty string, return nodes starting from the root + childStartIndex.
        /// If childStartIndex is zero, then return starting at the node indicated by absoluteName (or the root node if absoluteName is null or empty).
        /// </summary>
        public MetadataRetrievalNode[] Browse(string nodeId
            , int childStartIndex
            , int maxChildNodes, TimeSpan timeout)
        {

            if (String.IsNullOrEmpty(nodeId) || nodeId == "/")
            {
                MetadataRetrievalNode courseNode = new MetadataRetrievalNode
                {
                    NodeId = "courses",
                    DisplayName = "Course Offerings",
                    Description = "Provides listings of courses",
                    Direction = MetadataRetrievalNodeDirections.Outbound,
                    IsOperation = false
                };

                MetadataRetrievalNode instructorNode = new MetadataRetrievalNode
                {
                    NodeId = "instructors",
                    DisplayName = "Instructor listings",
                    Description = "Provides listings of instructors",
                    Direction = MetadataRetrievalNodeDirections.Outbound,
                    IsOperation = false
                };
                return new MetadataRetrievalNode[] { courseNode, instructorNode };
            }
            else
            {
                switch (nodeId)
                {
                    case "courses":
                        return GetCourseNodes();
                    case "instructors":
                        return GetInstructorNodes();
                    default:
                        return new MetadataRetrievalNode[] { };
                }
            }
            
        }

        private MetadataRetrievalNode[] GetInstructorNodes()
        {
            MetadataRetrievalNode instructorNode = new MetadataRetrievalNode
            {
                NodeId = "getInstructors",
                DisplayName = "List Instructors",
                Description = "Provides listings of instructors",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { instructorNode };
        }

        private MetadataRetrievalNode[] GetCourseNodes()
        {
            MetadataRetrievalNode courseNode = new MetadataRetrievalNode
            {
                NodeId = "getCourses",
                DisplayName = "List Courses",
                Description = "Provides listings of courses",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { courseNode };
        }

        #endregion IMetadataBrowseHandler Members
    }
}
