/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterMetadataSearchHandler.cs
/// Description :  This class is used for performing a connection-based search for metadata from the target system
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;

using System.Linq;

#endregion

namespace Pluralsight.LOB
{
    public class PluralsightLOBAdapterMetadataSearchHandler : PluralsightLOBAdapterHandlerBase, IMetadataSearchHandler
    {
        /// <summary>
        /// Initializes a new instance of the PluralsightLOBAdapterMetadataSearchHandler class
        /// </summary>
        public PluralsightLOBAdapterMetadataSearchHandler(PluralsightLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IMetadataSearchHandler Members

        /// <summary>
        /// Retrieves an array of MetadataRetrievalNodes (see Microsoft.ServiceModel.Channels) from the target system.
        /// The search will begin at the path provided in absoluteName, which points to a location in the tree of metadata nodes.
        /// The contents of the array are filtered by SearchCriteria and the number of nodes returned is limited by maxChildNodes.
        /// The method should complete within the specified timespan or throw a timeout exception.  If absoluteName is null or an empty string, return nodes starting from the root.
        /// If SearchCriteria is null or an empty string, return all nodes.
        /// </summary>
        public MetadataRetrievalNode[] Search(string nodeId
            , string searchCriteria
            , int maxChildNodes, TimeSpan timeout)
        {
            switch (nodeId)
            {
                case "courses":
                    return GetCourseNodes();
                case "instructors":
                    return GetInstructorNodes();
                default:
                    return GetCourseNodes().Union(GetInstructorNodes()).ToArray();
            }
        }

        #endregion IMetadataSearchHandler Members

        private MetadataRetrievalNode[] GetInstructorNodes()
        {
            MetadataRetrievalNode instructorNode = new MetadataRetrievalNode
            {
                NodeId = "getInstructors",
                DisplayName = "List Instructors",
                Description = "Provides listings of instructors",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { instructorNode };
        }

        private MetadataRetrievalNode[] GetCourseNodes()
        {
            MetadataRetrievalNode courseNode = new MetadataRetrievalNode
            {
                NodeId = "getCourses",
                DisplayName = "List Courses",
                Description = "Provides listings of courses",
                Direction = MetadataRetrievalNodeDirections.Outbound,
                IsOperation = true
            };

            return new MetadataRetrievalNode[] { courseNode };
        }
    }
}
