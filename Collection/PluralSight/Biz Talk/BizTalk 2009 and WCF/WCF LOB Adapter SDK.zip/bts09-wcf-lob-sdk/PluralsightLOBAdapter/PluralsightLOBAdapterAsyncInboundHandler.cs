/// -----------------------------------------------------------------------------------------------------------
/// Module      :  PluralsightLOBAdapterAsyncInboundHandler.cs
/// Description :  This class implements an interface for asynchronously sending data.
/// -----------------------------------------------------------------------------------------------------------

#region Using Directives
using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel.Channels;

using Microsoft.ServiceModel.Channels.Common;
#endregion

namespace Pluralsight.LOB
{
    public class PluralsightLOBAdapterAsyncInboundHandler : PluralsightLOBAdapterHandlerBase, IAsyncInboundHandler
    {
        /// <summary>
        /// Initializes a new instance of the PluralsightLOBAdapterAsyncInboundHandler class
        /// </summary>
        public PluralsightLOBAdapterAsyncInboundHandler(PluralsightLOBAdapterConnection connection
            , MetadataLookup metadataLookup)
            : base(connection, metadataLookup)
        {
        }

        #region IAsyncInboundHandler Members

        /// <summary>
        /// Asynchronously waits for a message from the target system
        /// </summary>
        IAsyncResult IAsyncInboundHandler.BeginWaitForMessage(TimeSpan timeout, AsyncCallback callback, object state)
        {
            //
            //TODO: Implement BeginWaitForMessage
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Ends the asynchronous WaitForMessage operation
        /// </summary>
        bool IAsyncInboundHandler.EndWaitForMessage(IAsyncResult result)
        {
            //
            //TODO: Implement EndWaitForMessage
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Asynchronously tries to receive a message within a specified interval of time.
        /// </summary>
        IAsyncResult IAsyncInboundHandler.BeginTryReceive(TimeSpan timeout, AsyncCallback callback, object state)
        {
            //
            //TODO: Implement BeginTryReceive
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Ends the asynchronous TryReceive operation
        /// </summary>
        bool IAsyncInboundHandler.EndTryReceive(IAsyncResult result, out Message message, out IInboundReply reply)
        {
            //
            //TODO: Implement EndTryReceive
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Start the listener
        /// </summary>
        public void StartListener(string[] actions, TimeSpan timeout)
        {
            //
            //TODO: Implement start adapter listener logic.
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Stop the listener
        /// </summary>
        public void StopListener(TimeSpan timeout)
        {
            //
            //TODO: Implement stop adapter listener logic.
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Tries to receive a message within a specified interval of time. 
        /// </summary>
        public bool TryReceive(TimeSpan timeout, out System.ServiceModel.Channels.Message message, out IInboundReply reply)
        {
            reply = new PluralsightLOBAdapterInboundReply();
            //
            //TODO: Implement Try Receive logic.
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        /// <summary>
        /// Returns a value that indicates whether a message has arrived within a specified interval of time
        /// </summary>
        public bool WaitForMessage(TimeSpan timeout)
        {
            //
            //TODO: Implement Wait for message logic.
            //
            throw new NotImplementedException("The method or operation is not implemented.");
        }

        #endregion IAsyncInboundHandler Members
    }
}
