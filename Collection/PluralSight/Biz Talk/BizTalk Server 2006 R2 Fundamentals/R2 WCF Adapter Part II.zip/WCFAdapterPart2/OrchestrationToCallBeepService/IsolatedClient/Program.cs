using System;
using System.Collections.Generic;
using System.Text;

namespace IsolatedClient
{
    class Program
    {
        static void Main(string[] args)
        {
            OrchestrationToCallBeepService_MyOrchestration_MyMessageInClient
             proxy = new OrchestrationToCallBeepService_MyOrchestration_MyMessageInClient();
            MySchemaType mst = new MySchemaType();
            mst.MyData = "Calling WCF EP - To BizTalk - To WCF Service";
            proxy.MyMessageExchange(mst);
        }
    }
}
