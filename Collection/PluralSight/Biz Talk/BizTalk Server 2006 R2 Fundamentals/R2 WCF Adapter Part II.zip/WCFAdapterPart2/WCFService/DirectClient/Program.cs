using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using ServiceNS;

namespace DirectClient
{
    class Program
    {
        static void Main(string[] args)
        {
            WSHttpBinding binding = new WSHttpBinding();
            EndpointAddress ea =
                new EndpointAddress("http://localhost:8077/BeepService");
            ChannelFactory<IBeepService> cf =
                new ChannelFactory<IBeepService>(binding, ea);
            cf.Open();
            IBeepService s = cf.CreateChannel();
            Data d = new Data();
            Console.WriteLine("Press enter to send message");
            Console.ReadLine();
            d.Message = "using beep service";
            Data returnData = s.DoBeep(d);
            Console.WriteLine("Service returned {0}",
                returnData.Message);
        }
    }
}
