using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;

namespace ServiceNS
{
    class Service
    {
        static void Main(string[] args)
        {
            WSHttpBinding binding
             = new WSHttpBinding();
            string uri = "http://localhost:8077/";
            ServiceHost sh = new ServiceHost(
                typeof(BeepService), 
                new Uri(uri));
            ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
            smb.HttpGetEnabled = true;
            sh.Description.Behaviors.Add(smb);
            sh.AddServiceEndpoint(typeof(IBeepService),
                binding,
                "BeepService");
            sh.AddServiceEndpoint(typeof(IBasicBeepService),
                new BasicHttpBinding(),
                "BasicBeepService");
            sh.Open();
            Console.WriteLine("Service up and running...");
            Console.ReadLine();


        }
    }
    public class BeepService : IBeepService, IBasicBeepService
    {
        #region IBeepService Members

        public Data DoBeep(Data d)
        {
            ConsoleColor c = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("DoBeep message {0}",d.Message);
            Console.Beep(100, 300);
            d.Message = "Beeped";

            Console.ForegroundColor = c;
       
          
            return d;
        }

        #endregion

        #region IBeepService2 Members

        public void DoBeep(Message msg)
        {
            ConsoleColor c = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("DoBeep2 message {0}",
                msg.GetReaderAtBodyContents().ReadOuterXml());
            Console.Beep(500, 300);
           

            Console.ForegroundColor = c;


        }

        #endregion
    }
    [ServiceContract]
    public interface IBeepService
    {
        [OperationContract]
        Data DoBeep(Data d);
    }
    [ServiceContract]
    public interface IBasicBeepService
    {
        [OperationContract()]
        void DoBeep(Message msg);
    }
    [DataContract]
    public class Data
    {
        [DataMember]
        public string Message;
    }

}
