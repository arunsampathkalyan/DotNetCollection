using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Transactions;

namespace ABizTalkClient
{
    class Program
    {
        static void Main(string[] args)
        {
            NetTcpBinding binding =
                new NetTcpBinding();
            binding.TransactionFlow = true;
            binding.TransactionProtocol =
                TransactionProtocol.OleTransactions;

            EndpointAddress ea =
                new
                EndpointAddress("net.tcp://localhost:5006/BizTalkEndPoint");
            ChannelFactory<IUniversal> cf
               =
               new ChannelFactory<IUniversal>(binding,
                                  ea);
            cf.Open();
            IUniversal channel = cf.CreateChannel();
            Message msg = Message.CreateMessage(MessageVersion.Default,
                                             "*",
                                             "Sending a message to BizTalk Server 2006 R2");

            using (TransactionScope ts = new TransactionScope())
            {
                channel.Operation(msg);
                ts.Complete();
            }

            Console.WriteLine("Sent message to BizTalk");
            //Message ret = channel.Operation(msg);

            //Console.WriteLine(ret.GetReaderAtBodyContents().ReadOuterXml());

        }
        [ServiceContract]
        public interface IUniversal
        {
            [TransactionFlow(TransactionFlowOption.Allowed)]
            [OperationContract(Action = "*", ReplyAction = "*")]
            void Operation(Message msg);
        }
    }
}
