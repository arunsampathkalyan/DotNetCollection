﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.SensorServices.Rfid;

namespace MyRFIDEventHandlerLibrary
{
    public class MyEventHandler : RfidEventHandlerBase

    {
        [RfidEventHandlerMethod]
        public RfidEventBase[] MyExecute(TagReadEvent theEvent)
        {
            GPSEventData enrich = new GPSEventData();
            enrich.Lat = 5;
            enrich.Long = 5;
            return new RfidEventBase[]{theEvent,enrich};
        }
        //to build a sink
        //[RfidEventHandlerMethod]
        //public void MySink(TagReadEvent theEvent)
        //{
        //}
        //[RfidEventHandlerMethod]
        //public RfidEventBase[] MyExecute(RfidEventBase[] theEvent)
        //{
        //    GPSEventData enrich = new GPSEventData();
        //    enrich.Lat = 5;
        //    enrich.Long = 5;
        //    return new RfidEventBase[] { theEvent, enrich };
        //}
        public static RfidEventHandlerMetadata
            GetEventHandlerMetadata(bool vendorEvents)
        {
            Dictionary<string, RfidEventHandlerParameterMetadata> prms
                = new Dictionary<string, RfidEventHandlerParameterMetadata>();
            prms.Add("MyProperty", new RfidEventHandlerParameterMetadata(typeof(string), "MyProperty Description",
                null, false));

            RfidEventHandlerMetadata ret =
                new RfidEventHandlerMetadata(
                    "The description of my Event Handler", 
                    prms);
            return ret;
        }
        public override void Init(
            Dictionary<string, object> parameters,
            RfidProcessContext container)
        {

            _MyProperty  =  parameters["MyProperty"].ToString();

        }
        private string _MyProperty;

    }
    [Serializable]
    public class GPSEventData : RfidEventBase
    {
        public float Lat;
        public float Long;
    }
}
