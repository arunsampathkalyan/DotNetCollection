using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.Component.Interop;
using System.Runtime.InteropServices;
using Microsoft.BizTalk.Message.Interop;
namespace PipelineComponents
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Validate)]
    [Guid("964839CB-4C2D-4b72-8C9F-35F38FBBEBEE")]
    public class PropertyPromoter: IComponent,
         IBaseComponent, IPersistPropertyBag
    {
        #region Properties

        private string pName;

        public string PropertyName
        {
            get { return pName; }
            set { pName = value; }
        }

        private string pNamespace;

        public string PropertyNamespace
        {
            get { return pNamespace; }
            set { pNamespace = value; }
        }

        private string pValue;

        public string PropertyValue
        {
            get { return pValue; }
            set { pValue = value; }
        }

        #endregion Properties


        #region IComponent Members

        public Microsoft.BizTalk.Message.Interop.IBaseMessage Execute(IPipelineContext pContext, Microsoft.BizTalk.Message.Interop.IBaseMessage pInMsg)
        {
            IBaseMessage pOutMsg;
            IBaseMessageFactory factory = pContext.GetMessageFactory();
            IBaseMessagePart bodyPart;

            //create message and part
            pOutMsg = factory.CreateMessage();
            bodyPart = factory.CreateMessagePart();

            //copy message context
            pOutMsg.Context = PipelineUtil.CloneMessageContext(pInMsg.Context);

            //copy the body part and its properties
            bodyPart.Data = pInMsg.BodyPart.Data;
            bodyPart.PartProperties = PipelineUtil.CopyPropertyBag(pInMsg.BodyPart.PartProperties, factory);

            //add the part to the message
            pOutMsg.AddPart(pInMsg.BodyPartName, bodyPart, true);


            //promote the message context property
            pOutMsg.Context.Promote(PropertyName,
                PropertyNamespace, PropertyValue);

            
            return pOutMsg;

        }

        #endregion

        #region IBaseComponent Members

        public string Description
        {
            get { return "Promotes properties to the message context"; }
        }

        public string Name
        {
            get { return "PropertyPromoter"; }
        }

        public string Version
        {
            get { return "1.0"; }
        }

        #endregion


        #region IPersistPropertyBag Members

        public void GetClassID(out Guid classID)
        {
            classID = new Guid("964839CB-4C2D-4b72-8C9F-35F38FBBEBEE");

        }

        public void InitNew()
        {
            //initialize a new instance with defaults
        }

        public void Load(IPropertyBag propertyBag, int errorLog)
        {
            PropertyName = ReadPropertyBag(propertyBag, "PropName");
            PropertyNamespace = ReadPropertyBag(propertyBag, "PropNS");
            PropertyValue = ReadPropertyBag(propertyBag, "PropVal");      
        }

        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
            WritePropertyBag(propertyBag, "PropName",  PropertyName);
            WritePropertyBag(propertyBag, "PropNS",  PropertyNamespace);
            WritePropertyBag(propertyBag, "PropVal",  PropertyValue);
        }

        #region PropertyBagHelpers

        protected string ReadPropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName)
        {
            object val = null;
            try
            {
                pb.Read(propName, out val, 0);
            }

            catch (ArgumentException)
            {
                return String.Empty;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            return val== null ? String.Empty:val.ToString();
        }

        protected void WritePropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName, string val)
        {
            object tempVal = (object)val;
            try
            {
                pb.Write(propName, ref tempVal);
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        #endregion

        #endregion
    }
}
