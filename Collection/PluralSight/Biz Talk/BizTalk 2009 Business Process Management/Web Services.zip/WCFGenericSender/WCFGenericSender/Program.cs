﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.Xml;
using System.ServiceModel;

namespace WCFGenericSender
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 1)
            {
                PrintUsage();
                return;
            }

            string fileName = args[0];

            Message msg = Message.CreateMessage(MessageVersion.Default, "*", 
                XmlReader.Create(fileName));

            IUniversalOneWayContract proxy =
                new ChannelFactory<IUniversalOneWayContract>(
                    new NetTcpBinding(), "net.tcp://localhost:808/OrderService").CreateChannel();

            proxy.SubmitMessage(msg);

            Console.WriteLine("Message sent to the service.");
            Console.ReadLine();
        }

       
        private static void PrintUsage()
        {
            Console.WriteLine("Usage: WCFGenericSender.exe <Message File Name>");
            Console.ReadLine();
        }
    }

    [ServiceContract]
    public interface IUniversalOneWayContract
    {
        [OperationContract(IsOneWay=true, Action="*")]
        void SubmitMessage(Message msg);
    }

    [ServiceContract]
    public interface IUniversalTwoWayContract
    {
        [OperationContract(IsOneWay = false, Action = "*", ReplyAction="*")]
        Message SubmitMessage(Message msg);
    }
}
