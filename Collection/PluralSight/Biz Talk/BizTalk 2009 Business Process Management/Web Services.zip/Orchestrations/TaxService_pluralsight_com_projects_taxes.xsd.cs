namespace Orchestrations {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "ComputeTaxResult.TaxAmount", XPath = @"/*[local-name()='ComputeTaxResponse' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='ComputeTaxResult' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='TaxAmount' and namespace-uri()='http://pluralsight.com/projects/taxes']", XsdType = @"decimal")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"ComputeTax", @"TaxRequest", @"ComputeTaxResponse", @"TaxCalculationResult"})]
    public sealed class TaxService_pluralsight_com_projects_taxes : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:tns=""http://pluralsight.com/projects/taxes"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" elementFormDefault=""qualified"" targetNamespace=""http://pluralsight.com/projects/taxes"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""ComputeTax"">
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""request"" nillable=""true"" type=""tns:TaxRequest"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""TaxRequest"">
    <xs:sequence>
      <xs:element minOccurs=""0"" name=""CustomerID"" nillable=""true"" type=""xs:string"" />
      <xs:element minOccurs=""0"" name=""TotalAmount"" type=""xs:decimal"" />
    </xs:sequence>
  </xs:complexType>
  <xs:element name=""TaxRequest"" nillable=""true"" type=""tns:TaxRequest"" />
  <xs:element name=""ComputeTaxResponse"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='ComputeTaxResponse' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='ComputeTaxResult' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='TaxAmount' and namespace-uri()='http://pluralsight.com/projects/taxes']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element minOccurs=""0"" name=""ComputeTaxResult"" nillable=""true"" type=""tns:TaxCalculationResult"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""TaxCalculationResult"">
    <xs:sequence>
      <xs:element minOccurs=""0"" name=""TaxAmount"" type=""xs:decimal"" />
    </xs:sequence>
  </xs:complexType>
  <xs:element name=""TaxCalculationResult"" nillable=""true"" type=""tns:TaxCalculationResult"" />
</xs:schema>";
        
        public TaxService_pluralsight_com_projects_taxes() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [4];
                _RootElements[0] = "ComputeTax";
                _RootElements[1] = "TaxRequest";
                _RootElements[2] = "ComputeTaxResponse";
                _RootElements[3] = "TaxCalculationResult";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
        
        [Schema(@"http://pluralsight.com/projects/taxes",@"ComputeTax")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"ComputeTax"})]
        public sealed class ComputeTax : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public ComputeTax() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "ComputeTax";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/projects/taxes",@"TaxRequest")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"TaxRequest"})]
        public sealed class TaxRequest : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public TaxRequest() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "TaxRequest";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/projects/taxes",@"ComputeTaxResponse")]
        [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.Decimal), "ComputeTaxResult.TaxAmount", XPath = @"/*[local-name()='ComputeTaxResponse' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='ComputeTaxResult' and namespace-uri()='http://pluralsight.com/projects/taxes']/*[local-name()='TaxAmount' and namespace-uri()='http://pluralsight.com/projects/taxes']", XsdType = @"decimal")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"ComputeTaxResponse"})]
        public sealed class ComputeTaxResponse : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public ComputeTaxResponse() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "ComputeTaxResponse";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
        
        [Schema(@"http://pluralsight.com/projects/taxes",@"TaxCalculationResult")]
        [System.SerializableAttribute()]
        [SchemaRoots(new string[] {@"TaxCalculationResult"})]
        public sealed class TaxCalculationResult : Microsoft.XLANGs.BaseTypes.SchemaBase {
            
            [System.NonSerializedAttribute()]
            private static object _rawSchema;
            
            public TaxCalculationResult() {
            }
            
            public override string XmlContent {
                get {
                    return _strSchema;
                }
            }
            
            public override string[] RootNodes {
                get {
                    string[] _RootElements = new string [1];
                    _RootElements[0] = "TaxCalculationResult";
                    return _RootElements;
                }
            }
            
            protected override object RawSchema {
                get {
                    return _rawSchema;
                }
                set {
                    _rawSchema = value;
                }
            }
        }
    }
}
