using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.ServiceModel.Description;

namespace TaxCalculationService
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host =
                new ServiceHost(typeof(TaxService),
                new Uri("http://localhost:9973/Services/TaxService"),
                new Uri("net.tcp://localhost:9974/Services/TaxService"));

            ServiceMetadataBehavior meta =
                new ServiceMetadataBehavior();
            meta.HttpGetEnabled = true;
            host.Description.Behaviors.Add(meta);


            host.AddServiceEndpoint("TaxCalculationService.ITaxService",
                new BasicHttpBinding(),
                "");

            host.AddServiceEndpoint("TaxCalculationService.ITaxService",
               new NetTcpBinding(),
               "");

            host.Open();
            foreach(ServiceEndpoint ep in host.Description.Endpoints)
                Console.WriteLine("Listening on {0}", ep.Address.Uri);

            Console.ReadLine();
        }
    }

    [ServiceContract(Namespace="http://pluralsight.com/projects/taxes")]
    public interface ITaxService
    {
        [OperationContract]
        TaxCalculationResult ComputeTax(TaxRequest request);
    }

    public class TaxService : ITaxService
    {

        #region ITaxService Members

        public TaxCalculationResult ComputeTax(TaxRequest request)
        {
            TaxCalculationResult result = new TaxCalculationResult();
            result.TaxAmount = request.TotalAmount * .07m;

            return result;
        }

        #endregion
    }

    [DataContract(Namespace = "http://pluralsight.com/projects/taxes")]
    public class TaxCalculationResult
    {
        private decimal taxAmount;

        [DataMember]
        public decimal TaxAmount
        {
            get { return taxAmount; }
            set { taxAmount = value; }
        }

    }

    [DataContract(Namespace = "http://pluralsight.com/projects/taxes")]
    public class TaxRequest
    {
        private string cust;

        [DataMember]
        public string CustomerID
        {
            get { return cust; }
            set { cust = value; }
        }

        private decimal amount;

        [DataMember]
        public decimal TotalAmount
        {
            get { return amount; }
            set { amount = value; }
        }

    }
}
