namespace Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://Schemas.Order",@"ExternalOrder")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Schemas.CustomerIdentifier), XPath = @"/*[local-name()='ExternalOrder' and namespace-uri()='http://Schemas.Order']/*[local-name()='CustomerID' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"ExternalOrder"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.Common", typeof(Schemas.Common))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.OrderProperties", typeof(Schemas.OrderProperties))]
    public sealed class Order : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:props=""https://Schemas.OrderProperties"" xmlns:common=""http://pluralsight.com/common"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://Schemas.Order"" targetNamespace=""http://Schemas.Order"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""Schemas.Common"" namespace=""http://pluralsight.com/common"" />
  <xs:annotation>
    <xs:appinfo>
      <b:references>
        <b:reference targetNamespace=""http://pluralsight.com/common"" />
      </b:references>
      <b:imports>
        <b:namespace prefix=""props"" uri=""https://Schemas.OrderProperties"" location=""Schemas.OrderProperties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""ExternalOrder"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""props:CustomerIdentifier"" xpath=""/*[local-name()='ExternalOrder' and namespace-uri()='http://Schemas.Order']/*[local-name()='CustomerID' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element maxOccurs=""2"" name=""Address"" type=""common:AddressType"" />
        <xs:element name=""Items"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Price"" type=""xs:string"" />
                    <xs:element name=""Qty"" type=""xs:string"" />
                    <xs:element name=""Sku"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public Order() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "ExternalOrder";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
