namespace Correlation {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/billing",@"BillingRequest")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Correlation.Taxes), XPath = @"/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='BillableItems' and namespace-uri()='']/*[local-name()='Tax' and namespace-uri()='']", XsdType = @"decimal")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Correlation.OrderNumber), XPath = @"/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='OrderIdentifier' and namespace-uri()='']", XsdType = @"integer")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Correlation.CustomerIdentifier), XPath = @"/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='Customer' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"BillingRequest"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Correlation.OrderProperties", typeof(Correlation.OrderProperties))]
    public sealed class Billing : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:ns0=""https://Schemas.OrderProperties"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/billing"" targetNamespace=""http://pluralsight.com/billing"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <schemaEditorExtension:schemaInfo namespaceAlias=""b"" extensionClass=""Microsoft.BizTalk.FlatFileExtension.FlatFileExtension"" standardName=""Flat File"" xmlns:schemaEditorExtension=""http://schemas.microsoft.com/BizTalk/2003/SchemaEditorExtensions"" />
      <b:schemaInfo standard=""Flat File"" codepage=""65001"" default_pad_char="" "" pad_char_type=""char"" count_positions_by_byte=""false"" parser_optimization=""speed"" lookahead_depth=""3"" suppress_empty_nodes=""false"" generate_empty_nodes=""true"" allow_early_termination=""false"" early_terminate_optional_fields=""false"" allow_message_breakup_of_infix_root=""false"" compile_parse_tables=""false"" root_reference=""BillingRequest"" />
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Schemas.OrderProperties"" location=""Correlation.OrderProperties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""BillingRequest"">
    <xs:annotation>
      <xs:appinfo>
        <b:recordInfo structure=""delimited"" child_delimiter_type=""hex"" child_delimiter=""0xD 0xA"" child_order=""infix"" sequence_number=""1"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" />
        <b:properties>
          <b:property name=""ns0:Taxes"" xpath=""/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='BillableItems' and namespace-uri()='']/*[local-name()='Tax' and namespace-uri()='']"" />
          <b:property name=""ns0:OrderNumber"" xpath=""/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='OrderIdentifier' and namespace-uri()='']"" />
          <b:property name=""ns0:CustomerIdentifier"" xpath=""/*[local-name()='BillingRequest' and namespace-uri()='http://pluralsight.com/billing']/*[local-name()='Customer' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:annotation>
          <xs:appinfo>
            <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
          </xs:appinfo>
        </xs:annotation>
        <xs:element name=""Customer"" type=""xs:string"">
          <xs:annotation>
            <xs:appinfo>
              <b:fieldInfo justification=""left"" sequence_number=""1"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
        <xs:element name=""OrderIdentifier"" type=""xs:integer"">
          <xs:annotation>
            <xs:appinfo>
              <b:fieldInfo justification=""left"" sequence_number=""2"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
        <xs:element name=""OrderDate"" type=""xs:date"">
          <xs:annotation>
            <xs:appinfo>
              <b:fieldInfo justification=""left"" sequence_number=""3"" datetime_format=""yyyyMMdd"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
        <xs:element name=""BillingAddress"" type=""FlatAddressType"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo structure=""delimited"" child_delimiter_type=""char"" child_delimiter="","" child_order=""infix"" sequence_number=""4"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" tag_name=""BILLTO:"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
        <xs:element name=""ShippingAddress"" type=""FlatAddressType"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo sequence_number=""5"" structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" tag_name=""SHIPTO:"" child_delimiter_type=""char"" child_delimiter="","" child_order=""infix"" />
            </xs:appinfo>
          </xs:annotation>
        </xs:element>
        <xs:element name=""BillableItems"">
          <xs:annotation>
            <xs:appinfo>
              <b:recordInfo sequence_number=""6"" structure=""delimited"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" child_delimiter_type=""hex"" child_delimiter=""0x0D 0x0A"" child_order=""infix"" />
            </xs:appinfo>
          </xs:annotation>
          <xs:complexType>
            <xs:sequence>
              <xs:annotation>
                <xs:appinfo>
                  <b:groupInfo sequence_number=""0"" />
                </xs:appinfo>
              </xs:annotation>
              <xs:element maxOccurs=""unbounded"" name=""BillableItem"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:recordInfo sequence_number=""1"" structure=""positional"" preserve_delimiter_for_empty_data=""true"" suppress_trailing_delimiters=""false"" tag_name=""001 "" />
                  </xs:appinfo>
                </xs:annotation>
                <xs:complexType>
                  <xs:sequence>
                    <xs:annotation>
                      <xs:appinfo>
                        <b:groupInfo sequence_number=""0"" />
                      </xs:appinfo>
                    </xs:annotation>
                    <xs:element default=""AP21"" name=""ProductID"" type=""xs:string"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo justification=""left"" sequence_number=""1"" pos_length=""5"" pad_char_type=""char"" pad_char="" "" pos_offset=""4"" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element name=""ExtendedPrice"" type=""xs:decimal"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo sequence_number=""2"" justification=""right"" pos_length=""7"" pad_char_type=""char"" pad_char=""#"" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                    <xs:element name=""Quantity"" type=""xs:positiveInteger"">
                      <xs:annotation>
                        <xs:appinfo>
                          <b:fieldInfo sequence_number=""3"" justification=""right"" pad_char_type=""char"" pad_char=""#"" pos_length=""3"" />
                        </xs:appinfo>
                      </xs:annotation>
                    </xs:element>
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
              <xs:element name=""Tax"" type=""xs:decimal"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""2"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
              <xs:element name=""Total"" type=""xs:decimal"">
                <xs:annotation>
                  <xs:appinfo>
                    <b:fieldInfo justification=""left"" sequence_number=""3"" />
                  </xs:appinfo>
                </xs:annotation>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""FlatAddressType"">
    <xs:sequence>
      <xs:annotation>
        <xs:appinfo>
          <groupInfo sequence_number=""0"" xmlns=""http://schemas.microsoft.com/BizTalk/2003"" />
        </xs:appinfo>
      </xs:annotation>
      <xs:element name=""Addressee"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""1"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
      <xs:element name=""Street"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""2"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
      <xs:element name=""City"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""3"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
      <xs:element name=""State"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""4"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
      <xs:element name=""Zip"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""5"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
      <xs:element name=""Country"" type=""xs:string"">
        <xs:annotation>
          <xs:appinfo>
            <b:fieldInfo justification=""left"" sequence_number=""6"" />
          </xs:appinfo>
        </xs:annotation>
      </xs:element>
    </xs:sequence>
  </xs:complexType>
</xs:schema>";
        
        public Billing() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "BillingRequest";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
