namespace Correlation {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/abts/ordershipment",@"OrderShipping")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Correlation.OrderNumber), XPath = @"/*[local-name()='OrderShipping' and namespace-uri()='http://pluralsight.com/abts/ordershipment']/*[local-name()='OrderID' and namespace-uri()='']", XsdType = @"integer")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Correlation.CustomerIdentifier), XPath = @"/*[local-name()='OrderShipping' and namespace-uri()='http://pluralsight.com/abts/ordershipment']/*[local-name()='CustomerID' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"OrderShipping"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Correlation.OrderProperties", typeof(Correlation.OrderProperties))]
    public sealed class OrderShipping : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:ns0=""https://Schemas.OrderProperties"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/abts/ordershipment"" targetNamespace=""http://pluralsight.com/abts/ordershipment"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""ns0"" uri=""https://Schemas.OrderProperties"" location=""Correlation.OrderProperties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""OrderShipping"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""ns0:OrderNumber"" xpath=""/*[local-name()='OrderShipping' and namespace-uri()='http://pluralsight.com/abts/ordershipment']/*[local-name()='OrderID' and namespace-uri()='']"" />
          <b:property name=""ns0:CustomerIdentifier"" xpath=""/*[local-name()='OrderShipping' and namespace-uri()='http://pluralsight.com/abts/ordershipment']/*[local-name()='CustomerID' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element name=""OrderID"" type=""xs:integer"" />
        <xs:element name=""PointOfContact"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""NameAndTitle"" type=""xs:string"" />
              <xs:element name=""Phone"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderDate"" type=""xs:dateTime"" />
        <xs:element name=""RequiredShipDate"" type=""xs:date"" />
        <xs:element name=""ShipAddress"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Street"" type=""xs:string"" />
              <xs:element name=""City"" type=""xs:string"" />
              <xs:element name=""Region"" type=""xs:string"" />
              <xs:element name=""PostalCode"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""PackingSlip"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Sku"" type=""xs:string"" />
                    <xs:element name=""Qty"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderTotal"" type=""xs:double"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public OrderShipping() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "OrderShipping";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
