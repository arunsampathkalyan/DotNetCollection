namespace Correlation {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Property)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"CustomerIdentifier", @"ShippingCountry", @"Taxes", @"OrderNumber"})]
    public sealed class OrderProperties : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://Schemas.OrderProperties"" targetNamespace=""https://Schemas.OrderProperties"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo schema_type=""property"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""CustomerIdentifier"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""c2a5fd4e-67d0-4933-af57-ca5a96ed7883"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ShippingCountry"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""9dd7da3e-3db9-4267-8ade-722df70327d9"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""Taxes"" type=""xs:decimal"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""a193fc60-e684-4828-89a9-74253508aad5"" propSchFieldBase=""MessageContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""OrderNumber"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""9a559df1-beb3-4ea2-a75a-1a2249425a74"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
</xs:schema>";
        
        public OrderProperties() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [4];
                _RootElements[0] = "CustomerIdentifier";
                _RootElements[1] = "ShippingCountry";
                _RootElements[2] = "Taxes";
                _RootElements[3] = "OrderNumber";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"CustomerIdentifier",@"https://Schemas.OrderProperties","string","System.String")]
    [PropertyGuidAttribute(@"c2a5fd4e-67d0-4933-af57-ca5a96ed7883")]
    public sealed class CustomerIdentifier : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"CustomerIdentifier", @"https://Schemas.OrderProperties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ShippingCountry",@"https://Schemas.OrderProperties","string","System.String")]
    [PropertyGuidAttribute(@"9dd7da3e-3db9-4267-8ade-722df70327d9")]
    public sealed class ShippingCountry : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ShippingCountry", @"https://Schemas.OrderProperties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"Taxes",@"https://Schemas.OrderProperties","decimal","System.Decimal")]
    [PropertyGuidAttribute(@"a193fc60-e684-4828-89a9-74253508aad5")]
    public sealed class Taxes : Microsoft.XLANGs.BaseTypes.MessageContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"Taxes", @"https://Schemas.OrderProperties");
        
        private static decimal PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(decimal);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"OrderNumber",@"https://Schemas.OrderProperties","string","System.String")]
    [PropertyGuidAttribute(@"9a559df1-beb3-4ea2-a75a-1a2249425a74")]
    public sealed class OrderNumber : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"OrderNumber", @"https://Schemas.OrderProperties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
}
