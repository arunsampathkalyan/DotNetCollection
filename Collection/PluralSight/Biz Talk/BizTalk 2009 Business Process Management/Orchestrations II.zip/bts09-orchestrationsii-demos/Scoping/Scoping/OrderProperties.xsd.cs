namespace Scoping {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Property)]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"CustomerIdentifier", @"ShippingCountry", @"OrchProcessed"})]
    public sealed class OrderProperties : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://Schemas.OrderProperties"" targetNamespace=""https://Schemas.OrderProperties"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo schema_type=""property"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""CustomerIdentifier"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""c2a5fd4e-67d0-4933-af57-ca5a96ed7883"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""ShippingCountry"" type=""xs:string"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""9dd7da3e-3db9-4267-8ade-722df70327d9"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
  <xs:element name=""OrchProcessed"" type=""xs:boolean"">
    <xs:annotation>
      <xs:appinfo>
        <b:fieldInfo propertyGuid=""84363fdf-4557-4ca3-84f2-2849313005d6"" propSchFieldBase=""MessageContextPropertyBase"" />
      </xs:appinfo>
    </xs:annotation>
  </xs:element>
</xs:schema>";
        
        public OrderProperties() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [3];
                _RootElements[0] = "CustomerIdentifier";
                _RootElements[1] = "ShippingCountry";
                _RootElements[2] = "OrchProcessed";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"CustomerIdentifier",@"https://Schemas.OrderProperties","string","System.String")]
    [PropertyGuidAttribute(@"c2a5fd4e-67d0-4933-af57-ca5a96ed7883")]
    public sealed class CustomerIdentifier : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"CustomerIdentifier", @"https://Schemas.OrderProperties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"ShippingCountry",@"https://Schemas.OrderProperties","string","System.String")]
    [PropertyGuidAttribute(@"9dd7da3e-3db9-4267-8ade-722df70327d9")]
    public sealed class ShippingCountry : Microsoft.XLANGs.BaseTypes.MessageDataPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"ShippingCountry", @"https://Schemas.OrderProperties");
        
        private static string PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(string);
            }
        }
    }
    
    [System.SerializableAttribute()]
    [PropertyType(@"OrchProcessed",@"https://Schemas.OrderProperties","boolean","System.Boolean")]
    [PropertyGuidAttribute(@"84363fdf-4557-4ca3-84f2-2849313005d6")]
    public sealed class OrchProcessed : Microsoft.XLANGs.BaseTypes.MessageContextPropertyBase {
        
        [System.NonSerializedAttribute()]
        private static System.Xml.XmlQualifiedName _QName = new System.Xml.XmlQualifiedName(@"OrchProcessed", @"https://Schemas.OrderProperties");
        
        private static bool PropertyValueType {
            get {
                throw new System.NotSupportedException();
            }
        }
        
        public override System.Xml.XmlQualifiedName Name {
            get {
                return _QName;
            }
        }
        
        public override System.Type Type {
            get {
                return typeof(bool);
            }
        }
    }
}
