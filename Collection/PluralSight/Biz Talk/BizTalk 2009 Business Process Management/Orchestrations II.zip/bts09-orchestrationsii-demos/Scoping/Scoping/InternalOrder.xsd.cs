namespace Scoping {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/ordering",@"InternalOrder")]
    [Microsoft.XLANGs.BaseTypes.PropertyAttribute(typeof(Scoping.ShippingCountry), XPath = @"/*[local-name()='InternalOrder' and namespace-uri()='http://pluralsight.com/ordering']/*[local-name()='ShippingAddress' and namespace-uri()='']/*[local-name()='Country' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"InternalOrder"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Scoping.OrderProperties", typeof(Scoping.OrderProperties))]
    public sealed class InternalOrder : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:props=""https://Schemas.OrderProperties"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/ordering"" targetNamespace=""http://pluralsight.com/ordering"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:annotation>
    <xs:appinfo>
      <b:imports>
        <b:namespace prefix=""props"" uri=""https://Schemas.OrderProperties"" location=""Scoping.OrderProperties"" />
      </b:imports>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""InternalOrder"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property name=""props:ShippingCountry"" xpath=""/*[local-name()='InternalOrder' and namespace-uri()='http://pluralsight.com/ordering']/*[local-name()='ShippingAddress' and namespace-uri()='']/*[local-name()='Country' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerName"" type=""xs:string"" />
        <xs:element name=""ShippingAddress"" type=""AddressType"" />
        <xs:element name=""BillingAddress"" type=""AddressType"" />
        <xs:element name=""Items"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""ProductID"" type=""xs:string"" />
                    <xs:element name=""Price"" type=""xs:decimal"" />
                    <xs:element name=""Quantity"" type=""xs:positiveInteger"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:complexType name=""AddressType"">
    <xs:sequence>
      <xs:element name=""Street"" type=""xs:string"" />
      <xs:element name=""City"" type=""xs:string"" />
      <xs:element name=""Region"" type=""xs:string"" />
      <xs:element name=""PostalCode"" type=""xs:string"" />
      <xs:element name=""Country"" type=""xs:string"" />
    </xs:sequence>
  </xs:complexType>
</xs:schema>";
        
        public InternalOrder() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "InternalOrder";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
