using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.BizTalk.Component.Interop;
using Microsoft.BizTalk.Message.Interop;
using System.Runtime.InteropServices;

namespace PipelineComponents
{
    [ComponentCategory(CategoryTypes.CATID_PipelineComponent)]
    [ComponentCategory(CategoryTypes.CATID_Any)]
    [Guid("F6BE8EBB-CF5E-424a-9938-C997183EB178")]
    public class PropertyPromoting  : IBaseComponent,
        IPersistPropertyBag, IComponent
    {
        private string ns;

        public string PropertyNamespace
        {
            get { return ns; }
            set { ns = value; }
        }

        private string prop;

        public string PropertyName
        {
            get { return prop; }
            set { prop = value; }
        }

        private string propValue;

        public string PromotedValue
        {
            get { return propValue; }
            set { propValue = value; }
        }



        #region IBaseComponent Members

        public string Description
        {
            get { return "Promotes the specified property to the message context."; }
        }

        public string Name
        {
            get { return "PS Property Promoter"; }
        }

        public string Version
        {
            get { return "1.0"; }
        }

        #endregion



        #region IPersistPropertyBag Members

        public void GetClassID(out Guid classID)
        {
            classID = new Guid("F6BE8EBB-CF5E-424a-9938-C997183EB178");
        }

        public void InitNew()
        {
        }

        public void Load(IPropertyBag propertyBag, int errorLog)
        {
            object returnedValue;
            returnedValue = ReadPropertyBag(propertyBag, "PropertyName");
            
            if (returnedValue != null)
                PropertyName = returnedValue.ToString();

            returnedValue = ReadPropertyBag(propertyBag, "PropertyNamespace");

            if (returnedValue != null)
                PropertyNamespace = returnedValue.ToString();


            returnedValue = ReadPropertyBag(propertyBag, "PropertyValue");

            if (returnedValue != null)
                PromotedValue = returnedValue.ToString();

        }

        public void Save(IPropertyBag propertyBag, bool clearDirty, bool saveAllProperties)
        {
            WritePropertyBag(propertyBag,"PropertyName", PropertyName);
            WritePropertyBag(propertyBag, "PropertyNamespace", PropertyNamespace);
            WritePropertyBag(propertyBag, "PropertyValue", PromotedValue);
        }

        #endregion

        #region IComponent Members

        public IBaseMessage Execute(IPipelineContext pContext, IBaseMessage pInMsg)
        {
            IBaseMessageFactory factory = pContext.GetMessageFactory();
            IBaseMessage pOutMsg = factory.CreateMessage();;
            IBaseMessagePart bodyPart = factory.CreateMessagePart();

            bodyPart.Data = pInMsg.BodyPart.Data;
            pOutMsg.Context = PipelineUtil.CloneMessageContext(pInMsg.Context);

            pOutMsg.AddPart("body", bodyPart, true);

            //promote property
            pOutMsg.Context.Promote(PropertyName, PropertyNamespace, PromotedValue);


            return pOutMsg;

        }

        #endregion

        #region Persistence Helpers

        /// <summary>
        /// Reads property value from property bag.
        /// </summary>
        /// <param name="pb">Property bag.</param>
        /// <param name="propName">Name of property.</param>
        /// <returns>Value of the property.</returns>
        protected object ReadPropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName)
        {
            object val = null;
            try
            {
                pb.Read(propName, out val, 0);
            }

            catch (ArgumentException)
            {
                return val;
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
            return val;
        }

        /// <summary>
        /// Writes property values into a property bag.
        /// </summary>
        /// <param name="pb">Property bag.</param>
        /// <param name="propName">Name of property.</param>
        /// <param name="val">Value of property.</param>
        protected void WritePropertyBag(Microsoft.BizTalk.Component.Interop.IPropertyBag pb, string propName, object val)
        {
            try
            {
                pb.Write(propName, ref val);
            }
            catch (Exception ex)
            {
                throw new ApplicationException(ex.Message);
            }
        }

        #endregion Persistence Helpers

    }
}
