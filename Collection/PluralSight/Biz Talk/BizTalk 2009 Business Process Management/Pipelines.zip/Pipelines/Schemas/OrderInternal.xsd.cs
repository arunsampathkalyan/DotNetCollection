namespace OrderProcessing.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/abts/order/internal",@"Order")]
    [Microsoft.XLANGs.BaseTypes.DistinguishedFieldAttribute(typeof(System.String), "CustomerID", XPath = @"/*[local-name()='Order' and namespace-uri()='http://pluralsight.com/abts/order/internal']/*[local-name()='CustomerID' and namespace-uri()='']", XsdType = @"string")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"Order"})]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"OrderProcessing.Schemas.CommonTypes", typeof(OrderProcessing.Schemas.CommonTypes))]
    public sealed class OrderInternal : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:common=""http://pluralsight.com/abts/common"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/abts/order/internal"" targetNamespace=""http://pluralsight.com/abts/order/internal"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:import schemaLocation=""OrderProcessing.Schemas.CommonTypes"" namespace=""http://pluralsight.com/abts/common"" />
  <xs:annotation>
    <xs:appinfo>
      <b:schemaInfo root_reference=""Order"" xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" />
      <b:references>
        <b:reference targetNamespace=""http://pluralsight.com/abts/common"" />
      </b:references>
    </xs:appinfo>
  </xs:annotation>
  <xs:element name=""Order"">
    <xs:annotation>
      <xs:appinfo>
        <b:properties>
          <b:property distinguished=""true"" xpath=""/*[local-name()='Order' and namespace-uri()='http://pluralsight.com/abts/order/internal']/*[local-name()='CustomerID' and namespace-uri()='']"" />
        </b:properties>
      </xs:appinfo>
    </xs:annotation>
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""OrderDate"" type=""xs:dateTime"" />
        <xs:element name=""CustomerID"" type=""xs:string"" />
        <xs:element name=""CompanyName"" type=""xs:string"" />
        <xs:element name=""PointOfContact"">
          <xs:complexType>
            <xs:sequence>
              <xs:element name=""Name"" type=""xs:string"" />
              <xs:element name=""Title"" type=""xs:string"" />
              <xs:element name=""Phone"" type=""xs:string"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element ref=""common:ShipTo"" />
        <xs:element ref=""common:BillTo"" />
        <xs:element name=""LineItems"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" ref=""common:LineItem"" />
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""OrderTotal"" type=""xs:double"" />
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>";
        
        public OrderInternal() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "Order";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
