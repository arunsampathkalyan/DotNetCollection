namespace OrderProcessing.Schemas {
    using Microsoft.XLANGs.BaseTypes;
    
    
    [SchemaType(SchemaTypeEnum.Document)]
    [Schema(@"http://pluralsight.com/abts/order/external",@"OrderExternal")]
    [System.SerializableAttribute()]
    [SchemaRoots(new string[] {@"OrderExternal"})]
    public sealed class OrderExternal : Microsoft.XLANGs.BaseTypes.SchemaBase {
        
        [System.NonSerializedAttribute()]
        private static object _rawSchema;
        
        [System.NonSerializedAttribute()]
        private const string _strSchema = @"<?xml version=""1.0"" encoding=""utf-16""?>
<xs:schema xmlns:b=""http://schemas.microsoft.com/BizTalk/2003"" xmlns=""http://pluralsight.com/abts/order/external"" targetNamespace=""http://pluralsight.com/abts/order/external"" xmlns:xs=""http://www.w3.org/2001/XMLSchema"">
  <xs:element name=""OrderExternal"">
    <xs:complexType>
      <xs:sequence>
        <xs:element name=""CustomerID"" type=""CustomerIDType"" />
        <xs:element name=""Addresses"">
          <xs:complexType>
            <xs:sequence>
              <xs:element maxOccurs=""unbounded"" name=""Address"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Addressee"" type=""xs:string"" />
                    <xs:element name=""Line1"" type=""xs:string"" />
                    <xs:element name=""Line2"" type=""xs:string"" />
                    <xs:element name=""City"" type=""xs:string"" />
                    <xs:element name=""Region"" type=""xs:string"" />
                    <xs:element name=""PostalCode"" type=""xs:string"" />
                    <xs:element name=""Country"" type=""xs:string"" />
                  </xs:sequence>
                  <xs:attribute name=""Label"" type=""AddressLabelEnum"" use=""required"" />
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name=""Items"">
          <xs:complexType>
            <xs:sequence>
              <xs:element minOccurs=""0"" maxOccurs=""unbounded"" name=""Item"">
                <xs:complexType>
                  <xs:sequence>
                    <xs:element name=""Sku"" type=""xs:positiveInteger"" />
                    <xs:element name=""Description"" type=""xs:string"" />
                    <xs:element name=""Price"" type=""xs:double"" />
                    <xs:element name=""Quantity"" type=""xs:string"" />
                  </xs:sequence>
                </xs:complexType>
              </xs:element>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
  <xs:simpleType name=""AddressLabelEnum"">
    <xs:restriction base=""xs:string"">
      <xs:enumeration value=""ShipTo"" />
      <xs:enumeration value=""BillTo"" />
    </xs:restriction>
  </xs:simpleType>
  <xs:simpleType name=""CustomerIDType"">
    <xs:restriction base=""xs:string"">
      <xs:pattern value=""[A-Z]{5}"" />
    </xs:restriction>
  </xs:simpleType>
</xs:schema>";
        
        public OrderExternal() {
        }
        
        public override string XmlContent {
            get {
                return _strSchema;
            }
        }
        
        public override string[] RootNodes {
            get {
                string[] _RootElements = new string [1];
                _RootElements[0] = "OrderExternal";
                return _RootElements;
            }
        }
        
        protected override object RawSchema {
            get {
                return _rawSchema;
            }
            set {
                _rawSchema = value;
            }
        }
    }
}
