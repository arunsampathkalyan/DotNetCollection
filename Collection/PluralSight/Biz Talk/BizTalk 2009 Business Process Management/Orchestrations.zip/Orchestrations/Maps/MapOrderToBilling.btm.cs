namespace Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.ExternalOrder", typeof(Schemas.ExternalOrder))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.BillingRequestFlat", typeof(Schemas.BillingRequestFlat))]
    public sealed class MapOrderToBilling : Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 ScriptNS0 userCSharp userVB"" version=""1.0"" xmlns:s0=""http://pluralsight.com/ABTS/Schemas"" xmlns:ns0=""http://pluralsight.com/ABTS/Flat"" xmlns:s1=""http://Schemas.ExternalOrder"" xmlns:ScriptNS0=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"" xmlns:userVB=""http://schemas.microsoft.com/BizTalk/2003/userVB"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Order"" />
  </xsl:template>
  <xsl:template match=""/s1:Order"">
    <xsl:variable name=""var:v3"" select=""userCSharp:DateCurrentDate()"" />
    <ns0:BillingRequest>
      <xsl:variable name=""var:v1"" select=""ScriptNS0:DBLookup(0 , string(CustomerID/text()) , &quot;provider=sqloledb.1;server=.;database=northwind;integrated security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
      <xsl:variable name=""var:v2"" select=""ScriptNS0:DBValueExtract(string($var:v1) , &quot;CompanyName&quot;)"" />
      <CustomerName>
        <xsl:value-of select=""$var:v2"" />
      </CustomerName>
      <BillingDate>
        <xsl:value-of select=""$var:v3"" />
      </BillingDate>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v4"" select=""userCSharp:LogicalEq(string(@AddressType) , &quot;Shipping&quot;)"" />
        <xsl:if test=""$var:v4"">
          <xsl:variable name=""var:v7"" select=""userCSharp:StringConcat(string(Line1/text()) , &quot;;&quot; , string(Line2/text()))"" />
          <ShippingAddress>
            <xsl:variable name=""var:v5"" select=""ScriptNS0:DBLookup(0 , string(../../CustomerID/text()) , &quot;provider=sqloledb.1;server=.;database=northwind;integrated security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
            <xsl:variable name=""var:v6"" select=""ScriptNS0:DBValueExtract(string($var:v5) , &quot;ContactName&quot;)"" />
            <Name>
              <xsl:value-of select=""$var:v6"" />
            </Name>
            <Street>
              <xsl:value-of select=""$var:v7"" />
            </Street>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <State>
              <xsl:value-of select=""State/text()"" />
            </State>
            <Zip>
              <xsl:value-of select=""Zip/text()"" />
            </Zip>
          </ShippingAddress>
        </xsl:if>
      </xsl:for-each>
      <xsl:for-each select=""Addresses/Address"">
        <xsl:variable name=""var:v8"" select=""string(@AddressType)"" />
        <xsl:variable name=""var:v9"" select=""userCSharp:LogicalEq($var:v8 , &quot;Billing&quot;)"" />
        <xsl:if test=""$var:v9"">
          <xsl:variable name=""var:v10"" select=""string(../../CustomerID/text())"" />
          <xsl:variable name=""var:v13"" select=""string(Line1/text())"" />
          <xsl:variable name=""var:v14"" select=""string(Line2/text())"" />
          <xsl:variable name=""var:v15"" select=""userCSharp:StringConcat($var:v13 , &quot;;&quot; , $var:v14)"" />
          <BillingAddress>
            <xsl:variable name=""var:v11"" select=""ScriptNS0:DBLookup(0 , $var:v10 , &quot;provider=sqloledb.1;server=.;database=northwind;integrated security=SSPI&quot; , &quot;Customers&quot; , &quot;CustomerID&quot;)"" />
            <xsl:variable name=""var:v12"" select=""ScriptNS0:DBValueExtract(string($var:v11) , &quot;ContactName&quot;)"" />
            <Name>
              <xsl:value-of select=""$var:v12"" />
            </Name>
            <Street>
              <xsl:value-of select=""$var:v15"" />
            </Street>
            <City>
              <xsl:value-of select=""City/text()"" />
            </City>
            <State>
              <xsl:value-of select=""State/text()"" />
            </State>
            <Zip>
              <xsl:value-of select=""Zip/text()"" />
            </Zip>
          </BillingAddress>
        </xsl:if>
      </xsl:for-each>
      <Totals>
        <xsl:variable name=""var:v16"" select=""userCSharp:InitCumulativeSum(0)"" />
        <xsl:for-each select=""/s1:Order/Items/Item"">
          <xsl:variable name=""var:v17"" select=""userCSharp:MathMultiply(string(Price/text()) , string(Qty/text()))"" />
          <xsl:variable name=""var:v18"" select=""userCSharp:AddToCumulativeSum(0,string($var:v17),&quot;1000&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v19"" select=""userCSharp:GetCumulativeSum(0)"" />
        <SubTotal>
          <xsl:value-of select=""$var:v19"" />
        </SubTotal>
        <xsl:variable name=""var:v20"" select=""userCSharp:InitCumulativeSum(1)"" />
        <xsl:for-each select=""/s1:Order/Items/Item"">
          <xsl:variable name=""var:v21"" select=""string(Price/text())"" />
          <xsl:variable name=""var:v22"" select=""string(Qty/text())"" />
          <xsl:variable name=""var:v23"" select=""userCSharp:MathMultiply($var:v21 , $var:v22)"" />
          <xsl:variable name=""var:v24"" select=""userVB:ComputeTax(string($var:v23))"" />
          <xsl:variable name=""var:v25"" select=""userCSharp:AddToCumulativeSum(1,string($var:v24),&quot;1000&quot;)"" />
        </xsl:for-each>
        <xsl:variable name=""var:v26"" select=""userCSharp:GetCumulativeSum(1)"" />
        <Tax>
          <xsl:value-of select=""$var:v26"" />
        </Tax>
      </Totals>
    </ns0:BillingRequest>
    <xsl:variable name=""var:v27"" select=""ScriptNS0:DBLookupShutdown()"" />
  </xsl:template>
  <msxsl:script language=""VB"" implements-prefix=""userVB""><![CDATA[
''Uncomment the following code for a sample Inline VBNet function
''that concatenates two inputs. Change the number of parameters of
''this function to be equal to the number of inputs connected to this functoid.
Public Function ComputeTax(byval price as string) As String
	Return cstr( cdbl(price) * .03)
End Function


]]></msxsl:script>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string DateCurrentDate()
{
	DateTime dt = DateTime.Now;
	return dt.ToString(""yyyy-MM-dd"", System.Globalization.CultureInfo.InvariantCulture);
}


public bool LogicalEq(string val1, string val2)
{
	bool ret = false;
	double d1 = 0;
	double d2 = 0;
	if (IsNumeric(val1, ref d1) && IsNumeric(val2, ref d2))
	{
		ret = d1 == d2;
	}
	else
	{
		ret = String.Compare(val1, val2, StringComparison.Ordinal) == 0;
	}
	return ret;
}


public string StringConcat(string param0, string param1, string param2)
{
   return param0 + param1 + param2;
}


public string InitCumulativeSum(int index)
{
	if (index >= 0)
	{
		if (index >= myCumulativeSumArray.Count)
		{
			int i = myCumulativeSumArray.Count;
			for (; i<=index; i++)
			{
				myCumulativeSumArray.Add("""");
			}
		}
		else
		{
			myCumulativeSumArray[index] = """";
		}
	}
	return """";
}

public System.Collections.ArrayList myCumulativeSumArray = new System.Collections.ArrayList();

public string AddToCumulativeSum(int index, string val, string notused)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
    }
	double d = 0;
	if (IsNumeric(val, ref d))
	{
		if (myCumulativeSumArray[index] == """")
		{
			myCumulativeSumArray[index] = d;
		}
		else
		{
			myCumulativeSumArray[index] = (double)(myCumulativeSumArray[index]) + d;
		}
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string GetCumulativeSum(int index)
{
	if (index < 0 || index >= myCumulativeSumArray.Count)
	{
		return """";
	}
	return (myCumulativeSumArray[index] is double) ? ((double)myCumulativeSumArray[index]).ToString(System.Globalization.CultureInfo.InvariantCulture) : """";
}

public string MathMultiply(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 1;
	bool first = true;
	foreach (string obj in listValues)
	{
		double d = 0;
		if (IsNumeric(obj, ref d))
		{
			if (first)
			{
				first = false;
				ret = d;
			}
			else
			{
				ret *= d;
			}
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects>
  <ExtensionObject Namespace=""http://schemas.microsoft.com/BizTalk/2003/ScriptNS0"" AssemblyName=""Microsoft.BizTalk.BaseFunctoids, Version=3.0.1.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"" ClassName=""Microsoft.BizTalk.BaseFunctoids.FunctoidScripts"" />
</ExtensionObjects>";
        
        private const string _strSrcSchemasList0 = @"Schemas.ExternalOrder";
        
        private const Schemas.ExternalOrder _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Schemas.BillingRequestFlat";
        
        private const Schemas.BillingRequestFlat _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Schemas.ExternalOrder";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Schemas.BillingRequestFlat";
                return _TrgSchemas;
            }
        }
    }
}
