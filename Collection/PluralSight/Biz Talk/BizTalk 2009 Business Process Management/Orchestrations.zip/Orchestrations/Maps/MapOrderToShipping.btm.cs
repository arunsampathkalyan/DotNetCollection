namespace Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.ExternalOrder", typeof(Schemas.ExternalOrder))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Schemas.OrderShipping", typeof(Schemas.OrderShipping))]
    public sealed class MapOrderToShipping : Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1 userCSharp"" version=""1.0"" xmlns:s0=""http://pluralsight.com/ABTS/Schemas"" xmlns:ns0=""http://pluralsight.com/abts/ordershipment"" xmlns:common=""http://pluralsight.com/abts/common"" xmlns:s1=""http://Schemas.ExternalOrder"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Order"" />
  </xsl:template>
  <xsl:template match=""/s1:Order"">
    <ns0:OrderShipping>
      <CustomerID>
        <xsl:value-of select=""CustomerID/text()"" />
      </CustomerID>
      <xsl:for-each select=""Addresses/Address"">
        <common:ShipTo>
          <Line1>
            <xsl:value-of select=""Line1/text()"" />
          </Line1>
          <xsl:if test=""Line2"">
            <Line2>
              <xsl:value-of select=""Line2/text()"" />
            </Line2>
          </xsl:if>
          <City>
            <xsl:value-of select=""City/text()"" />
          </City>
          <Region>
            <xsl:value-of select=""State/text()"" />
          </Region>
          <PostalCode>
            <xsl:value-of select=""Zip/text()"" />
          </PostalCode>
          <Country>
            <xsl:text>USA</xsl:text>
          </Country>
        </common:ShipTo>
      </xsl:for-each>
      <PackingSlip>
        <xsl:for-each select=""Items/Item"">
          <xsl:variable name=""var:v1"" select=""userCSharp:MathMultiply(string(Price/text()) , string(Qty/text()))"" />
          <common:LineItem>
            <ProductID>
              <xsl:value-of select=""ProductID/text()"" />
            </ProductID>
            <UnitPrice>
              <xsl:value-of select=""Price/text()"" />
            </UnitPrice>
            <Quantity>
              <xsl:value-of select=""Qty/text()"" />
            </Quantity>
            <ExtendedPrice>
              <xsl:value-of select=""$var:v1"" />
            </ExtendedPrice>
          </common:LineItem>
        </xsl:for-each>
      </PackingSlip>
    </ns0:OrderShipping>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string MathMultiply(string param0, string param1)
{
	System.Collections.ArrayList listValues = new System.Collections.ArrayList();
	listValues.Add(param0);
	listValues.Add(param1);
	double ret = 1;
	bool first = true;
	foreach (string obj in listValues)
	{
		double d = 0;
		if (IsNumeric(obj, ref d))
		{
			if (first)
			{
				first = false;
				ret = d;
			}
			else
			{
				ret *= d;
			}
		}
		else
		{
			return """";
		}
	}
	return ret.ToString(System.Globalization.CultureInfo.InvariantCulture);
}


public bool IsNumeric(string val)
{
	if (val == null)
	{
		return false;
	}
	double d = 0;
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}

public bool IsNumeric(string val, ref double d)
{
	if (val == null)
	{
		return false;
	}
	return Double.TryParse(val, System.Globalization.NumberStyles.AllowThousands | System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d);
}


]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Schemas.ExternalOrder";
        
        private const Schemas.ExternalOrder _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Schemas.OrderShipping";
        
        private const Schemas.OrderShipping _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Schemas.ExternalOrder";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Schemas.OrderShipping";
                return _TrgSchemas;
            }
        }
    }
}
