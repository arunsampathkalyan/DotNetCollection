Julie Lerman for Pluralsight
www.learnentityframework.com
www.pluralsight.com

Sample solution for "Inheritance in Entity Data Model (Course 2, Module 3)

The project in this solution shows the EDM after making all of the customizations shown in the video.
It also contains the integration tests used in the video. If you want to run those tests, you'll need to create the Conferences database using the include sql script, then attach the database to your SQL Server or SQL Server Express instance, then make the necessary modifications to the connection string in app.config.

