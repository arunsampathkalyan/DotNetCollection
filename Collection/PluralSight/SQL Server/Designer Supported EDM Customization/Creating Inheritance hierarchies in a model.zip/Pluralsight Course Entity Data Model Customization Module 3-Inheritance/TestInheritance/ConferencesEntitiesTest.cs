﻿using System.Linq;
using ConferenceModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestInheritance
{

  [TestClass]
  public class ConferencesEntitiesTest
  {




    [TestMethod]
    public void QueryingBaseTypeReturnsAllHierarchyTypes()
    {
      var context = new ConferencesEntities();
      var allSpeakers = context.Speakers.ToList();
      foreach (var s in allSpeakers)
      {
        System.Diagnostics.Debug.WriteLine
          (s.FirstName.Trim() + " " + s.LastName + ":    " + s.GetType().Name);
      }
      Assert.IsTrue(allSpeakers.Any(s => s is ActiveSpeaker) &&
        allSpeakers.Any(s => s is InactiveSpeaker));
    }



    [TestMethod]
    public void QueryingDerivedTypeReturnsOnlyThatType()
    {
      var context = new ConferencesEntities();
      var allSpeakers = context.Speakers.OfType<ActiveSpeaker>().ToList();
      foreach (var s in allSpeakers)
      {
        System.Diagnostics.Debug.WriteLine
          (s.FirstName.Trim() + " " + s.LastName + ":    " + s.GetType().Name);
      }
      Assert.IsFalse(allSpeakers.Any(s => s is InactiveSpeaker));
    }



    [TestMethod]
    public void QueryingBaseTypeSessionReturnsAllSessionTypes()
    {
      var context = new ConferencesEntities();
      var allSessions = context.Sessions.ToList();
      foreach (var s in allSessions)
      {
        System.Diagnostics.Debug.WriteLine
          (s.Title.Trim() + ":    " + s.GetType().Name);
      }
      Assert.IsTrue(allSessions.Any(s => s is Workshop) &&
        allSessions.Any(s => (!(s is Workshop))));
    }



    [TestMethod]
    public void QueryingDerivedTypeWorkhopReturnsOnlyWorkshopTypes()
    {
      var context = new ConferencesEntities();
      var someSessions = context.Sessions.OfType<Workshop>().ToList();
      foreach (var s in someSessions)
      {
        System.Diagnostics.Debug.WriteLine
         (s.Title.Trim() + ":    " + s.GetType().Name);
      }
      Assert.IsFalse(someSessions.Any(s => (!(s is Workshop))));
    }



    [TestMethod]
    public void InsertNewTPHActiveSpeakerGeneratesSingleDbInsert()
    {
      var newSpeaker = new ActiveSpeaker
                         {
                           FirstName = "Julie",
                           LastName = "Lerman",
                           Expertise = "Entity Framework"
                         };
      var context = new ConferencesEntities();
      context.Speakers.AddObject(newSpeaker);
      context.SaveChanges();
      var newSpeakerId = newSpeaker.SpeakerId;
      newSpeaker = null;

      context = new ConferencesEntities(); //fresh context with no knowledge of speaker
      var dbSpeaker = context.Speakers.Where(s => s.SpeakerId == newSpeakerId).First();
      Assert.IsInstanceOfType(dbSpeaker, typeof(ActiveSpeaker));
      //check profiler for insert command
    }
    
    
    
    [TestMethod]
    public void InsertNewTPTWorkshopGeneratesMultipleDbInserts()
    {
      var context = new ConferencesEntities();
      var newWorkshop = new Workshop
                          {
                            Title = "My Long Life With Dracula",
                            ConferenceTrackTrackId = 1,
                            Length = "60",
                            PreRequisite="Study of Bram Stoker's Dracula"
                          };

      context.Sessions.AddObject(newWorkshop);
      context.SaveChanges();
      Assert.Inconclusive("check profiler for generated commands");
    }

  }
}

