Julie Lerman for Pluralsight
www.learnentityframework.com
www.pluralsight.com

Sample solution for "Designer Supported Entity Data Model Customization" (Course 2, Module 1)

The project in this solution shows the EDM after making all of the customizations shown in the video.

