﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AWModel
{
  class Class1
  {
    public Product GetProducts()
    {
      var context = new AWEntities();
      //using a complex type in a LINQ to Entities query
      var productQuery = from p in context.Products
                         where p.PhysicalAttributes.Color == "Black"
                         select p;
      //using a complex type as an object instance
      var attri = new ProductAttributes {Color = "blue"};
      var product = new Product {PhysicalAttributes = attri};
    }


  }
}