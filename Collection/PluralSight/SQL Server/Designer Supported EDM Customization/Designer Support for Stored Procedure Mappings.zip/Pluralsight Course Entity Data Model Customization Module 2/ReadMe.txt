Julie Lerman for Pluralsight
www.learnentityframework.com
www.pluralsight.com

Sample solution for "Designer Support for Stored Procedures in Entity Data Model (Course 2, Module 2)

The project in this solution shows the EDM after making all of the customizations shown in the video.
It also contains the integration tests used in the video. If you want to run those tests, you'll need to attach the AdventureWorksSuperLT to your SQL Server or SQL Server Express instance and make the necessary modifications to the connection string in app.config.

