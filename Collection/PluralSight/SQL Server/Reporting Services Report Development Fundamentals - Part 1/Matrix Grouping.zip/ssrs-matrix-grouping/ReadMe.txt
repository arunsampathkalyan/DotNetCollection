Basic Report Development
Stacia Misner
www.pluralsight.com


This demonstration assumes that you have installed AdventureWorksDW2008R2 database 
in the local SQL Server 2008 R2 database instance. You can download the database
available from http://msftdbprodsamples.codeplex.com/releases/view/55926.
