Julie Lerman for Pluralsight
www.learnentityframework.com
www.pluralsight.com


Sample solution for "Digging Deeper with LINQ to Entities" 

This project contains the model and the tests used to explore querying with the Entity Framework.

There is also a sql script for creating the database, AdventureWorksSuperLT which is used for this solution.

The connection string in the app.config files points to a SQL Server instance of the database. Modify the connection string as necessary based on where you create this sample database.

Julie Lerman
twitter.com/julielerman


