Julie Lerman for Pluralsight
www.learnentityframework.com
www.pluralsight.com


Sample solution for "Querying Entity Framework Overview" 

This project contains the model and the tests used to explore querying with the Entity Framework.

There is also a sql script for creating the database, AdventureWorksLT which is used for this solution.

The connection string in the app.config files points to a SQL Server instance of the database. Modify the connection string as necessary based on where you create this sample database.

Julie Lerman
twitter.com/julielerman


