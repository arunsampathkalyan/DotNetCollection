USE SpatialData 

CREATE TABLE [dbo].[ShippingRoute] (
    [ID]                INT IDENTITY(1, 1),
    [StartLocation]     VARCHAR(100),
    [EndLocation]       VARCHAR(50),
    [DATE]				DATETIME,
    [StartLatitude]     FLOAT,
    [StartLongitude]    FLOAT,
    [EndLatitude]     FLOAT,
    [EndLongitude]    FLOAT
    
)
GO

INSERT INTO [dbo].[ShippingRoute] ( [StartLocation],[EndLocation],[Date], [StartLatitude], [StartLongitude], [EndLatitude], [EndLongitude] )
VALUES ( 'MEMPHIS, TN','LAS VEGAS, NV', '7/20/2010', 35.14, -90.4, 36.175, -115.13 ),
      (  'NEWARK, NJ', 'MEMPHIS,TN', '7/19/2010', 40.73, -74.17, 35.14, -90.4 ),
      ( 'ANCHORAGE, AK', 'NEWARK, NJ', '7/18/2010', 61.2, -149.9 ,  40.73, -74.17  ),
      ( 'HONG KONG', 'ANCHORAGE, AK', '7/16/2010', 22.25, 114.16, 61.2, -149.9 ),
      ( 'SHENZHEN, CHINA', 'HONG KONG', '7/16/2010', 22.53, 114.13, 22.25, 114.16 )
GO

ALTER TABLE [dbo].[ShippingRoute]
ADD [Route] GEOGRAPHY
GO


UPDATE [dbo].[ShippingRoute]
SET [Route] = 
                    
                    geography::STGeomFromText('LINESTRING(' + 
                    CAST([StartLongitude] as VARCHAR(20)) + ' ' + 
                    CAST([StartLatitude] as VARCHAR(20)) + ', ' + 
                    CAST([EndLongitude] as VARCHAR(20)) + ' ' + 
                    CAST([EndLatitude] as VARCHAR(20)) + ')', 4326)
GO