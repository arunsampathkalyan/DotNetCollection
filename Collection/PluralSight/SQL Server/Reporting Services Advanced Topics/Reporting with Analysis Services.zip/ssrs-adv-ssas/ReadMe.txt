Reporting with Analysis Services
Stacia Misner
www.pluralsight.com


This demonstration also assumes that you have installed Adventure Works DW 2008R2 database
in the local Analysis Services instance. The solution for this database is part of the same 
download for the SQL Server 2008 R2 database, and must be deployed manually following the 
instructions available at 
http://msftdbprodsamples.codeplex.com/wikipage?title=Installing%20Analysis%20Services%20Database. In the project properties, be sure to change the database name to Adventure Works DW 2008R2.
