select * into people4 from people;

select * from people4;

delete people4;

select * from people4;

select * into people5 from people;


select * from people5;

select * from people5 where [first name]='toby';

delete people5 where [first name]='toby';

select * from people5 where [first name]='toby';

select * from people5;

delete people5 where [first name]='bud' and [last name]='abbott';

select * from people5 where [first name]='bud' and [last name]='abbott';
