select * from authors
 for xml raw, elements, type