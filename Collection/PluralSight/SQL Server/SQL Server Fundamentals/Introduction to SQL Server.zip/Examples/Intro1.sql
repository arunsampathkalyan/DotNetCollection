insert into names values ('dawn');

select * from names
