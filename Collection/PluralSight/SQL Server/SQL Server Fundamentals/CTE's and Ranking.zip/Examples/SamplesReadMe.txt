Sample Code Content:

Database.sql is a sql script that that will build the table from the demos and fill them with content


Demos from talks:

AggregatePartitions.sql
employees.sql
EntityAttributeValue.sql
ExCTE.sql
ntile.sql
Partitioning.sql
Rank.sql
RowNumber.sql
ShiftNames.txt
Top.sql
Working.sql

