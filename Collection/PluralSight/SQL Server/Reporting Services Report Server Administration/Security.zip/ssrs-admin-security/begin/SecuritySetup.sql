DECLARE @EuropeMgr nvarchar(200) 
DECLARE @PacificMgr nvarchar(200) 
DECLARE @Analyst nvarchar(200) 

SET @EuropeMgr = @@SERVERNAME + '\EuropeMgr'
SET @PacificMgr = @@SERVERNAME + '\PacificMgr'


--drop the users from the database if they exist
use AdventureWorksDW2008
if exists(select * from sysusers where name=@EuropeMgr)
	exec sp_revokedbaccess @name_in_db=@EuropeMgr	
if exists(select * from sysusers where name=@PacificMgr)
	exec sp_revokedbaccess @name_in_db=@PacificMgr	

--create the logins
use master
exec sp_revokelogin @loginame=@EuropeMgr
exec sp_grantlogin @loginame=@EuropeMgr

exec sp_revokelogin @loginame=@PacificMgr
exec sp_grantlogin @loginame=@PacificMgr


use AdventureWorksDW2008
--add the users to the databases and give them permissions
exec sp_grantdbaccess @EuropeMgr, @EuropeMgr
exec sp_addrolemember 'db_datareader', @EuropeMgr
exec sp_grantdbaccess @PacificMgr, @PacificMgr
exec sp_addrolemember 'db_datareader', @PacificMgr


--create and populate PermissionsSalesTerritory Table

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[PermissionsSalesTerritory]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[PermissionsSalesTerritory]
GO

CREATE TABLE [dbo].[PermissionsSalesTerritory] (
	[UserId] [varchar] (50) NULL, 
	[SalesTerritoryGroup] [nvarchar] (50) NULL 
) ON [PRIMARY]
GO

declare @db_server as varchar(50)
set @db_server = @@SERVERNAME
INSERT INTO 
[dbo].[PermissionsSalesTerritory] VALUES 
(@db_server + '\Administrator', 'Europe')
GO

declare @db_server as varchar(50)
set @db_server = @@SERVERNAME
INSERT INTO 
[dbo].[PermissionsSalesTerritory] VALUES 
(@db_server + '\EuropeMgr', 'Europe')
GO

declare @db_server as varchar(50)
set @db_server = @@SERVERNAME
INSERT INTO 
[dbo].[PermissionsSalesTerritory] VALUES 
(@db_server + '\Administrator', 'North America')	
GO

declare @db_server as varchar(50)
set @db_server = @@SERVERNAME
INSERT INTO 
[dbo].[PermissionsSalesTerritory] VALUES 
(@db_server + '\PacificMgr', 'Pacific')	
GO

declare @db_server as varchar(50)
set @db_server = @@SERVERNAME
INSERT INTO 
[dbo].[PermissionsSalesTerritory] VALUES 
(@db_server + '\Administrator', 'Pacific')
GO
