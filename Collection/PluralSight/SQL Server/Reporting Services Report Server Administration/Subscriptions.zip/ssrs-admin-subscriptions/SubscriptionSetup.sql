USE [AdventureWorksDW2008]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SubscriptionDelivery]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SubscriptionDelivery]
GO

CREATE TABLE [dbo].[SubscriptionDelivery](
	[To] [nvarchar](100) NULL,
	[IncludeReport] [bit] NULL,
	[RenderFormat] [nvarchar](15) NULL,
	[IncludeLink] [bit] NULL,
	[ReportParameter] [nvarchar](100) NULL
) ON [PRIMARY]

GO

INSERT INTO [AdventureWorksDW2008].[dbo].[SubscriptionDelivery] 
     VALUES
           ('EuropeMgr@adventure-works.com'
           ,1
           ,'Excel'
           ,1
           ,'Europe')

INSERT INTO [AdventureWorksDW2008].[dbo].[SubscriptionDelivery] 
     VALUES
           ('PacificMgr@adventure-works.com'
           ,1
           ,'PDF'
           ,0
           ,'Pacific')
           
           
GO


