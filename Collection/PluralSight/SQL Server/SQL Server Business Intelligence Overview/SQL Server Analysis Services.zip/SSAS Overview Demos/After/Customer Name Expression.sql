SELECT FirstName, MiddleName, LastName, 

/* Copy just the following expression, 
   not the whole script,  
   if you are copying the code for lab */
   
COALESCE(FirstName + ' ' + MiddleName, FirstName) + ' ' + LastName

AS [Customer Name]
 FROM AdventureWorksDW2008.dbo.DimCustomer;