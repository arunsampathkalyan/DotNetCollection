﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AnalysisServices.AdomdClient;

namespace AdventureWorks_Sales_Web
{
  public partial class _Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      //Establish a connection to SSAS
      using (AdomdConnection con = new AdomdConnection("Data Source=localhost;Initial Catalog=AdventureWorks Sales"))
      {
        //Build the MDX Query as a string
        string mdxQuery = 
          "SELECT " +
          "  NON EMPTY {[Measures].[Sales Amount]} ON COLUMNS, " +
          "  NON EMPTY {[Order Date].[Calendar Year].ALLMEMBERS} ON ROWS " +
          "FROM [Internet Sales Cube]";

        //Create an AdomdCommand object to run the query with
        AdomdCommand cmd = new AdomdCommand(mdxQuery, con);
        con.Open();

        //Execute the command, and return an AdomdDataReader
        AdomdDataReader dr = cmd.ExecuteReader();
        
        //Bind the data reader up to the SalesGrid GridView.
        SalesGrid.DataSource = dr;
        SalesGrid.DataBind();
      }
    }
  }
}
