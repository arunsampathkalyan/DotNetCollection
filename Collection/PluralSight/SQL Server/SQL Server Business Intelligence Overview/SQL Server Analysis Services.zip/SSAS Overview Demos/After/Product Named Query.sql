USE AdventureWorksDW2008;

/*Copy the following query 
(don't include the above USE AdventureWorksDW2008 statement) 
to use as the source of the "Product" named query in the lab */

SELECT
  P.ProductKey,
  P.EnglishProductName AS Product,
  S.ProductSubcategoryKey AS SubcategoryKey,
  S.EnglishProductSubcategoryName AS Subcategory,
  C.ProductCategoryKey AS CategoryKey,
  C.EnglishProductCategoryName AS Category
FROM DimProduct AS P 
JOIN DimProductSubcategory AS S
ON P.ProductSubcategoryKey = S.ProductSubcategoryKey
JOIN DimProductCategory AS C
ON S.ProductCategoryKey = C.ProductCategoryKey;