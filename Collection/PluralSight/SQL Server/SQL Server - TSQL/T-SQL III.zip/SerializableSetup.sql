use tsql3
drop table number

create table number
(
value int
)

insert into number values (1212)

select * from number
