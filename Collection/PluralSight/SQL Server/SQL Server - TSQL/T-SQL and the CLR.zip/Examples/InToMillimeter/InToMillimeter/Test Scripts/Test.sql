﻿declare @mm real;
select @mm=dbo.InToMillimeter(1);
print @mm




