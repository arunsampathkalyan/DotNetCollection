﻿-- Add your test scenario here --

select dbo.sub2(1,2) as result;
