﻿select dbo.mymul(90,100);


