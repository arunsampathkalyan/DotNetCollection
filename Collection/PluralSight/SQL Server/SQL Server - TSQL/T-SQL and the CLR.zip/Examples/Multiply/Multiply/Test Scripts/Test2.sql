﻿-- Add your test scenario here --

use clr1;

--update Multab set m1 = m1 + m1;

select * from Multab;



