﻿declare @result real;
select @result = dbo.mymul(3,5);
print @result



