﻿ALTER TABLE [BI].[DimProduct]
	ADD CONSTRAINT [PK_DimProduct]
	PRIMARY KEY (DimProductID)