﻿ALTER TABLE [BI].[DimCustomer]
	ADD CONSTRAINT [PK_DimCustomer]
	PRIMARY KEY (DimCustomerID)