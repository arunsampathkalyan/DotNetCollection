declare @shortestLastName int;
declare @longestLastName int;

set @shortestLastName = 6;
set @longestLastName = 9;


if @longestLastName is null set @longestLastName =10
select * from dbo.People as P
where len(P.last) between @shortestLastName and @longestLastName



select max(len(last)) from dbo.People as P


