create 
--drop
table images
(
[serial-number] varchar(30),
[make] varchar(50),
[model] varchar(50),
[title] nvarchar(50),
[image] varbinary(max),
[exp-time] nvarchar(15),
[f-number] float,
[date-taken] nvarchar(20),
[exp-program] nvarchar(20),
[shutter] nvarchar(15),
[aperture] float,
[exp-bias] float,
[meter-mode] nvarchar(25),
[flash] nvarchar(50) ,
[metadata] varbinary(max)
constraint images_pk primary key ([make], [model], [serial-number], [date-taken])
);
