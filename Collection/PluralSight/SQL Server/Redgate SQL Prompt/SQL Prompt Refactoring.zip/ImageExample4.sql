select  [serial-number]
,       make
,       model
,       title
,       image
,       [exp-time]
,       [f-number]
,       [date-taken]
,       [exp-program]
,       shutter
,       aperture
,       [exp-bias]
,       [meter-mode]
,       flash
,       cast(metadata as xml) from dbo.images as I;
