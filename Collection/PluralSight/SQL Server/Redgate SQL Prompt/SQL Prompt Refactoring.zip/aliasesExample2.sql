use [sql prompt refactoring]


select * from dbo.People;

select * from dbo.People as p;


select * from dbo.People as P;


select  distinct P.id
,       P.first
,       P.last
from dbo.People as P join dbo.People as P2
on P.first = P2.first and P.last != P2.last;

select * from dbo.tblCars as TC;

select * from dbo.tblPrices as TP;

select  id
,       C.model
,       price from dbo.tblCars as C join dbo.tblPrices as P
on C.model = P.model;

select * from dbo.tblCars as autos;









