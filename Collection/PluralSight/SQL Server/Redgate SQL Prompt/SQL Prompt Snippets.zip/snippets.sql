




create table 
(
	-- column_name data_type,...
);



create table items
(
	item varchar(50)
);


create table tools 
( 
	tool varchar(50) 
);


create table cars 
( 
	car varchar(40)
	
);

	   
CREATE UNIQUE NONCLUSTERED INDEX AK_Cars 
ON dbo.cars 
(
	car ASC
)
WITH 
(
	SORT_IN_TEMPDB = OFF, 
	DROP_EXISTING = OFF
) 
ON [PRIMARY];

EXEC sys.sp_addextendedproperty 
	@name=N'MS_Description', 
	@value=N'index of cars on lot' ,
	@level0type=N'SCHEMA', 
	@level0name=N'dbo', 
	@level1type=N'TABLE', 
	@level1name=N'cars', 
	@level2type=N'INDEX', 
	@level2name=N'AK_Cars';

sp_help cars

select * from sys.extended_properties


