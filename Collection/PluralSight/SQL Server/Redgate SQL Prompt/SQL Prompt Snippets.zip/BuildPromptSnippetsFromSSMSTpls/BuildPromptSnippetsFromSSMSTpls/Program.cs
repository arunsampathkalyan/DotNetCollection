﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;

namespace BuildPromptSnippetsFromSSMSTpls
{
  class CommandLineArguments
  {
    [SwitchAttribute(SwitchName = "SnippetDir")]
    internal string PromptSnippetDirectory;

    [SwitchAttribute(SwitchName = "SSMSTplDir")]
    internal string SsmsTplDirectory;
  }

  class Program
  {
    static void Main(string[] args)
    {
      var commandLineArguments = new CommandLineArguments();
      // set command line argument values
      SwitchAttribute.SetCommandLineArguments(args, commandLineArguments);
      // set default directory for snippets
      if (string.IsNullOrEmpty(commandLineArguments.PromptSnippetDirectory))
      {
        commandLineArguments.PromptSnippetDirectory = @"C:\Users\admin\AppData\Local\Red Gate\SQL Prompt 5\Snippets";
      }
      // set default directory for SSMS templates
      if (string.IsNullOrEmpty(commandLineArguments.SsmsTplDirectory))
      {
        commandLineArguments.SsmsTplDirectory =
          @"C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\VSShell\Common7\IDE\SqlWorkbenchProjectItems\Sql";
      }
      // xpath expressions to find parts of the snippet file
      // title
      const string snippetTitleXPath = "/CodeSnippets/CodeSnippet/Header/Title";
      // shortcut
      const string snippetShortcutXPath = "/CodeSnippets/CodeSnippet/Header/Shortcut";
      const string snippetDescriptionXPath = "/CodeSnippets/CodeSnippet/Header/Description";
      // description
      const string snippetAuthorXPath = "/CodeSnippets/CodeSnippet/Header/Author";
      // code
      const string snippetCodeXPath = "/CodeSnippets/CodeSnippet/Snippet/Code";
      // regex to find description in SSMS template file
      var regexObj = new Regex(@"^--\s+(?<template>.*?)\s+Template$",
                                RegexOptions.Compiled | RegexOptions.Multiline | RegexOptions.IgnoreCase);
      XmlDocument snippetXmlTemplate = null;
      var xmlWriterSettings = new XmlWriterSettings {Indent = true};
      foreach (var directory in Directory.GetDirectories(commandLineArguments.SsmsTplDirectory))
      {
        // don't use this directory
        if(Path.GetFileName(directory).Equals("earlier versions", StringComparison.InvariantCultureIgnoreCase))
        {
          continue;
        }
        // get each *.sql file, i.e. each SSMS template file
        foreach (var filePath in
          Directory.GetFiles(directory, "*.sql", SearchOption.AllDirectories))
        {
          // get stream of what the .sqlpromptsnippet file should look like
          using (var stm =
            Assembly.GetEntryAssembly().GetManifestResourceStream(Assembly.GetEntryAssembly().GetName().Name +
                                                                  ".PromptTpl.xml"))
          {
            // make an xml document with PromptTpl.xml in it
            snippetXmlTemplate = new XmlDocument();
            snippetXmlTemplate.Load(stm);
          }
          // find the key parts of the empty sqlprompt snippet file
          var title = (XmlElement)snippetXmlTemplate.SelectSingleNode(snippetTitleXPath);
          var shortcut = (XmlElement)snippetXmlTemplate.SelectSingleNode(snippetShortcutXPath);
          var description = (XmlElement)snippetXmlTemplate.SelectSingleNode(snippetDescriptionXPath);
          var author = (XmlElement)snippetXmlTemplate.SelectSingleNode(snippetAuthorXPath);
          var code = (XmlElement)snippetXmlTemplate.SelectSingleNode(snippetCodeXPath);
          string ssmsTemplate = null;
          // read in the SSMS template file
          using (var stm = new StreamReader(filePath))
          {
            stm.ReadLine();
            ssmsTemplate = stm.ReadLine();
          }
          // see if it contains the description header we expect
          var match = regexObj.Match(ssmsTemplate);
          if (!match.Success)
          {
            continue;
          }
          // use the title we found in the header of the SSMS template files
          // as the title of the .sqlpromptsnippet file
          var ssmsTitle = match.Groups["template"].Value;
          // write it into the content of the title tag
          title.InnerText = ssmsTitle;
          // replace any spaces in the title as it will be used to make the shortcut
          ssmsTitle = Regex.Replace(ssmsTitle, @"\s", "_");
          // make the shortcut _ms_ title
          shortcut.InnerText = string.Format("_ms_{0}", ssmsTitle);
          // add a description
          description.InnerText = string.Format("{0} Pluralsight.com auto-generated template",
                                                title.InnerText);
          // add an author.. this program is the author :-)
          author.InnerText = "Pluralsight.com SQL Prompt 5.0 Course";
          string templateCode = null;
          // get the content of the SSMS template as a string
          using (var stm = new StreamReader(filePath))
          {
            templateCode = stm.ReadToEnd();
          }

          // set the content of the code element to what we found in the SSMS template
          // not the xml api takes care of escaping any prohibited xml characters automatically
          code.InnerText = templateCode;
          // build the file name for the snippet
          var promptSnippetName = Path.Combine(commandLineArguments.PromptSnippetDirectory,
                                               string.Format("{0}.sqlpromptsnippet", shortcut.InnerText));
          // use an xml writer to write the xml document we just made into the snippet directory.
          using (var xwriter = XmlWriter.Create(promptSnippetName, xmlWriterSettings))
          {
            snippetXmlTemplate.WriteTo(xwriter);
          }
        }
      }
    }
  }
}



