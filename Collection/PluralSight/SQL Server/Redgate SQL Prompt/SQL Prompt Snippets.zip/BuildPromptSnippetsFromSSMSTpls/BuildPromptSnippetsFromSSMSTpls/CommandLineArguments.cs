﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace BuildPromptSnippetsFromSSMSTpls
{
  [AttributeUsage(AttributeTargets.Field,  AllowMultiple=false)]
  public class SwitchAttribute : Attribute
  {
    private static readonly Regex SwitchValueRegex;
    static SwitchAttribute()
    {
      SwitchValueRegex = new Regex("^/(?<switch>.+)$|^[^/](?<value>.+)$", RegexOptions.Compiled);
      
    }
    public SwitchAttribute()
    {
      HasValue = true;
      Position = -1; // this is not a positional value
    }
    public string SwitchName;
    public  bool HasValue;
    public  int Position;
    internal static bool SwitchExists(IEnumerable<string> args, string @switch)
    {
      return  (from arg in args
             let match = SwitchValueRegex.Match(arg)
             where match.Groups["switch"].Success
                   && match.Groups["switch"].Value.Equals(@switch, StringComparison.InvariantCultureIgnoreCase)
             select true).FirstOrDefault();

    }
    internal static string FindValueBySwitch(IEnumerable<string> args, string @switch)
    {
      // this assumes the switch has a value, if it doesn't the results are no specified
      return (from index in Enumerable.Range(0, args.Count()-1)
              let arg = args.ElementAt(index)
              let match = SwitchValueRegex.Match(arg)
              where match.Groups["switch"].Success
              && match.Groups["switch"].Value.Equals(@switch, StringComparison.InvariantCultureIgnoreCase)
              && index < args.Count()-1
              select args.ElementAt(index+1)).FirstOrDefault();
    }
    internal static string FindValueByPosition(IEnumerable<string> args, IEnumerable<string> switchesWithoutValues, int position)
    {
      // finds all the non-switch arguments
      // the trick here is that a positional value might be preceeded by a switch that has no value
      var values = from index in Enumerable.Range(0, args.Count())
                   let match = SwitchValueRegex.Match(args.ElementAt(index))
                   where match.Success
                         && match.Groups["value"].Success
                         && ((index == 0) 
                         || !(SwitchValueRegex.Match(args.ElementAt(index-1)).Groups["switch"].Success)
                         || (SwitchValueRegex.Match(args.ElementAt(index - 1)).Groups["switch"].Success
                         && switchesWithoutValues.Contains(
                         SwitchValueRegex.Match(args.ElementAt(index - 1)).Groups["switch"].Value))
                         )
                   select args.ElementAt(index);
      return values.Count() > position ? values.ElementAt(position) : string.Empty;
    }
    public static void SetCommandLineArguments(IEnumerable<string> args, object obj)
    {
      var objType = obj.GetType();
      var switchesWithoutValues = from sw in objType.GetFields()
                                  let switchAttributes = 
                                  (SwitchAttribute[])sw.GetCustomAttributes(typeof(SwitchAttribute), false)
                                  where switchAttributes.Count() == 1
                                        && switchAttributes[0].Position == -1
                                        && switchAttributes[0].HasValue == false
                                  select switchAttributes[0].SwitchName;
      foreach (var field in objType.GetFields())
      {
        var switchAtrs = (SwitchAttribute[])field.GetCustomAttributes(typeof(SwitchAttribute), false);
        if (switchAtrs.Length != 1) continue;
        if (switchAtrs[0].Position == -1)
        {
          // found a field that is associated with a switch
          if (!switchAtrs[0].HasValue)
          {
            // this is a switch with no value associated with it, it's a boolean
            field.SetValue(obj, true);
            continue;
          }
          if (switchAtrs[0].HasValue)
          {
            SetFieldValue(field, obj, FindValueBySwitch(args, switchAtrs[0].SwitchName));
              
          }
        }
        else
        {
          var stringValue = FindValueByPosition(args, switchesWithoutValues, switchAtrs[0].Position);
          SetFieldValue(field, obj, stringValue);
        }
      }
    }


    private static void SetFieldValue(FieldInfo field, object obj, string stringValue)
    {
      if (field.FieldType.Equals(typeof(string)))
      {
        // just copy the switch value into the field, if the field is a string
        field.SetValue(obj, stringValue);
        return;
      }
      // looks to see if field type has a static parse method that takes a string as a parameter
      var fieldType = field.FieldType;
      var methods = fieldType.GetMethods();

      var parseMethods = from method in methods
                         where method.Name.Equals("parse", StringComparison.InvariantCultureIgnoreCase)
                         select method;
      var parseStringMethods = from method in parseMethods
                               where method.GetParameters().Length == 1
                                     && method.GetParameters()[0].ParameterType.Equals(typeof(string))
                               select method;
      if (parseStringMethods.Count() > 0)
      {
        // just use the first method that takes a string as its input parameter
        field.SetValue(obj, parseStringMethods.First().Invoke(
          null,
          new object[] {
                         stringValue}
                              ));
      }
    }
  }
  
}
