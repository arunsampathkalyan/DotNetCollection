﻿Pluralsight
Course: Entity Framework and Data Models
Module: Model First Entity Data Models
Created November 2010

Project: BeerModel-ModelFirst

This is the model created solely in the EDM Designer.

The "Generate Database from Model" wizard was used to build the backing metadata inside the edmx file (SSDL & MSL sections) as well as the included sql file.

You can execute the SQL file to build schema in a pre-existing database. The connection to the database is defined in the connection string in the app.config file. It is currently pointing to a local SQL Server instance. Change the connection string to point to your own database or database file in order to execute the SQL script.

Julie Lerman (www.learnentityframework.com)
for Pluralsight: www.pluralsight.com