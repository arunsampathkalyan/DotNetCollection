
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 10/18/2010 18:06:47
-- Generated from EDMX file: F:\Documents\Visual Studio 2010\Projects\PSOD\COURSE 1\Model First\BeerModel\BeerModel\BeerModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [PluralsightBeer];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_BeerBrewery]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Beers] DROP CONSTRAINT [FK_BeerBrewery];
GO
IF OBJECT_ID(N'[dbo].[FK_BeerConsumer_Beer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[BeerConsumer] DROP CONSTRAINT [FK_BeerConsumer_Beer];
GO
IF OBJECT_ID(N'[dbo].[FK_BeerConsumer_Consumer]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[BeerConsumer] DROP CONSTRAINT [FK_BeerConsumer_Consumer];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Beers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Beers];
GO
IF OBJECT_ID(N'[dbo].[Breweries]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Breweries];
GO
IF OBJECT_ID(N'[dbo].[Consumers]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Consumers];
GO
IF OBJECT_ID(N'[dbo].[BeerConsumer]', 'U') IS NOT NULL
    DROP TABLE [dbo].[BeerConsumer];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Beers'
CREATE TABLE [dbo].[Beers] (
    [BeerId] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(50)  NOT NULL,
    [Description] nvarchar(max)  NULL,
    [ProductionStart] datetime  NULL,
    [BreweryId] int  NOT NULL
);
GO

-- Creating table 'Breweries'
CREATE TABLE [dbo].[Breweries] (
    [BreweryId] int IDENTITY(1,1) NOT NULL,
    [Name] nvarchar(max)  NOT NULL,
    [Location] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'Consumers'
CREATE TABLE [dbo].[Consumers] (
    [ConsumerId] int IDENTITY(1,1) NOT NULL,
    [FirstName] nvarchar(max)  NOT NULL,
    [LastName] nvarchar(max)  NOT NULL,
    [DateOfBirth] datetime  NOT NULL
);
GO

-- Creating table 'BeerConsumer'
CREATE TABLE [dbo].[BeerConsumer] (
    [Beers_BeerId] int  NOT NULL,
    [Consumers_ConsumerId] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [BeerId] in table 'Beers'
ALTER TABLE [dbo].[Beers]
ADD CONSTRAINT [PK_Beers]
    PRIMARY KEY CLUSTERED ([BeerId] ASC);
GO

-- Creating primary key on [BreweryId] in table 'Breweries'
ALTER TABLE [dbo].[Breweries]
ADD CONSTRAINT [PK_Breweries]
    PRIMARY KEY CLUSTERED ([BreweryId] ASC);
GO

-- Creating primary key on [ConsumerId] in table 'Consumers'
ALTER TABLE [dbo].[Consumers]
ADD CONSTRAINT [PK_Consumers]
    PRIMARY KEY CLUSTERED ([ConsumerId] ASC);
GO

-- Creating primary key on [Beers_BeerId], [Consumers_ConsumerId] in table 'BeerConsumer'
ALTER TABLE [dbo].[BeerConsumer]
ADD CONSTRAINT [PK_BeerConsumer]
    PRIMARY KEY NONCLUSTERED ([Beers_BeerId], [Consumers_ConsumerId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [BreweryId] in table 'Beers'
ALTER TABLE [dbo].[Beers]
ADD CONSTRAINT [FK_BeerBrewery]
    FOREIGN KEY ([BreweryId])
    REFERENCES [dbo].[Breweries]
        ([BreweryId])
    ON DELETE CASCADE ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_BeerBrewery'
CREATE INDEX [IX_FK_BeerBrewery]
ON [dbo].[Beers]
    ([BreweryId]);
GO

-- Creating foreign key on [Beers_BeerId] in table 'BeerConsumer'
ALTER TABLE [dbo].[BeerConsumer]
ADD CONSTRAINT [FK_BeerConsumer_Beer]
    FOREIGN KEY ([Beers_BeerId])
    REFERENCES [dbo].[Beers]
        ([BeerId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating foreign key on [Consumers_ConsumerId] in table 'BeerConsumer'
ALTER TABLE [dbo].[BeerConsumer]
ADD CONSTRAINT [FK_BeerConsumer_Consumer]
    FOREIGN KEY ([Consumers_ConsumerId])
    REFERENCES [dbo].[Consumers]
        ([ConsumerId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_BeerConsumer_Consumer'
CREATE INDEX [IX_FK_BeerConsumer_Consumer]
ON [dbo].[BeerConsumer]
    ([Consumers_ConsumerId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------