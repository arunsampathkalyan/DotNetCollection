﻿Pluralsight
Course: Entity Framework and Data Models
Module: Database First Entity Data Models
Created November 2010

Project: AWModel

This is the model which was reverse engineered from the included AdeventureWorksSuperLT database.

Julie Lerman (www.learnentityframework.com)
for Pluralsight: www.pluralsight.com