﻿using System;
using System.ServiceModel;

namespace RoutingCommon
{
  [ServiceContract(Namespace = "http://www.pluralsight.com/WCF")]
  public interface IOneWayService
  {
    [OperationContract(IsOneWay = true)]
    void WriteInfo(string info);
  }

  [ServiceContract(Namespace = "http://www.pluralsight.com/WCF")]
  public interface IHelloWorldService
  {
    [OperationContract]
    // Action name: http://www.pluralsight.com/WCF/IHelloWorldService/SayHello
    string SayHello(string name);
  }

  [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.Single)]
  public class HelloWorldService : IOneWayService, IHelloWorldService
  {
    private readonly string _instanceName;

    public HelloWorldService(string instanceName)
    {
      _instanceName = instanceName;  
    }

    public string SayHello(string name)
    {
      return string.Format("Hello to {0} from {1}!", name, _instanceName);
    }

    public void WriteInfo(string info)
    {
      Console.WriteLine("Write Info: {0} at {1}", info, _instanceName);
    }
  }
}
