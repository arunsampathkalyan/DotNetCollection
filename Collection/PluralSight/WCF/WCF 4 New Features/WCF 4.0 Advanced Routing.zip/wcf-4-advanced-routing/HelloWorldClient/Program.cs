﻿using System;
using System.ServiceModel;

namespace HelloWorldClient
{
  class Program
  {
    static void Main()
    {
      Console.WriteLine("Press [Enter] to start");
      Console.ReadLine();
      do
      {
        var client = new HelloService.HelloWorldServiceClient("HelloWorld");
        try
        {
          Console.WriteLine(client.SayHello("Pluralsight"));
          client.Close();
        }
        catch (FaultException fe)
        {
          Console.WriteLine(fe.ToString());
          client.Abort();
        }
        catch (CommunicationException ce)
        {
          Console.WriteLine(ce.ToString());
          client.Abort();
        }
        catch (TimeoutException te)
        {
          Console.WriteLine(te.ToString());
          client.Abort();
        }
        Console.WriteLine("Press [q] to quit");
      } while (Console.ReadLine().ToLower() != "q");

      var onewayClient = new HelloService.OneWayServiceClient("OneWayService");
      onewayClient.WriteInfo("OneWay");
      onewayClient.Close();
      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
    }
  }
}
