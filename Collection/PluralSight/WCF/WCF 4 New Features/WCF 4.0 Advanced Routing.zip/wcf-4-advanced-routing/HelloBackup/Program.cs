﻿using System;
using System.ServiceModel;
using RoutingCommon;

namespace HelloBackup
{
  class Program
  {
    static void Main(string[] args)
    {
      var host = new ServiceHost(new HelloWorldService("HelloBackup"), new Uri("http://localhost/Demo/Backup"));

      host.Open();

      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
    }
  }
}
