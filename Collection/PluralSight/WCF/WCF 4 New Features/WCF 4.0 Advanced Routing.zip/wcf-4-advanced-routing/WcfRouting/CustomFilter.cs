﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Dispatcher;

namespace WcfRouting
{
  public class CustomFilter : MessageFilter
  {
    private string _filterData;

    public CustomFilter(string filterData)  
    {
      _filterData = filterData;
    }

    public override bool Match(MessageBuffer buffer)
    {
      var message = buffer.CreateMessage();
      return Match(message);
    }

    public override bool Match(Message message)
    {
      return string.Equals(message.Headers.To.Host, _filterData);
    }

    protected override IMessageFilterTable<TFilterData> CreateFilterTable<TFilterData>()
    {
      return new CustomFilterTable<TFilterData>();
    }
  }

  public class CustomFilterTable<TFilterData> : Dictionary<MessageFilter, TFilterData>, IMessageFilterTable<TFilterData>
  {
    public bool GetMatchingValue(Message message, out TFilterData value)
    {
      value = default(TFilterData);
      var matchingFilter = Keys.FirstOrDefault(key => key.Match(message));
      if (matchingFilter == null)
      {
        return false;
      }
      value = this[matchingFilter];
      return true;
    }

    public bool GetMatchingValue(MessageBuffer messageBuffer, out TFilterData value)
    {
      value = default(TFilterData);
      var matchingFilter = Keys.FirstOrDefault(key => key.Match(messageBuffer));
      if (matchingFilter == null)
      {
        return false;
      }
      value = this[matchingFilter];
      return true;
    }

    public bool GetMatchingValues(Message message, ICollection<TFilterData> results)
    {
      var matchingResults = from key in Keys
                              where key.Match(message)
                              select this[key];
      var retval = false;
      foreach (var match in matchingResults)
      {
        retval = true;
        results.Add(match);
      }
      return retval;
    }

    public bool GetMatchingValues(MessageBuffer messageBuffer, ICollection<TFilterData> results)
    {
      var matchingResults = from key in Keys
                            where key.Match(messageBuffer)
                            select this[key];
      var retval = false;
      foreach (var match in matchingResults)
      {
        retval = true;
        results.Add(match);
      }
      return retval;
    }

    public bool GetMatchingFilter(Message message, out MessageFilter filter)
    {
      filter = null;
      var matchingFilter = Keys.FirstOrDefault(key => key.Match(message));
      if (matchingFilter == null)
      {
        return false;
      }
      filter = matchingFilter;
      return true;
    }

    public bool GetMatchingFilter(MessageBuffer messageBuffer, out MessageFilter filter)
    {
      filter = null;
      var matchingFilter = Keys.FirstOrDefault(key => key.Match(messageBuffer));
      if (matchingFilter == null)
      {
        return false;
      }
      filter = matchingFilter;
      return true;
    }

    public bool GetMatchingFilters(Message message, ICollection<MessageFilter> results)
    {
      var matchingResults = from key in Keys
                            where key.Match(message)
                            select key;
      var retval = false;
      foreach (var match in matchingResults)
      {
        retval = true;
        results.Add(match);
      }
      return retval;
    }

    public bool GetMatchingFilters(MessageBuffer messageBuffer, ICollection<MessageFilter> results)
    {
      var matchingResults = from key in Keys
                            where key.Match(messageBuffer)
                            select key;
      var retval = false;
      foreach (var match in matchingResults)
      {
        retval = true;
        results.Add(match);
      }
      return retval;
    }
  }
}