﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using RoutingCommon;

namespace HelloPrimary
{
  class Program
  {
    static void Main(string[] args)
    {
      var host = new ServiceHost(new HelloWorldService("HelloPrimary"), new Uri("http://localhost/Demo/Primary"));
      host.AddDefaultEndpoints();
      host.AddServiceEndpoint(typeof (IMetadataExchange), MetadataExchangeBindings.CreateMexHttpBinding(), "/mex");
      host.Open();
      foreach (ServiceEndpoint se in host.Description.Endpoints)
      {
        Console.WriteLine(se.ListenUri);
      }
      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
    }
  }
}
