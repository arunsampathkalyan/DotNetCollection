﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Discovery;
using Common;

namespace DiscoverableClient
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Press [Enter] to call.");
      Console.ReadLine();
      var probeAddress = new Uri("http://localhost/Demo/Probe");
      var discoveryEndpoint = new DiscoveryEndpoint(new WSHttpBinding(), new EndpointAddress(probeAddress));
      var discoveryClient = new DiscoveryClient(discoveryEndpoint);
      var findCriteria = new FindCriteria(typeof (IHelloWorld));
      findCriteria.Scopes.Add(new Uri("ldap:///ou=teachers,o=pluralsight.com"));
      var findResponse = discoveryClient.Find(findCriteria);
      discoveryClient.Close();
      if (findResponse.Endpoints.Count > 0)
      {
        var factory = new ChannelFactory<IHelloWorld>(new BasicHttpBinding(), findResponse.Endpoints[0].Address);
        var channel = factory.CreateChannel();
        Console.WriteLine(channel.SayHi("Scott"));
        ((IChannel)channel).Close();
      }
      else
      {
        Console.WriteLine("No endpoints found.");
      }
      Console.WriteLine("Press [Enter] to exit.");
      Console.ReadLine();
    }
  }
}
