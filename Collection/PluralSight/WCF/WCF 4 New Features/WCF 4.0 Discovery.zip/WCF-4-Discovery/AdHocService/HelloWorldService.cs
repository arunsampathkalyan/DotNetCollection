﻿using Common;

namespace AdHocService
{
  public class HelloWorldService : IHelloWorld
  {
    public string SayHi(string name)
    {
      return string.Format("Hello, {0}!", name);
    }
  }
}