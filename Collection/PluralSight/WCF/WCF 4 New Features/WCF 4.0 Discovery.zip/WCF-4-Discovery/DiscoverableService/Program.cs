﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;

namespace DiscoverableService
{
  class Program
  {
    static void Main(string[] args)
    {
      var announcementAddress = new Uri("http://localhost/Demo/Announce");
      var host = new ServiceHost(typeof (HelloWorldService));
      try
      {
        host.AddDefaultEndpoints();

        // Create an announcement endpoint, which points to the Announcement Endpoint hosted by the proxy service.
        var announcementEndpoint = new AnnouncementEndpoint(new WSHttpBinding(), new EndpointAddress(announcementAddress));
        var serviceDiscoveryBehavior = new ServiceDiscoveryBehavior();
        serviceDiscoveryBehavior.AnnouncementEndpoints.Add(announcementEndpoint);

        // Make the service discoverable
        host.Description.Behaviors.Add(serviceDiscoveryBehavior);

        host.Open();
        foreach (ServiceEndpoint se in host.Description.Endpoints)
        {
          Console.WriteLine("{0}", se.ListenUri);
        }
        Console.WriteLine("Press <ENTER> to terminate the service.");
        Console.ReadLine();
        host.Close();
      }
      catch (CommunicationException e)
      {
        Console.WriteLine(e.Message);
      }
      catch (TimeoutException e)
      {
        Console.WriteLine(e.Message);
      }

      if (host.State != CommunicationState.Closed)
      {
        Console.WriteLine("Aborting the service...");
        host.Abort();
      }
    }
  }
}
