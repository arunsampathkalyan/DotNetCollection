﻿using System;
using System.ServiceModel;

namespace AnnounceService
{
  class Program
  {
    static void Main()
    {
      var host = new ServiceHost(typeof(HelloWorldService));
      host.Open();
      foreach (var serviceEndpoint in host.Description.Endpoints)
      {
        Console.WriteLine(serviceEndpoint.ListenUri);
      }
      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
      host.Close();
    }
  }
}
