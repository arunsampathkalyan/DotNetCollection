﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;

namespace ManagedDiscovery
{
  class Program
  {
    static void Main()
    {
      var host = new ServiceHost(new PluralsightDiscoveryProxy(), new Uri("http://localhost/Demo"));
      try
      {
        host.AddServiceEndpoint(new DiscoveryEndpoint(new WSHttpBinding(), new EndpointAddress(host.BaseAddresses[0] + "/Probe"))
                                  {IsSystemEndpoint = false});
        host.AddServiceEndpoint(new AnnouncementEndpoint(new WSHttpBinding(), new EndpointAddress(host.BaseAddresses[0] + "/Announce")) { IsSystemEndpoint = false });
        host.Open();
        foreach (ServiceEndpoint se in host.Description.Endpoints)
        {
          Console.WriteLine("{0}", se.ListenUri);
        }
        Console.WriteLine("Press <ENTER> to terminate the service.");
        Console.ReadLine();
        host.Close();
      }
      catch(CommunicationException ce)
      {
        Console.WriteLine(ce);
      }
      catch (TimeoutException te)
      {
        Console.WriteLine(te);
      }
      if (host.State != CommunicationState.Closed)
      {
        Console.WriteLine("Aborting");
        host.Abort();
      }
    }
  }
}
