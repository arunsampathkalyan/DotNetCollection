﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Discovery;

namespace ManagedDiscovery
{
  [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Multiple)]
  class PluralsightDiscoveryProxy : DiscoveryProxy
  {
    readonly Dictionary<EndpointAddress, EndpointDiscoveryMetadata> _onlineServices = new Dictionary<EndpointAddress, EndpointDiscoveryMetadata>();

    protected override IAsyncResult OnBeginOnlineAnnouncement(DiscoveryMessageSequence messageSequence, EndpointDiscoveryMetadata endpointDiscoveryMetadata, AsyncCallback callback, object state)
    {
      AddOnlineService(endpointDiscoveryMetadata);
      return new OnOnlineAnnouncementAsyncResult(callback, state);
    }
    
    protected override void OnEndOnlineAnnouncement(IAsyncResult result)
    {
      OnOnlineAnnouncementAsyncResult.End(result);
    }

    protected override IAsyncResult OnBeginOfflineAnnouncement(DiscoveryMessageSequence messageSequence, EndpointDiscoveryMetadata endpointDiscoveryMetadata, AsyncCallback callback, object state)
    {
      RemoveOnlineService(endpointDiscoveryMetadata);
      return new OnOfflineAnnouncementAsyncResult(callback, state);
    }

    protected override void OnEndOfflineAnnouncement(IAsyncResult result)
    {
      OnOfflineAnnouncementAsyncResult.End(result);
    }

    protected override IAsyncResult OnBeginFind(FindRequestContext findRequestContext, AsyncCallback callback, object state)
    {
      Console.WriteLine("***");
      foreach (var typeName in findRequestContext.Criteria.ContractTypeNames)
      {
        Console.WriteLine("Caller is asking for an implementation of {0}.",
                          typeName);
      }
      foreach (var scopeName in findRequestContext.Criteria.Scopes)
      {
        Console.WriteLine("Caller is asking for an matching scope {0}.",
                          scopeName);
      }
      Console.WriteLine("***");
      MatchFromOnlineService(findRequestContext);
      return new OnFindAsyncResult(callback, state);
    }
    
    protected override void OnEndFind(IAsyncResult result)
    {
      OnFindAsyncResult.End(result);
    }

    protected override IAsyncResult OnBeginResolve(ResolveCriteria resolveCriteria, AsyncCallback callback, object state)
    {
      return new OnResolveAsyncResult(MatchFromOnlineService(resolveCriteria), callback, state);
    }

    protected override EndpointDiscoveryMetadata OnEndResolve(IAsyncResult result)
    {
      return OnResolveAsyncResult.End(result);
    }

    private void AddOnlineService(EndpointDiscoveryMetadata endpointDiscoveryMetadata)
    {
      lock (_onlineServices)
      {
        _onlineServices[endpointDiscoveryMetadata.Address] = endpointDiscoveryMetadata;
      }

      PrintDiscoveryMetadata(endpointDiscoveryMetadata, "Adding");
    }

    private void RemoveOnlineService(EndpointDiscoveryMetadata endpointDiscoveryMetadata)
    {
      if (_onlineServices.ContainsKey(endpointDiscoveryMetadata.Address))
      {
        lock (_onlineServices)
        {
          if (_onlineServices.ContainsKey(endpointDiscoveryMetadata.Address))
          {
            _onlineServices.Remove(endpointDiscoveryMetadata.Address);
          }
        }
      }
      PrintDiscoveryMetadata(endpointDiscoveryMetadata, "Removing");
    }

    void MatchFromOnlineService(FindRequestContext findRequestContext)
    {
      lock (_onlineServices)
      {
        var matches = from endpointDiscoveryMetadata in _onlineServices.Values
                      where findRequestContext.Criteria.IsMatch(endpointDiscoveryMetadata)
                      select endpointDiscoveryMetadata;
        foreach (EndpointDiscoveryMetadata endpointDiscoveryMetadata in matches)
        {
          findRequestContext.AddMatchingEndpoint(endpointDiscoveryMetadata);
        }
      }
    }

    EndpointDiscoveryMetadata MatchFromOnlineService(ResolveCriteria criteria)
    {
      EndpointDiscoveryMetadata matchingEndpoint = null;
      lock (_onlineServices)
      {
        var matches = from endpointDiscoveryMetadata in _onlineServices.Values
                      where criteria.Address == endpointDiscoveryMetadata.Address
                      select endpointDiscoveryMetadata;
        if (matches.Count() > 0)
        {
          matchingEndpoint = matches.First();
        }
      }
      return matchingEndpoint;
    }

    static void PrintDiscoveryMetadata(EndpointDiscoveryMetadata endpointDiscoveryMetadata, string verb)
    {
      Console.WriteLine(string.Format("\n**** {0} service of the following type from cache.", verb));
      foreach (var contractName in endpointDiscoveryMetadata.ContractTypeNames)
      {
        Console.WriteLine("** {0}", contractName);
        break;
      }
      Console.WriteLine("**** Operation Completed");
    }
    
    sealed class OnOnlineAnnouncementAsyncResult : AsyncResult
    {
      public OnOnlineAnnouncementAsyncResult(AsyncCallback callback, object state)
        : base(callback, state)
      {
        Complete(true);
      }

      public static void End(IAsyncResult result)
      {
        End<OnOnlineAnnouncementAsyncResult>(result);
      }
    }

    sealed class OnOfflineAnnouncementAsyncResult : AsyncResult
    {
      public OnOfflineAnnouncementAsyncResult(AsyncCallback callback, object state)
        : base(callback, state)
      {
        Complete(true);
      }

      public static void End(IAsyncResult result)
      {
        End<OnOfflineAnnouncementAsyncResult>(result);
      }
    }

    sealed class OnFindAsyncResult : AsyncResult
    {
      public OnFindAsyncResult(AsyncCallback callback, object state)
        : base(callback, state)
      {
        Complete(true);
      }

      public static void End(IAsyncResult result)
      {
        End<OnFindAsyncResult>(result);
      }
    }

    sealed class OnResolveAsyncResult : AsyncResult
    {
      readonly EndpointDiscoveryMetadata _matchingEndpoint;

      public OnResolveAsyncResult(EndpointDiscoveryMetadata matchingEndpoint, AsyncCallback callback, object state)
        : base(callback, state)
      {
        _matchingEndpoint = matchingEndpoint;
        Complete(true);
      }

      public static EndpointDiscoveryMetadata End(IAsyncResult result)
      {
        var thisPtr = End<OnResolveAsyncResult>(result);
        return thisPtr._matchingEndpoint;
      }
    }
  }
}
