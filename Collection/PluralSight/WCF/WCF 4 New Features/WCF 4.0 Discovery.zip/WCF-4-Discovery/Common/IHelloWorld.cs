﻿using System.ServiceModel;

namespace Common
{
  [ServiceContract(Namespace="http://www.pluralsight.com/WCF")]
  public interface IHelloWorld
  {
    [OperationContract]
    string SayHi(string name);
  }
}