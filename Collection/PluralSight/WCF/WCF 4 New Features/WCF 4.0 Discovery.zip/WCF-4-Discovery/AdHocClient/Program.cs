﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;
using Common;

namespace AdHocClient
{
  class Program
  {
    static void Main()
    {
      CallThroughConfig();
      DynamicallyBind();
    }
    
    private static void CallThroughConfig()
    {
      try
      {
        var factory = new ChannelFactory<IHelloWorld>("discovery");
        var channel = factory.CreateChannel();
        Console.WriteLine(channel.SayHi("Scott"));
        ((IChannel) channel).Close();
      }
      catch(EndpointNotFoundException ex)
      {
        Console.WriteLine(ex.Message);
      }
      Console.ReadLine();
    }

    private static void DynamicallyBind()
    {
      var discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
      var findCriteria = FindCriteria.CreateMetadataExchangeEndpointCriteria(typeof (IHelloWorld));
      findCriteria.MaxResults = 1;
      findCriteria.Scopes.Add(new Uri("ldap:///ou=teachers,o=pluralsight.com"));
      var findResults = discoveryClient.Find(findCriteria);
      if (findResults.Endpoints.Count > 0)
      {
        var endpoints = MetadataResolver.Resolve(typeof (IHelloWorld), findResults.Endpoints[0].Address);
        if (endpoints.Count > 0)
        {
          var factory = new ChannelFactory<IHelloWorld>(endpoints[0].Binding, endpoints[0].Address);
          var channel = factory.CreateChannel();
          Console.WriteLine(channel.SayHi("Dynamic"));
        }
      }
      Console.ReadLine();
    }
  }
}
