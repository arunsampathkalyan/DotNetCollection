﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;
using System.Xml;
using Common;

namespace AnnounceClient
{
  class Program
  {
    static void Main()
    {
      // Create an AnnouncementService instance
      var announcementService = new AnnouncementService();

      // Subscribe the announcement events
      announcementService.OnlineAnnouncementReceived += OnOnlineEvent;
      announcementService.OfflineAnnouncementReceived += OnOfflineEvent;

      // Create ServiceHost for the AnnouncementService
      using (var announcementServiceHost = new ServiceHost(announcementService))
      {
        // Listen for the announcements sent over UDP multicast
        announcementServiceHost.AddServiceEndpoint(new UdpAnnouncementEndpoint());
        announcementServiceHost.Open();
        Console.WriteLine("Press <ENTER> to terminate.");
        Console.ReadLine();
      }

    }

    static void OnOnlineEvent(object sender, AnnouncementEventArgs e)
    {
      Console.WriteLine("Received an online announcement from {0}", e.EndpointDiscoveryMetadata.Address);
      Console.WriteLine("Endpoint supports these contracts:");
      var contractDescription = ContractDescription.GetContract(typeof (IHelloWorld));
      var qualifiedName = new XmlQualifiedName(contractDescription.Name, contractDescription.Namespace);
      var scopeUri = new Uri("urn:" + qualifiedName);
      var mexContractDescription = ContractDescription.GetContract(typeof (IMetadataExchange));
      var mexQualifiedName = new XmlQualifiedName(mexContractDescription.Name, mexContractDescription.Namespace);
      foreach (var name in e.EndpointDiscoveryMetadata.ContractTypeNames)
      {
        Console.WriteLine(name);
        if (mexQualifiedName == name)
        {
          // See if the mex endpoint exposes something we want
          foreach (var scope in e.EndpointDiscoveryMetadata.Scopes)
          {
            if (scope == scopeUri)
            {
              var endpoints = MetadataResolver.Resolve(typeof (IHelloWorld), e.EndpointDiscoveryMetadata.Address);
              if (endpoints.Count > 0)
              {
                var factory = new ChannelFactory<IHelloWorld>(endpoints[0].Binding, endpoints[0].Address);
                var channel = factory.CreateChannel();
                Console.WriteLine(channel.SayHi("announce"));
                ((IChannel) channel).Close();
              }
            }
          }
          Console.WriteLine("*** Found IHelloWorld impl ***");
        }
      }
      Console.WriteLine("Endpoint supports these scopes:");
      foreach (var scope in e.EndpointDiscoveryMetadata.Scopes)
      {
        Console.WriteLine(scope);
      }
    }


    static void OnOfflineEvent(object sender, AnnouncementEventArgs e)
    {
      Console.WriteLine("Received an offline announcement from {0}", e.EndpointDiscoveryMetadata.Address);
    }

  }
}
