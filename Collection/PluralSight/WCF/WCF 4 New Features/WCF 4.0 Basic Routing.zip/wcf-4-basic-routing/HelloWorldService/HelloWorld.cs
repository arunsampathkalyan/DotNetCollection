﻿using System.ServiceModel;

namespace HelloWorldService
{
  [ServiceContract(Namespace="http://www.pluralsight.com/Demo/HelloWorld")]
  public class HelloWorld
  {
    [OperationContract]
    public string SayHi(string name)
    {
      return string.Format("Hello, {0}!", name);
    }
  }
}