﻿using System;
using System.ServiceModel;

namespace OneWay
{
  [ServiceContract(Namespace = "http://www.pluralsight.com/Demo/OneWay")]
  class OneWayService
  {
    [OperationContract(IsOneWay = true)]
    void PrintHi(string name)
    {
      Console.WriteLine("Hello from {0}", name);
    }
  }
}
