﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Messaging;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;

namespace OneWay
{
  class Program
  {
    static void Main(string[] args)
    {
      SetupMsmq();
      var host = new ServiceHost(typeof(OneWayService));
      host.AddDefaultEndpoints();
      host.Open();
      foreach (ServiceEndpoint se in host.Description.Endpoints)
      {
        Console.WriteLine(se.ListenUri);
      }
      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
    }

    private static void SetupMsmq()
    {
      const string queueName = @".\private$\OnewayService";
      if (!MessageQueue.Exists(queueName))
      {
        MessageQueue.Create(queueName, false);
      }
    }
  }
}
