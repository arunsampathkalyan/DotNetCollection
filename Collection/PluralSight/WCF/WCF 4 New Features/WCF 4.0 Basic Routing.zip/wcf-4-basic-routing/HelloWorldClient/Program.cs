﻿using System;
using System.ServiceModel;

namespace HelloWorldClient
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Press [Enter] to execute RequestReply");
      Console.ReadLine();
      var client = new HelloWorldClient1.ServiceReference1.HelloWorldClient("HelloWorld");
      Console.WriteLine(client.SayHi("Router"));
      client.Close();

      Console.WriteLine("Press [Enter] to execute OneWay");
      Console.ReadLine();

      var oneway = new OneWayRef.OneWayServiceClient("OneWay");
      oneway.PrintHi("OneWay");
      oneway.Close();

      Console.WriteLine("Press [Enter] to execute Duplex");
      Console.ReadLine();

      var duplex = new DuplexRef.DuplexServiceClient(new InstanceContext(new DuplexCallback()));
      Console.WriteLine(duplex.GetMessage());

      Console.WriteLine("Press [Enter] to exit");
      Console.ReadLine();
    }
  }

  class DuplexCallback : DuplexRef.DuplexServiceCallback
  {
    public DateTime GetTime()
    {
      return DateTime.Now;
    }
  }
}
