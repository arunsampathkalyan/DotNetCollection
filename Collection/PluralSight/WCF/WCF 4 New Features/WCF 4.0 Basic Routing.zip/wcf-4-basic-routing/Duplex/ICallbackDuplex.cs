﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace Duplex
{
  [ServiceContract(Namespace = "http://www.pluralsight.com/Demo/Duplex")]
  interface ICallbackDuplex
  {
    [OperationContract]
    DateTime GetTime();
  }
}
