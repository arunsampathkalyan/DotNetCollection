﻿using System;
using System.ServiceModel;

namespace Duplex
{
  [ServiceContract(Namespace = "http://www.pluralsight.com/Demo/Duplex", 
    CallbackContract = typeof(ICallbackDuplex),
    SessionMode = SessionMode.Required)]
  [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple, InstanceContextMode = InstanceContextMode.PerSession)]
  class DuplexService
  {
    [OperationContract]
    private string GetMessage()
    {
      var callback = OperationContext.Current.GetCallbackChannel<ICallbackDuplex>();
      Console.WriteLine("Asking client for the time");
      return string.Format("You think the time is {0}.", callback.GetTime());
    }
  }
}
