﻿using System.ServiceModel.Web;

namespace WcfConfigDemo
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "HelloWorldService" in code, svc and config file together.
  public class HelloWorldService : IHelloWorldService
  {
    [WebGet(UriTemplate = "/{name}")]
    public string SayHi(string name)
    {
      return string.Format("Hello, {0}", name);
    }
  }
}
