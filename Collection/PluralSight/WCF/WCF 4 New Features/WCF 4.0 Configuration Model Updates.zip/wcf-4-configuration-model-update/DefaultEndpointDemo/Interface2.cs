﻿using System.ServiceModel;

namespace DefaultEndpointDemo
{
  [ServiceContract]
  interface Interface2
  {
    [OperationContract]
    int EchoInt(int value);
  }
}
