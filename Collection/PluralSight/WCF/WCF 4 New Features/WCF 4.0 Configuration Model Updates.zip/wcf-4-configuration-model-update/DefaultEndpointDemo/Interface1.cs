﻿using System.ServiceModel;

namespace DefaultEndpointDemo
{
  [ServiceContract]
  interface Interface1
  {
    [OperationContract]
    string EchoString(string value);
  }
}
