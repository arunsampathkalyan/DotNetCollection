﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefaultEndpointDemo
{
  class ServiceImplementation : Interface1, Interface2
  {
    public string EchoString(string value)
    {
      return value;
    }

    public int EchoInt(int value)
    {
      return value;
    }
  }
}
