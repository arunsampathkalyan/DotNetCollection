﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace DefaultEndpointDemo
{
  class Program
  {
    static void Main()
    {
      using (var host = new ServiceHost(typeof(ServiceImplementation),
        new Uri("net.tcp://localhost/"), 
        new Uri("http://localhost/demo")))
      {
        host.Description.Behaviors.Add(new ServiceMetadataBehavior{ HttpGetEnabled = true});
        host.AddServiceEndpoint(typeof (IMetadataExchange), MetadataExchangeBindings.CreateMexHttpBinding(), "/mex");
        host.AddDefaultEndpoints();
        host.Open();

        foreach (ServiceEndpoint endpoint in host.Description.Endpoints)
        {
          Console.WriteLine("{0}", endpoint.ListenUri);
        }
        Console.WriteLine("Press [Enter] to exit");
        Console.ReadLine();
      }
    }
  }
}
