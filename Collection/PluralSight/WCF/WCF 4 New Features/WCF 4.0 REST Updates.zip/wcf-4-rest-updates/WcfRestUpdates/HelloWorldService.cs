﻿using System;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

namespace WcfRestUpdates
{
  [ServiceContract]
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
  public class HelloWorldService
  {
    private static Dictionary<string, int> Value { get; set;}

    static HelloWorldService()
    {
      Value = new Dictionary<string, int>();
    }

    [OperationContract]
    [WebGet(UriTemplate="value/{name}")]
    public int GetValue(string name)
    {
      if (!Value.ContainsKey(name))
      {
        throw new WebFaultException<string>(string.Format("Key {0} does not exist.", name), HttpStatusCode.NotFound);
      }
      return Value[name];
    }

    [OperationContract]
    [WebInvoke(Method = "PUT", UriTemplate = "value/{name}")]
    public void PutValue(string name, int value)
    {
      // Idempotent. Put cannot be used for creation.
      if (!Value.ContainsKey(name))
      {
        throw new WebFaultException<string>(string.Format("Key {0} does not exist. Cannot update the key.", name),
          HttpStatusCode.NotFound);
      }
      Value[name] = value;
    }

    [OperationContract]
    [WebInvoke(Method = "DELETE", UriTemplate = "value/{name}")]
    public void DeleteValue(string name)
    {
      // Idempotent. Deleting a non-existing item is OK
      if (Value.ContainsKey(name))
      {
        Value.Remove(name);
      }
    }

    [OperationContract]
    [WebInvoke(Method = "POST", UriTemplate = "value/{name}")]
    public void PostValue(string name, int value)
    {
      // POST is used for creation, not update.
      if (Value.ContainsKey(name))
      {
        throw new WebFaultException<string>(string.Format("Key {0} already exists. Cannot create the key.", name),
          HttpStatusCode.Conflict);
      }
      Value[name] = value;
    }

    [OperationContract]
    [WebGet(UriTemplate = "/time")]
    [AspNetCacheProfile("CacheFor10Seconds")]
    public DateTime GetTime()
    {
      return DateTime.Now;
    }
  }
}