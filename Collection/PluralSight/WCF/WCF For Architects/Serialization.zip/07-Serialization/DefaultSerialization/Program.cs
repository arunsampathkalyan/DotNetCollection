﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;
using System.Xml.Schema;
using Common.Surrogate;

namespace DefaultSerialization
{
  class Program
  {
    static void Main(string[] args)
    {
      //ShowXsd(typeof (Default.PurchaseOrder));
      //var defaultSerializer = new DataContractSerializer(typeof (Default.PurchaseOrder));
      //var defaultObject = CreateDefaultPurchaseOrder();
      //var stream = new MemoryStream();
      //var writer = new XmlTextWriter(stream, Encoding.UTF8){Formatting = Formatting.Indented};
      ////defaultSerializer.WriteObject(writer, defaultObject);
      ////writer.Flush();
      ////PrintStream(stream);
      //var contractObject = CreateContractPurchaseOrder();
      //var contractSerializer = new DataContractSerializer(typeof (Contract.PurchaseOrder));
      //stream = new MemoryStream();
      //writer = new XmlTextWriter(stream, Encoding.UTF8) { Formatting = Formatting.Indented };
      //contractSerializer.WriteObject(writer, contractObject);
      //writer.Flush();
      //PrintStream(stream);
      //ShowXsd(typeof(Contract.PurchaseOrder));
      //ShowXsd(typeof(Common.Polymorphism.BaseType));

      ShowSurrogate();
    }

    private static void ShowSurrogate()
    {
      var ser = new DataContractSerializer(typeof (NonSerializableType), null, int.MaxValue, false,
        true, new NonSerializableTypeSurrogate());
      ser.WriteObject(new XmlTextWriter(Console.Out),
        new NonSerializableType(){ MyInt = 10, MyString = "Test"});
    }

    static void PrintStream(MemoryStream stream)
    {
      Console.WriteLine();
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      Console.WriteLine();
    }

    static Default.PurchaseOrder CreateDefaultPurchaseOrder()
    {
      var rand = new Random();
      var retval = new Default.PurchaseOrder {CustomerId = 10, PurchaseOrderId = 101};
      for (var i = 1; i <= 4; ++i )
      {
        var lineItem = new Default.LineItem
                         {
                           ItemId = rand.Next(10, 10000),
                           PurchaseOrderId = retval.PurchaseOrderId,
                           Line = i,
                           Price = (rand.NextDouble())*1000
                         };
        retval.LineItems.Add(lineItem);
      }
      return retval;
    }

    static Contract.PurchaseOrder CreateContractPurchaseOrder()
    {
      var retval = new Contract.PurchaseOrder();
      var rand = new Random();
      for (var i = 1; i <= 4; ++i)
      {
        var lineItem = new Contract.LineItem
                         {
                           ItemId = rand.Next(10, 10000),
                           PurchaseOrderId = retval.PurchaseOrderId,
                           Line = i,
                           Price = (rand.NextDouble())*1000
                         };
        retval.LineItems.Add(lineItem);
      }
      return retval;
    }

    static void ShowXsd(Type type)
    {
      var exporter = new XsdDataContractExporter();
      exporter.Export(type);
      foreach (XmlSchema schema in exporter.Schemas.Schemas())
      {
        var writer = new XmlTextWriter(Console.Out) {Formatting = Formatting.Indented};
        schema.Write(writer);
        Console.WriteLine();
      }
    }
  }
}
