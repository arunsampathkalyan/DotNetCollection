﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;
using System.Xml.Schema;

namespace TextSerialization
{
  class Program
  {
    static void Main(string[] args)
    {
      var normal = new NormalType() {SomeInt = 10, SomeString = "Hello, World!"};
      
      //WriteText(normal);
      ////ShowXsd(normal.GetType());
      
      //WriteMtom(normal);

      //WriteBinary(normal);
      //WriteBinarySession(normal);
      //WriteBinarySessionWithDictionary(normal);
     // return;
      var data = new BinaryDataType() {SomeInt = 10, SomeString = "Hello, World!"};
      var buffer = new byte[767];
      data.Data = buffer;
      for (var i = 0; i < buffer.Length; ++i)
      {
        buffer[i] = (byte)((i%26) + 'a');
      }
      WriteText(data);
      WriteMtom(data);
      //WriteBinary(data);
      //WriteBinarySession(data);
      buffer = new byte[2200];
      data.Data = buffer;
      for (var i = 0; i < buffer.Length; ++i)
      {
        buffer[i] = (byte)((i % 26) + 'a');
      }
      WriteText(data);
      WriteMtom(data);
      //WriteBinary(data);
      //WriteBinarySession(data);
    }

    static void WriteText(object data)
    {
      var ser = new DataContractSerializer(data.GetType());
      var stream = new MemoryStream();
      var writer = XmlDictionaryWriter.CreateTextWriter(stream);
      ser.WriteObject(writer, data);
      Console.WriteLine();
      writer.Flush();
      Console.WriteLine("Stream size: {0} bytes", stream.Length);
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      stream.Close();
    }

    static void WriteMtom(object data)
    {
      var ser = new DataContractSerializer(data.GetType());
      var stream = new MemoryStream();
      var writer = XmlDictionaryWriter.CreateMtomWriter(stream, Encoding.UTF8, int.MaxValue, string.Empty);
      ser.WriteObject(writer, data);
      Console.WriteLine();
      writer.Flush();
      Console.WriteLine("Stream size: {0} bytes", stream.Length);
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      stream.Close();
    }

    static void WriteBinary(object data)
    {
      var ser = new DataContractSerializer(data.GetType());
      var stream = new MemoryStream();
      var writer = XmlDictionaryWriter.CreateBinaryWriter(stream);
      ser.WriteObject(writer, data);
      Console.WriteLine();
      writer.Flush();
      Console.WriteLine("Stream size: {0} bytes", stream.Length);
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      stream.Close();
    }

    static void WriteBinarySession(object data)
    {
      var ser = new DataContractSerializer(data.GetType());
      var stream = new MemoryStream();
      var dict = new XmlDictionary();
      var session = new XmlBinaryWriterSession();
      var writer = XmlDictionaryWriter.CreateBinaryWriter(stream, dict, session);
      ser.WriteObject(writer, data);
      Console.WriteLine();
      writer.Flush();
      Console.WriteLine("Stream size: {0} bytes", stream.Length);
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      stream.Close();
    }


    static void WriteBinarySessionWithDictionary(NormalType data)
    {
      var ser = new DataContractSerializer(typeof(NormalType));
      var stream = new MemoryStream();
      var dict = new XmlDictionary();
      var session = new XmlBinaryWriterSession();
      var readerSession = new XmlBinaryReaderSession();
      var someString = dict.Add("SomeString");
      var someInt = dict.Add("SomeInt");
      var name = dict.Add("NormalType");
      var ns = dict.Add("http://schemas.datacontract.org/2004/07/TextSerialization");
      var ns2 = dict.Add("http://www.w3.org/2001/XMLSchema-instance");
      var key = 0;
      session.TryAdd(someString, out key);
      readerSession.Add(key, someString.Value);
      session.TryAdd(someInt, out key);
      readerSession.Add(key, someInt.Value);
      session.TryAdd(name, out key);
      readerSession.Add(key, name.Value);
      session.TryAdd(ns, out key);
      readerSession.Add(key, ns.Value);
      session.TryAdd(ns2, out key);
      readerSession.Add(key, ns2.Value);
      var writer = XmlDictionaryWriter.CreateBinaryWriter(stream, dict, session);
      ser.WriteObject(writer, data);
      Console.WriteLine();
      writer.Flush();
      Console.WriteLine("Stream size: {0} bytes", stream.Length);
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      stream.Seek(0, SeekOrigin.Begin);
      var reader = XmlDictionaryReader.CreateBinaryReader(stream, null, XmlDictionaryReaderQuotas.Max, readerSession);
      var readValue = ser.ReadObject(reader) as NormalType;
      Console.WriteLine(readValue.SomeString);
      stream.Close();
    }

    static void ShowXsd(Type type)
    {
      var exporter = new XsdDataContractExporter();
      exporter.Export(type);
      foreach (XmlSchema schema in exporter.Schemas.Schemas())
      {
        var writer = new XmlTextWriter(Console.Out) { Formatting = Formatting.Indented };
        schema.Write(writer);
        Console.WriteLine();
      }
    }
  }
}
