﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextSerialization
{
  public class BinaryDataType : NormalType
  {
    public byte[] Data { get; set; }
  }
}
