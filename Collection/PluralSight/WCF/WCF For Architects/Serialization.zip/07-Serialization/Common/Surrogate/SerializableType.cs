﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Common.Surrogate
{
  [DataContract]
  class SerializableType
  {
    [DataMember]
    public int MyInt{ get; set;}

    [DataMember(Name="ThisIsMyString")]
    public string MyString { get; set; }
  }
}
