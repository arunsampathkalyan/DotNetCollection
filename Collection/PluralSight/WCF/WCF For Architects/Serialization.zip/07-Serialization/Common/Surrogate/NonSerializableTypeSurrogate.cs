﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;

namespace Common.Surrogate
{
  public class NonSerializableTypeSurrogate : IDataContractSurrogate
  {
    public Type GetDataContractType(Type type)
    {
      var retval = default(Type);
      if (type == typeof(NonSerializableType))
      {
        retval = typeof (SerializableType);
      }
      return retval;
    }

    public object GetObjectToSerialize(object obj, Type targetType)
    {
      var nonSerializable = obj as NonSerializableType;
      if (nonSerializable != null)
      {
        var serializableType = new SerializableType
                                 {
                                   MyInt = nonSerializable.MyInt,
                                   MyString = nonSerializable.MyString
                                 };
        return serializableType;
      }
      return obj;
    }

    public object GetDeserializedObject(object obj, Type targetType)
    {
      var serializable = obj as SerializableType;
      if (serializable != null)
      {
        var nonSerializable = new NonSerializableType
                                {
                                  MyInt = serializable.MyInt, 
                                  MyString = serializable.MyString
                                };
        return nonSerializable;
      }
      return obj;
    }

    public object GetCustomDataToExport(MemberInfo memberInfo, Type dataContractType)
    {
      return null;
    }

    public object GetCustomDataToExport(Type clrType, Type dataContractType)
    {
      return null;
    }

    public void GetKnownCustomDataTypes(Collection<Type> customDataTypes)
    {
    }

    public Type GetReferencedTypeOnImport(string typeName, string typeNamespace, object customData)
    {
      // This method is called on schema import.

      // What we say here is that if we see a SerializableType data contract in the specified namespace,
      // we should not create a new type for it since we already have an existing type, "NonSerializableType".
      Type retval = null;
      if (typeNamespace == "http://www.pluralsight.com/demos/surrogate" &&
        typeName == typeof(SerializableType).Name)
      {
        retval = typeof (NonSerializableType);
      }
      return retval;
    }

    public CodeTypeDeclaration ProcessImportedType(CodeTypeDeclaration typeDeclaration, CodeCompileUnit compileUnit)
    {
      return typeDeclaration;
    }
  }
}
