﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Surrogate
{
  public class NonSerializableType
  {
    public int MyInt;

    public string MyString;
  }
}
