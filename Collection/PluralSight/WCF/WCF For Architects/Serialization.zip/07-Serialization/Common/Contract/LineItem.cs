﻿using System.Runtime.Serialization;

namespace DefaultSerialization.Contract
{
  [DataContract]
  public enum BlockColors
  {
    [EnumMember(Value = "green")]
    Green,

    [EnumMember(Value = "red")]
    Red,

    [EnumMember(Value = "blue")]
    Blue
  }

  [DataContract(Name = "lineItem")]
  public class LineItem
  {

    [DataMember] private BlockColors _color;
    [DataMember(IsRequired = false, EmitDefaultValue = false, Name = "line", Order = 2)]
    public int Line { get; set; }

    [IgnoreDataMember]
    public int ItemId { get; set; }

    [DataMember]
    public double Price { get; set; }

    [DataMember]
    public int Quantity { get; set; }

    [DataMember]
    public int PurchaseOrderId { get; set; }
  }
}
