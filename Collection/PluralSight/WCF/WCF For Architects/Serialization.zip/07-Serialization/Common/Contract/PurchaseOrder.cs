﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace DefaultSerialization.Contract
{
  [DataContract]
  public class PurchaseOrder
  {
    public PurchaseOrder()
    {
      LineItems = new LineItemCollection();
    }

    [DataMember]
    public int CustomerId { get; set; }
    
    [DataMember]
    public LineItemCollection LineItems { get; private set; }

    [DataMember]
    public int PurchaseOrderId { get; set; }
  }
}
