﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Common.Polymorphism
{
  [DataContract]
  //[KnownType(typeof(DerivedTypeA))]
  [KnownType("GetDerivedTypes")]
  public class BaseType
  {
    [DataMember] public string StringData;

    public override string ToString()
    {
      return string.Format("StringData: {0}\n", StringData);
    }

    static public IEnumerable<Type> GetDerivedTypes()
    {
      return from type in typeof (BaseType).Assembly.GetTypes()
             where typeof (BaseType).IsAssignableFrom(type)
             select type;
    }
  }
}
