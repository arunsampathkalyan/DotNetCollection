﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Common.Polymorphism
{
  [DataContract]
  public class DerivedTypeA : BaseType
  {
    [DataMember]
    public int IntData;

    public override string ToString()
    {
      return string.Format("{0}IntData: {1}\n", base.ToString(), IntData);
    }
  }

}
