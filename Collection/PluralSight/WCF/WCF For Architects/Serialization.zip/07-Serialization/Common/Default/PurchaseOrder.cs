﻿using System;
using System.Collections.Generic;

namespace DefaultSerialization.Default
{
  [Serializable]
  public class PurchaseOrder
  {
    public PurchaseOrder()
    {
      LineItems = new List<LineItem>();
    }

    public int CustomerId { get; set; }

    public List<LineItem> LineItems { get; private set; }

    public int PurchaseOrderId { get; set; }
  }
}
