﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using DefaultSerialization.Contract;

namespace JsonConsole
{
  class Program
  {
    static void Main(string[] args)
    {
      var ser = new DataContractJsonSerializer(typeof (LineItem));

      var lineItem = new LineItem {ItemId = 10, Line = 11, Price = 10.49, PurchaseOrderId = 100, Quantity = 1000};
      var stream = new MemoryStream();
      ser.WriteObject(stream, lineItem);
      stream.Flush();
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      Console.ReadLine();
    }
  }
}
