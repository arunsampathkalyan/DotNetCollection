﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace ControlInterface
{
  [ServiceContract(Namespace="http://www.pluralsight.com/control/1.0.0")]
  public interface IControlService
  {
    [OperationContract]
    void SetRectangleColor(byte red, byte green, byte blue);
  }
}
