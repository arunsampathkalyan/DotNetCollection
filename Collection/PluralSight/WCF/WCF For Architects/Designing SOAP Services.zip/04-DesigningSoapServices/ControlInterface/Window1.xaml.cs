﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControlInterface
{
  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>
  [ServiceBehavior(InstanceContextMode= InstanceContextMode.Single)]
  public partial class Window1 : Window, IControlService
  {

    ServiceHost _host = null;
    public Window1()
    {
      InitializeComponent();
      try
      {
        _host = new ServiceHost(this);
        _host.Open();
      }
      catch(Exception ex)
      {
        Debug.WriteLine(ex.ToString());
      }
    }

    public void SetRectangleColor(byte red, byte green, byte blue)
    {
      var color = Color.FromRgb(red, green, blue);
      rectangle1.Fill = new SolidColorBrush(color);
    }

    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
    {
      if (_host.State == CommunicationState.Opened)
      {
        _host.Close();
      }
      else 
      {
        _host.Abort();
      }
      base.OnClosing(e);
    }
  }
}
