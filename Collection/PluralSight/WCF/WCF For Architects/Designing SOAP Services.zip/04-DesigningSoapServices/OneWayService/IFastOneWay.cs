﻿using System.ServiceModel;

namespace OneWayService
{
  // NOTE: If you change the interface name "IIFastOneWay" here, you must also update the reference to "IIFastOneWay" in App.config.
  [ServiceContract]
  public interface IFastOneWay
  {
    [OperationContract(IsOneWay = true)]
    void SendInt(int value);

    [OperationContract(IsOneWay = true)]
    void SendString(string value);
  }
}
