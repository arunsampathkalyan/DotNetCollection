﻿using System;
using System.ServiceModel;
using System.Threading;

namespace OneWayService
{
  // NOTE: If you change the class name "IFastOneWay" here, you must also update the reference to "IFastOneWay" in App.config.
  [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall)]
  public class FastOneWay : IFastOneWay
  {
    private int callCount = 0;
    public void SendInt(int value)
    {
      ++callCount;
      var rand = new Random();
      Thread.Sleep(rand.Next(100, 1000));
      Console.WriteLine("Received an int: {0}, CallCount: {1}", value, callCount);
    }

    public void SendString(string value)
    {
      ++callCount;
      Console.WriteLine("Received a string: {0}, CallCount: {1}", value, callCount);
    }
  }
}
