﻿using System;
using System.ServiceModel;

namespace OneWayClient
{
  class Program
  {
    static void Main(string[] args)
    {
      for (int i = 0; i < 100; ++i)
      {
        var client = new OneWayReference.FastOneWayClient();
        try
        {
          client.SendInt(i);
          client.SendString("Number " + i);
          client.Close();
        }
        catch (FaultException fe)
        {
          Console.WriteLine(fe.Message);
          client.Abort();
        }
        catch (CommunicationException ce)
        {
          Console.WriteLine(ce.Message);
          client.Abort();
        }
        catch (TimeoutException te)
        {
          Console.WriteLine(te.Message);
          client.Abort();
        }

      }
    }
  }
}
