﻿using System;
using System.IO;

namespace ChoreographyClient
{
  class Program
  {
    static void Main(string[] args)
    {
      if (File.Exists("app_tracelog.svclog")) File.WriteAllText("app_tracelog.svclog", string.Empty);
      var client = new ServiceReference1.HelloWorldServiceClient();
      Console.WriteLine(client.SayHello("Pluralsight"));
      client.Close();
    }
  }
}
