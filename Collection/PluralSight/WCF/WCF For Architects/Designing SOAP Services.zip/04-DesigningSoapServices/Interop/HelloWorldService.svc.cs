﻿
namespace Interop
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "HelloWorldService" in code, svc and config file together.
  public class HelloWorldService : IHelloWorldService
  {
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}!", name);
    }
  }
}
