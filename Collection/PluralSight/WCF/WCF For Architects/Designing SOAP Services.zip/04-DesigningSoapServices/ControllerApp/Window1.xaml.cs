﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ControllerApp
{
  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>
  public partial class Window1 : Window
  {
    public Window1()
    {
      InitializeComponent();
      var colorNames = from name in typeof (System.Drawing.Color).GetProperties(
                         BindingFlags.Static | BindingFlags.Public)
                       select name.Name;
      comboBox1.ItemsSource = colorNames;
    }

    private void btnSetColor_Click(object sender, RoutedEventArgs e)
    {
      var client = new ControlServiceReference.ControlServiceClient();
      try
      {
        var colorProperty = (from color in typeof (System.Drawing.Color).GetProperties(
          BindingFlags.Static | BindingFlags.Public)
                            where color.Name == (string) comboBox1.SelectedValue
                            select color).First();
        var rectColor = (System.Drawing.Color)(colorProperty.GetValue(null, new object[]{}));
        client.SetRectangleColor(rectColor.R, rectColor.G, rectColor.B);
        client.Close();
      }
      catch(Exception ex)
      {
        MessageBox.Show(ex.ToString());
        client.Abort();
      }
      
    }
  }
}
