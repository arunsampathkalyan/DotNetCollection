﻿
namespace ChoreographyDemo
{
  class HelloWorldService : IHelloWorldService
  {
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}!", name);
    }
  }
}
