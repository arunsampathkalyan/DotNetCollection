﻿using System.ServiceModel;

namespace ChoreographyDemo
{
  [ServiceContract]
  interface IHelloWorldService
  {
    [OperationContract]
    string SayHello(string name);
  }
}
