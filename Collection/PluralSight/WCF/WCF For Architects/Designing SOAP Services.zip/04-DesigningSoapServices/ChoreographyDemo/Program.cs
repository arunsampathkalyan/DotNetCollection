﻿using System;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ChoreographyDemo
{
  class Program
  {
    static void Main(string[] args)
    {
      if (File.Exists("app_tracelog.svclog")) File.WriteAllText("app_tracelog.svclog", string.Empty);
      var host = new ServiceHost(typeof(HelloWorldService));
      host.Open();

      try
      {
        foreach (ServiceEndpoint se in host.Description.Endpoints)
        {
          Console.WriteLine(se.ListenUri);
        }
        Console.ReadLine();
        host.Close();
      }
      catch (CommunicationObjectFaultedException cofe)
      {
        host.Abort();
      }
    }
  }
}
