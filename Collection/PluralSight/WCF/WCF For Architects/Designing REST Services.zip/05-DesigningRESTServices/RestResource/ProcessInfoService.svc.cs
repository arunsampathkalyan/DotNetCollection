﻿using System;
using System.Data.Services;
using System.Linq.Expressions;

namespace RestResource
{
  // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ProcessInfo" in code, svc and config file together.
  public class ProcessInfoService : DataService<ProcessInfoDataService>
  {
    public static void InitializeService(IDataServiceConfiguration config)
    {
      config.SetEntitySetAccessRule("Processes", EntitySetRights.AllRead);
    }

    [QueryInterceptor("Processes")]
    public Expression<Func<ProcessInfo, bool>> OnQueryProcesses()
    {
      return process => true;
      //return process => process.ProcessName.Contains("a");
    }
  }
}
