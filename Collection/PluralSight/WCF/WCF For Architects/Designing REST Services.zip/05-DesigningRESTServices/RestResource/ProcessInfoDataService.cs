﻿using System.Linq;
using System.Diagnostics;

namespace RestResource
{
    public class ProcessInfoDataService
    {
        public IQueryable<ProcessInfo> Processes
        {
            get
            {
                return (from process in Process.GetProcesses()
                       select new ProcessInfo(process.Id)).AsQueryable(); 
            }
        }
    }
}
