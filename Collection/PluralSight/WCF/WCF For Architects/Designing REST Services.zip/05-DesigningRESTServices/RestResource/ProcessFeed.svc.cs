﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;
using System.Web;

namespace RestResource
{
  // NOTE: If you change the class name "ProcessFeed" here, you must also update the reference to "ProcessFeed" in Web.config.
  [ServiceContract]
  [ServiceKnownType(typeof(Atom10FeedFormatter))]
  [ServiceKnownType(typeof(Rss20FeedFormatter))]
  [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
  public class ProcessFeed
  {
    [OperationContract]
    [WebGet(UriTemplate = "*", BodyStyle = WebMessageBodyStyle.Bare)]
    public SyndicationFeedFormatter DoWork()
    {
      Uri requestUri = HttpContext.Current.Request.Url;

      // Look at the URL to figure out which user and the response format
      // (Atom | RSS).
      string fileName = requestUri.Segments[requestUri.Segments.Length - 1];
      string feedType = Path.GetExtension(fileName.ToUpper());
      SyndicationFeedFormatter formatter;
      SyndicationFeed feed = new SyndicationFeed(string.Format("Process Feed for computer {0}",
          Environment.MachineName), "A Process Feed", HttpContext.Current.Request.Url);

      // Pick the feed.
      if (feedType.Equals(".ATOM"))
      {
        formatter = feed.GetAtom10Formatter();
      }
      else if (feedType.Equals(".RSS"))
      {
        formatter = feed.GetRss20Formatter();
      }
      else
      {
        // We don't understand the request type, so 
        // tell the caller that the resource they want can't
        // be found.
        WebOperationContext.Current.OutgoingResponse.StatusCode =
            System.Net.HttpStatusCode.NotFound;
        return null;
      }

      // Get all the public images for the user in question
      var processes = from proc in Process.GetProcesses()
                      select new ProcessInfo(proc.Id);

      // No public images means no resource to return.
      // Maybe the user doesn't exist?
      if (processes.Count() == 0)
      {
        WebOperationContext.Current.OutgoingResponse.StatusCode =
            System.Net.HttpStatusCode.NotFound;
        return null;
      }

      List<SyndicationItem> items = processes.
        Select(process => new SyndicationItem(process.Id.ToString(),
          process.ProcessName,
          new Uri(string.Format("http://{0}{1}/ProcessInfoService.svc/Processes({2})",
            HttpContext.Current.Request.Url.Authority,
            HttpContext.Current.Request.ApplicationPath, process.Id)),
            process.ProcessName, DateTimeOffset.UtcNow)).ToList();
      feed.Items = items;
      return formatter;
    }
  }
}
