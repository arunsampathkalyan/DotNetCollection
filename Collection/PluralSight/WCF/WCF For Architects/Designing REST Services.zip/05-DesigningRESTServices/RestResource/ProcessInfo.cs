﻿// [Book name], ISBN: [isbn]
// Kenn Scribner and Scott Seely
// This code supplied without any warranties, express or implied. 
// Code is free to use, public domain. 
// Have a nice day!

using System.Data.Services.Common;
using System.Diagnostics;

namespace RestResource
{
    [DataServiceKey("Id")]
    public class ProcessInfo
    {
        public ProcessInfo() :
            this(Process.GetCurrentProcess().Id)
        {
        }

        public ProcessInfo(int processId)
        {
            Process process = Process.GetProcessById(processId);
            ProcessName = process.ProcessName;
            Id = process.Id;
            BasePriority = process.BasePriority;
            HandleCount = process.HandleCount;
            NonpagedSystemMemorySize64 = process.NonpagedSystemMemorySize64;
            PagedMemorySize64 = process.PagedMemorySize64;
            PeakPagedMemorySize64 = process.PeakPagedMemorySize64;
            PeakVirtualMemorySize64 = process.PeakVirtualMemorySize64;
            PeakWorkingSet64 = process.PeakWorkingSet64;
            PrivateMemorySize64 = process.PrivateMemorySize64;
            Responding = process.Responding;
            VirtualMemorySize64 = process.VirtualMemorySize64;
            WorkingSet64 = process.WorkingSet64;
            SessionId = process.SessionId;
            MainWindowTitle = process.MainWindowTitle;
        }

        public int BasePriority { get; set; }

        public int HandleCount { get; set; }

        public int Id { get; set; }

        public string MainWindowTitle { get; set; }

        public long NonpagedSystemMemorySize64 { get; set; }

        public long PagedMemorySize64 { get; set; }

        public long PagedSystemMemorySize64 { get; set; }

        public long PeakPagedMemorySize64 { get; set; }

        public long PeakVirtualMemorySize64 { get; set; }

        public long PeakWorkingSet64 { get; set; }

        public bool PriorityBoostEnabled { get; set; }

        public long PrivateMemorySize64 { get; set; }

        public string ProcessName { get; set; }

        public bool Responding { get; set; }

        public int SessionId { get; set; }

        public long VirtualMemorySize64 { get; set; }

        public long WorkingSet64 { get; set; }
    }
}
