﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Syndication;
using System.Text;
using System.Xml;

namespace ConsoleApplication1
{
  class Program
  {
    static void Main(string[] args)
    {
      var reader = XmlTextReader.Create("http://feeds2.feedburner.com/Devlicious");
      var feed = SyndicationFeed.Load(reader);
      foreach (var feeditem in feed.Items)
      {
        Console.WriteLine("Title: {0}", feeditem.Title.Text);
      }
      Console.ReadLine();
    }
  }
}
