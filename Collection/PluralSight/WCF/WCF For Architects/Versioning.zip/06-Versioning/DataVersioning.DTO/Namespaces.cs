﻿
namespace DataVersioning.DTO
{
  public static class Namespaces
  {
    public const string V1 = "http://www.pluralsight.com/Purchase/1.0.0";
    public const string V2 = "http://www.pluralsight.com/Purchase/2.0.0";
    public const string V3 = "http://www.pluralsight.com/Purchase/3.0.0";
  }
}
