﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            MathClient client = new MathClient("BasicHttpBinding_IMath");

            Console.WriteLine("Enter x: ");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter y: ");
            double y = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("add: {0}", client.Add(x, y));
            Console.WriteLine("sub: {0}", client.Subtract(x, y));
            Console.WriteLine("mul: {0}", client.Multiply(x, y));
            Console.WriteLine("div: {0}", client.Divide(x, y));
            Console.WriteLine("mod: {0}", client.Mod(x, y));

            Console.WriteLine();

            MathClient client2 = new MathClient("NetTcpBinding_IMath");

            Console.WriteLine("add: {0}", client2.Add(x, y));
            Console.WriteLine("sub: {0}", client2.Subtract(x, y));
            Console.WriteLine("mul: {0}", client2.Multiply(x, y));
            Console.WriteLine("div: {0}", client2.Divide(x, y));
            Console.WriteLine("mod: {0}", client2.Mod(x, y));

        }
    }
}
