﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using Client.EvalServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*** Client Application ***");
            Console.WriteLine("Press <Enter> to run the client...");
            Console.ReadLine();

            EvalServiceClient client =
                new EvalServiceClient("NetTcpBinding_IEvalService");
            EvalServiceClient client2 =
                new EvalServiceClient("NetTcpBinding_IEvalService");

            try
            {
                Eval eval = new Eval();
                eval.Submitter = "Aaron";
                eval.Comments = "I'm really liking this";

                client.SubmitEval(eval);
                client.SubmitEval(eval);
                client.SubmitEval(eval);
                client2.SubmitEval(eval);
                client2.SubmitEval(eval);

                List<Eval> evals = client.GetEvals();
                Console.WriteLine("Number of evals: {0}", evals.Count);

                Console.ReadLine();
                client.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                client.Abort();
            }
        }
    }
}
