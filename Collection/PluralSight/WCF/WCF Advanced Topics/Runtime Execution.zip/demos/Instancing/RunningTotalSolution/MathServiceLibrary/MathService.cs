﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MathServiceLibrary
{
    [ServiceContract(SessionMode=SessionMode.Required)]
    public interface IMath
    {
        [OperationContract]
        double Add(double x);
        [OperationContract]
        double Subtract(double x);
        [OperationContract]
        double Multiply(double x);
        [OperationContract]
        double Divide(double x);
        [OperationContract]
        double Mod(double x);
        [OperationContract(IsInitiating=false, IsTerminating=true)]
        double GetRunningTotal();
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession)]
    public class MathService : IMath
    {
        double runningTotal;

        #region IMath Members

        public double Add(double x)
        {
            Console.WriteLine("object id: {0}, session id: {1}", 
                this.GetHashCode(), OperationContext.Current.SessionId);
            return runningTotal += x;
        }

        public double Subtract(double x)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return runningTotal -= x;
        }

        public double Multiply(double x)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return runningTotal *= x;
        }

        public double Divide(double x)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return runningTotal /= x;
        }

        public double Mod(double x)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return runningTotal %= x;
        }

        public double GetRunningTotal()
        {
            return runningTotal;
        }
        #endregion
    }

}
