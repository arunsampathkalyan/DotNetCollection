﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            MathClient client = new MathClient("NetTcpBinding_IMath");

            Console.WriteLine("Enter x: ");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("add: {0}", client.Add(x));
            Console.WriteLine("add: {0}", client.Add(x));
            Console.WriteLine("add: {0}", client.Add(x));
            Console.WriteLine("sub: {0}", client.Subtract(x));
            Console.WriteLine("mul: {0}", client.Multiply(x));
            Console.WriteLine("div: {0}", client.Divide(x));
            Console.WriteLine("total: {0}", client.GetRunningTotal());
            //Console.WriteLine("mod: {0}", client.Mod(x));

            Console.WriteLine();

            MathClient client2 = new MathClient("NetTcpBinding_IMath");

            Console.WriteLine("add: {0}", client2.Add(x));
            Console.WriteLine("add: {0}", client2.Add(x));
            Console.WriteLine("add: {0}", client2.Add(x));
            Console.WriteLine("sub: {0}", client2.Subtract(x));
            Console.WriteLine("mul: {0}", client2.Multiply(x));
            Console.WriteLine("div: {0}", client2.Divide(x));
            Console.WriteLine("mod: {0}", client2.Mod(x));
            Console.WriteLine("total: {0}", client2.GetRunningTotal());

        }
    }
}
