﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace DurableCalculatorServiceHost
{
    [ServiceContract]
    public interface ICalculator
    {
        [OperationContract]
        void Clear();
        [OperationContract]
        int Add(int value);
        [OperationContract]
        int GetFinalSum();
    }

    [Serializable]
    [DurableService]
    public class DurableCalculatorService : ICalculator
    {
        int sum;

        #region ICalculator Members

        [DurableOperation]
        public void Clear()
        {
            this.sum = 0;
        }

        [DurableOperation]
        public int Add(int value)
        {
            return this.sum += value;
        }

        [DurableOperation(CompletesInstance=true)]
        public int GetFinalSum()
        {
            return this.sum;
        }

        #endregion
    }


    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = new ServiceHost(typeof(DurableCalculatorService));
            try
            {
                host.Open();
                Console.WriteLine("DurableCalculatorService is up and running...");
                Console.ReadLine();
                host.Close();
            }
            catch (Exception)
            {
                host.Abort();
                throw;
            }
        }
    }
}
