﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Channels;
using System.IO;
using System.Runtime.Serialization;
using System.Collections;
using Client.DurableCalculatorServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();

            CalculatorClient client = new CalculatorClient("BasicHttpContextBinding_ICalculator");
            IContextManager mgr = client.InnerChannel.GetProperty<IContextManager>();

            try
            {
                string command = "";
                while (!command.Equals("exit"))
                {
                    Console.WriteLine("Enter a command: add, clear, total, load, save, exit");
                    command = Console.ReadLine();

                    switch (command)
                    {
                        case "add":
                            Console.WriteLine("Enter a number to add: ");
                            int num = int.Parse(Console.ReadLine());
                            Console.WriteLine("sum: {0}", client.Add(num));
                            break;
                        case "clear":
                            client.Clear();
                            break;
                        case "total":
                            int total = client.GetFinalSum();
                            Console.WriteLine("sum: {0}", total);
                            break;
                        case "load":
                            LoadContext(mgr);
                            break;
                        case "save":
                            PersistContext(mgr);
                            break;
                        case "exit":
                            break;
                    }

                    PersistContext(mgr);
                }
                client.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                client.Abort();
            }
        }

        static void PersistContext(IContextManager mgr)
        {
            IDictionary<string, string> ctx = mgr.GetContext();
            using (FileStream fs = new FileStream("context.bin", FileMode.Create))
            {
                DataContractSerializer dcs = new DataContractSerializer(typeof(IDictionary<string, string>));
                dcs.WriteObject(fs, ctx);
            }
        }
        static void LoadContext(IContextManager mgr)
        {
            IDictionary<string, string> ctx = null;
            using (FileStream fs = new FileStream("context.bin", FileMode.Open))
            {
                DataContractSerializer dcs = new DataContractSerializer(typeof(IDictionary<string, string>));
                ctx = dcs.ReadObject(fs) as IDictionary<string, string>;
            }
            if (null != ctx)
                mgr.SetContext(ctx);
        }
    }
}
