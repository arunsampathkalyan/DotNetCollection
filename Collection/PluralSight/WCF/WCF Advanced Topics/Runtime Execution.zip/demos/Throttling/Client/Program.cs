﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            MathClient client = new MathClient("BasicHttpBinding_IMath");
            client.AddCompleted += new EventHandler<AddCompletedEventArgs>(client_AddCompleted);
           
            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine("Add({0},{0}) called.", i);
                client.AddAsync(i, i);
            }

            Console.ReadLine();
        }

        static void client_AddCompleted(object sender, AddCompletedEventArgs e)
        {
            Console.WriteLine("Add completed: {0}", e.Result);
        }
    }
}
