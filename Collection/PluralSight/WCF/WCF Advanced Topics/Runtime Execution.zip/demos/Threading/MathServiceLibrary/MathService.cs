﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MathServiceLibrary
{
    [ServiceContract]
    public interface IMath
    {
        [OperationContract]
        double Add(double x, double y);
        [OperationContract]
        double Subtract(double x, double y);
        [OperationContract]
        double Multiply(double x, double y);
        [OperationContract]
        double Divide(double x, double y);
        [OperationContract]
        double Mod(double x, double y);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession,
        ConcurrencyMode=ConcurrencyMode.Multiple)]
    public class MathService : IMath
    {
        #region IMath Members

        public double Add(double x, double y)
        {
            Console.WriteLine("object id: {0}, session id: {1}", 
                this.GetHashCode(), OperationContext.Current.SessionId);
            System.Threading.Thread.Sleep(5000);
            return x + y;
        }

        public double Subtract(double x, double y)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return x - y;
        }

        public double Multiply(double x, double y)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return x * y;
        }

        public double Divide(double x, double y)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return x / y;
        }

        public double Mod(double x, double y)
        {
            Console.WriteLine("object id: {0}, session id: {1}",
                this.GetHashCode(), OperationContext.Current.SessionId);
            return x % y;
        }

        #endregion
    }

}
