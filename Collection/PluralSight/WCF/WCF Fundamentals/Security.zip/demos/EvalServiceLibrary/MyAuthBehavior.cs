﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.IdentityModel.Claims;

namespace EvalServiceLibrary
{
    public class MyAuthBehavior : ServiceAuthorizationManager
    {
        public override bool CheckAccess(OperationContext operationContext)
        {
            if (operationContext.IncomingMessageHeaders.Action.Equals(
                "http://tempuri.org/IEvalService/SubmitEval"))
            {
                ServiceSecurityContext ctx = operationContext.ServiceSecurityContext;
                foreach (ClaimSet cs in ctx.AuthorizationContext.ClaimSets)
                {
                    foreach (Claim c in cs)
                    {
                        Console.WriteLine("{0} -- {1} -- {2}", c.ClaimType, c.Right, c.Resource);
                        if (c.ClaimType.Equals("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid") &&
                            c.Right.Equals("http://schemas.xmlsoap.org/ws/2005/05/identity/right/possessproperty") &&
                            c.Resource.ToString().Equals("S-1-5-21-855717018-293123909-2847481543-1011")) // EvalUsers group
                            return true;
                    }
                }
                return false;
            }
            else
                return true;
        }
    }
}
