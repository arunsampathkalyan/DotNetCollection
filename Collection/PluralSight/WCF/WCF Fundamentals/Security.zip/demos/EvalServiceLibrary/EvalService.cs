﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;
using System.Net.Security;
using System.Threading;
using System.IO;
using System.Security.Permissions;
using System.IdentityModel.Claims;

namespace EvalServiceLibrary
{
    [DataContract(Namespace="http://pluralsight.com/evals")]
    public class Eval
    {
        [DataMember]
        public string Id;
        [DataMember]
        public string Submitter;
        [DataMember]
        public DateTime Timesent;
        [DataMember]
        public string Comments;
    }

    [ServiceContract(ProtectionLevel=ProtectionLevel.EncryptAndSign)]
    public interface IEvalService
    {
        [OperationContract]
        void SubmitEval(Eval eval);

        [OperationContract]
        Eval GetEval(string id);

        [OperationContract]
        List<Eval> GetAllEvals();

        [OperationContract]
        List<Eval> GetEvalsBySubmitter(string submitter);

        [OperationContract]
        void RemoveEval(string id);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class EvalService : IEvalService
    {
        List<Eval> evals = new List<Eval>();
        int evalCount = 0;

        #region IEvalService Members

        //[PrincipalPermission(SecurityAction.Demand, 
        //    Role="skonnard-office\\EvalUsers")]
        //[OperationBehavior(Impersonation=ImpersonationOption.Required)]
        public void SubmitEval(Eval eval)
        {
            Console.WriteLine("Caller identity: {0}",
                ServiceSecurityContext.Current.PrimaryIdentity.Name);
            //if (!this.AuthorizeCaller())
            //    throw new FaultException("Access denied -- didn't provide the correct claimset");

            using (FileStream fs = new FileStream(string.Format("{0}.xml", Guid.NewGuid().ToString()), FileMode.Create, FileAccess.Write))
            {
                DataContractSerializer dcs = new DataContractSerializer(typeof(Eval));
                dcs.WriteObject(fs, eval);
            }
            eval.Id = (++evalCount).ToString();
            evals.Add(eval);
        }

        private bool AuthorizeCaller()
        {
            ServiceSecurityContext ctx = ServiceSecurityContext.Current;
            foreach (ClaimSet cs in ctx.AuthorizationContext.ClaimSets)
            {
                foreach (Claim c in cs)
                {
                    Console.WriteLine("{0} -- {1} -- {2}", c.ClaimType, c.Right, c.Resource);
                    if (c.ClaimType.Equals("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid") &&
                        c.Right.Equals("http://schemas.xmlsoap.org/ws/2005/05/identity/right/possessproperty") &&
                        c.Resource.ToString().Equals("S-1-5-21-855717018-293123909-2847481543-1011")) // EvalUsers group
                        return true;
                }
            }
            return false;
        }

        public Eval GetEval(string id)
        {
            return evals.First(e => e.Id.Equals(id));
        }

        public List<Eval> GetAllEvals()
        {
            return this.GetEvalsBySubmitter(null);
        }

        public List<Eval> GetEvalsBySubmitter(string submitter)
        {
            if (submitter == null || submitter.Equals(""))
                return evals;
            else
                return evals.Where(e => e.Submitter.ToLower().Equals(submitter.ToLower())).ToList<Eval>();
        }

        public void RemoveEval(string id)
        {
            evals.RemoveAll(e => e.Id.Equals(id));
        }

        #endregion
    }
}
