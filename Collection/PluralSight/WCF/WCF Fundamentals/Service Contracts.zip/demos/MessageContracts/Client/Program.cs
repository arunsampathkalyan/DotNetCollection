﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            SimpleMathClient client = new SimpleMathClient("BasicHttpBinding_SimpleMath");

            Console.WriteLine("Enter x: ");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter y: ");
            double y = double.Parse(Console.ReadLine());
            Console.WriteLine();

            MathInputs inputs = new MathInputs();
            inputs.x = x;
            inputs.y = y;
            string userid = "aaron";

            Console.WriteLine("add: {0}", client.add(userid, inputs));
            Console.WriteLine("sub: {0}", client.sub(userid, inputs));
        }
    }
}
