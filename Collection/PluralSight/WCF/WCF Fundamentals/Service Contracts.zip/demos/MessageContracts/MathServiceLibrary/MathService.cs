﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace MathServiceLibrary
{
    [DataContract(Namespace="http://pluralsight.com/math")]
    public class MathInputs
    {
        [DataMember]
        public double x;
        [DataMember]
        public double y;
    }

    [MessageContract(IsWrapped=false)]
    public class MathRequest
    {
        [MessageBodyMember]
        public MathInputs inputs;
        [MessageHeader]
        public string userId;
    }

    [MessageContract(IsWrapped=false)]
    public class MathResponse
    {
        public MathResponse() { }
        public MathResponse(double res) { this.result = res; }
        [MessageBodyMember]
        public double result;
    }

    [ServiceContract(Name="SimpleMath", Namespace="http://pluralsight.com/math")]
    public interface IMath
    {
        [OperationContract(Name="add")]
        MathResponse Add(MathRequest request);
        [OperationContract(Name = "sub")]
        MathResponse Subtract(MathRequest request);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerCall)]
    public class MathService : IMath
    {
        #region IMath Members

        public MathResponse Add(MathRequest request)
        {
            Console.WriteLine("Add was called by {0}", request.userId);
            return new MathResponse(request.inputs.x + request.inputs.y);
        }

        public MathResponse Subtract(MathRequest request)
        {
            Console.WriteLine("Subtract was called by {0}", request.userId);
            return new MathResponse(request.inputs.x - request.inputs.y);
        }

        #endregion
    }

}
