﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace MultipleServiceContracts
{
    public class MyService : IFoo, IBar, IBaz
    {
        #region IFoo Members

        public string SayHello(string name)
        {
            return string.Format("Hello {0}!", name);
        }

        #endregion

        #region IBar Members

        public string SayGoodbye(string name)
        {
            return string.Format("Bye {0}!", name);
        }

        #endregion

        #region IBaz Members

        public string SaySomethingNice(string name)
        {
            return string.Format("{0} is cool!", name);
        }

        #endregion
    }
}
