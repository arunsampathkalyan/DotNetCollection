using System;   
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using ChatLibrary;

namespace ChatServer
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ServiceHost host = new ServiceHost(
                typeof(ChatManagerService),
                new Uri("http://localhost:8080/chatmgr")))
            {
                host.Open();
                PrintServiceDesc(host); 
                Console.ReadKey();
            }
        }
        static void PrintServiceDesc(ServiceHost host)
        {
            Console.WriteLine("{0} is up and running with the following endpoints:",
                host.Description.ServiceType.Name);
            foreach (ServiceEndpoint se in host.Description.Endpoints)
            {
                Console.WriteLine("Address: {0} ({1})",
                    se.Address.ToString(), se.Binding.Name);
            }
        }
    }
}
