using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace ChatLibrary
{
    [DataContract(Namespace = "http://example.org/chat")]
    public class ChatMessage
    {
        public ChatMessage() { }
        public ChatMessage(string n, DateTime ts, string m)
        {
            this.Name = n;
            this.TimeStamp = ts;
            this.Message = m;
        }
        [DataMember]
        public string Name;
        [DataMember]
        public DateTime TimeStamp;
        [DataMember]
        public string Message;
    }

    [ServiceContract(Namespace = "http://example.org/chat")]
    public interface IChat
    {
        [OperationContract(IsOneWay=true)]
        void SendMessage(ChatMessage msg);
    }

    [ServiceContract(Namespace = "http://example.org/chat",
        CallbackContract = typeof(IChat))]
    public interface IChatManager
    {
        [OperationContract(IsOneWay = true)]
        void RegisterClient(string name);
        [OperationContract(IsOneWay = true)]
        void SubmitMessage(ChatMessage msg);
    }

    public class ChatService : IChat
    {
        #region IChat Members

        public void SendMessage(ChatMessage msg)
        {
            Console.WriteLine("{0} {1} says: {2}",
                msg.TimeStamp, msg.Name, msg.Message);
        }

        #endregion
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class ChatManagerService : IChatManager
    {
        Dictionary<string, IChat> clients = new Dictionary<string, IChat>();

        #region IChatManager Members

        public void RegisterClient(string name)
        {
            IChat client = OperationContext.Current.GetCallbackChannel<IChat>();
            if (null != client)
                clients.Add(name, client);
            Console.WriteLine("{0} joined.", name);
        }

        public void SubmitMessage(ChatMessage msg)
        {
            foreach (string key in clients.Keys)
            {
                try
                {
                    if (!msg.Name.Equals(key))
                        clients[key].SendMessage(msg);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            }
        }
        #endregion
    }
}
