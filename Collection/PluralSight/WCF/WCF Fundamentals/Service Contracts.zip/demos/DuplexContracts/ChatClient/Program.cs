using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using ChatLibrary;

namespace ChatSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to ChatClient!");
            Console.WriteLine("Please enter your name:");
            string name = Console.ReadLine();

            ChatService localService = new ChatService();
            DuplexChannelFactory<IChatManager> dcf =
                new DuplexChannelFactory<IChatManager>(localService, "mgr");

            #region If you're not running on Vista
            /* Note: use this code if you're not running on Vista
             * 
            WSDualHttpBinding binding = new WSDualHttpBinding();
            string baseAddress = "http://localhost:9999/chatclient";
            string uniqueAddress = string.Format("{0}/{1}/",
                baseAddress, Guid.NewGuid().ToString());
            binding.ClientBaseAddress = new Uri(uniqueAddress);

            DuplexChannelFactory<IChatManager> dcf =
                new DuplexChannelFactory<IChatManager>(
                    localService, 
                    binding,
                    new EndpointAddress("http://localhost:8080/chatmgr/duplex")
                    );
            */
            #endregion

            IChatManager mgr = dcf.CreateChannel();
            mgr.RegisterClient(name);

            Console.WriteLine("\nPlease enter a message: ");
            string command = Console.ReadLine();
            while (!command.Equals("exit"))
            {
                mgr.SubmitMessage(new ChatMessage(name, DateTime.Now, command));
                command = Console.ReadLine();
            }
        }
    }
}
