﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;

namespace MathServiceLibrary
{
    [ServiceContract(Name="SimpleMath", Namespace="http://pluralsight.com/math")]
    public interface IMath
    {
        [OperationContract(Name="add")]
        double Add(double x, double y);
        [OperationContract(Name = "sub")]
        double Subtract(double x, double y);
        [OperationContract(Action="*", ReplyAction="*")]
        Message CatchAll(Message request);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerCall)]
    public class MathService : IMath
    {
        #region IMath Members

        public double Add(double x, double y)
        {
            return x + y;
        }
        public double Subtract(double x, double y)
        {
            return x - y;
        }

        public Message CatchAll(Message request)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(request.GetReaderAtBodyContents());
            Console.WriteLine(doc.InnerXml);

            throw new FaultException("You called an unsupported operation...please refresh your WSDL");
        }

        #endregion
    }

}
