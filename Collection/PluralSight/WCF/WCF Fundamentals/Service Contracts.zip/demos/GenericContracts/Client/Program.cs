﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;
using System.ServiceModel;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            SimpleMathClient client = new SimpleMathClient("BasicHttpBinding_SimpleMath");

            Console.WriteLine("Enter x: ");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter y: ");
            double y = double.Parse(Console.ReadLine());
            Console.WriteLine();

            try
            {
                Console.WriteLine("add: {0}", client.add(x, y));
                Console.WriteLine("sub: {0}", client.sub(x, y));
                //Console.WriteLine("mul: {0}", client.mul(x, y));
            }
            catch (FaultException fe)
            {
                Console.WriteLine(fe.Reason);
            }
        }
    }
}
