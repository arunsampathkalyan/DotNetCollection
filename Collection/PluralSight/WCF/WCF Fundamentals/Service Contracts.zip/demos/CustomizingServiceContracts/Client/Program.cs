﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.MathServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press <enter> to run the client...");
            Console.ReadLine();

            SimpleMathClient client = new SimpleMathClient("BasicHttpBinding_SimpleMath");

            Console.WriteLine("Enter x: ");
            double x = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter y: ");
            double y = double.Parse(Console.ReadLine());
            Console.WriteLine();

            List<double> numbers = new List<double>();
            numbers.Add(234);
            numbers.Add(456);
            numbers.Add(987);

            Console.WriteLine("add: {0}", client.add(x, y));
            Console.WriteLine("sub: {0}", client.sub(x, y));
            Console.WriteLine("mul: {0}", client.mul(x, y));
            Console.WriteLine("div: {0}", client.div(x, y));
            Console.WriteLine("mod: {0}", client.mod(x, y));

            Console.WriteLine();

            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");
            client.addList(numbers);
            Console.WriteLine("Call completed.");

        }
    }
}
