﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace MathServiceLibrary
{
    [ServiceContract(Name="SimpleMath", Namespace="http://pluralsight.com/math")]
    public interface IMath
    {
        [OperationContract(Name="add")]
        double Add(double x, double y);
        [OperationContract(Name = "addList", IsOneWay=true)]
        void Add(List<double> numbers);
        [OperationContract(Name = "sub")]
        double Subtract(double x, double y);
        [OperationContract(Name="mul")]
        double Multiply(double x, double y);
        [OperationContract(Name="div")]
        double Divide(double x, double y);
        [OperationContract(Name="mod")]
        double Mod(double x, double y);
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerCall)]
    public class MathService : IMath
    {
        #region IMath Members

        public double Add(double x, double y)
        {
            return x + y;
        }

        public void Add(List<double> numbers)
        {
            System.Threading.Thread.Sleep(5000);
            double sum = 0;
            foreach (double d in numbers)
                sum += d;
            Console.WriteLine("Add list results: {0}", sum);
        }

        public double Subtract(double x, double y)
        {
            return x - y;
        }

        public double Multiply(double x, double y)
        {
            return x * y;
        }

        public double Divide(double x, double y)
        {
            return x / y;
        }

        public double Mod(double x, double y)
        {
            return x % y;
        }

        #endregion
    }

}
