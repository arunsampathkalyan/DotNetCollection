﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Client.EvalServiceReference;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {

            EvalServiceClient client =
                new EvalServiceClient("NetTcpBinding_IEvalService");

            DetailedEval eval = new DetailedEval();
            eval.from = "Bob";
            eval.when = DateTime.Now;
            eval.what = null;
            eval.additional = "More comments from client.";

            client.SubmitEval(eval);

            List<evaluation> evals = client.GetEvals();
            Console.WriteLine("Eval from {0} says: {1}",
                evals[0].from, evals[0].what);
        }
    }
}
