﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EvalServiceLibrary;
using System.IO;
using System.Runtime.Serialization;

namespace Serialization
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0 && args[0].Equals("-d"))
                Deserialize();
            else
                Serialize();
        }

        static void Serialize()
        {
            DetailedEval eval = new DetailedEval();
            eval.Submitter = "Aaron";
            eval.Timesent = DateTime.Now;
            //eval.Comments = "Serialization is magic!";
            eval.AdditionalComments = "I say again -- it's magic!";
            eval.Questions = new List<QuestionRating>();

            QuestionRating qr = new QuestionRating();
            qr.QuestionText = "How do you like the features?";
            qr.Rating = 5;

            eval.Questions.Add(qr);
            eval.Questions.Add(qr);
            eval.Questions.Add(qr);

            using (FileStream fs = new FileStream("eval.xml", FileMode.Create))
            {
                DataContractSerializer dcs =
                    new DataContractSerializer(typeof(Eval));
                dcs.WriteObject(fs, eval);
            }
        }

        static void Deserialize()
        {
            using (FileStream fs = new FileStream("eval.xml", FileMode.Open))
            {
                DataContractSerializer dcs =
                    new DataContractSerializer(typeof(Eval));
                Eval eval = dcs.ReadObject(fs) as Eval;
                Console.WriteLine("Eval from {0} -- he says: {1}",
                    eval.Submitter, eval.Comments);
                if (eval is DetailedEval)
                {
                    DetailedEval de = eval as DetailedEval;
                    Console.WriteLine("He said more: {0}",
                        de.AdditionalComments);
                }
            }

        }
    }
}
