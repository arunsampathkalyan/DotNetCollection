﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Data;

namespace EvalServiceLibrary
{
    [KnownType(typeof(DetailedEval))]
    [DataContract(Name="evaluation", Namespace="http://pluralsight.com/evals")]
    public class Eval
    {
        [DataMember(IsRequired=true, Name="from")]
        public string Submitter;
        [DataMember(Name="when")]
        public Nullable<DateTime> Timesent;
        [DataMember(EmitDefaultValue=false, Name="what")]
        public string Comments;

        [OnDeserialized]
        private void Fixup(StreamingContext ctx)
        {
            if (this.Comments == null)
                this.Comments = "My default comment...";
        }
    }

    [DataContract(Namespace="http://pluralsight.com/evals")]
    public class DetailedEval : Eval
    {
        [DataMember(Name="additional")]
        public string AdditionalComments;
        [DataMember]
        public List<QuestionRating> Questions;
    }

    [DataContract(Namespace = "http://pluralsight.com/evals")]
    public class QuestionRating
    {
        [DataMember]
        public string QuestionText;
        [DataMember]
        public int Rating;
    }
}
