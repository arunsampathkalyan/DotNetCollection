﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace EvalServiceLibrary
{
    public class MyErrorHandler : IErrorHandler
    {
        #region IErrorHandler Members

        public bool HandleError(Exception error)
        {
            Console.WriteLine("*** IErrorHandler.HandleError was called. ***");
            Console.WriteLine(error.Message);
            return true;
        }

        public void ProvideFault(Exception error, System.ServiceModel.Channels.MessageVersion version, ref System.ServiceModel.Channels.Message fault)
        {
            fault = Message.CreateMessage(version,
                FaultCode.CreateSenderFaultCode(
                    "BadEvalSubmission", "http://pluralsight.com/evals"),
                "Bad eval submitted (IErrorHandler)",
                new BadEvalSubmission(),
                "http://tempuri.org/IEvalService/SubmitEvalBadEvalSubmissionFault");

        }

        #endregion
    }

    public class MyErrorHandlerAttribute : Attribute, IServiceBehavior
    {
        #region IServiceBehavior Members

        public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, System.Collections.ObjectModel.Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
        {
        }

        public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
            foreach (ChannelDispatcher cd in serviceHostBase.ChannelDispatchers)
                cd.ErrorHandlers.Add(new MyErrorHandler());
        }

        public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
        {
        }

        #endregion
    }

}
