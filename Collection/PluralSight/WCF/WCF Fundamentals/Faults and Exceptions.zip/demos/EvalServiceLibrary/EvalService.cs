﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Syndication;

namespace EvalServiceLibrary
{
    [DataContract(Namespace="http://pluralsight.com/evals")]
    public class Eval
    {
        [DataMember]
        public string Id;
        [DataMember]
        public string Submitter;
        [DataMember]
        public DateTime Timesent;
        [DataMember]
        public string Comments;
    }

    [DataContract(Namespace = "http://pluralsight.com/evals")]
    public class BadEvalSubmission
    {
        [DataMember]
        public string Problem;
    }

    [ServiceContract]
    public interface IEvalService
    {
        [FaultContract(typeof(BadEvalSubmission))]
        [OperationContract]
        void SubmitEval(Eval eval);

        [OperationContract]
        Eval GetEval(string id);

        [OperationContract]
        List<Eval> GetAllEvals();

        [OperationContract]
        List<Eval> GetEvalsBySubmitter(string submitter);

        [OperationContract]
        void RemoveEval(string id);
    }

    //[MyErrorHandler]
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
        //, IncludeExceptionDetailInFaults=true)]
    public class EvalService : IEvalService
    {
        List<Eval> evals = new List<Eval>();
        int evalCount = 0;

        #region IEvalService Members

        public void SubmitEval(Eval eval)
        {
            if (eval.Submitter.Equals("throw1"))
                throw new Exception("something bad happened");
            else if (eval.Submitter.Equals("throw2"))
                throw new FaultException("something bad happened",
                    FaultCode.CreateSenderFaultCode("BadEvalSubmission", "http://pluralsight.com/evals"));
            else if (eval.Submitter.Equals("throw3"))
                throw new FaultException<BadEvalSubmission>(
                    new BadEvalSubmission(), "something bad happened");

            eval.Id = (++evalCount).ToString();
            evals.Add(eval);
        }

        public Eval GetEval(string id)
        {
            return evals.First(e => e.Id.Equals(id));
        }

        public List<Eval> GetAllEvals()
        {
            return this.GetEvalsBySubmitter(null);
        }

        public List<Eval> GetEvalsBySubmitter(string submitter)
        {
            if (submitter == null || submitter.Equals(""))
                return evals;
            else
                return evals.Where(e => e.Submitter.ToLower().Equals(submitter.ToLower())).ToList<Eval>();
        }

        public void RemoveEval(string id)
        {
            evals.RemoveAll(e => e.Id.Equals(id));
        }

        #endregion
    }
}
