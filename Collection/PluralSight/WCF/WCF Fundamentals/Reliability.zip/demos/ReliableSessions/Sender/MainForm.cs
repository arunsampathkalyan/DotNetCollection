using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Sender
{
	public partial class MainForm : Form
	{
		private const int maximumMessageSize = 65000;
		int numberOfChunks = 10;
		
		private ImageChunkSender sender = null;
		private Image imageToSend = null;
		private bool continueSending = false;
		private ImageChunk[][] chunks = null;
		private bool chunked = false;
		private int imageSize = 0;
		
		public MainForm()
		{
			InitializeComponent();
		}

		private void OpenButtonClickEventHandler(object sender, EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();
			openFileDialog.Filter = "JPG files (*.jpg)|*.jpg|All files (*.*)|*.*";
			openFileDialog.FilterIndex = 1;
			openFileDialog.RestoreDirectory = true;

			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				// Sets up an image object to be displayed.
				if (imageToSend != null)
				{
					imageToSend.Dispose();
				}

				this.chunked = false;

				// Stretches the image to fit the pictureBox.
				this.Picture.SizeMode = PictureBoxSizeMode.StretchImage;
				this.imageToSend = new Bitmap(openFileDialog.FileName);

				FileInfo fileInformation = new FileInfo(openFileDialog.FileName);
				this.imageSize = (int)fileInformation.Length;

				this.Picture.Image = (Image)imageToSend.Clone();

				this.ChunkTimer.Enabled = true;

				this.SendButton.Enabled = true;
			}
		}

		private void SendButtonClickEventHandler(object sender, EventArgs e)
		{
			this.SendButton.Enabled = false;
			this.Progress.Value = 0;

			if (!this.sender.Opened)
			{
				this.sender.Open();
			}

			this.continueSending = true;
			this.Send();

			SendButton.Enabled = true;
		}

		private void Send()
		{
			while (!(this.chunked))
			{
			}

			for (int row = 0; row < numberOfChunks; row++)
			{
				for (int column = 0; column < numberOfChunks; column++)
				{
					if (!(continueSending))
					{
						break;
					}
					
					this.sender.TransferImageRectangle(this.chunks[row][column]);

					Progress.Value += 1;
					Progress.Invalidate();

					
				}
				if (!(continueSending))
				{
					break;
				}

				
			}

			this.ProgressTimer.Enabled = true;
		}

		private void ChunkTimer_Tick(object sender, EventArgs e)
		{

			this.sender = new ImageChunkSender(numberOfChunks);

			this.ChunkTimer.Enabled = false;

			this.chunks = new ImageChunk[numberOfChunks][];

			int imageWidth;
			int imageHeight = this.Picture.Height / numberOfChunks;
			int imageX;
			int imageY = 0;

			int chunkWidth;
			int chunkHeight = imageToSend.Height / numberOfChunks;
			int chunkX;
			int chunkY = 0;

			this.sender.ResetChunkCount();

			for (int row = 0; row < numberOfChunks; row++)
			{
				this.chunks[row] = new ImageChunk[numberOfChunks];

				imageWidth = this.Picture.Width / numberOfChunks;
				imageX = 0;
				chunkWidth = imageToSend.Width / numberOfChunks;
				chunkX = 0;

				for (int column = 0; column < numberOfChunks; column++)
				{
					Bitmap chunkToSend = new Bitmap(imageToSend.Width / (numberOfChunks * 1), imageToSend.Height / (numberOfChunks * 1));
					Graphics chunk = Graphics.FromImage(chunkToSend);
					chunk.DrawImage(imageToSend, new Rectangle(0, 0, chunkWidth, chunkHeight), new Rectangle(chunkX, chunkY, chunkWidth, chunkHeight), GraphicsUnit.Pixel);
					chunk.Dispose();

					byte[] chunkBytes = new byte[chunkWidth * chunkHeight * 8];
					MemoryStream memoryStream = new MemoryStream(chunkBytes, true);
					chunkToSend.Save(memoryStream, ImageFormat.Jpeg);
					chunkToSend.Dispose();

					this.chunks[row][column] = new ImageChunk(numberOfChunks,chunkX, chunkY, chunkWidth, chunkHeight, chunkBytes);
					
					memoryStream.Close();

					imageX += imageWidth;
					if ((imageX + (imageWidth * 2)) > this.Picture.Width)
					{
						imageWidth = this.Picture.Width - imageX;
					}
					chunkX += chunkWidth;
					if ((chunkX + (chunkWidth * 2)) > imageToSend.Width)
					{
						chunkWidth = imageToSend.Width - chunkX;
					}
				}
				

				imageY += imageHeight;
				if (((imageY + imageHeight * 2)) > this.Picture.Height)
				{
					imageHeight = this.Picture.Height - imageY;
				}
				chunkY += chunkHeight;
				if ((chunkY + (chunkHeight * 2)) > imageToSend.Height)
				{
					chunkHeight = imageToSend.Height - chunkY;
				}
			}

			this.chunked = true;
		}

		private void ProgressTimer_Tick(object sender, EventArgs e)
		{
			this.ProgressTimer.Enabled = false;

			this.Progress.Value = 0;
			this.Progress.Invalidate();
		}

		


	}
}