namespace Sender
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.OpenButton = new System.Windows.Forms.Button();
			this.Progress = new System.Windows.Forms.ProgressBar();
			this.SendButton = new System.Windows.Forms.Button();
			this.Picture = new System.Windows.Forms.PictureBox();
			this.ChunkTimer = new System.Windows.Forms.Timer(this.components);
			this.ProgressTimer = new System.Windows.Forms.Timer(this.components);
			((System.ComponentModel.ISupportInitialize)(this.Picture)).BeginInit();
			this.SuspendLayout();
			// 
			// OpenButton
			// 
			this.OpenButton.Location = new System.Drawing.Point(62, 565);
			this.OpenButton.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.OpenButton.Name = "OpenButton";
			this.OpenButton.Size = new System.Drawing.Size(115, 63);
			this.OpenButton.TabIndex = 14;
			this.OpenButton.Text = "Open...";
			this.OpenButton.Click += new System.EventHandler(this.OpenButtonClickEventHandler);
			// 
			// Progress
			// 
			this.Progress.Location = new System.Drawing.Point(62, 648);
			this.Progress.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.Progress.Name = "Progress";
			this.Progress.Size = new System.Drawing.Size(344, 29);
			this.Progress.Step = 1;
			this.Progress.TabIndex = 13;
			// 
			// SendButton
			// 
			this.SendButton.Enabled = false;
			this.SendButton.Location = new System.Drawing.Point(291, 565);
			this.SendButton.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.SendButton.Name = "SendButton";
			this.SendButton.Size = new System.Drawing.Size(115, 63);
			this.SendButton.TabIndex = 12;
			this.SendButton.Text = "&Send";
			this.SendButton.Click += new System.EventHandler(this.SendButtonClickEventHandler);
			// 
			// Picture
			// 
			this.Picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Picture.Location = new System.Drawing.Point(62, 29);
			this.Picture.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.Picture.Name = "Picture";
			this.Picture.Size = new System.Drawing.Size(344, 517);
			this.Picture.TabIndex = 11;
			this.Picture.TabStop = false;
			// 
			// ChunkTimer
			// 
			this.ChunkTimer.Tick += new System.EventHandler(this.ChunkTimer_Tick);
			// 
			// ProgressTimer
			// 
			this.ProgressTimer.Interval = 5000;
			this.ProgressTimer.Tick += new System.EventHandler(this.ProgressTimer_Tick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(468, 708);
			this.Controls.Add(this.OpenButton);
			this.Controls.Add(this.Progress);
			this.Controls.Add(this.SendButton);
			this.Controls.Add(this.Picture);
			this.Font = new System.Drawing.Font("Lucida Console", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Sender";
			((System.ComponentModel.ISupportInitialize)(this.Picture)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button OpenButton;
		private System.Windows.Forms.ProgressBar Progress;
		private System.Windows.Forms.Button SendButton;
		private System.Windows.Forms.PictureBox Picture;
		private System.Windows.Forms.Timer ChunkTimer;
		private System.Windows.Forms.Timer ProgressTimer;
	}
}

