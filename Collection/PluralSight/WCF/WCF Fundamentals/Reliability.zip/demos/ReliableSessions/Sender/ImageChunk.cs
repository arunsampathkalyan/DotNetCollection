using System;
using System.Collections.Generic;
using System.Text;

namespace Sender
{
	public class ImageChunk
	{
		private int numberOfChunks;
		private int x;
		private int y;
		private int width;
		private int height;
		private byte[] content;

		public int NumberOfChunks
		{
			get
			{
				return this.numberOfChunks;
			}
		}

		public int X
		{
			get
			{
				return this.x;
			}
		}

		public int Y
		{
			get
			{
				return this.y;
			}
		}

		public int Width
		{
			get
			{
				return this.width;
			}
		}

		public int Height
		{
			get
			{
				return this.height;
			}
		}

		public byte[] Content
		{
			get
			{
				return this.content;
			}
		}

		private ImageChunk()
		{
		}

		public ImageChunk(int numberOfChunks, int x, int y, int width, int height, byte[] content)
		{
			this.numberOfChunks = numberOfChunks;
			this.x = x;
			this.y = y;
			this.width = width;
			this.height = height;
			this.content = content;
		}
	}
}
