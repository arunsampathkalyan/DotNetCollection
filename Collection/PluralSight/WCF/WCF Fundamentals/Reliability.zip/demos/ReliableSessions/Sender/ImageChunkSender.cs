using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.ServiceModel.Channels;


namespace Sender
{
	public class ImageChunkSender
	{
		IImageTransfer proxy;
		IChannel channel;
		bool opened = false;
		ContextCallback callback = null;
		int chunksSent;

		public ImageChunkSender(int numberOfChunks)
		{
			this.callback = new ContextCallback(this.DoTransfer);
		}

		public void ResetChunkCount()
		{
			chunksSent = 0;
		}

		public int ChunksSent
		{
			get 
			{
				return this.chunksSent;
			}
		}

		public void Close()
		{
			if (channel != null)
			{
				opened = false;
				try
				{
					channel.Close();
				}
				catch (Exception)
				{
					// Do nothing
				}
				finally
				{
					channel.Close();
				}
			}
		}

		public void Abort()
		{
			if (channel != null)
			{
				opened = false;
				try
				{
					channel.Abort();
				}
				catch (Exception)
				{
					// Do nothing
				}
				finally
				{
					channel.Close();
					channel = null;
				}
			}
		}

		public void Open()
		{
			proxy = new ChannelFactory<IImageTransfer>("Destination").CreateChannel();
			channel = ((IChannel)proxy);
			channel.Open();
			opened = true;
		}

		public bool Opened 
		{ 
			get 
			{ 
				return opened; 
			} 
		}

		public void TransferImageRectangle(ImageChunk chunk)
		{
			ExecutionContext context = ExecutionContext.Capture();
			ExecutionContext.Run(context, this.callback, chunk);
		}

		private void DoTransfer(object state)
		{
			ImageChunk chunk = state as ImageChunk;
			proxy.TransferImageRectangle(chunk.NumberOfChunks,chunk.X, chunk.Y, chunk.Width, chunk.Height, chunk.Content);
			chunksSent++;
		}

		
	}
}
