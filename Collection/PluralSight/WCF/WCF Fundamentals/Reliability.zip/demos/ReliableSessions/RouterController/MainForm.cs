using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;


namespace Router
{
    [ServiceContract]
    public interface IBridge
    {
        [OperationContract]
        int GetDropRate();
        [OperationContract]
        void ReportReceivedCount();
        [OperationContract]
        void ReportDroppedCount();
        [OperationContract]
        void ReportForwardedCount();
    }

    [ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)]
    public class Bridge: IBridge
    {
        private MainForm form = null;
        private int dropRate = 0;

        public Bridge(MainForm form)
        {
            this.form = form;
        }

        public int DropRate
        {
            set
            {
                this.dropRate = value;
            }
        }

        #region IBridge Members

        int IBridge.GetDropRate()
        {
            this.form.UpdateReceived();
            return this.dropRate;
        }

        void IBridge.ReportReceivedCount()
        {
            this.form.UpdateReceived();
        }

        void IBridge.ReportDroppedCount()
        {
            this.form.UpdateDropped();
        }

        void IBridge.ReportForwardedCount()
        {
            this.form.UpdateForwarded();
        }

        #endregion
    }

	public partial class MainForm : Form
	{
        Bridge bridge = null;
        int dropped = 0;
        int forwarded = 0;
        int received = 0;
		
		public MainForm()
		{
			InitializeComponent();
		}

        public void UpdateDropped()
        {
            this.dropped++;
            this.DroppedMessageCountLabel.Text = this.dropped.ToString();
        }

        public void UpdateReceived()
        {
            this.received++;
            this.ReceivedMessageCountLabel.Text = this.received.ToString();
        }

        public void UpdateForwarded()
        {
            this.forwarded++;
            this.RoutedMessageCountLabel.Text = this.forwarded.ToString();
        }
        

		private void trackBar1_Scroll(object sender, EventArgs e)
		{
			if (lossBar.Value == 0)
			{
				lblPercentToDrop.Text = "Not dropping any messages";
			}
			else
			{
				lblPercentToDrop.Text = string.Format("Dropping about {0}% of messages.",lossBar.Value.ToString());
			}
			this.bridge.DropRate = lossBar.Value;
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
            this.bridge = new Bridge(this);
            ServiceHost service = new ServiceHost(this.bridge);
            service.Open();
			//ServiceHost<Intermediary> service = new ServiceHost<Intermediary>((Intermediary)this.router, new Uri[] { new Uri(ConfigurationManager.AppSettings["ServiceAddress"]) });
			//service.Open();
			//string routerAddress = ConfigurationManager.AppSettings["RouterAddress"]; //= "http://localhost/task-scheduler/";
			//string serviceAddress = ConfigurationManager.AppSettings["ServiceAddress"];

			//this.router = new Intermediary(serviceAddress);

			//ServiceHost service = new ServiceHost(this.router, new Uri(routerAddress));
			//service.Open();

			
		}

		private void UpdateTimer_Tick(object sender, EventArgs e)
		{
			//this.RoutedMessageCountLabel.Text = this.router.SentMessages.ToString();
			//this.DroppedMessageCountLabel.Text = this.router.DroppedMessages.ToString();
			//this.ReceivedMessageCountLabel.Text = this.router.ReceivedMessages.ToString();
		}

		private void ClearButton_Click(object sender, EventArgs e)
		{
            this.dropped = -1;
            this.forwarded = -1;
            this.received = -1;
            this.UpdateDropped();
            this.UpdateForwarded();
            this.UpdateReceived();
			//this.router.ResetStatistics();
		}

		private void CloseButton_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		
	}
}