namespace Router
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.ClearButton = new System.Windows.Forms.Button();
			this.lblPercentToDrop = new System.Windows.Forms.Label();
			this.CloseButton = new System.Windows.Forms.Button();
			this.label5 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.DroppedMessageCountLabel = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.RoutedMessageCountLabel = new System.Windows.Forms.Label();
			this.lossBar = new System.Windows.Forms.TrackBar();
			this.UpdateTimer = new System.Windows.Forms.Timer(this.components);
			this.label1 = new System.Windows.Forms.Label();
			this.ReceivedMessageCountLabel = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.lossBar)).BeginInit();
			this.SuspendLayout();
			// 
			// ClearButton
			// 
			this.ClearButton.Location = new System.Drawing.Point(18, 323);
			this.ClearButton.Margin = new System.Windows.Forms.Padding(13, 9, 13, 9);
			this.ClearButton.Name = "ClearButton";
			this.ClearButton.Size = new System.Drawing.Size(91, 64);
			this.ClearButton.TabIndex = 21;
			this.ClearButton.Text = "C&lear";
			this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
			// 
			// lblPercentToDrop
			// 
			this.lblPercentToDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPercentToDrop.Location = new System.Drawing.Point(30, 111);
			this.lblPercentToDrop.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.lblPercentToDrop.Name = "lblPercentToDrop";
			this.lblPercentToDrop.Size = new System.Drawing.Size(220, 60);
			this.lblPercentToDrop.TabIndex = 20;
			this.lblPercentToDrop.Text = "Not dropping messages";
			this.lblPercentToDrop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// CloseButton
			// 
			this.CloseButton.Location = new System.Drawing.Point(171, 321);
			this.CloseButton.Margin = new System.Windows.Forms.Padding(13, 9, 13, 9);
			this.CloseButton.Name = "CloseButton";
			this.CloseButton.Size = new System.Drawing.Size(91, 64);
			this.CloseButton.TabIndex = 19;
			this.CloseButton.Text = "&Close";
			this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.Location = new System.Drawing.Point(30, 13);
			this.label5.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(220, 24);
			this.label5.TabIndex = 18;
			this.label5.Text = "Network Message Loss";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(29, 259);
			this.label3.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(98, 21);
			this.label3.TabIndex = 17;
			this.label3.Text = "Dropped";
			// 
			// DroppedMessageCountLabel
			// 
			this.DroppedMessageCountLabel.AutoSize = true;
			this.DroppedMessageCountLabel.Location = new System.Drawing.Point(232, 259);
			this.DroppedMessageCountLabel.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.DroppedMessageCountLabel.Name = "DroppedMessageCountLabel";
			this.DroppedMessageCountLabel.Size = new System.Drawing.Size(20, 21);
			this.DroppedMessageCountLabel.TabIndex = 16;
			this.DroppedMessageCountLabel.Text = "0";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(29, 221);
			this.label2.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(189, 21);
			this.label2.TabIndex = 15;
			this.label2.Text = "Routed forward";
			// 
			// RoutedMessageCountLabel
			// 
			this.RoutedMessageCountLabel.AutoSize = true;
			this.RoutedMessageCountLabel.Location = new System.Drawing.Point(232, 221);
			this.RoutedMessageCountLabel.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.RoutedMessageCountLabel.Name = "RoutedMessageCountLabel";
			this.RoutedMessageCountLabel.Size = new System.Drawing.Size(20, 21);
			this.RoutedMessageCountLabel.TabIndex = 14;
			this.RoutedMessageCountLabel.Text = "0";
			// 
			// lossBar
			// 
			this.lossBar.LargeChange = 1;
			this.lossBar.Location = new System.Drawing.Point(42, 61);
			this.lossBar.Margin = new System.Windows.Forms.Padding(13, 9, 13, 9);
			this.lossBar.Name = "lossBar";
			this.lossBar.Size = new System.Drawing.Size(197, 45);
			this.lossBar.TabIndex = 13;
			this.lossBar.Scroll += new System.EventHandler(this.trackBar1_Scroll);
			// 
			// UpdateTimer
			// 
			this.UpdateTimer.Enabled = true;
			this.UpdateTimer.Tick += new System.EventHandler(this.UpdateTimer_Tick);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(29, 183);
			this.label1.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(111, 21);
			this.label1.TabIndex = 23;
			this.label1.Text = "Received";
			// 
			// ReceivedMessageCountLabel
			// 
			this.ReceivedMessageCountLabel.AutoSize = true;
			this.ReceivedMessageCountLabel.Location = new System.Drawing.Point(232, 183);
			this.ReceivedMessageCountLabel.Margin = new System.Windows.Forms.Padding(13, 0, 13, 0);
			this.ReceivedMessageCountLabel.Name = "ReceivedMessageCountLabel";
			this.ReceivedMessageCountLabel.Size = new System.Drawing.Size(20, 21);
			this.ReceivedMessageCountLabel.TabIndex = 22;
			this.ReceivedMessageCountLabel.Text = "0";
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(280, 432);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.ReceivedMessageCountLabel);
			this.Controls.Add(this.ClearButton);
			this.Controls.Add(this.lblPercentToDrop);
			this.Controls.Add(this.CloseButton);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.DroppedMessageCountLabel);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.RoutedMessageCountLabel);
			this.Controls.Add(this.lossBar);
			this.Font = new System.Drawing.Font("Lucida Console", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Margin = new System.Windows.Forms.Padding(7, 5, 7, 5);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Router";
			this.Load += new System.EventHandler(this.MainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.lossBar)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button ClearButton;
		private System.Windows.Forms.Label lblPercentToDrop;
		private System.Windows.Forms.Button CloseButton;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label DroppedMessageCountLabel;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label RoutedMessageCountLabel;
		private System.Windows.Forms.TrackBar lossBar;
		private System.Windows.Forms.Timer UpdateTimer;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label ReceivedMessageCountLabel;
	}
}

