// ----------------------------------------------------------------------------
// Copyright (C) 2003-2005 Microsoft Corporation, All rights reserved.
// ----------------------------------------------------------------------------
namespace Router
{
    using System;
    using System.ServiceModel;

    [ServiceContract]
    public interface IBridge
    {
        [OperationContract]
        int GetDropRate();
        [OperationContract]
        void ReportReceivedCount();
        [OperationContract]
        void ReportDroppedCount();
        [OperationContract]
        void ReportForwardedCount();
    }

    public class Bridge : IBridge
    {

        #region IBridge Members

        int IBridge.GetDropRate()
        {
            return 0;
        }

        void IBridge.ReportReceivedCount()
        {

        }

        void IBridge.ReportDroppedCount()
        {

        }

        void IBridge.ReportForwardedCount()
        {

        }

        #endregion
    }
}
namespace Microsoft.ServiceModel.Samples
{
    using System;
	using System.ServiceModel.Dispatcher;
	using System.ServiceModel.Description;
    using System.ServiceModel;
    using System.ServiceModel.Channels;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Configuration;

    class SoapRouterExtension : IExtension<ServiceHostBase>
    {
        IDictionary<string, Binding> bindings = new Dictionary<string, Binding>(3);

        IDictionary<EndpointAddress, ISimplexDatagramRouter> simplexDatagramChannels = new Dictionary<EndpointAddress, ISimplexDatagramRouter>();
        IDictionary<EndpointAddress, IRequestReplyDatagramRouter> requestReplyDatagramChannels = new Dictionary<EndpointAddress, IRequestReplyDatagramRouter>();

        RoutingTable routingTable = new RoutingTable();
        object configurationLock = new object();

        public SoapRouterExtension()
        {
            this.bindings.Add("http", new RouterBinding(RouterTransport.Http));
            this.bindings.Add("net.tcp", new RouterBinding(RouterTransport.Tcp));
            this.bindings.Add("net.pipe", new RouterBinding(RouterTransport.NamedPipe));
        }

        public IDictionary<string, Binding> Bindings
        {
            get { return this.bindings; }
        }

        public IDictionary<EndpointAddress, ISimplexDatagramRouter> SimplexDatagramChannels
        {
            get { return this.simplexDatagramChannels; }
        }

        public IDictionary<EndpointAddress, IRequestReplyDatagramRouter> RequestReplyDatagramChannels
        {
            get { return this.requestReplyDatagramChannels; }
        }

        public RoutingTable RoutingTable
        {
            get { return this.routingTable; }
        }

        public object ConfigurationLock
        {
            get { return this.configurationLock; }
        }

        public void Attach(ServiceHostBase owner)
        { }

        public void Detach(ServiceHostBase owner)
        { }
    }

    class SoapRouterServiceBehavior : Attribute, IServiceBehavior
    {

        void IServiceBehavior.Validate(ServiceDescription description, ServiceHostBase serviceHostBase)
        {
        }

        void IServiceBehavior.AddBindingParameters(ServiceDescription description, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection parameters)
        {
        }

        void IServiceBehavior.ApplyDispatchBehavior(ServiceDescription description, ServiceHostBase serviceHostBase)
        {
            SoapRouterExtension extension = new SoapRouterExtension();
            serviceHostBase.Extensions.Add(extension);
        }
    }

    [SoapRouterServiceBehavior]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Multiple, ValidateMustUnderstand = false)]
    public sealed class SoapRouter : ISimplexDatagramRouter, ISimplexSessionRouter, IRequestReplyDatagramRouter, IDuplexSessionRouter, IDisposable
    {
        Random randomizer = null;
        SoapRouterExtension extension;
        object sessionSyncRoot = new object();

        ISimplexSessionRouter simplexSessionChannel;
        IDuplexSessionRouter duplexSessionChannel;

        public SoapRouter()
        {
            this.randomizer = new Random(100);
            ServiceHostBase host = OperationContext.Current.Host;
            this.extension = host.Extensions.Find<SoapRouterExtension>();
        }

        #region SoapIntermediary Simplex Datagram
        void ISimplexDatagramRouter.ProcessMessage(Message message)
        {
            EndpointAddress to = this.extension.RoutingTable.SelectDestination(message);
            if (to == null)
            {
                message.Close();
                return;
            }

            // If the router doesn't already have a one-way datagram channel to the 'to' EPR or if that channel is no longer opened, create one.
            ISimplexDatagramRouter forwardingChannel;
            if (!this.extension.SimplexDatagramChannels.TryGetValue(to, out forwardingChannel) || ((IClientChannel)forwardingChannel).State != CommunicationState.Opened)
            {
                lock (this.extension.SimplexDatagramChannels)
                {
                    if (!this.extension.SimplexDatagramChannels.TryGetValue(to, out forwardingChannel) || ((IClientChannel)forwardingChannel).State != CommunicationState.Opened)
                    {
                        forwardingChannel = new ChannelFactory<ISimplexDatagramRouter>(this.extension.Bindings[to.Uri.Scheme], to).CreateChannel();
                        this.extension.SimplexDatagramChannels.Add(to, forwardingChannel);
                    }
                }
            }

            message.Properties[HttpRequestMessageProperty.Name] = null;
            message.Properties.Via = null;

            Console.WriteLine("Forwarding message " + message.Headers.Action + "...");
            forwardingChannel.ProcessMessage(message);
        }
        #endregion

        #region SoapIntermediary Request-Reply Datagram
        Message IRequestReplyDatagramRouter.ProcessMessage(Message message)
        {
            EndpointAddress to = this.extension.RoutingTable.SelectDestination(message);
            if (to == null)
            {
                message.Close();
                return null;
            }

            // If the router doesn't already have a two-way datagram channel to the 'to' EPR or if that channel is no longer opened, create one.
            IRequestReplyDatagramRouter forwardingChannel;
            if (!this.extension.RequestReplyDatagramChannels.TryGetValue(to, out forwardingChannel) || ((IClientChannel)forwardingChannel).State != CommunicationState.Opened)
            {
                lock (this.extension.RequestReplyDatagramChannels)
                {
                    if (!this.extension.RequestReplyDatagramChannels.TryGetValue(to, out forwardingChannel) || ((IClientChannel)forwardingChannel).State != CommunicationState.Opened)
                    {
                        ChannelFactory<IRequestReplyDatagramRouter> factory = new ChannelFactory<IRequestReplyDatagramRouter>(this.extension.Bindings[to.Uri.Scheme], to);
                        // Add a channel behavior that will turn off validation of @mustUnderstand on the reply's headers.
                        factory.Endpoint.Behaviors.Add(new MustUnderstandBehavior(false));
                        forwardingChannel = factory.CreateChannel();

                        this.extension.RequestReplyDatagramChannels.Add(to, forwardingChannel);
                    }
                }
            }

            message.Properties[HttpRequestMessageProperty.Name] = null;
            message.Properties.Via = null;

            Console.WriteLine("Forwarding request " + message.Headers.Action + "...");
            Message response = forwardingChannel.ProcessMessage(message);

            Console.WriteLine("Forwarding response " + response.Headers.Action + "...");
            return response;
        }
        #endregion

        #region SoapIntermediary Simplex Session
        void ISimplexSessionRouter.ProcessMessage(Message message)
        {
            // One router service instance exists for each sessionful channel. If a channel hasn't been created yet, create one.
            if (this.simplexSessionChannel == null)
            {
                lock (this.sessionSyncRoot)
                {
                    if (this.simplexSessionChannel == null)
                    {
                        EndpointAddress forwardingAddress = this.extension.RoutingTable.SelectDestination(message);
                        if (forwardingAddress == null)
                        {
                            message.Close();
                            return;
                        }

                        // Don't register the forwarding channel with the service instance. That way, the service instance can get disposed when the incoming channel closes, and then dispose of the forwarding channel.
                        using (OperationContextScope scope = new OperationContextScope((OperationContext)null))
                        {
                            this.simplexSessionChannel = new ChannelFactory<ISimplexSessionRouter>(this.extension.Bindings[forwardingAddress.Uri.Scheme], forwardingAddress).CreateChannel();
                        }
                    }
                }
            }

            message.Properties.Via = null;

            Console.WriteLine("Forwarding message " + message.Headers.Action + "...");
            this.simplexSessionChannel.ProcessMessage(message);
        }
        #endregion

        #region SoapIntermediary Duplex Session
        void IDuplexSessionRouter.ProcessMessage(Message message)
        {
            Router.IBridge bridge = new ChannelFactory<Router.IBridge>("Bridge").CreateChannel();
                      try
                      {
                          int dropRate = 0;
                          try
                          {
                              dropRate = bridge.GetDropRate();

                          }
                          catch (Exception)
                          {
                              dropRate = 0;
                          }
                          if (this.randomizer.Next(100) < dropRate)
                          {
                              message.Close();
                              try
                              {
                                  bridge.ReportDroppedCount();
                              }
                              catch (Exception)
                              {
                              }
                              return;
                          }
            // One router service instance exists for each sessionful channel. If a channel hasn't been created yet, create one.
            if (this.duplexSessionChannel == null)
            {
                lock (this.sessionSyncRoot)
                {
                    if (this.duplexSessionChannel == null)
                    {
                        EndpointAddress forwardingAddress = this.extension.RoutingTable.SelectDestination(message);
                        if (forwardingAddress == null)
                        {
                            message.Close();
                            return;
                        }

                        ISimplexSessionRouter callbackChannel = OperationContext.Current.GetCallbackChannel<ISimplexSessionRouter>();
                        // Don't register the forwarding channel with the service instance. That way, the service instance can get disposed when the incoming channel closes, and then dispose of the forwarding channel.
                        using (new OperationContextScope((OperationContext)null))
                        {
                            ChannelFactory<IDuplexSessionRouter> factory = new DuplexChannelFactory<IDuplexSessionRouter>(new InstanceContext(null, new ReturnMessageHandler(callbackChannel)),this.extension.Bindings[forwardingAddress.Uri.Scheme], forwardingAddress);
                            // Add a channel behavior that will turn off validation of @mustUnderstand on the headers belonging to messages flowing the opposite direction.
                            factory.Endpoint.Behaviors.Add(new MustUnderstandBehavior(false));
                            this.duplexSessionChannel = factory.CreateChannel();
                        }
                    }
                    
                }
            }}
                      finally
                      {
                          ((IChannel)bridge).Close();
                      }
            

            message.Properties.Via = null;

            Console.WriteLine("Forwarding message " + message.Headers.Action + "...");
            this.duplexSessionChannel.ProcessMessage(message);
        }

        class ReturnMessageHandler : ISimplexSessionRouter
        {
            ISimplexSessionRouter returnChannel;

            public ReturnMessageHandler(ISimplexSessionRouter returnChannel)
            {
                this.returnChannel = returnChannel;
            }

            void ISimplexSessionRouter.ProcessMessage(Message message)
            {
                message.Properties.Via = null;

                Console.WriteLine("Forwarding return message " + message.Headers.Action + "...");
                this.returnChannel.ProcessMessage(message);
            }
        }
        #endregion

        void IDisposable.Dispose()
        {
            IClientChannel channel = null;

            if (this.simplexSessionChannel != null)
            {
                channel = (IClientChannel)this.simplexSessionChannel;
            }
            else if (this.duplexSessionChannel != null)
            {
                channel = (IClientChannel)this.duplexSessionChannel;
            }

            if (channel != null && channel.State != CommunicationState.Closed)
            {
                try
                {
                    channel.Close();
                }
                catch
                {
                    channel.Abort();
                    throw;
                }
            }
        }
    }

    public class ServiceDriver
    {
        public static void Main(string[] args)
        {
            ServiceHost serviceHost = new ServiceHost(typeof(SoapRouter), new Uri(ConfigurationManager.AppSettings["httpBaseAddress"]), new Uri(ConfigurationManager.AppSettings["tcpBaseAddress"]));
            serviceHost.Open();

            for (int i=0; i<serviceHost.ChannelDispatchers.Count; ++i)
            {
                ChannelDispatcher channelDispatcher = serviceHost.ChannelDispatchers[i] as ChannelDispatcher;
                if (channelDispatcher != null)
                {
                    for (int j=0; j<channelDispatcher.Endpoints.Count; ++j)
                    {
                        EndpointDispatcher endpointDispatcher = channelDispatcher.Endpoints[j];
                        Console.WriteLine("Listening on " + endpointDispatcher.EndpointAddress + "...");
                    }
                }
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }
    }
}
