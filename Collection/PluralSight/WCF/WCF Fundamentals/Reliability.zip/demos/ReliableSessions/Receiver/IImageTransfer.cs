using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace Receiver
{
	[ServiceContract(SessionMode=SessionMode.Allowed)]
	public interface IImageTransfer
	{
		[OperationContract(IsOneWay = true)]
		void TransferImageRectangle(int numberOfChunks, int x, int y, int width, int height, byte[] bytes);
	}
}
