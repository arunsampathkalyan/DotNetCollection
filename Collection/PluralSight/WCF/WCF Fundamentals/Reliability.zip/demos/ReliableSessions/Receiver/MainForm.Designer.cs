namespace Receiver
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.ClearButton = new System.Windows.Forms.Button();
			this.CloseButton = new System.Windows.Forms.Button();
			this.MessageCountLabel = new System.Windows.Forms.Label();
			this.Picture = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.Picture)).BeginInit();
			this.SuspendLayout();
			// 
			// ClearButton
			// 
			this.ClearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.ClearButton.Location = new System.Drawing.Point(45, 620);
			this.ClearButton.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.ClearButton.Name = "ClearButton";
			this.ClearButton.Size = new System.Drawing.Size(126, 67);
			this.ClearButton.TabIndex = 19;
			this.ClearButton.Text = "C&lear";
			this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
			// 
			// CloseButton
			// 
			this.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.CloseButton.Location = new System.Drawing.Point(298, 620);
			this.CloseButton.Margin = new System.Windows.Forms.Padding(13, 10, 13, 10);
			this.CloseButton.Name = "CloseButton";
			this.CloseButton.Size = new System.Drawing.Size(126, 67);
			this.CloseButton.TabIndex = 18;
			this.CloseButton.Text = "&Close";
			this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
			// 
			// MessageCountLabel
			// 
			this.MessageCountLabel.ForeColor = System.Drawing.Color.Black;
			this.MessageCountLabel.Location = new System.Drawing.Point(45, 552);
			this.MessageCountLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
			this.MessageCountLabel.Name = "MessageCountLabel";
			this.MessageCountLabel.Size = new System.Drawing.Size(379, 46);
			this.MessageCountLabel.TabIndex = 20;
			// 
			// Picture
			// 
			this.Picture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Picture.Location = new System.Drawing.Point(45, 31);
			this.Picture.Margin = new System.Windows.Forms.Padding(6);
			this.Picture.Name = "Picture";
			this.Picture.Size = new System.Drawing.Size(379, 496);
			this.Picture.TabIndex = 21;
			this.Picture.TabStop = false;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 21F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(468, 707);
			this.Controls.Add(this.Picture);
			this.Controls.Add(this.MessageCountLabel);
			this.Controls.Add(this.ClearButton);
			this.Controls.Add(this.CloseButton);
			this.Font = new System.Drawing.Font("Lucida Console", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Location = new System.Drawing.Point(526, 0);
			this.Margin = new System.Windows.Forms.Padding(6);
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Receiver";
			this.Load += new System.EventHandler(this.MainForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.Picture)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button ClearButton;
		private System.Windows.Forms.Button CloseButton;
		private System.Windows.Forms.Label MessageCountLabel;
		private System.Windows.Forms.PictureBox Picture;
	}
}

