using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace Receiver
{
	[ServiceBehavior(InstanceContextMode=InstanceContextMode.Single,ConcurrencyMode=ConcurrencyMode.Multiple)]
	public class Receiver: IImageTransfer
	{
		private MainForm form = null;

		private Receiver()
		{
		}

		public Receiver(MainForm form)
		{
			this.form = form;
		}

		#region IImageTransfer Members

		void IImageTransfer.TransferImageRectangle(int numberOfChunks, int x, int y, int width, int height, byte[] content)
		{
			this.form.UpdateImage(numberOfChunks, x, y, width, height, content);
			//return true;
		}

		#endregion
}
}
