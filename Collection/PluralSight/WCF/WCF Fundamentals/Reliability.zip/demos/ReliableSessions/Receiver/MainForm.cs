using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;

namespace Receiver
{
	
	public partial class MainForm : Form
	{
		private delegate void UpdateImageDelegate(int numberOfChunks, int x, int y, int width, int height, byte[] content);

		UpdateImageDelegate updateImageRoutine = null;
		int messagesReceived = 0;

		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			this.updateImageRoutine = new UpdateImageDelegate(this.UpdateImage);

			Receiver receiver = new Receiver(this);
			ServiceHost service = new ServiceHost(receiver);
			service.Open();
		}

		public void UpdateImage(int numberOfChunks, int x, int y, int width, int height, byte[] content)
		{
			if (!(this.InvokeRequired))
			{
				this.messagesReceived++;

				MemoryStream memoryStream = new MemoryStream(content);
				Bitmap chunkReceived = new Bitmap(memoryStream);
				if (Picture.Image == null)
				{
					Picture.Image = (Image)(new Bitmap(width * (numberOfChunks), height * (numberOfChunks)));
					Picture.SizeMode = PictureBoxSizeMode.StretchImage;
				}
				Graphics pic = Graphics.FromImage(Picture.Image);
				pic.DrawImage(chunkReceived, new Rectangle(x, y, width, height), new Rectangle(0, 0, width, height), GraphicsUnit.Pixel);
				pic.Dispose();
				Picture.Invalidate();

				this.UpdateCountDisplay(this.messagesReceived);
			}
			else
			{
				this.Invoke(this.updateImageRoutine, new object[]{numberOfChunks,x, y, width, height, content});
			}
		}

		private void CloseButton_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void ClearButton_Click(object sender, EventArgs e)
		{
			this.messagesReceived = 0;
			this.UpdateCountDisplay(0);

			this.Picture.Image = null;
			this.Picture.Invalidate();
		}

		private void UpdateCountDisplay(int count)
		{
			if(count <= 0)
			{
				this.MessageCountLabel.Text = string.Empty;
			}
			else
			{
				this.MessageCountLabel.Text = string.Format("Received {0} messages.",count);
			}
		}

		

	}
}