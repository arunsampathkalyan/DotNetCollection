using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace ChatConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHost host = null;
            try
            {

                host = new ServiceHost(typeof(ChatService));
                
                #region code-driven
                /*
                 * ,
                    new Uri("http://localhost:8080/chat"),
                    new Uri("net.tcp://localhost:8081/chat"),
                    new Uri("net.msmq://localhost/private/chat"));

                ServiceMetadataBehavior meta = new ServiceMetadataBehavior();
                meta.HttpGetEnabled = true;
                host.Description.Behaviors.Add(meta);

                host.AddServiceEndpoint(
                    typeof(IChat),
                    new BasicHttpBinding(),
                    "");
                host.AddServiceEndpoint(
                    typeof(IChat),
                    new WSHttpBinding(),
                    "secure");
                host.AddServiceEndpoint(
                    typeof(IMetadataExchange),
                    new BasicHttpBinding(),
                    "mex");
                
                host.AddServiceEndpoint(
                    typeof(IChat),
                    new NetTcpBinding(),
                    "");

                NetMsmqBinding msmqBinding = new NetMsmqBinding();
                msmqBinding.Security.Mode = NetMsmqSecurityMode.None;

                host.AddServiceEndpoint(
                    typeof(IChat),
                    msmqBinding,
                    "");
                */
                #endregion
                
                host.Open();
                PrintEndpoints(host);

                Console.ReadLine();

                host.Close();
            }
            catch (Exception e)
            {
                if (host != null) host.Abort();
                Console.WriteLine(e.Message);
            }
        }
        private static void PrintEndpoints(ServiceHost host)
        {
            foreach (ServiceEndpoint se in host.Description.Endpoints)
                Console.WriteLine(se.Address.ToString());
        }
    }
}














