using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;
using System.Messaging;

#region ChatMessage
[DataContract(Namespace="http://example.org/chat")]
public class ChatMessage
{
    public ChatMessage()
    {
    }
    public ChatMessage(string username, string text)
    {
        this.Username = username;
        this.Text = text;
        this.Timesent = DateTime.Now;
    }
    [DataMember]
    public string Username;
    [DataMember]
    public DateTime Timesent;
    [DataMember]
    public string Text;
}
#endregion

[ServiceContract(Namespace="http://example.org/chat")]
public interface IChat
{
    [OperationContract(IsOneWay=true)]
    void SendChatMessage(ChatMessage msg);
}

public class ChatService : IChat
{
    #region IChat Members

    public void SendChatMessage(ChatMessage msg)
    {
        Console.WriteLine("{0} -- {1} says: {2}",
            msg.Timesent, msg.Username, msg.Text);
    }

    #endregion
}
