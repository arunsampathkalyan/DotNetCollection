using System;
using System.Collections.Generic;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Transactions;
using ChatClientNS.localhost;

namespace ChatClientNS
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.ReadLine();

                ChatClient client = new ChatClient("WSHttpBinding_IChat");
                ChatMessage msg = new ChatMessage();
                msg.Username = "bob";
                msg.Timesent = DateTime.Now;
                msg.Text = "hello, world";
                
                using (TransactionScope tx = new TransactionScope())
                {
                    client.SendChatMessage(msg);
                    //tx.Complete();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
