﻿using System;
using System.Collections.Generic;
using log4net;
using log4net.Core;

namespace AmortizationLibrary
{
  public class AmortizationCalculator
  {
    private ILog log = LogManager.GetLogger(typeof(AmortizationCalculator));
    public IEnumerable<PaymentDetails> Calculate(double principal, double annualPercentageRate, int numberPayments)
    {
      if (log.IsDebugEnabled)
      {
        log.DebugFormat("Principal: {0}, %: {1}, Payments: {2}", principal, annualPercentageRate, numberPayments);
      }
      var retval = new List<PaymentDetails>(numberPayments);
      double rate = annualPercentageRate/12.0d;
      var payments = (double)numberPayments;
      var onePlusRToTheN = Math.Pow(1 + rate, payments);
      var amount = principal * rate * onePlusRToTheN / (onePlusRToTheN - 1);
      for (var i = 0; i < (int)payments; ++i)
      {
        var interest = principal * rate;
        var payment = principal > amount ? amount : (principal + interest);
        var principalPaid = payment - interest;
        principal -= principalPaid;
        retval.Add(new PaymentDetails
                     {
                       PaymentNumber = i + 1,
                       Payment = payment,
                       InterestPaid = interest,
                       PrincipalPaid = principalPaid,
                       Balance = principal 
                     });
      }
      if (log.IsDebugEnabled)
      {
        log.DebugFormat("Returning {0} items", retval.Count);
      }
      return retval;      
    }
  }
}
