﻿
namespace AmortizationLibrary
{
  public class PaymentDetails
  {
    public int PaymentNumber { get; set; }

    public double Payment { get; set; }

    public double InterestPaid { get; set; }

    public double PrincipalPaid { get; set; }

    public double Balance { get; set; }
  }
}
