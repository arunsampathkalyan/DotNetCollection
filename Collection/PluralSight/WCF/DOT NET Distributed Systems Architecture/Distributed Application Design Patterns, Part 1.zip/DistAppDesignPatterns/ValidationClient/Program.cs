﻿using System;
using System.ServiceModel;
using ValidationClient.ServiceReference;

namespace ValidationClient
{
  class Program
  {
    static void Main()
    {
      var name = new Name {FirstName = "Scott", LastName = "Seely"};
      var client = new HelloWorldServiceClient();
      try
      {
        Console.WriteLine(client.SayHello(name));
      }
      catch(FaultException<ValidationFault> fault)
      {
        foreach (var detail in fault.Detail.Details)
        {
          Console.WriteLine("{0}: {1}", detail.Key, detail.Message);
        }
      }
      client.Close();
      Console.ReadLine();
    }
  }
}
