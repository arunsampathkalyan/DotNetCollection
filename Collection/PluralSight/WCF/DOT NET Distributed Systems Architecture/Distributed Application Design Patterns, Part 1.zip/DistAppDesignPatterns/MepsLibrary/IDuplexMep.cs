﻿using System.ServiceModel;

namespace MepsLibrary
{
  [ServiceContract(CallbackContract=typeof(IDuplexCallbackMep), SessionMode=SessionMode.Required)]
  public interface IDuplexMep
  {
    [OperationContract]
    string SayHiToMe();
  }
}
