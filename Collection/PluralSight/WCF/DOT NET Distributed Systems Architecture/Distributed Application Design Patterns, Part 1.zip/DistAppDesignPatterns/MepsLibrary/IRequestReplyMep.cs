﻿using System.ServiceModel;

namespace MepsLibrary
{
  [ServiceContract]
  public interface IRequestReplyMep
  {
    [OperationContract]
    string SayHello(string name);
  }
}
