﻿using System;
using System.ServiceModel;

namespace SanitizedResponse
{
  [ServiceContract]
  [SanitizingHandler]
  public class FaultyService
  {
    [OperationContract]
    public bool ForceThrow()
    {
      throw new ArgumentException("This always throws");
    }
  }
}
