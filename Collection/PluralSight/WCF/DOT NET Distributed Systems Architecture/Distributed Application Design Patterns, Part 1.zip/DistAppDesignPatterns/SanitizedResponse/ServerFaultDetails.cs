﻿using System.Runtime.Serialization;

namespace SanitizedResponse
{
  [DataContract(Namespace = "http://www.pluralsight.com/", Name="ServerFault")]
  public class ServerFaultDetails
  {
    [DataMember]
    public string FaultId { get; set; }
  }
}