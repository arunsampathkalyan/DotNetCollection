﻿using System;
using System.IO;
using System.ServiceModel;

namespace SanitizedResponse
{
  class Program
  {
    static void Main()
    {
      if (File.Exists("app_messages.svclog")) File.WriteAllText("app_messages.svclog", string.Empty);
      using (var host = new ServiceHost(typeof(FaultyService)))
      {
        host.AddDefaultEndpoints();
        // If this line fails, open an elevated command prompt and run this:
        // netsh http add urlacl url=http://+:80/Demo user=.\Users
        host.Open();
        foreach (var endpoint in host.Description.Endpoints)
        {
          Console.WriteLine("Listening at: {0}", endpoint.ListenUri);
        }
        Console.WriteLine("Press [Enter] to exit");
        Console.ReadLine();
      }
    }
  }
}
