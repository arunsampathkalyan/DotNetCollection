﻿using System.ServiceModel;

namespace MepsLibrary
{
  [ServiceContract]
  public interface IOneWayMep
  {
    [OperationContract(IsOneWay=true)]
    void PrintHi(string name);
  }
}
