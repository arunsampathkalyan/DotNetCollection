﻿using System.ServiceModel;

namespace MepsLibrary
{
  [ServiceContract]
  public interface IDuplexCallbackMep
  {
    [OperationContract]
    string GetName();
  }
}