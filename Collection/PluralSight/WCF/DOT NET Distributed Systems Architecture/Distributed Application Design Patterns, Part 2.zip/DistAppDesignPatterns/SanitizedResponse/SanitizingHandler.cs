﻿using System;
using System.Collections.ObjectModel;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;

namespace SanitizedResponse
{
  [AttributeUsage(AttributeTargets.Class)]
  public class SanitizingHandlerAttribute : Attribute, IErrorHandler, IServiceBehavior
  {
    private const string FaultAction = "http://www.pluralsight.com/ServerFault";
    public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
    {
      if (!HandleError(error)) return;
      string id = LogFault(error);
      var details = new ServerFaultDetails {FaultId = id};
      var faultException = new FaultException<ServerFaultDetails>(details, 
        new FaultReason("Server Error"),
        FaultCode.CreateReceiverFaultCode(new FaultCode("Receiver")));
      var msgFault = faultException.CreateMessageFault();
      fault = Message.CreateMessage(version, msgFault, FaultAction);
    }

    static string LogFault(Exception error)
    {
      var id = Guid.NewGuid();
      Console.WriteLine("\n*******{0}******\n{1}\n**********\n", id, error);
      return id.ToString();
    }

    public bool HandleError(Exception error)
    {
      // Handle all errors that make it here.
      return !(error is FaultException);
    }

    public void Validate(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
    {
    }

    public void AddBindingParameters(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase, Collection<ServiceEndpoint> endpoints, BindingParameterCollection bindingParameters)
    {
    }

    public void ApplyDispatchBehavior(ServiceDescription serviceDescription, ServiceHostBase serviceHostBase)
    {
      var faultDescription = new FaultDescription(FaultAction)
                               {
                                 Name = "ServerFault",
                                 Namespace = "http://www.pluralsight.com/",
                                 DetailType = typeof (ServerFaultDetails)
                               };
      foreach (var endpoint in serviceDescription.Endpoints)
      {
        foreach (var operationDescription in endpoint.Contract.Operations)
        {
          if (operationDescription.IsOneWay) continue;
          operationDescription.Faults.Add(faultDescription);
        }
      }
      foreach (ChannelDispatcher dispatcher in serviceHostBase.ChannelDispatchers)
      {
        dispatcher.ErrorHandlers.Add(this);
      }
    }
  }
}
