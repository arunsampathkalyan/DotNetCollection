﻿using System;
using System.ServiceModel;
using SanitizedResponseClient.ServiceReference;

namespace SanitizedResponseClient
{
  class Program
  {
    static void Main()
    {
      Console.ReadLine();
      var client = new FaultyServiceClient();
      try
      {
        client.ForceThrow();
      }
      catch(FaultException<ServerFaultDetails> fault)
      {
        Console.WriteLine("{0}: {1}", fault.Detail.FaultId, fault.Code.Name);
        Console.WriteLine(fault.ToString());
      }
    }
  }
}
