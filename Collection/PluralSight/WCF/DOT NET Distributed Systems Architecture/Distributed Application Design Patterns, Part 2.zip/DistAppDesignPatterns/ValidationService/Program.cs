﻿using System;
using System.ServiceModel;

namespace ValidationService
{
  class Program
  {
    static void Main()
    {
      using (var host = new ServiceHost(typeof(HelloWorldService)))
      {
        host.AddDefaultEndpoints();
        // If this line fails, open an elevated command prompt and run this:
        // netsh http add urlacl url=http://+:80/Demo user=.\Users
        host.Open();
        foreach (var endpoint in host.Description.Endpoints)
        {
          Console.WriteLine("Listening at: {0}", endpoint.ListenUri);
        }
        Console.WriteLine("Press [Enter] to exit");
        Console.ReadLine();
      }
    }
  }
}
