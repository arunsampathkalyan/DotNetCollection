﻿using System.ComponentModel.DataAnnotations;

namespace ValidationService
{
  public class Name
  {
    [StringLength(25, 
      MinimumLength = 1, 
      ErrorMessageResourceName = "StringLengthError", 
      ErrorMessageResourceType = typeof(Resource))]
    public string FirstName { get; set; }

    [StringLength(25,
      MinimumLength = 1,
      ErrorMessageResourceName = "StringLengthError",
      ErrorMessageResourceType = typeof(Resource))]
    public string LastName { get; set; }
  }
}
