﻿using System.ServiceModel;
using Microsoft.Practices.EnterpriseLibrary.Validation.Integration.WCF;

namespace ValidationService
{
  [ServiceContract]
  [ValidationBehavior]
  public class HelloWorldService
  {
    [OperationContract]
    [FaultContract(typeof(ValidationFault))]
    public string SayHello(Name name)
    {
      return string.Format("Hello, {0} {1}!",
        name.FirstName, name.LastName);
    }
  }
}
