﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MepsLibrary;

namespace MepsClient
{
  class ClientContext : IDuplexCallbackMep
  {
    public string GetName()
    {
      return "Scott";
    }
  }
}
