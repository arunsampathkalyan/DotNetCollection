﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Text;
using MepsLibrary;

namespace MepsClient
{
  class Program
  {
    static void Main(string[] args)
    {
      const string filename = "app_tracelog.svclog";
      if (File.Exists(filename)) File.WriteAllText(filename, string.Empty);
      Console.WriteLine("Press [Enter] when the service is ready.");
      Console.ReadLine();
      var address = new EndpointAddress("net.pipe://localhost/Demo");
      var binding = new NetNamedPipeBinding();
      SendOneWay(address, binding);
      Console.ReadLine();
      SendRequestReply(address, binding);
      Console.ReadLine();
      SendDuplex(address, binding);
      Console.ReadLine();
    }

    static void SendOneWay(EndpointAddress address, Binding binding)
    {
      var onewayFactory = new ChannelFactory<IOneWayMep>(binding);
      var oneway = onewayFactory.CreateChannel(address);
      oneway.PrintHi("Scott");      
      onewayFactory.Close();
    }

    static void SendRequestReply(EndpointAddress address, Binding binding)
    {
      var requestReplyFactory = new ChannelFactory<IRequestReplyMep>(binding);
      var requestReply = requestReplyFactory.CreateChannel(address);
      Console.WriteLine(requestReply.SayHello("Scott"));
      requestReplyFactory.Close();
    }

    private static void SendDuplex(EndpointAddress address, Binding binding)
    {
      var duplexFactory = new DuplexChannelFactory<IDuplexMep>(new ClientContext(), binding);
      var duplex = duplexFactory.CreateChannel(address);
      Console.WriteLine(duplex.SayHiToMe());
      duplexFactory.Close();
    }
  }
}
