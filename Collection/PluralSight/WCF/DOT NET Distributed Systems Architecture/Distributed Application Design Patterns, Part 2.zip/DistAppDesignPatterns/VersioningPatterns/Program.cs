﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace VersioningPatterns
{
  class Program
  {
    static void Main(string[] args)
    {
      var imp = new XmlReflectionImporter();
      var typeMapping = imp.ImportTypeMapping(typeof (VersionedXmlRoot));
      var schemas = new XmlSchemas();
      var exporter = new XmlSchemaExporter(schemas);
      exporter.ExportTypeMapping(typeMapping);
      var writer = new XmlTextWriter(Console.Out) {Formatting = Formatting.Indented};
      for (var i = 0; i < schemas.Count; ++i)
      {
        schemas[i].Write(writer);
      }
      writer.Flush();
      writer.Close();
    }
  }
}
