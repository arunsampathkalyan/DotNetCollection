﻿using System;
using System.Xml;
using System.Xml.Serialization;

namespace VersioningPatterns
{
  [XmlRoot(Namespace = "http://www.pluralsight.com/VersionedXmlRoot/1.23")]
  public class VersionedXmlRoot
  {
    [XmlElement]
    public int SomeNumber { get; set; }

    [XmlElement]
    public DateTime SomeTime { get; set; }

    [XmlAttribute]
    public string SomeString { get; set; }

    [XmlAnyAttribute]
    public XmlNode[] Attributes { get; set; }

    [XmlAnyElement]
    public XmlNode[] Elements { get; set; }
  }
}
