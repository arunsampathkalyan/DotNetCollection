﻿using System;
using System.Runtime.Serialization;

namespace VersioningPatterns
{
  [DataContract(Namespace ="http://www.pluralsight.com/VersionedDataContract/1.0.33")]
  public class VersionedDataContract : IExtensibleDataObject
  {
    [DataMember]
    public int SomeNumber { get; set; }

    [DataMember]
    public DateTime SomeTime { get; set; }

    [DataMember]
    public string SomeString { get; set; }

    public ExtensionDataObject ExtensionData { get; set; }
  }
}
