﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;

namespace VersioningPatterns
{
  [ServiceContract]
  [XmlSerializerFormat]
  class DummyService
  {
    [OperationContract]
    public VersionedXmlRoot DoIt()
    {
      return null;
    }
  }
}
