﻿using System.ServiceModel;

namespace BroadcastDiscoveryCommon
{
  [ServiceContract]
  public interface IHelloWorld
  {
    [OperationContract]
    string SayHello(string name);
  }
}
