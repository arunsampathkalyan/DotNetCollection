﻿using System;
using System.ServiceModel;

namespace BroadcastDiscoveryServer
{
  class Program
  {
    static void Main()
    {
      using (var host = new ServiceHost(typeof(HelloWorldService)))
      {
        host.AddDefaultEndpoints();
        host.Open();

        foreach (var endpoint in host.Description.Endpoints)
        {
          Console.WriteLine(endpoint.ListenUri);
        }
        Console.WriteLine("Press [Enter] to exit.");
        Console.ReadLine();
      }
    }
  }
}
