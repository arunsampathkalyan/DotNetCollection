﻿using BroadcastDiscoveryCommon;

namespace BroadcastDiscoveryServer
{
  class HelloWorldService : IHelloWorld
  {
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}!", name);
    }
  }
}
