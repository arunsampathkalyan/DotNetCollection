﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using MepsLibrary;

namespace MepsService
{
  [ServiceBehavior(ConcurrencyMode=ConcurrencyMode.Multiple)]
  class MepsService : IOneWayMep, IRequestReplyMep, IDuplexMep
  {
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}!", name);
    }

    public void PrintHi(string name)
    {
      Console.WriteLine(SayHello(name));
    }

    public string SayHiToMe()
    {
      var callback = OperationContext.Current.GetCallbackChannel<IDuplexCallbackMep>();
      var name = callback.GetName();
      return SayHello(name);
    }
  }
}
