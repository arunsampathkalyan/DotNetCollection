﻿using System;
using System.IO;
using System.ServiceModel;

namespace MepsService
{
  class Program
  {
    static void Main()
    {
      const string filename = "app_tracelog.svclog";
      if (File.Exists(filename)) File.WriteAllText(filename, string.Empty);

      using (var host = new ServiceHost(typeof(MepsService), new Uri("net.pipe://localhost/Demo")))
      {
        host.Open();
        foreach (var endpoint in host.Description.Endpoints)
        {
          Console.WriteLine(endpoint.ListenUri);
        }
        Console.WriteLine("Press Enter to Exit");
        Console.ReadLine();
      }
    }
  }
}
