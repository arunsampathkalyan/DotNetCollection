﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Discovery;
using BroadcastDiscoveryCommon;

namespace BroadcastDiscoveryClient
{
  class Program
  {
    static void Main()
    {
      var discoveryClient = new DiscoveryClient(new UdpDiscoveryEndpoint());
      var criteria = FindCriteria.CreateMetadataExchangeEndpointCriteria(typeof (IHelloWorld));
      criteria.MaxResults = 1;
      var findResponse = discoveryClient.Find(criteria);
      discoveryClient.Close();
      if (findResponse.Endpoints.Count > 0)
      {
        var endpoints = MetadataResolver.Resolve(
          typeof (IHelloWorld),
          findResponse.Endpoints[0].Address);
        if (endpoints.Count > 0)
        {
          var factory = new ChannelFactory<IHelloWorld>(endpoints[0].Binding, endpoints[0].Address);
          var channel = factory.CreateChannel();
          Console.WriteLine(channel.SayHello("Scott"));
          factory.Close();
        }
      }
    }
  }
}
