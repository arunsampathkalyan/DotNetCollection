﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Xml;
using System.Xml.Schema;

namespace MessagingSystems
{
  [DataContract(Namespace = "http://www.pluralsight.com/", Name = "root")]
  class Root
  {
    [DataMember(Name = "child")]
    public string Child { get; set; }

    [DataMember]
    public double DoubleValue { get; set; }
  }

  class Program
  {
    static void Main()
    {
      var exporter = new XsdDataContractExporter();
      exporter.Export(typeof(Root));
      foreach (XmlSchema schema in exporter.Schemas.Schemas("http://www.pluralsight.com/"))
      {
        var writer = new XmlTextWriter(Console.Out) {Formatting = Formatting.Indented};
        schema.Write(writer);
        Console.WriteLine();
      }
      Console.WriteLine();
      var objectWriter = new XmlTextWriter(Console.Out) { Formatting = Formatting.Indented };
      var ser = new DataContractSerializer(typeof (Root));
      ser.WriteObject(objectWriter, new Root{Child="Some Text"});
      Console.WriteLine();

      var jsonSer = new DataContractJsonSerializer(typeof (Root));
      var stream = new MemoryStream();
      jsonSer.WriteObject(stream, new Root { Child = "Some Text", DoubleValue = 3.14});
      stream.Flush();
      Console.WriteLine(Encoding.UTF8.GetString(stream.GetBuffer(), 0, (int)stream.Length));
      Console.WriteLine();
    }
  }
}
