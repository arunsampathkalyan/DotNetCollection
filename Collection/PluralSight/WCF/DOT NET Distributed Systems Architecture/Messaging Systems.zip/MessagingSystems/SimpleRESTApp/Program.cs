﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace SimpleRESTApp
{
  [ServiceContract]
  public class SimpleService
  {
    [OperationContract]
    [WebGet(UriTemplate = "/Hello/{name}", ResponseFormat =  WebMessageFormat.Json)]
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}", name);
    }
    
  }

  class Program
  {
    static void Main()
    {
      using (var host = new WebServiceHost(typeof(SimpleService), new Uri("http://localhost/Demo")))
      {
        host.Open();
        Console.ReadLine();
      }
    }
  }
}
