﻿using System;
using System.IO;
using System.ServiceModel;

namespace SimpleSOAPApp
{
  [ServiceContract(SessionMode = SessionMode.Required)]
  interface IHelloWorld
  {
    [OperationContract(IsInitiating = true, IsTerminating = false)]
    string SayHello(string name);
    [OperationContract(IsInitiating = false, IsTerminating = true)]
    string SayGoodbye(string name);
  }

  [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
  public class HelloWorldService : IHelloWorld
  {
    public string SayHello(string name)
    {
      return string.Format("Hello, {0}", name);
    }

    public string SayGoodbye(string name)
    {
      return string.Format("Goodbye, {0}", name);
    }
  }

  class Program
  {
    static void Main()
    {
      if (File.Exists("app_messages.svclog")) File.WriteAllText("app_messages.svclog", string.Empty);
      using (var host = new ServiceHost(typeof(HelloWorldService), new Uri("net.pipe://localhost/helloworld")))
      {
        host.AddDefaultEndpoints();
        host.Open();

        var factory = new ChannelFactory<IHelloWorld>(host.Description.Endpoints[0]);
        var channel = factory.CreateChannel();
        Console.WriteLine(channel.SayHello("Scott"));
        Console.WriteLine(channel.SayGoodbye("Scott"));
        factory.Close();
      }
      using (var host = new ServiceHost(typeof(HelloWorldService), new Uri("net.tcp://localhost/helloworld")))
      {
        var binding = new NetTcpBinding
                        {
                          Security = {Mode = SecurityMode.Message},
                          ReliableSession =
                            {
                              Enabled = true,
                              Ordered = true
                            }
                        };
        host.AddServiceEndpoint(typeof(IHelloWorld), binding, "");
        host.Open();

        var factory = new ChannelFactory<IHelloWorld>(host.Description.Endpoints[0]);
        var channel = factory.CreateChannel();
        Console.WriteLine(channel.SayHello("Scott"));
        Console.WriteLine(channel.SayGoodbye("Scott"));
        factory.Close();
      }
    }
  }
}
