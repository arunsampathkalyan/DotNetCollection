﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;
using CloudComputingCommon;
using Microsoft.WindowsAzure.StorageClient;

namespace QueueSender
{
  class Program
  {
    static void Main()
    {
      var client = Utility.StorageAccount.CreateCloudQueueClient();
      var cloudQueue = new CloudQueue(
        Utility.StorageAccount.QueueEndpoint.ToString() + "pluralsight", 
        client.Credentials);
      cloudQueue.CreateIfNotExist();
      var name = new Name {FirstName = "Scott", LastName = "Seely"};
      var stream = new MemoryStream();
      var writer = XmlDictionaryWriter.CreateBinaryWriter(stream);
      var ser = new DataContractSerializer(typeof (Name));
      ser.WriteObject(writer, name);
      writer.Flush();
      var buffer = new byte[stream.Length];
      Array.Copy(stream.GetBuffer(), buffer, stream.Length);
      var message = new CloudQueueMessage(buffer);
      cloudQueue.AddMessage(message, TimeSpan.FromHours(1));
    }
  }
}
