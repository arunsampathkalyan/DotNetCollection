﻿using System;
using System.IO;
using CloudComputingCommon;
using Microsoft.WindowsAzure.StorageClient;

namespace StorageDemo
{
  class Program
  {
    static void Main()
    {
      var client = Utility.StorageAccount.CreateCloudBlobClient();
      var dirInfo = new DirectoryInfo(Environment.CurrentDirectory);
      var cloudContainer = new CloudBlobContainer("pluralsight", client);
      var permissions = new BlobContainerPermissions
                          {
                            PublicAccess = BlobContainerPublicAccessType.Blob
                          };
      cloudContainer.CreateIfNotExist();
      cloudContainer.SetPermissions(permissions);
      foreach (var fileInfo in dirInfo.EnumerateFiles("*.jpg"))
      {
        var blobRef = cloudContainer.GetBlobReference(fileInfo.Name);
        blobRef.DeleteIfExists();
        blobRef.UploadFile(fileInfo.FullName);
      }
    }
  }
}
