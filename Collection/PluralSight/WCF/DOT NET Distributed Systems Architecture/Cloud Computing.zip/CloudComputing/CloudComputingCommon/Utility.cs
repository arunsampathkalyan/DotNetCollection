﻿using System.Configuration;
using Microsoft.WindowsAzure;

namespace CloudComputingCommon
{
  public static class Utility
  {
    private static CloudStorageAccount _account;

    public static CloudStorageAccount StorageAccount
    {
      get
      {
        if (_account == null)
        {
          _account = CloudStorageAccount.Parse(ConfigurationManager.AppSettings["storageAccount"]);
        }
        return _account;
      }
    }
  }
}
