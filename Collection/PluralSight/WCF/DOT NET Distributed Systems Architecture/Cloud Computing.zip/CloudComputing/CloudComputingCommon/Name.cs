﻿using System;
using System.Runtime.Serialization;

namespace CloudComputingCommon
{
  [DataContract]
  public class Name
  {
    [DataMember]
    public string FirstName { get; set; }

    [DataMember]
    public string LastName { get; set; }

    [DataMember]
    public DateTime TimeAdded { get; set; }
  }
}
