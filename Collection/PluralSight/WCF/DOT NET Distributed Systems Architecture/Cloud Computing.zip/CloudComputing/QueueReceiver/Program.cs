﻿using System;
using System.Runtime.Serialization;
using System.Threading;
using System.Xml;
using CloudComputingCommon;
using Microsoft.WindowsAzure.StorageClient;

namespace QueueReceiver
{
  class Program
  {
    static void Main()
    {
      var client = Utility.StorageAccount.CreateCloudQueueClient();
      var cloudQueue = new CloudQueue(
        Utility.StorageAccount.QueueEndpoint + "pluralsight",
        client.Credentials);
      cloudQueue.CreateIfNotExist();
      var ser = new DataContractSerializer(typeof(Name));
      var timeToStop = DateTime.Now + TimeSpan.FromMinutes(2);
      while (DateTime.Now < timeToStop)
      {
        if (cloudQueue.RetrieveApproximateMessageCount() > 0)
        {
          var message = cloudQueue.GetMessage();
          var buffer = message.AsBytes;
          var writer = XmlDictionaryReader.CreateBinaryReader(buffer, 0, buffer.Length, XmlDictionaryReaderQuotas.Max);
          var name = ser.ReadObject(writer) as Name;
          if (name != null)
          {
            Console.WriteLine("{0} {1} {2}", name.FirstName, name.LastName, message.InsertionTime);
          }
          cloudQueue.DeleteMessage(message);
        }
        Thread.Sleep(TimeSpan.FromSeconds(1));
      }
      cloudQueue.Delete();
    }
  }
}
