﻿using System;
using System.Diagnostics;
using System.Security.Principal;
using System.Threading;

namespace AuthDemo
{
  class Program
  {
    static void Main()
    {
      var identity = WindowsIdentity.GetCurrent();
      Console.WriteLine(identity.Name);
      
      foreach (var group in identity.Groups)
      {
        var sid = group as SecurityIdentifier;
        var ntAccount = group.Translate(typeof (NTAccount)) as NTAccount;
        Console.WriteLine("{0}; {1}", ntAccount.Value, sid.Value);
      }

    }
  }
}
