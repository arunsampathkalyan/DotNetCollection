﻿using System;
using System.Configuration;

namespace ManageabilityDemo
{
  public class DemoConfigurationSection : ConfigurationSection
  {
    private const string DelayTimeKey = "delayTime";

    public static readonly string SectionName = "demo";

    [ConfigurationProperty(DelayTimeKey, DefaultValue = "00:00:05")]
    public TimeSpan DelayTime
    {
      get { return (TimeSpan) base[DelayTimeKey]; }
      set { base[DelayTimeKey] = value; }
    }

    public static DemoConfigurationSection GetSection()
    {
      var section = ConfigurationManager.GetSection(SectionName);
      if (section == null)
      {
        // Return version with default values
        section = new DemoConfigurationSection();
      }
      return section as DemoConfigurationSection;
    }

    public static DemoConfigurationSection GetSection(Configuration config)
    {
      var section = config.GetSection(SectionName);
      if (section == null)
      {
        // Add to config and return version with default values
        section = new DemoConfigurationSection();
        config.Sections.Add(SectionName, section);
      }
      return section as DemoConfigurationSection;
    }
  }
}
