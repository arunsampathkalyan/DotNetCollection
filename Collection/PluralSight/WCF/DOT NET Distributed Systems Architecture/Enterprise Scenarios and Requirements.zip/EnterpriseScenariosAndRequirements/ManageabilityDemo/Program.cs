﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;

namespace ManageabilityDemo
{
  class Program
  {
    static void Main()
    {
      EventLog.WriteEntry("Pluralsight", "Application Starting");
      ConfigureApp();
      
      CreateCounters();

      var traceSource = new TraceSource("Pluralsight");

      traceSource.TraceInformation("Application starting");
      var perfCounter = new PerformanceCounter("Pluralsight", "Demo", "Scott", false);
      perfCounter.RawValue = 0;
      for (var i = 0; i < 400; ++i)
      {
        Thread.Sleep(DemoConfigurationSection.GetSection().DelayTime);
        perfCounter.Increment();
      }

      traceSource.TraceInformation("Application stopping");
      traceSource.Flush();
      EventLog.WriteEntry("Pluralsight", "Application Stopping");
    }

    private static void ConfigureApp()
    {
      var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
      var section = DemoConfigurationSection.GetSection(config);
      Console.WriteLine(section.DelayTime);
      section.DelayTime = TimeSpan.FromSeconds(1);
      config.Save();
    }

    private static void CreateCounters()
    {
      // IMPORTANT
      // This code requires Admin privileges to run. Include as part of
      // setup application.
      if (!PerformanceCounterCategory.Exists("Pluralsight"))
      {
        var counters = new CounterCreationDataCollection();
        var ccdDemo = new CounterCreationData();
        ccdDemo.CounterName = "Demo";
        ccdDemo.CounterType = PerformanceCounterType.NumberOfItems32;
        counters.Add(ccdDemo);
        PerformanceCounterCategory.Create("Pluralsight", "Sample Category", counters);
      }
    }
  }
}
