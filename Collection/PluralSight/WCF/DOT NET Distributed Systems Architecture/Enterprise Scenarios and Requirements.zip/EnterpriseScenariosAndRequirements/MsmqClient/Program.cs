﻿using System;
using System.Messaging;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Transactions;

namespace MsmqClient
{
  [ServiceContract(SessionMode = SessionMode.Required)]
  interface ITalkToWorld
  {
    [OperationContract(IsOneWay = true, IsInitiating = true, IsTerminating = false)]
    void SayHi(string name);

    [OperationContract(IsOneWay = true, IsTerminating = true, IsInitiating = false)]
    void SayBye(string name);
  }

  [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
  class TalkToWorldService : ITalkToWorld
  {
    [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = false)]
    public void SayHi(string name)
    {
      Console.WriteLine("Hello, {0}", name);
    }

    [OperationBehavior(TransactionScopeRequired = true, TransactionAutoComplete = true)]
    public void SayBye(string name)
    {
      Console.WriteLine("Bye, {0}", name);
    }
  }

  class Program 
  {
    static void Main()
    {
      //if (MessageQueue.Exists(@".\private$\pluralsightdemo")) MessageQueue.Delete(@".\private$\pluralsightdemo");
      //MessageQueue.Create(@".\private$\pluralsightdemo", true);
      
      var binding = new NetMsmqBinding(NetMsmqSecurityMode.None);
      var factory = new ChannelFactory<ITalkToWorld>(binding, "net.msmq://localhost/private/pluralsightdemo");
      var talkToWorld = factory.CreateChannel();
      using (var transaction = new TransactionScope())
      {
        talkToWorld.SayHi("Scott");
        talkToWorld.SayBye("Audience");
        var channel = talkToWorld as IChannel;
        if (channel != null)
        {
          channel.Close();
        }
        transaction.Complete();
      }

      using (var host = new ServiceHost(typeof(TalkToWorldService)))
      {
        host.AddServiceEndpoint(typeof(ITalkToWorld), binding, "net.msmq://localhost/private/pluralsightdemo");
        host.Open();
        foreach (ServiceEndpoint se in host.Description.Endpoints)
        {
          Console.WriteLine(se.ListenUri);
        }
        Console.ReadLine();
      }
    }
  }
}
