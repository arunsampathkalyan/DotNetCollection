﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelDemo
{
  class Program
  {
    static void Main()
    {
      Console.WriteLine("I am your main app. ThreadID: {0}", Thread.CurrentThread.ManagedThreadId);
      ThreadPool.QueueUserWorkItem(QueuedMethod, "Cool Data");

      Console.WriteLine("Press [Enter] to continue");
      Console.ReadLine();

      var squareValues = new int[10];
      Parallel.For(0, squareValues.Length, i => squareValues[i] = (i + 1) * (i + 1));
      Parallel.ForEach(squareValues, Console.WriteLine);

      var actions = new Action[squareValues.Length];
      Parallel.For(0, squareValues.Length, i => actions[i] = WriteValue(i));
      Parallel.Invoke(actions);

      Parallel.Invoke(
        () => Console.WriteLine(" first "),
        () => Console.WriteLine(" second "),
        () => Console.WriteLine(" third "),
        () => Console.WriteLine(" fourth "),
        () => Console.WriteLine(" fifth "),
        () => Console.WriteLine(" sixth "),
        () => Console.WriteLine(" seventh "),
        () => Console.WriteLine(" eighth "),
        () => Console.WriteLine(" ninth ")
        );

      var numbers = Enumerable.Range(20, 200);
      var divBy20Normal = from num in numbers
                    where num % 20 == 0
                    select num;

      foreach (var val in divBy20Normal)
      {
        Console.WriteLine(val);
      }
      var divBy20 = from num in numbers.AsParallel()
                    where num%20 == 0
                    select num;
      divBy20.ForAll(Console.WriteLine);
    }

    static Action WriteValue(int value)
    {
      return () => Console.WriteLine("Action #{0}", value);
    }

    static void QueuedMethod(object data)
    {
      Console.WriteLine("I am your callback. ThreadID: {0}; Data: {1}", Thread.CurrentThread.ManagedThreadId, data);
    }
  }
}
