﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.Linq;
using System.Net;
using Microsoft.ServiceModel.Web;
using System.ServiceModel.Channels;

// The following line sets the default namespace for DataContract serialized typed to be ""
[assembly: ContractNamespace("", ClrNamespace = "FavoriteMovie")]

namespace FavoriteMovie
{
    // resource representation type
    public class MyFavoriteMovie
    {
        public string Username { get; set; }
        public string Title { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    // RESTful HTTP interface
    [ServiceContract]
    public interface IFavoriteMovie
    {
        //[WebCache(Duration=30)]
        [WebHelp(Comment="Retrieves my current movie information")]
        [WebGet(UriTemplate = "")]
        [OperationContract]
        MyFavoriteMovie GetItem();

        [WebInvoke(Method = "POST", UriTemplate = "")]
        [OperationContract]
        MyFavoriteMovie AddItem(MyFavoriteMovie initialValue);

        [WebInvoke(Method = "PUT", UriTemplate = "")]
        [OperationContract]
        MyFavoriteMovie UpdateItem(MyFavoriteMovie newValue);

        [WebInvoke(Method = "DELETE", UriTemplate = "")]
        [OperationContract]
        void DeleteItem();
    }

    // RESTful service implementation
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, 
        InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class FavoriteMovieService : IFavoriteMovie
    {
        MyFavoriteMovie item = new MyFavoriteMovie() { Title = "Get Smart" };

        public MyFavoriteMovie GetItem()
        {
            item.LastUpdated = DateTime.Now;
            item.Username = WebOperationContext.Current.IncomingRequest.Headers["username"];

            if (item == null)
                throw new WebProtocolException(HttpStatusCode.NotFound,
                    GetHelpPageLink(), null);
            return item;
        }

        string GetHelpPageLink()
        {
            UriTemplate temp = new UriTemplate("help");
            string helpLink = string.Format(
                "Resource not found: please see <a href='{0}'>help page</a>",
                WebOperationContext.Current.BindTemplateToRequestUri(temp));
            return helpLink;
        }

        public MyFavoriteMovie AddItem(MyFavoriteMovie initialValue)
        {
            if (initialValue == null)
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.BadRequest;
                return null;
            }
            item = initialValue;
            WebOperationContext.Current.OutgoingResponse.SetStatusAsCreated(
                WebOperationContext.Current.IncomingRequest.UriTemplateMatch.BaseUri);
            return item;
        }

        public MyFavoriteMovie UpdateItem(MyFavoriteMovie newValue)
        {
            if (newValue == null)
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.BadRequest;
                return null;
            }
            item = newValue;
            return item;
        }

        public void DeleteItem()
        {
            item = null;
        }
    }

    public class MyInterceptor : RequestInterceptor
    {
        public MyInterceptor() : base(true) { }

        public override void ProcessRequest(ref RequestContext requestContext)
        {
            Message msg = requestContext.RequestMessage;
            HttpRequestMessageProperty httpProp =
                msg.Properties[HttpRequestMessageProperty.Name] as HttpRequestMessageProperty;

            string username = "unknown";

            if (httpProp != null)
            {
                string auth = httpProp.Headers[HttpRequestHeader.Authorization];
                if (!string.IsNullOrEmpty(auth))
                {
                    if (auth.Equals("123"))
                        username = "aaron";
                    else if (auth.Equals("456"))
                        username = "fritz";
                }
            }
            httpProp.Headers["username"] = username;
        }
    }

}