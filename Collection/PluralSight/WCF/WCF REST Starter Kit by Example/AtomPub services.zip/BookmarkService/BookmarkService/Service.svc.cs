﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.ServiceModel.Syndication;
using Microsoft.ServiceModel.Web;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using System.Globalization;
using System.ComponentModel;

namespace BookmarkService
{
    // TODO: Modify the service behavior settings (instancing, concurrency etc) based on the service's requirements.
    // TODO: NOTE: Please set IncludeExceptionDetailInFaults to false in production environments.
    [ServiceBehavior(IncludeExceptionDetailInFaults = true, InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Single)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service : AtomPublishingProtocolServiceBase, IAtomPublishingProtocolService
    {
        // TODO: These variables are used by the sample implementation. Remove if needed
        #region variables used in sample implementation
        const string sampleCollectionName = "bookmarks";
        List<SyndicationItem> bookmarkEntries = new List<SyndicationItem>();
        Dictionary<string, byte[]> collection1MediaItems = new Dictionary<string, byte[]>();
        Dictionary<string, string> collection1ContentTypes = new Dictionary<string, string>();
        #endregion

        public Service()
        {
            AddNewEntry("Pluralsight Training", "http://pluralsight.com", "Aaron Skonnard", "Pluralsight");
            AddNewEntry("Aaron's Blog", "http://pluralsight.com/aaron", "Aaron Skonnard", "Blogs");
            AddNewEntry("Fritz's Blog", "http://pluralsight.com/fritz", "Aaron Skonnard", "Blogs");
            AddNewEntry("Windows Live", "http://live.com", "Aaron Skonnard", "Search");
        }

        private void AddNewEntry(string title, string link, string author, string cat)
        {
            this.bookmarkEntries.Add(new SyndicationItem()
            {
                Title = new TextSyndicationContent(title),
                Links = { new SyndicationLink() { Uri = new Uri(link) } },
                PublishDate = DateTime.Now,
                LastUpdatedTime = DateTime.Now,
                Id = string.Format("http://tempuri.org/{0}", Guid.NewGuid().ToString()),
                Authors = { new SyndicationPerson() { Name = author } },
                Categories = { new SyndicationCategory(cat) }
            });
        }

        /// <summary>
        /// Specifies the maximum number of entries that are returned in the feed at a single time. If this is less than int.MaxValue, then the feed can
        /// be a partial collection and will contain a link to the next set of entries.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override int GetMaximumEntriesInFeed(string collection)
        {
            // TODO: Change the setting to limit the number of entries returned in the feed
            return int.MaxValue;
        }


        /// <summary>
        /// Returns an enumeration of SyndicationItems representing the entries in the requested collection, sorted by last updated time (newest first).
        /// The entries will be returned as an Atom feed. Set hasMoreEntries to true if maxEntries is smaller than the rest of the collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="startIndex">0-based index for the first entry requested</param>
        /// <param name="maxEntries">the maximum number of entries to return</param>
        /// <param name="hasMoreEntries"></param>
        /// <returns></returns>
        protected override IEnumerable<SyndicationItem> GetEntries(string collection, int startIndex, int maxEntries, out bool hasMoreEntries)
        {
            // TODO: Change the sample implementation here
            #region sample implementation
            hasMoreEntries = (startIndex + maxEntries) < this.bookmarkEntries.Count;
            int count = (maxEntries > (this.bookmarkEntries.Count - startIndex)) ? (this.bookmarkEntries.Count - startIndex) : maxEntries;
            return new List<SyndicationItem>(this.bookmarkEntries.OrderByDescending<SyndicationItem, long>(((item) => item.LastUpdatedTime.Ticks))).GetRange(startIndex, count);
            #endregion
        }


        /// <summary>
        /// Gets the SyndicationItem corresponding to the id. Return null if it does not exist
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override SyndicationItem GetEntry(string collection, string id)
        {
            // TODO: Change the sample implementation here
            #region sample implementation
            return this.bookmarkEntries.Where((item) => (item.Id == "http://tempuri.org/" + id)).SingleOrDefault();
            #endregion
        }

        /// <summary>
        /// Add the Atom entry to the collection. Return its id and the actual entry that was added to the collection. 
        /// If the item could not be added return null.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="entry">entry to be added</param>
        /// <param name="location">URI for the added entry</param>
        /// <returns></returns>
        protected override SyndicationItem AddEntry(string collection, SyndicationItem entry, out Uri location)
        {
            string newId;
            SyndicationItem newEntry;

            // TODO: Change the sample implementation here
            #region sample implementation that creates the Atom entry
            newId = Guid.NewGuid().ToString();
            entry.Id = "http://tempuri.org/" + newId;
            entry.LastUpdatedTime = DateTime.UtcNow;
            newEntry = entry;
            #endregion

            // Adds the edit link to the newly created entry. Do not remove this line
            ConfigureAtomEntry(collection, newEntry, newId, out location);

            // TODO: Change the sample implementation here
            #region sample implementation that stores the Atom entry
            this.bookmarkEntries.Add(newEntry);
            #endregion

            return newEntry;
        }

        /// <summary>
        /// Update the Atom entry specified by the id. If none exists, return null. Return the updated Atom entry. Return null if the entry does not exist.
        /// This method must be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <param name="entry">Entry to put</param>
        /// <returns></returns>
        protected override SyndicationItem PutEntry(string collection, string id, SyndicationItem entry)
        {
            // TODO: Change the sample implementation here
            #region Change the sample implementation here

            SyndicationItem oldEntry = GetEntry(collection, id);
            if (oldEntry == null) return null;
            this.bookmarkEntries.Remove(oldEntry);
            entry.Id = "http://tempuri.org/" + id;
            // update the last updated time of the entry
            entry.LastUpdatedTime = DateTime.UtcNow;
            this.bookmarkEntries.Add(entry);
            return entry;

            #endregion
        }

        /// <summary>
        /// Delete the Atom entry with the specified id. Return false if no such entry exists.
        /// This method should be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override bool DeleteEntry(string collection, string id)
        {
            // TODO: Change the sample implementation here
            #region sample implementation

            SyndicationItem entry = GetEntry(collection, id);
            if (entry == null) return false;
            this.bookmarkEntries.Remove(entry);
            return true;

            #endregion
        }

        /// <summary>
        /// Gets the SyndicationItem corresponding to the id. Return null if it does not exist.
        /// Set the contentType of the media item.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <param name="contentType">content type of the item</param>
        /// <returns></returns>
        protected override Stream GetMedia(string collection, string id, out string contentType)
        {
            // TODO: Change the sample implementation here
            #region sample implementation
            byte[] resultBytes;
            if (!this.collection1MediaItems.TryGetValue(id, out resultBytes))
            {
                contentType = null;
                return null;
            }
            contentType = this.collection1ContentTypes[id];
            MemoryStream ms = new MemoryStream(resultBytes);
            return ms;
            #endregion
        }

        /// <summary>
        /// Add the media item (represented by the stream, contentType and description) to the collection
        /// Return the id of the media item and the Atom entry representing it. If the item could not be added return null.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="stream">request entity body</param>
        /// <param name="contentType">content type of request</param>
        /// <param name="description">description, as provided in the Slug header</param>
        /// <param name="location">Uri for the media entry</param>
        /// <returns></returns>
        protected override SyndicationItem AddMedia(string collection, Stream stream, string contentType, string description, out Uri location)
        {
            string newId;
            SyndicationItem newEntry;

            // TODO: Change the sample implementation here
            #region sample implementation that stores the media item and creates a media Atom entry
            newId = Guid.NewGuid().ToString();
            using (MemoryStream ms = new MemoryStream())
            {
                byte[] buffer = new byte[64 * 1024];
                while (true)
                {
                    int count = stream.Read(buffer, 0, buffer.Length);
                    if (count <= 0) break;
                    ms.Write(buffer, 0, count);
                }
                this.collection1MediaItems.Add(newId, ms.GetBuffer());
                this.collection1ContentTypes.Add(newId, contentType);
            }
            newEntry = new SyndicationItem()
            {
                Id = "http://tempuri.org/" + newId,
                LastUpdatedTime = DateTime.UtcNow,
                Title = new TextSyndicationContent("Sample Item"),
                Authors = { new SyndicationPerson() },
                Summary = new TextSyndicationContent(description)
            };
            #endregion

            // Adds the edit and edit-media links and URL content to the newly created entry. Do not remove this line
            ConfigureMediaEntry(collection, newEntry, newId, contentType, out location);

            // TODO: change the same implementation here
            #region sample implementation that stores the media Atom entry
            this.bookmarkEntries.Add(newEntry);
            #endregion

            return newEntry;
        }



        /// <summary>
        /// Update the media item specified by the id. Return false if no such item exists.
        /// This method must be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the item</param>
        /// <param name="stream">new value for the media item</param>
        /// <param name="contentType">content type of the new value</param>
        /// <param name="description">description, as specifued in the Slug header</param>
        /// <returns></returns>
        protected override bool PutMedia(string collection, string id, Stream stream, string contentType, string description)
        {
            // TODO: Change the sample implementation here
            #region sample implementation

            if (!this.collection1MediaItems.ContainsKey(id)) return false;
            if (!string.IsNullOrEmpty(description))
            {
                SyndicationItem entry = GetEntry(collection, id);
                entry.Summary = new TextSyndicationContent(description);
            }
            using (MemoryStream ms = new MemoryStream())
            {
                byte[] buffer = new byte[64 * 1024];
                while (true)
                {
                    int count = stream.Read(buffer, 0, buffer.Length);
                    if (count <= 0) break;
                    ms.Write(buffer, 0, count);
                }
                this.collection1MediaItems[id] = ms.GetBuffer();
                this.collection1ContentTypes[id] = contentType;
            }
            return true;

            #endregion
        }


        /// <summary>
        /// Delete the media item with the specified id. Return false if no such item exists. Also delete the corresponding media entry
        /// This method should be idempotent.
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <param name="id">id of the entry</param>
        /// <returns></returns>
        protected override bool DeleteMedia(string collection, string id)
        {
            // TODO: Change the sample implementation here
            #region sample implementation

            if (!this.collection1MediaItems.ContainsKey(id)) return false;
            this.collection1MediaItems.Remove(id);
            this.collection1ContentTypes.Remove(id);
            this.DeleteEntry(collection, id);
            return true;

            #endregion
        }

        /// <summary>
        /// Create a feed container object (containing no entries) for the input collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override SyndicationFeed CreateFeed(string collection)
        {
            // TODO: Change the sample implementation here
            #region sample implementation
            return new SyndicationFeed()
            {
                Title = new TextSyndicationContent("Bookmarks Feed"),
                Id = "http://tempuri.org/BookmarksFeed",
                Description = new TextSyndicationContent("Bookmarks exposed by our service")
            };
            #endregion
        }

        /// <summary>
        /// Return true if the collection name is a valid collection, false otherwise
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override bool IsValidCollection(string collection)
        {
            // TODO: modify to allow only valid collections for your application
            return (collection == sampleCollectionName);
        }

        /// <summary>
        /// Return the service document describing the collections hosted by the service
        /// </summary>
        /// <returns></returns>
        protected override ServiceDocument GetServiceDocument()
        {
            // TODO: Change the sample implementation here
            #region sample implementation
            return new ServiceDocument()
            {
                Workspaces = 
                {
                    new Workspace()
                    {
                        Title = new TextSyndicationContent("Bookmark Service"),
                        Collections = 
                        {
                            new ResourceCollectionInfo(new TextSyndicationContent("Bookmarks"), GetAllEntriesUri(sampleCollectionName), null, GetAllowedContentTypes(sampleCollectionName))
                            {
                                Categories = 
                                {
                                    new InlineCategoriesDocument()
                                    {
                                        Categories = 
                                        {
                                            new SyndicationCategory()
                                            {
                                                Name = "Blogs",
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
            #endregion
        }

        /// <summary>
        /// Return the content types of items that can be added to the collection
        /// </summary>
        /// <param name="collection">collection name</param>
        /// <returns></returns>
        protected override IEnumerable<string> GetAllowedContentTypes(string collection)
        {
            // TODO: Specify the content-types allowed by the collection, By default all content-types are allowed
            return new string[] { "*/*" };
        }

    }
}