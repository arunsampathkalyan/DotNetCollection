﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Microsoft.Http;

namespace TwitterClient
{
    class Program
    {
        static void Main(string[] args)
        {
            HttpClient http = new HttpClient("http://localhost:35379/Service.svc/");
            HttpResponseMessage resp = http.Get("");
            TwitterStatus status = resp.Content.ReadAsXmlSerializable<TwitterStatus>();
            Console.WriteLine("Current status: {0}", status.Value);

            status.Value = "Test from the HttpClient app";
            http.Put("", HttpContentExtensions.CreateXmlSerializable<TwitterStatus>(status));

            resp = http.Get("");
            status = resp.Content.ReadAsXmlSerializable<TwitterStatus>();
            Console.WriteLine("Current status: {0}", status.Value);
        }
    }

    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class TwitterStatus
    {

        private string valueField;

        /// <remarks/>
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

}
