﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.Net;
using Microsoft.Http;

namespace TwitterShell
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Twitter Shell!");
            Console.WriteLine("*******************************");

            #region prompt for Twitter credentials
            Console.WriteLine("Enter your Twitter username: ");
            string username = Console.ReadLine();
            Console.WriteLine("Enter your Twitter password: ");
            string password = ReadPassword();
            #endregion

            // initialize HttpClient
            HttpClient http = new HttpClient("http://twitter.com/statuses/");
            http.TransportSettings.Credentials =
                new NetworkCredential(username, password);
            HttpResponseMessage resp = null;

            System.Net.ServicePointManager.Expect100Continue = false;

            Console.WriteLine("\nPlease enter a command: ");
            string command = Console.ReadLine();

            while (!command.Equals("q"))
            {
                try
                {
                    switch (command)
                    {
                        case "ls public":
                            // retrieve public timeline
                            GetStatuses(http, "public_timeline.xml");
                            break;
                        case "ls friends":
                            // retrieve friends timeline
                            GetStatuses(http, "friends_timeline.xml");
                            break;
                        case "ls":
                            // retrieve user's timeline
                            Console.WriteLine("Enter an id: ");
                            string screenname = Console.ReadLine();
                            Console.WriteLine("How many?");
                            string count = Console.ReadLine();

                            HttpQueryString vars = new HttpQueryString();
                            vars.Add("id", screenname);
                            vars.Add("count", count);

                            resp = http.Get(new Uri("user_timeline.xml", UriKind.Relative), vars);
                            resp.EnsureStatusIsSuccessful();
                            DisplayTwitterStatuses(resp.Content.ReadAsXElement());
                            break;
                        case "update":
                            // update user's status
                            Console.WriteLine("Enter a new status: ");
                            string status = Console.ReadLine();

                            HttpUrlEncodedForm form = new HttpUrlEncodedForm();
                            form.Add("status", status);

                            resp = http.Post("update.xml", form.CreateHttpContent());
                            resp.EnsureStatusIsSuccessful();
                            Console.WriteLine("Status updated!");
                            break;
                        case "delete":
                            // delete a specific status (for the auth user)
                            Console.WriteLine("Enter a status id: ");
                            string id = Console.ReadLine();
                            resp = http.Delete(string.Format("destroy/{0}.xml",
                                Uri.EscapeUriString(id)));
                            resp.EnsureStatusIsSuccessful();
                            Console.WriteLine("Status {0} deleted!", id);
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }

                // dispose of the response object
                if (resp != null) resp.Dispose();

                Console.WriteLine("\nPlease enter a command: ");
                command = Console.ReadLine();
            }

        }

        static void GetStatuses(HttpClient http, string uri)
        {
            HttpResponseMessage resp = http.Get(uri);
            resp.EnsureStatusIsSuccessful();
            DisplayTwitterStatuses(resp.Content.ReadAsXElement());
        }

        static void DisplayTwitterStatuses(XElement root)
        {
            var statuses = root.Descendants("status");
            foreach (XElement status in statuses)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(status.Element("user").Element("screen_name").Value);
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write(" {0} ", status.Element("id").Value);
                Console.ForegroundColor = ConsoleColor.White;
                string text = status.Element("text").Value;
                if (text.Length > 50)
                    text = text.Remove(50) + "...";
                Console.WriteLine(text);
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
        }

        static string ReadPassword()
        {
            StringBuilder sbPassword = new StringBuilder();
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key == ConsoleKey.Backspace)
                {
                    if (sbPassword.Length != 0)
                    {
                        sbPassword.Remove(sbPassword.Length - 1, 1);
                        Console.Write("\b \b"); // erase last char
                    }
                }
                else if (info.KeyChar >= ' ') // no control chars
                {
                    sbPassword.Append(info.KeyChar);
                    Console.Write("*");
                }
                info = Console.ReadKey(true);
            }
            Console.WriteLine();
            return sbPassword.ToString();
        }
    }
}
