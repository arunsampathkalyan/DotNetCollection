﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TwitterShell
{
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
    public partial class statuses
    {

        private statusesStatus[] statusField;

        private string typeField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("status")]
        public statusesStatus[] status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute()]
        public string type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }
    }
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class statusesStatus
    {

        private string created_atField;

        private uint idField;

        private string textField;

        private string sourceField;

        private bool truncatedField;

        private object in_reply_to_status_idField;

        private object in_reply_to_user_idField;

        private bool favoritedField;

        private object in_reply_to_screen_nameField;

        private statusesStatusUser userField;

        /// <remarks/>
        public string created_at
        {
            get
            {
                return this.created_atField;
            }
            set
            {
                this.created_atField = value;
            }
        }

        /// <remarks/>
        public uint id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string text
        {
            get
            {
                return this.textField;
            }
            set
            {
                this.textField = value;
            }
        }

        /// <remarks/>
        public string source
        {
            get
            {
                return this.sourceField;
            }
            set
            {
                this.sourceField = value;
            }
        }

        /// <remarks/>
        public bool truncated
        {
            get
            {
                return this.truncatedField;
            }
            set
            {
                this.truncatedField = value;
            }
        }

        /// <remarks/>
        public object in_reply_to_status_id
        {
            get
            {
                return this.in_reply_to_status_idField;
            }
            set
            {
                this.in_reply_to_status_idField = value;
            }
        }

        /// <remarks/>
        public object in_reply_to_user_id
        {
            get
            {
                return this.in_reply_to_user_idField;
            }
            set
            {
                this.in_reply_to_user_idField = value;
            }
        }

        /// <remarks/>
        public bool favorited
        {
            get
            {
                return this.favoritedField;
            }
            set
            {
                this.favoritedField = value;
            }
        }

        /// <remarks/>
        public object in_reply_to_screen_name
        {
            get
            {
                return this.in_reply_to_screen_nameField;
            }
            set
            {
                this.in_reply_to_screen_nameField = value;
            }
        }

        /// <remarks/>
        public statusesStatusUser user
        {
            get
            {
                return this.userField;
            }
            set
            {
                this.userField = value;
            }
        }
    }
    /// <remarks/>
    [System.CodeDom.Compiler.GeneratedCodeAttribute("System.Xml", "2.0.50727.3053")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
    public partial class statusesStatusUser
    {

        private uint idField;

        private string nameField;

        private string screen_nameField;

        private string locationField;

        private string descriptionField;

        private string profile_image_urlField;

        private string urlField;

        private bool protectedField;

        private ushort followers_countField;

        /// <remarks/>
        public uint id
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        public string name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        public string screen_name
        {
            get
            {
                return this.screen_nameField;
            }
            set
            {
                this.screen_nameField = value;
            }
        }

        /// <remarks/>
        public string location
        {
            get
            {
                return this.locationField;
            }
            set
            {
                this.locationField = value;
            }
        }

        /// <remarks/>
        public string description
        {
            get
            {
                return this.descriptionField;
            }
            set
            {
                this.descriptionField = value;
            }
        }

        /// <remarks/>
        public string profile_image_url
        {
            get
            {
                return this.profile_image_urlField;
            }
            set
            {
                this.profile_image_urlField = value;
            }
        }

        /// <remarks/>
        public string url
        {
            get
            {
                return this.urlField;
            }
            set
            {
                this.urlField = value;
            }
        }

        /// <remarks/>
        public bool @protected
        {
            get
            {
                return this.protectedField;
            }
            set
            {
                this.protectedField = value;
            }
        }

        /// <remarks/>
        public ushort followers_count
        {
            get
            {
                return this.followers_countField;
            }
            set
            {
                this.followers_countField = value;
            }
        }
    }
}
