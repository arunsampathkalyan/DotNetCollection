﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleClassLibrary
{
    public class ExternalOrder : IOrder
    {
        public string VendorId { get; set; }

        public bool ValidateOrder(OrderSummary summary)
        {
            //look at internal values

            return true;
        }
    }

    public interface IOrder
    {
        bool ValidateOrder(OrderSummary summary);
    }

    public enum DeliverySpeedType
    {
        TwoDay,
        NextDay,
        Overnight
    }

    public struct OrderSummary
    {
        public string ItemNumber { get; set; }
        public int Quantity { get; set; }
        public DeliverySpeedType DeliverySpeed { get; set; }
    }
}
