﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SampleClassLibrary
{
    public class SequenceDemo
    {
         public SequenceDemo()
        {
            Order o = new Order();
            bool response = o.PlaceOrder("1234");
            string trackingNum = o.GenerateTrackingNumber();

            DecrementInventory(100, 10);
        }

        private void DecrementInventory(int prodId, int quantity)
         {
            //
         }


    }

    public class Order
    {
        public bool PlaceOrder(string orderId)
        {
            return true;
        }

        public string GenerateTrackingNumber()
        {
            return Guid.NewGuid().ToString();
        }
    }
}
