﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Data.Services.Client;

namespace SLMovieReviews
{
    public partial class MainPage : UserControl
    {
        MoviesOData.moviereviewsEntities ctx = new MoviesOData.moviereviewsEntities(new Uri("http://localhost:4502/MovieServiceOData.svc"));
        DataServiceCollection<MoviesOData.movie> movieDS = new DataServiceCollection<MoviesOData.movie>();
        
        public MainPage()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

            // Do not load data at design time.
             if (!System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
             {                
                 var movies = from m in ctx.movies
                                  where m.release_date.Year == 1977
                                  select m;

                 movieDS.LoadCompleted += (o, lce) =>
                     {
                         Dispatcher.BeginInvoke(
                         () =>
                         {
                             System.Windows.Data.CollectionViewSource myCollectionViewSource = (System.Windows.Data.CollectionViewSource)this.Resources["moviesViewSource"];
                             myCollectionViewSource.Source = movieDS;
                         });
                     };

                 movieDS.LoadAsync(movies);
                 
             }
        }

        private void movie_selected(object sender, SelectionChangedEventArgs e)
        {
            MoviesOData.movie m = moviesDataGrid.SelectedItem as MoviesOData.movie;

            DataServiceCollection<MoviesOData.review> reviewDS = new DataServiceCollection<MoviesOData.review>();

            var reviews = from r in ctx.reviews
                              where r.movie_id == m.movie_id
                              select r;
            reviewDS.LoadCompleted += (o, lce) =>
            {
                Dispatcher.BeginInvoke(
               () =>
               {
                   System.Windows.Data.CollectionViewSource myCollectionViewSource = (System.Windows.Data.CollectionViewSource)this.Resources["moviesreviewsViewSource"];
                   myCollectionViewSource.Source = null;
                   myCollectionViewSource.Source = reviewDS;
               });
            };
            
            reviewDS.LoadAsync(reviews);

        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            ctx.BeginSaveChanges(SaveChangesOptions.Batch, new AsyncCallback(
                (ir) =>
                {
                    var response = ctx.EndSaveChanges(ir);
                    if (response.BatchStatusCode != 202)
                    {
                        MessageBox.Show("Updates caused an error");
                    }
                }), null);
        }
    }
}
