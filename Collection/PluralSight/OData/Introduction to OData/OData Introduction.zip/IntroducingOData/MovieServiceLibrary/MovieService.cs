﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Syndication;

namespace MovieServiceLibrary
{
    public class MovieService : IMovieService
    {
        public List<MovieLibrary.MovieModel> GetMovies()
        {
            MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities();

            return (from m in ctx.movies
                    select new MovieLibrary.MovieModel
                    {
                        Title = m.title,
                        ReleaseDate = m.release_date,
                        MovieID = m.movie_id
                    }).Take(50).ToList();
        }

        public List<MovieLibrary.MovieModel> GetMoviesByTitle(string title)
        {
            MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities();
                return (from m in ctx.movies
                        where m.title.Contains(title)
                        select new MovieLibrary.MovieModel
                        {
                            Title = m.title,
                            ReleaseDate = m.release_date,
                            MovieID = m.movie_id
                        }).Take(10).ToList();
        }

        public MovieLibrary.MovieModel GetMovie(string id)
        {
            var movieID = int.Parse(id);
            MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities();
                return (from m in ctx.movies
                        where m.movie_id == movieID
                        select new MovieLibrary.MovieModel
                        {
                            Title = m.title,
                            ReleaseDate = m.release_date,
                            MovieID = m.movie_id
                        }).FirstOrDefault();
            
        }

        public List<MovieLibrary.ReviewModel> GetReviews(string movieId)
        {
            var id = int.Parse(movieId);
            MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities();
            return (from r in ctx.reviews
                    where r.movie_id == id
                    select new MovieLibrary.ReviewModel
                    {
                        Rating = r.rating,
                        Reviewer = r.reviewer,
                        Summary = r.summary,
                        ReviewDetail = r.reviewText,
                        ReviewID = r.review_id
                    }).ToList();
        }

        public void SubmitReview(string movieId, MovieLibrary.ReviewModel review)
        {
            MovieLibrary.review r = new MovieLibrary.review
            {
                movie_id = int.Parse(movieId),
                rating = review.Rating,
                summary = review.Summary,
                reviewer = review.Reviewer,
                reviewText = review.ReviewDetail
            };
            MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities();
                ctx.AddToreviews(r);
                ctx.SaveChanges();
        }

        public System.ServiceModel.Syndication.SyndicationFeedFormatter GetMoviesFeed(string format)
        {
            SyndicationFeed feed =
                new SyndicationFeed
                {
                    Title = new TextSyndicationContent("Movie feed"),
                    Description = new TextSyndicationContent("Feed of movie title and release year"),
                    Items =
                        (from m in GetMovies()
                        select new SyndicationItem {Title = new TextSyndicationContent(m.Title),
                            Content = new TextSyndicationContent(m.Title, TextSyndicationContentKind.Plaintext)})  
                };

            if (format == "rss")
                return new Rss20FeedFormatter(feed);
            else
                return new Atom10FeedFormatter(feed);

        }
    }
}
