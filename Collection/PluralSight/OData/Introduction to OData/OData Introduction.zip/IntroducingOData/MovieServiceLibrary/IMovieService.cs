﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Syndication;
using System.ServiceModel.Web;

namespace MovieServiceLibrary
{
    [ServiceContract(Namespace="http://pluralsight.com")]
    public interface IMovieService
    {
        [OperationContract]
        [WebGet(UriTemplate = "movies")]
        List<MovieLibrary.MovieModel> GetMovies();

        [OperationContract]
        [WebGet(UriTemplate = "movies/{title}")]
        List<MovieLibrary.MovieModel> GetMoviesByTitle(string title);

        [OperationContract]
        [WebGet(UriTemplate = "movies({id})")]
        MovieLibrary.MovieModel GetMovie(string id);

        [OperationContract]
        [WebGet(UriTemplate = "movies({movieId})/reviews")]
        List<MovieLibrary.ReviewModel> GetReviews(string movieId);

        [OperationContract]
        [WebInvoke(UriTemplate = "movies({movieId})/reviews", Method = "POST")]
        void SubmitReview(string movieId, MovieLibrary.ReviewModel review);

        [OperationContract]
        [ServiceKnownType(typeof(Rss20FeedFormatter))]
        [ServiceKnownType(typeof(Atom10FeedFormatter))]
        [WebGet(UriTemplate = "movies?format={format}")]
        SyndicationFeedFormatter GetMoviesFeed(string format);
    }
}
