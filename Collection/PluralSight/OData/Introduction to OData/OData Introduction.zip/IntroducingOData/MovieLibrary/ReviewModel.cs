﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MovieLibrary
{
    [DataContract(Name = "Review", Namespace = "http://www.pluralsight.com/oData")]
    public class ReviewModel
    {
        [DataMember]
        public int Rating { get; set; }
        [DataMember]
        public string Reviewer { get; set; }
        [DataMember]
        public string Summary { get; set; }
        [DataMember]
        public string ReviewDetail { get; set; }
        [DataMember]
        public int ReviewID { get; set; }

    }
}
