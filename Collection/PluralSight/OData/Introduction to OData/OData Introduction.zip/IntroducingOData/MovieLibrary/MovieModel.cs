﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MovieLibrary
{
    [DataContract(Name="Movie", Namespace="http://www.pluralsight.com/oData")]
    public class MovieModel
    {
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public DateTime ReleaseDate { get; set; }
        [DataMember]
        public int MovieID { get; set; }
    }
}
