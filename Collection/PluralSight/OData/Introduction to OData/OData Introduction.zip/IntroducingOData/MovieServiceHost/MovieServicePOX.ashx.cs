﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using System.Net;

namespace MovieServiceHost
{
    
    public class MovieServicePOX : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            if (String.Compare(context.Request.HttpMethod, "GET", true) == 0)
            {
                ProcessGetRequest(context);
            }
            else if (String.Compare(context.Request.HttpMethod, "POST", true) == 0)
            {
                ProcessPostRequest(context);
            }

            else
            {
                context.Response.StatusCode = (int)HttpStatusCode.MethodNotAllowed;
            }
        }

        private static void ProcessGetRequest(HttpContext context)
        {
            context.Response.ContentType = "text/xml";
            using (MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities())
            {
                var result = (from m in ctx.movies
                              select new MovieLibrary.MovieModel
                    {
                        Title = m.title,
                        ReleaseDate = m.release_date,
                        MovieID = m.movie_id
                    }).Take(100);

                DataContractSerializer serializer = new DataContractSerializer(typeof(List<MovieLibrary.MovieModel>));
                serializer.WriteObject(context.Response.OutputStream, result.ToList());

            }
        }

        private static void ProcessPostRequest(HttpContext context)
        {
            context.Response.ContentType = "text/xml";
            DataContractSerializer serialzier = new DataContractSerializer(typeof(MovieLibrary.ReviewModel));
            var review = (MovieLibrary.ReviewModel)serialzier.ReadObject(context.Request.InputStream);

            MovieLibrary.review r = new MovieLibrary.review
            {
                movie_id = int.Parse(context.Request.QueryString["movieid"]),
                rating = review.Rating,
                summary = review.Summary,
                reviewer = review.Reviewer,
                reviewText = review.ReviewDetail
            };
            try
            {
                using (MovieLibrary.moviereviewsEntities ctx = new MovieLibrary.moviereviewsEntities())
                {
                    ctx.AddToreviews(r);
                    ctx.SaveChanges();
                }

                context.Response.StatusCode = (int)HttpStatusCode.Created;
            }
            catch
            {
                context.Response.StatusCode = (int)HttpStatusCode.BadRequest;
                context.Response.Write("<error>Invalid input</error>");
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}