﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOAPClient
{
    class Program
    {
        static void Main(string[] args)
        {
            MovieSOAP.MovieServiceClient client =
                new MovieSOAP.MovieServiceClient();

            foreach (var item in client.GetMovies())
            {
                Console.WriteLine(item.Title);
            }
        }
    }
}
