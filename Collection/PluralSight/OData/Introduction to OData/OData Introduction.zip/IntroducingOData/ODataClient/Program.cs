﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ODataClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var ctx = 
                new MovieServiceOData.moviereviewsEntities(
                    new Uri("http://localhost:4502/MovieServiceOData.svc"));

            var movies = from m in ctx.movies
                         where m.release_date.Year == 1977
                         select m;

            foreach (var item in movies)
            {
                Console.WriteLine(item.title);
            }

        }
    }
}
