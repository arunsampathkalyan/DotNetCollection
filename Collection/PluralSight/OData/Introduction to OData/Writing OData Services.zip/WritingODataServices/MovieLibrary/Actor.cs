﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Services.Common;

namespace MovieLibrary
{
    [DataServiceKey("Name")]
    public class Actor
    {
        
        public string Name { get; set; }
        public string List { get; set; }
    }

    public class ActorProvider 
    {
        private List<Actor> actors = new List<Actor>
        {
            new Actor{Name = "Tom Cruise", List="A"},
            new Actor{Name = "George Clooney", List="A"},
            new Actor{Name = "Joe Pantolino", List="B"},
            new Actor{Name = "Halle Berry", List="A"},
            new Actor{Name = "Steven Segal", List="C"},
            new Actor{Name = "Meryl Streep", List="A"},
            new Actor{Name = "Joan Cusack", List="B"},
            new Actor{Name = "Kate Beckinsdale", List="B"},
            new Actor{Name = "Diane Lane", List="A"},
            new Actor{Name = "Mike Meyers", List="B"},
            new Actor{Name = "Rob Schneider", List="C"},

        };

        public IQueryable<Actor> Actors
        {
            get { return actors.AsQueryable(); }
        }


       
    }
}
