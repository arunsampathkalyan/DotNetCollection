﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using System.ServiceModel;
using System.Linq.Expressions;

namespace MovieServiceHost
{
    public class MovieServiceOData : DataService< MovieLibrary.moviereviewsEntities >
    {
        // This method is called only once to initialize service-wide policies.
        public static void InitializeService(DataServiceConfiguration config)
        {
            // TODO: set rules to indicate which entity sets and service operations are visible, updatable, etc.
            // Examples:
            config.SetEntitySetAccessRule("movies", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("reviews", EntitySetRights.AllRead | EntitySetRights.AllWrite);
            
            config.SetServiceOperationAccessRule("TopMovies", ServiceOperationRights.All);
            config.SetServiceOperationAccessRule("TopMoviesByYear", ServiceOperationRights.All);
            config.DataServiceBehavior.MaxProtocolVersion = DataServiceProtocolVersion.V2;
        }

        [WebGet]
        public IQueryable<MovieLibrary.movie> TopMovies()
        {
            return (from m in CurrentDataSource.movies
                    let rating = m.reviews.Average(r => r.rating)
                    where rating > 9
                    orderby rating
                    select m).Take(20);
        }

        [WebGet]
        public IQueryable<MovieLibrary.movie> TopMoviesByYear(string year)
        {
            var yearInt = int.Parse(year);

            return (from m in CurrentDataSource.movies
                    let rating = m.reviews.Average(r => r.rating)
                    where rating > 9 && m.release_date.Year == yearInt
                    orderby rating
                    select m).Take(20);

        }

        [QueryInterceptor("reviews")]
        public Expression<Func<MovieLibrary.review, bool>> FilterReviews()
        {
            return (r) => r.reviewer == "Bjorne Toulouse";
        }

        [ChangeInterceptor("reviews")]
        public void FilterReviewChange(MovieLibrary.review r, UpdateOperations operations)
        {
            if (operations == UpdateOperations.Add && (r.rating < 1 || r.rating > 10))
            {
                throw new DataServiceException(400, "Ratings must be between 1 and 10");
            }
        }
    }
}
