To set up the log files for these exercises, download this file:
https://s3.amazonaws.com/pluralsight-mediasource/dan-sullivan/rx-sequence-operation-logfiles.zip

and unzip the contents (log.txt, log1.txt, log2.txt) into this directory.