﻿using System;
using System.Linq;
using System.Reactive.Linq;

namespace SkipEnd
{
    class Program
    {
        static void Main(string[] args)
        {

        }
        static int Work(int number)
        {
            Console.WriteLine("Work {0}", number);
            return number;
        }
    }
}
