To set up the log.txt file for these exercises, download this file:
https://s3.amazonaws.com/pluralsight-mediasource/dan-sullivan/reactive-regex-logfile.zip

and unzip the contents (log.txt) into this directory