namespace LinqAndCSharp
{
    partial class MovieReviewsDataContext
    {

        partial void OnCreated()
        {
            // add some logging that DataContext was created ...    
        }
    }
}
