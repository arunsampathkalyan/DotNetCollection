﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace MyLibrary
{
    public abstract class Car
    {
        public Car(string make, string model, int year, Color color)
        {
            Make = make;
            Model = model;
            Year = year;
            Color = color;
        }

        // provide default implementation
        public virtual void Start()
        {
            Console.WriteLine("Roar!");
        }

        // derived classes must define these methods
        public abstract void PressAccelerator(double howFar);
        public abstract void PressBrake(double pressure);

        // inherited properties (and the implicit fields behind them)
        public string Make { get; private set; }
        public string Model  { get; private set; }
        public int Year { get; private set; }
        public Color Color { get; set; }
    }
}
