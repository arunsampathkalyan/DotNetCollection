﻿using System;
using MyLibrary;
using System.Drawing;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ICar car = new M3 { Color = Color.Silver };

            car.CarStopped += new EventHandler(OnCarStopped);

            car.Start();
            car.PressAccelerator(10);
            car.PressBrake(10);
        }

        static void OnCarStopped(object sender, EventArgs e)
        {
            Console.WriteLine("Car stopped!");
        }
    }
}
