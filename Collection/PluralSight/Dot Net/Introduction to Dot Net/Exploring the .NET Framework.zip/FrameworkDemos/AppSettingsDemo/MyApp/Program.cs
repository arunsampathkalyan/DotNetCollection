﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string setting = ConfigurationManager.AppSettings["MySetting"];
            if (null == setting)
                throw new ApplicationException("Please configure an appSetting for MySetting");

            Console.WriteLine(setting);
        }
    }
}
