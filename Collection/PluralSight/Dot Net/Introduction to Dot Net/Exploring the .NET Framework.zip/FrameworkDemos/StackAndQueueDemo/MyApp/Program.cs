﻿using System;
using System.Linq;
using System.Text;
using System.Collections;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Stack stack = new Stack();

            //stack.Push("Fine");
            //stack.Push("Does");
            //stack.Push("Boy");
            //stack.Push("Good");
            //stack.Push("Every");

            //Console.WriteLine("peek returns {0}", stack.Peek());

            //while (stack.Count > 0)
            //    Console.WriteLine(stack.Pop());

            //stack.Pop();

            Queue queue = new Queue();

            queue.Enqueue("Fine");
            queue.Enqueue("Does");
            queue.Enqueue("Boy");
            queue.Enqueue("Good");
            queue.Enqueue("Every");

            Console.WriteLine("peek returns {0}", queue.Peek());

            while (queue.Count > 0)
                Console.WriteLine(queue.Dequeue());

            queue.Dequeue();
        }
    }
}
