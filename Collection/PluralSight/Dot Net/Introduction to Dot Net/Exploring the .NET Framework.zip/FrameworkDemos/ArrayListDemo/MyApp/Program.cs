﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList(50);

            list.Add("World");
            list.Add("Hello");

            Console.WriteLine("Count: {0}", list.Count);
            Console.WriteLine("Capacity: {0}", list.Capacity);

            list.Sort();

            PrintCollection(list);

            Console.WriteLine("list[0] = {0}", list[0]);
            Console.WriteLine("list[1] = {0}", list[1]);

            Console.WriteLine("Contains Hello: {0}", list.Contains("Hello"));
            Console.WriteLine("Contains Foo: {0}", list.Contains("Foo"));

            Console.WriteLine("BinarySearch for Hello returns {0}", list.BinarySearch("Hello"));
        }

        private static void PrintCollection(IEnumerable collection)
        {
            foreach (object obj in collection)
                Console.WriteLine(obj);
        }
    }
}
