using System;

class Program
{
    static void Main()
    {
        Foo.PrintLocation();
    }
}