﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedList table = new SortedList();

            table["Keith"] = 42;
            table["Aaron"] = 35;
            table["Fritz"] = 37;

            Console.WriteLine("Keith is at index {0}", table.IndexOfKey("Keith"));
            Console.WriteLine("Aaron is at index {0}", table.IndexOfKey("Aaron"));
            Console.WriteLine("Fritz is at index {0}", table.IndexOfKey("Fritz"));

            Console.WriteLine("Keith is {0} years old", table["Keith"]);
            Console.WriteLine("Aaron is {0} years old", table["Aaron"]);
            Console.WriteLine("Fritz is {0} years old", table["Fritz"]);

            Console.WriteLine("ContainsKey Foo? {0}", table.ContainsKey("Foo"));
            Console.WriteLine("ContainsKey Aaron? {0}", table.ContainsKey("Aaron"));

            PrintCollection(table.Keys);
            PrintCollection(table.Values);
        }

        private static void PrintCollection(IEnumerable collection)
        {
            foreach (object obj in collection)
                Console.WriteLine(obj);
        }
    }
}
