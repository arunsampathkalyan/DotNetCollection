These are VB.NET apps.  The solution containing all the code from the PPT is 
available in "LanguageChangesApp".  The version with the "__" prefix has chunks
removed for demonstration purposes.

Cheers,

  - joe hummel
    Pluralsight, LLC