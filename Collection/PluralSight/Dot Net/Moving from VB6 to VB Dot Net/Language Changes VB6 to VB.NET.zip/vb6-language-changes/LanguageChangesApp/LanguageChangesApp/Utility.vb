﻿Module Utility

  Public Function ReadTextFile(ByVal fn As String) As String
    Dim fileNum As Integer, isOpen As Boolean, errCode As Integer

    On Error GoTo ReadTextFileHandler

    fileNum = FreeFile()                   '** ask VB for a file number
    FileOpen(fileNum, fn, OpenMode.Input)  '** open file
    isOpen = True

    ReadTextFile = InputString(fileNum, LOF(fileNum))  '** read contents

    FileClose(fileNum)                     '** close file
    Exit Function

ReadTextFileHandler:
    If isOpen Then FileClose(fileNum)
    errCode = Err.Number
    Debug.Print("Error opening '" & fn & "': " & CStr(errCode))

    Err.Raise(errCode)
  End Function

  Public Function ReadTextFile2(ByVal fn As String) As String

    Try
      Using reader = New System.IO.StreamReader(fn)
        ReadTextFile2 = reader.ReadToEnd()
      End Using

    Catch ex As Exception
      Dim msg As String = String.Format("Error opening '{0}': {1}", fn, ex.Message)
      System.Diagnostics.Debug.WriteLine(msg)
      Throw
    End Try

  End Function

  Public Function ReadTextFile3(ByVal fn As String) As String

    ReadTextFile3 = My.Computer.FileSystem.ReadAllText(fn)

  End Function

End Module
