﻿Public Class Form1

  Private Sub cmdReadTextFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReadTextFile.Click
    Dim filename As String, result As String

    filename = txtFileName.Text

    Try
      result = Utility.ReadTextFile3(filename)
      MessageBox.Show(result)
    Catch ex As Exception
      MessageBox.Show(ex.Message)
    End Try
  End Sub

  Private Sub cmdCreateProduct_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreateProduct.Click
    Dim p As Product

    p = New Product(CLng(txtProductID.Text), txtProductName.Text)

    p.Info.Add("19.95", "Price")

    Dim msg As String = String.Format("Product '{0}' created", p.ProductName)
    MessageBox.Show(msg)
  End Sub

  Private Sub cmdListProducts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdListProducts.Click
    Dim products As Collection

    products = Database.ReadProducts("products.mdb")

    For Each p In products
      lstProducts.Items.Add(p.ProductName)
    Next

    If products.Count > 0 Then lstProducts.SelectedIndex = 0
  End Sub

  'Private Sub cmdListProducts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdListProducts.Click
  '  Dim products As Dictionary(Of Long, Product)

  '  products = Database.ReadProducts2("products.mdb")

  '  For Each p In products.Values
  '    lstProducts.Items.Add(p.ProductName)
  '  Next

  '  If products.Count > 0 Then lstProducts.SelectedIndex = 0
  'End Sub

End Class
