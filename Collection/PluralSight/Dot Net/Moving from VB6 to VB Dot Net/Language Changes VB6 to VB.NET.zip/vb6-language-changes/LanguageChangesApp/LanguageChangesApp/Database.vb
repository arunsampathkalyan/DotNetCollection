﻿Module Database

  '**
  '** Straight port of VB6 data access code using com-based ADO objects:
  '**
  Public Function ReadProducts(ByVal dbName As String) As Collection
    Dim path As String, connectionStr As String

    path = System.IO.Path.Combine(My.Application.Info.DirectoryPath, dbName)
    connectionStr = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Persist Security Info=False", path)

    Dim db As ADODB.Connection
    db = New ADODB.Connection
    db.Open(connectionStr)

    Dim rs As ADODB.Recordset
    rs = New ADODB.Recordset
    rs.Open("Select * from Products", db)

    Dim pid As Long, pname As String, p As Product, products As Collection

    products = New Collection()

    Do While Not rs.EOF
      pid = rs.Fields("ID").Value
      pname = rs.Fields("Name").Value

      p = New Product(pid, pname)

      products.Add(p, CStr(pid))

      rs.MoveNext()
    Loop

    rs.Close()
    db.Close()

    '**
    '** Done, return products:
    '**
    ReadProducts = products
  End Function

  '**
  '** Same data access code rewritten "the .NET way" for improved performance and 
  '** interop:
  '**
  Public Function ReadProducts2(ByVal dbName As String) As Dictionary(Of Long, Product)
    Dim path As String, connectionStr As String, provider As String

    path = System.IO.Path.Combine(My.Application.Info.DirectoryPath, dbName)
    connectionStr = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Persist Security Info=False", path)
    provider = "System.Data.OleDb"

    Dim dbFactory As System.Data.Common.DbProviderFactory
    dbFactory = System.Data.Common.DbProviderFactories.GetFactory(provider)

    Dim ds As System.Data.DataSet
    ds = New System.Data.DataSet()

    Using dbConn = dbFactory.CreateConnection()
      Dim dbCmd As System.Data.Common.DbCommand
      Dim dbAdapter As System.Data.Common.DbDataAdapter

      dbCmd = dbFactory.CreateCommand()
      dbCmd.Connection = dbConn
      dbCmd.CommandText = "Select * from Products"

      dbAdapter = dbFactory.CreateDataAdapter()
      dbAdapter.SelectCommand = dbCmd

      dbConn.ConnectionString = connectionStr

      dbConn.Open()  '** open, execute, close!
      dbAdapter.Fill(ds)
    End Using

    '** 
    '** Process dataset to yield collection of Product objects:
    '**
    Dim pid As Long, pname As String, p As Product, products As Dictionary(Of Long, Product)

    products = New Dictionary(Of Long, Product)

    For Each row In ds.Tables(0).Rows
      pid = CLng(row("ID"))
      pname = CStr(row("Name"))

      p = New Product(pid, pname)

      products.Add(pid, p)
    Next

    '**
    '** Done, return products:
    '**
    ReadProducts2 = products
  End Function

End Module
