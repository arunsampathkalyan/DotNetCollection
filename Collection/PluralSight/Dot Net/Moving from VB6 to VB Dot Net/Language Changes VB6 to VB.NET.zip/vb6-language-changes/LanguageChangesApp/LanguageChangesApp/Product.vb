﻿Public Class Product

  Public ProductID As Long
  Public ProductName As String
  Public Info As Collection

  Public Sub New(ByVal pid As Long, ByVal pname As String)  '** Constructor:
    Info = New Collection
    ProductID = pid
    ProductName = pname
  End Sub

End Class

