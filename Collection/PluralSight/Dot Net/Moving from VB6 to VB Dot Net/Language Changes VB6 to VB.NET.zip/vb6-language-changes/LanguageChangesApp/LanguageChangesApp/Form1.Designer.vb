﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.Label1 = New System.Windows.Forms.Label
    Me.txtFileName = New System.Windows.Forms.TextBox
    Me.cmdReadTextFile = New System.Windows.Forms.Button
    Me.txtProductID = New System.Windows.Forms.TextBox
    Me.Label2 = New System.Windows.Forms.Label
    Me.txtProductName = New System.Windows.Forms.TextBox
    Me.Label3 = New System.Windows.Forms.Label
    Me.cmdCreateProduct = New System.Windows.Forms.Button
    Me.lstProducts = New System.Windows.Forms.ListBox
    Me.cmdListProducts = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(42, 41)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(80, 20)
    Me.Label1.TabIndex = 0
    Me.Label1.Text = "FileName:"
    '
    'txtFileName
    '
    Me.txtFileName.Location = New System.Drawing.Point(143, 38)
    Me.txtFileName.Name = "txtFileName"
    Me.txtFileName.Size = New System.Drawing.Size(162, 26)
    Me.txtFileName.TabIndex = 1
    Me.txtFileName.Text = "file1.txt"
    '
    'cmdReadTextFile
    '
    Me.cmdReadTextFile.Location = New System.Drawing.Point(355, 34)
    Me.cmdReadTextFile.Name = "cmdReadTextFile"
    Me.cmdReadTextFile.Size = New System.Drawing.Size(149, 35)
    Me.cmdReadTextFile.TabIndex = 2
    Me.cmdReadTextFile.Text = "Read Text File"
    Me.cmdReadTextFile.UseVisualStyleBackColor = True
    '
    'txtProductID
    '
    Me.txtProductID.Location = New System.Drawing.Point(162, 139)
    Me.txtProductID.Name = "txtProductID"
    Me.txtProductID.Size = New System.Drawing.Size(162, 26)
    Me.txtProductID.TabIndex = 4
    Me.txtProductID.Text = "12254"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(42, 142)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(89, 20)
    Me.Label2.TabIndex = 3
    Me.Label2.Text = "Product ID:"
    '
    'txtProductName
    '
    Me.txtProductName.Location = New System.Drawing.Point(162, 175)
    Me.txtProductName.Name = "txtProductName"
    Me.txtProductName.Size = New System.Drawing.Size(162, 26)
    Me.txtProductName.TabIndex = 6
    Me.txtProductName.Text = "The Matrix"
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(42, 178)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(114, 20)
    Me.Label3.TabIndex = 5
    Me.Label3.Text = "Product Name:"
    '
    'cmdCreateProduct
    '
    Me.cmdCreateProduct.Location = New System.Drawing.Point(355, 154)
    Me.cmdCreateProduct.Name = "cmdCreateProduct"
    Me.cmdCreateProduct.Size = New System.Drawing.Size(149, 35)
    Me.cmdCreateProduct.TabIndex = 7
    Me.cmdCreateProduct.Text = "Create Product"
    Me.cmdCreateProduct.UseVisualStyleBackColor = True
    '
    'lstProducts
    '
    Me.lstProducts.FormattingEnabled = True
    Me.lstProducts.ItemHeight = 20
    Me.lstProducts.Location = New System.Drawing.Point(46, 257)
    Me.lstProducts.Name = "lstProducts"
    Me.lstProducts.Size = New System.Drawing.Size(278, 144)
    Me.lstProducts.TabIndex = 8
    '
    'cmdListProducts
    '
    Me.cmdListProducts.Location = New System.Drawing.Point(355, 306)
    Me.cmdListProducts.Name = "cmdListProducts"
    Me.cmdListProducts.Size = New System.Drawing.Size(149, 35)
    Me.cmdListProducts.TabIndex = 9
    Me.cmdListProducts.Text = "List Products"
    Me.cmdListProducts.UseVisualStyleBackColor = True
    '
    'Form1
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(737, 433)
    Me.Controls.Add(Me.cmdListProducts)
    Me.Controls.Add(Me.lstProducts)
    Me.Controls.Add(Me.cmdCreateProduct)
    Me.Controls.Add(Me.txtProductName)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.txtProductID)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.cmdReadTextFile)
    Me.Controls.Add(Me.txtFileName)
    Me.Controls.Add(Me.Label1)
    Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
    Me.Name = "Form1"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Language Changes in VB.NET"
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents txtFileName As System.Windows.Forms.TextBox
  Friend WithEvents cmdReadTextFile As System.Windows.Forms.Button
  Friend WithEvents txtProductID As System.Windows.Forms.TextBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents txtProductName As System.Windows.Forms.TextBox
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents cmdCreateProduct As System.Windows.Forms.Button
  Friend WithEvents lstProducts As System.Windows.Forms.ListBox
  Friend WithEvents cmdListProducts As System.Windows.Forms.Button

End Class
