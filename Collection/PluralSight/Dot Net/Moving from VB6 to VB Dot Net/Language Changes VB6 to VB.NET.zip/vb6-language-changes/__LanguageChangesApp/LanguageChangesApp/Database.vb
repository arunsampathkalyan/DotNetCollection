﻿Module Database

  Public Function ReadProducts(ByVal dbName As String) As Dictionary(Of Long, Product)
    Dim path As String, connectionStr As String, provider As String

    path = System.IO.Path.Combine(My.Application.Info.DirectoryPath, dbName)
    connectionStr = String.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Persist Security Info=False", path)

    Dim ds As System.Data.DataSet
    ds = New System.Data.DataSet()

    provider = "System.Data.OleDb"

    Dim dbFactory As System.Data.Common.DbProviderFactory
    dbFactory = System.Data.Common.DbProviderFactories.GetFactory(provider)

    Using dbConn = dbFactory.CreateConnection()




    End Using

    '** 
    '** Process dataset to yield collection of Product objects:
    '**
    Dim products As Dictionary(Of Long, Product)
    products = New Dictionary(Of Long, Product)




    '**
    '** Done, return products:
    '**
    ReadProducts = products
  End Function

End Module
