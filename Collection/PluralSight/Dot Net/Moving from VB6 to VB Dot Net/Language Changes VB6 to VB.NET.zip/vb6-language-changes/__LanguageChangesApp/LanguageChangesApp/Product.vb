﻿Public Class Product

  Public ProductName As String

End Class

