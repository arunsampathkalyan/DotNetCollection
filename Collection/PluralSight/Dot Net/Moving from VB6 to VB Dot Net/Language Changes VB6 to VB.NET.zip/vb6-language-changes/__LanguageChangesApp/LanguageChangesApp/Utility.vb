﻿Module Utility

  Public Function ReadTextFile(ByVal fn As String) As String

    ReadTextFile = "<<Utility.ReadTextFile not yet implemented>>"

  End Function

End Module
