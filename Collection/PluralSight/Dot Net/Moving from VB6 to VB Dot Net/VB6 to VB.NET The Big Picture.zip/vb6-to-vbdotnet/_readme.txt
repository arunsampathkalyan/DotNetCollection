  These are VB6 apps.  To run the .EXEs, you need to either (a) install VB6, or
(b) install the necessary controls (.OCXs).  Note that under Vista (and newer),
if you choose to install VB6, you should run the setup programs as administrator 
(it's not enough to login as administrator, you have to right-click the .exe
and run-as administrator).  [ Note: even so, I also had to manually register 
comdlg32.ocx and comctl32.ocx: run cmd.exe as administrator, cd to 
C:\Windows\system32, and regsvr32 the 2 .ocx files. ]

  If you want to try installing the individual controls (.OCXs), note that you
can download control files from here:

 http://activex.microsoft.com/controls/vb6/comctl32.cab

To install, open the .cab, extract the .ocx to say C:\windows\system32, open
cmd.exe as administrator, and regsvr32 the .ocx.

  To open the Visual Studio projects (.VBP) in their native VB6 format, you'll 
need to install VB6.  To open and convert in Visual Studio 2008, use 
File || Open, Convert...

Cheers,

  - joe hummel
    Pluralsight, LLC