To build the .hlp file, modify the .rtf file accordingly, then
run the help compiler:

  hc  editor.hpj

Cheers,

  - joe hummel
