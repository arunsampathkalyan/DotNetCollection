﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FetchMtpsContent
{
    class PrimaryDocument
    {
        public string Format { get; set; }
        public Uri DocumentUri { get; set; }
    }
}
