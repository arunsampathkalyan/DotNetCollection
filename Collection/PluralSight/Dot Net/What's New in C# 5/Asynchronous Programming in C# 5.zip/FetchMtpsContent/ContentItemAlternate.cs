﻿using System;

namespace FetchMtpsContent
{
    [System.Diagnostics.DebuggerDisplay("{Locale}, {VersionString}")]
    class ContentItemAlternate
    {
        public string Locale { get; set; }
        public string VersionString { get; set; }
        public Uri AlternateUri { get; set; }

        public string VersionTextPart
        {
            get
            {
                int dotIndex = VersionString.IndexOf('.');
                if (dotIndex < 0) { throw new InvalidOperationException(VersionNumberFormatError); }
                return VersionString.Substring(0, dotIndex);
            }
        }

        public int VersionNumberPart
        {
            get
            {
                int dotIndex = VersionString.IndexOf('.');
                if (dotIndex >= 0)
                {
                    string versionPartText = VersionString.Substring(dotIndex + 1);
                    int result;
                    if (int.TryParse(versionPartText, out result)) { return result; }
                }
                throw new InvalidOperationException(VersionNumberFormatError);
            }
        }

        private const string VersionNumberFormatError = "Version not in [Product].[VersionNumber] form";
    }
}
