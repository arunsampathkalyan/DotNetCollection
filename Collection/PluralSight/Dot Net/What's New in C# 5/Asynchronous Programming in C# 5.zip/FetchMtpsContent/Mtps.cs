﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace FetchMtpsContent
{
    class Mtps
    {
        public static readonly Uri BaseUrl = new Uri("http://services.mtps.microsoft.com/ServiceAPI/");

        public async static Task<string> GetPrimaryDocumentContent(string contentItemIdentifier, string locale)
        {
            ContentItemAlternate[] alternates = await GetContentItemAlternates(contentItemIdentifier);

            ContentItemAlternate bestAlternate = PickBestAlternate(locale, alternates);
            if (bestAlternate == null)
            { throw new ArgumentException("No alternates with specific locale", "locale"); }

            ContentItem contentItem = await GetContentItem(bestAlternate.AlternateUri);
            PrimaryDocument bestPrimaryDocument = PickBestPrimaryDocument(contentItem);
            using (var wc = new WebClient())
            {
                string content = await wc.DownloadStringTaskAsync(bestPrimaryDocument.DocumentUri);

                return content;
            }
        }

        private static PrimaryDocument PickBestPrimaryDocument(ContentItem contentItem)
        {
            PrimaryDocument result;
            result = contentItem.PrimaryDocuments.FirstOrDefault(d =>
                StringComparer.InvariantCultureIgnoreCase.Compare(d.Format,"Mtps.Offline") == 0);
            if (result == null)
            {
                result = contentItem.PrimaryDocuments.FirstOrDefault(d =>
                    StringComparer.InvariantCultureIgnoreCase.Compare(d.Format, "Mtps.Failsafe") == 0);
            }
            if (result == null)
            {
                result = contentItem.PrimaryDocuments.FirstOrDefault();
            }
            if (result == null)
            {
                throw new InvalidOperationException("No primary documents");
            }
            return result;
        }

        private static ContentItemAlternate PickBestAlternate(string locale, ContentItemAlternate[] alternates)
        {
            var alternatesForLocale = from alternate in alternates
                                      where StringComparer.InvariantCultureIgnoreCase.Compare(
                                                alternate.Locale, locale) == 0
                                      orderby alternate.VersionNumberPart descending
                                      select alternate;

            ContentItemAlternate bestAlternate = alternatesForLocale.FirstOrDefault();
            return bestAlternate;
        }

        public async static Task<ContentItemAlternate[]> GetContentItemAlternates(string contentItem)
        {
            using (var wc = new WebClient())
            {
                string alternatesRelativeUri = "content/" + contentItem;
                var alternatesUri = new Uri(BaseUrl, alternatesRelativeUri);

                string contentItemAlternatesXmlText = await wc.DownloadStringTaskAsync(alternatesUri);

                var doc = XDocument.Parse(contentItemAlternatesXmlText);
                var alternates = from alternateElement in doc.Root.GetElementsOfClass(Xhtml.Li, "alternate")
                                 let linkHref = (from link in alternateElement.GetElementsOfClass(Xhtml.A, "alternate-link")
                                                 from href in link.Attributes("href")
                                                 select href).SingleOrDefault()
                                 where linkHref != null
                                 let localeSpan = alternateElement.GetElementsOfClass(Xhtml.Span, "alternate-locale").SingleOrDefault()
                                 let versionSpan = alternateElement.GetElementsOfClass(Xhtml.Span, "alternate-version").SingleOrDefault()
                                 where localeSpan != null && versionSpan != null
                                 select new ContentItemAlternate
                                 {
                                     Locale = localeSpan.Value,
                                     VersionString = versionSpan.Value,
                                     AlternateUri = new Uri(alternatesUri, linkHref.Value)
                                 };

                return alternates.ToArray();
            }
        }

        public async static Task<ContentItem> GetContentItem(Uri contentItemUri)
        {
            using (var wc = new WebClient())
            {
                string contentItemXmlText = await wc.DownloadStringTaskAsync(contentItemUri);
                var doc = XDocument.Parse(contentItemXmlText);

                var imageDocuments = from imageElement in doc.Root.GetElementsOfClass(Xhtml.Li, "image-document")
                                     let linkHref = (from link in imageElement.GetElementsOfClass(Xhtml.A, "document-link")
                                                     from href in link.Attributes("href")
                                                     select href).SingleOrDefault()
                                     where linkHref != null
                                     let formatSpan = imageElement.GetElementsOfClass(Xhtml.Span, "image-format").SingleOrDefault()
                                     let nameSpan = imageElement.GetElementsOfClass(Xhtml.Span, "image-name").SingleOrDefault()
                                     where formatSpan != null && nameSpan != null
                                     select new ImageDocument
                                     {
                                         Format = formatSpan.Value,
                                         Name = nameSpan.Value,
                                         ImageUri = new Uri(contentItemUri, linkHref.Value)
                                     };

                var primaryDocuments = from primaryElement in doc.Root.GetElementsOfClass(Xhtml.Li, "primary-document")
                                       let linkHref = (from link in primaryElement.GetElementsOfClass(Xhtml.A, "document-link")
                                                       from href in link.Attributes("href")
                                                       select href).SingleOrDefault()
                                       where linkHref != null
                                       let formatSpan = primaryElement.GetElementsOfClass(Xhtml.Span, "primary-format").SingleOrDefault()
                                       where formatSpan != null
                                       select new PrimaryDocument
                                       {
                                           Format = formatSpan.Value,
                                           DocumentUri = new Uri(contentItemUri, linkHref.Value)
                                       };

                return new ContentItem
                {
                    ImageDocuments = imageDocuments.ToArray(),
                    PrimaryDocuments = primaryDocuments.ToArray()
                };
            }
        }
    }
}
