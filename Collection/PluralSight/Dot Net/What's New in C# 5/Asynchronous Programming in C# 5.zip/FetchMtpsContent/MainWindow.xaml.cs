﻿using System.Net;
using System.Windows;

namespace FetchMtpsContent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void getContentButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string contentBody = await Mtps.GetPrimaryDocumentContent(contentIdentifierTextBox.Text,
                                                                          "en-US");
                contentBody = contentBody.Replace("\u00a0", "&nbsp;");
                contentWebBrowser.NavigateToString(contentBody);
            }
            catch (WebException)
            {
                // ...
                MessageBox.Show("Oops");
            }
        }
    }
}
