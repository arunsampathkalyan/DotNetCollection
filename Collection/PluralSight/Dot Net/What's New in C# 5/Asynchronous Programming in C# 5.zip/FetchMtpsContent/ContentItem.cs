﻿
namespace FetchMtpsContent
{
    class ContentItem
    {
        public ImageDocument[] ImageDocuments { get; set; }
        public PrimaryDocument[] PrimaryDocuments { get; set; }
    }
}
