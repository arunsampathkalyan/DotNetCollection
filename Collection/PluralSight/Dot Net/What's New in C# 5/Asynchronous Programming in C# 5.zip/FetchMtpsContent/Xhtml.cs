﻿using System.Xml.Linq;

namespace FetchMtpsContent
{
    class Xhtml
    {
        public const string Namespace = "http://www.w3.org/1999/xhtml";

        public static readonly XName Div = XName.Get("div", Namespace);
        public static readonly XName Li = XName.Get("li", Namespace);
        public static readonly XName Span = XName.Get("span", Namespace);
        public static readonly XName A = XName.Get("a", Namespace);
    }
}
