﻿using System;

namespace FetchMtpsContent
{
    class ImageDocument
    {
        public string Format { get; set; }
        public string Name { get; set; }
        public Uri ImageUri { get; set; }
    }
}
