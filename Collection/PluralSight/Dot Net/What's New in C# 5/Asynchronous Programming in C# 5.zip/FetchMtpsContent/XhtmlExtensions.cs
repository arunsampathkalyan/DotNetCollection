﻿using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace FetchMtpsContent
{
    static class XhtmlExtensions
    {
        public static IEnumerable<XElement> GetElementsOfClass(this XElement element, XName elementType, string className)
        {
            return from descendant in element.Descendants(elementType)
                   where descendant.Attributes("class").Any(attr => attr.Value == className)
                   select descendant;
        }
    }
}
