﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace CustomAsyncExample
{
    class CustomAsync
    {
        public static CustomAwaitable DoSomethingAsync()
        {
            return new CustomAwaitable();
        }
    }

    class CustomAwaitable
    {
        public CustomAwaitable GetAwaiter()
        {
            return this;
        }
        public bool BeginAwait(Action callback)
        {
            var ctx = SynchronizationContext.Current;
            var t = new Timer(delegate
                {
                    ctx.Post(
                        delegate
                        {
                            callback();
                        }, null);
                }, null,
                5000,
                -1);
            return true;
        }
        public string EndAwait()
        {
            return "";
        }
    }
}
