﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Threading;
using System.Diagnostics;

namespace AsyncFetch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void getButton_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Calling DoDownload");
            DoDownload();
            Debug.WriteLine("DoDownload done");
        }

        private async void DoDownload()
        {
            WebClient w = new WebClient();

            string txt = await w.DownloadStringTaskAsync("http://www.pluralsight.com/");
            dataTextBox.Text = txt;
        }

        private string FormatHeaders(WebHeaderCollection headers)
        {
            var headerStrings = from header in headers.Keys.Cast<string>()
                                select string.Format("{0}: {1}", header, headers[header]);

            return string.Join(Environment.NewLine, headerStrings.ToArray());
        }
    }
}
