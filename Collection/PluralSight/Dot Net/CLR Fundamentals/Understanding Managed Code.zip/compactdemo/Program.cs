using System;

class Widget
{
    uint before = 0xAAAAAAAA;
    int  index;
    uint after = 0xBBBBBBBB;

    public Widget(int index)
    {
        this.index = index;
    }
}

class Program
{
    const int MAX_WIDGETS = 10000;

    static void Main()
    {
        GC.Collect();

        Widget firstWidget = null;
        Widget lastWidget = null;

        for (int n = 0; n < MAX_WIDGETS; n++)
        {
            Widget w = new Widget(n);

            if (n == 0)
            {
                firstWidget = w;
            }
            else if (n == (MAX_WIDGETS - 1))
            {
                lastWidget = w;
            }
        }

        GC.Collect();

        GC.KeepAlive(firstWidget);
        GC.KeepAlive(lastWidget);
    }
}