﻿using System;

class Program
{
    static void Main()
    {
        Point pt = new Point(2, 4);
        
        Console.WriteLine("{0}, {1}", pt.X, pt.Y);
        pt.X++;
        pt.Y++;
        Console.WriteLine("{0}, {1}", pt.X, pt.Y);
    }
}
