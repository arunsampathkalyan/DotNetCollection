﻿// NOTE:
//
// In order for this application to run, you'll need to first register for
// an Amazon S3 account, and update app.config with your Amazon-provided
// access & secret keys.  You'll also need to use something like CloudBerry
// to upload 1 or more bitmap files to a bucket of your choosing (and put
// your bucket name in app.config as well).
//
// In order for the s3wrapper component to also work when called by the
// VBA macro from within Word (via COM interop), you'll also need to copy
// app.config to the directory where winword.exe is installed, renaming
// app.config to winword.exe.config.  This is due to the fact that the CLR
// will look for application configuration files in the APPBASE of the hosting
// process, which is WINWORD in that scenario.  This is not how you'd do
// things in production code, and is only done this way for expediency during
// the demo.  In practice, you'd need to make other arrangements to make your
// S3 keys available to your .NET assembly.
//
using System;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Pluralsight.PSOD.Samples.Interop
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
        }

        private void _selectImage_Click(object sender, RoutedEventArgs e)
        {
            S3ImageSelector imageChooser = new S3ImageSelector();
            imageChooser.ShowDialog();
            
            if( imageChooser.SelectedImage != null )
            {
                using (S3TempFile tempFile = imageChooser.SelectedImage.DownloadTempFile())
                {
                    _selectedImage.Source = GetImageSourceFromFile(tempFile.Path);
                }
            }
        }

        ImageSource GetImageSourceFromFile(string filePath)
        {
            BitmapImage bmpImage = new BitmapImage();
            bmpImage.BeginInit();
            bmpImage.StreamSource = new MemoryStream(File.ReadAllBytes(filePath));
            bmpImage.EndInit();
            bmpImage.Freeze();
            return (bmpImage);
        }
    }
}
