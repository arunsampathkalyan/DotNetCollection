﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Pluralsight.PSOD.Samples.Interop
{
    [ComVisible(true)]
    public class S3TempFile : IDisposable
    {
        string _filePath;

        public string Path
        {
            get { return (_filePath); }
        }

        public static S3TempFile FromStream(Stream src)
        {
            string tempFile = null;

            try
            {
                tempFile = System.IO.Path.GetTempFileName();

                using (FileStream dst = File.OpenWrite(tempFile))
                {
                    CopyStream(src, dst);
                }

                return new S3TempFile(tempFile);
            }
            catch
            {
                SafeDeleteFile(tempFile);
                return (null);
            }
        }

        private S3TempFile(string tempFile)
        {
            _filePath = tempFile;
        }

        static void SafeDeleteFile(string filePath)
        {
            try
            {
                if (!string.IsNullOrEmpty(filePath) && File.Exists(filePath))
                {
                    File.Delete(filePath);
                }
            }
            catch
            {
            }
        }

        static void CopyStream(Stream src, Stream dst)
        {
            byte[] buf = new byte[8192];
            int cb = 0;

            do
            {
                cb = src.Read(buf, 0, buf.Length);

                if (cb > 0)
                {
                    dst.Write(buf, 0, cb);
                }
            }
            while (cb > 0);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            SafeDeleteFile(_filePath);
        }

        ~S3TempFile()
        {
            SafeDeleteFile(_filePath);
        }
    }
}
