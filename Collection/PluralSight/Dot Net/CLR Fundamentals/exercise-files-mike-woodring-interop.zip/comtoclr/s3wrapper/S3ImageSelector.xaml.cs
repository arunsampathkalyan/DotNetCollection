﻿using System;
using System.Windows;
using System.Configuration;
using System.Runtime.InteropServices;

namespace Pluralsight.PSOD.Samples.Interop
{
    [ComVisible(true)]
    public class S3ImageSelectorUI
    {
        public S3TempFile ChooseImage()
        {
            S3ImageSelector imageChooser = new S3ImageSelector();
            imageChooser.ShowDialog();

            if (imageChooser.SelectedImage != null)
            {
                return imageChooser.SelectedImage.DownloadTempFile();
            }
            else
            {
                return (null);
            }
        }
    }

    public partial class S3ImageSelector : Window
    {
        public S3Image SelectedImage
        {
            get;
            set;
        }

        public S3ImageSelector()
        {
            InitializeComponent();

            string bucketName = ConfigurationManager.AppSettings["BucketName"];
            string awsAccessKey = ConfigurationManager.AppSettings["AWSAccessKey"];
            string awsSecretKey = ConfigurationManager.AppSettings["AWSSecretKey"];

            S3ImageBucket imageBucket = new S3ImageBucket(awsAccessKey, awsSecretKey, bucketName);

            foreach (S3Image image in imageBucket.EnumerateImages())
            {
                _imageList.Items.Add(image);
            }
        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);

            if (_imageList.Items.Count > 0)
            {
                _imageList.SelectedIndex = 0;
                _imageList.Focus();
            }
        }

        private void _okButton_Click(object sender, RoutedEventArgs e)
        {
            if (_imageList.SelectedIndex >= 0)
            {
                SelectedImage = _imageList.SelectedValue as S3Image;
            }

            Close();
        }
    }
}
