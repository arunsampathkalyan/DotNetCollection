﻿using System;
using System.IO;
using System.Drawing;
using Amazon.S3;
using Amazon.S3.Model;
using System.Runtime.InteropServices;

namespace Pluralsight.PSOD.Samples.Interop
{
    public class S3Image
    {
        S3ImageBucket _imageBucket;
        string _key;
        long _size;
        DateTime _lastModified;

        public S3Image(S3ImageBucket bucket, string key, long size, DateTime lastModified)
        {
            _imageBucket = bucket;
            _key = key;
            _size = size;
            _lastModified = lastModified;
        }

        public override string ToString()
        {
            return (_key);
        }

        public string Key
        {
            get { return (_key); }
            set { _key = value; }
        }

        public long Size
        {
            get { return (_size); }
            set { _size = value; }
        }

        public DateTime LastModified
        {
            get { return (_lastModified); }
            set { _lastModified = value; }
        }

        public Image DownloadImage()
        {
            using (Stream stm = GetObject())
            {
                return Image.FromStream(stm);
            }
        }

        public S3TempFile DownloadTempFile()
        {
            using (Stream stm = GetObject())
            {
                return S3TempFile.FromStream(stm);
            }
        }

        Stream GetObject()
        {
            GetObjectRequest getRequest = new GetObjectRequest();

            getRequest.BucketName = _imageBucket.Name;
            getRequest.Key = _key;

            return (_imageBucket.S3Client.GetObject(getRequest).ResponseStream);
        }
    }
}
