﻿using System;
using System.IO;
using System.Collections.Generic;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System.Runtime.InteropServices;

namespace Pluralsight.PSOD.Samples.Interop
{
    public class S3ImageBucket
    {
        AmazonS3 _s3Client;
        string _bucketName;

        public S3ImageBucket(string awsAccessKey, string awsSecretKey, string bucketName)
        {
            _bucketName = bucketName;

            // Connect to the S3 service.
            //
            _s3Client = AWSClientFactory.CreateAmazonS3Client(awsAccessKey, awsSecretKey);
            
            // Ensure that the specified bucket exists by sending a put (create)
            // bucket request.  This is not optimal, but simplifies the demo.
            //
            PutBucketRequest newBucketRequest = new PutBucketRequest();

            newBucketRequest.BucketName = _bucketName;
            newBucketRequest.BucketRegion = S3Region.US;

            _s3Client.PutBucket(newBucketRequest);
        }

        public string Name
        {
            get { return (_bucketName); }
        }

        public AmazonS3 S3Client
        {
            get { return (_s3Client); }
        }

        public S3Image[] EnumerateImages()
        {
            List<S3Image> imageList = new List<S3Image>();

            ListObjectsRequest listImagesRequest = new ListObjectsRequest();
            listImagesRequest.BucketName = _bucketName;

            ListObjectsResponse listImagesResponse = _s3Client.ListObjects(listImagesRequest);

            if (listImagesResponse.S3Objects != null)
            {
                foreach (S3Object image in listImagesResponse.S3Objects)
                {
                    imageList.Add(new S3Image(this, image.Key, image.Size, DateTime.Parse(image.LastModified)));
                }
            }

            return imageList.ToArray();
        }
    }
}