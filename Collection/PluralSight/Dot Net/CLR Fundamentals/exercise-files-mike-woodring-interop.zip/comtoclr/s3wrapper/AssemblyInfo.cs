﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// This is the assembly-wide default, which is overridden on
// a type-by-type basis using ComVisible(true).
//
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM.
//
[assembly: Guid("3e82c114-df00-477c-9fc9-d6ab71a29deb")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
