// Calc.cpp : Implementation of CCalc

#include "stdafx.h"
#include "Calc.h"

STDMETHODIMP CCalc::Add(long a, long b, long * pSum)
{
	*pSum = (a + b);
	return(S_OK);
}

STDMETHODIMP CCalc::Sum(long *pValues, long count, long *pResult)
{
	*pResult = 0;

	for( long n = 0; n < count; n++ )
	{
		*pResult += pValues[n];
	}

	return(S_OK);
}

