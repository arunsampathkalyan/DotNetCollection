// dllmain.h : Declaration of module class.

class CcomcalcModule : public CAtlDllModuleT< CcomcalcModule >
{
public :
	DECLARE_LIBID(LIBID_comcalcLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_COMCALC, "{A6EEF476-520A-408F-A6DB-4F8D6649F7C4}")
};

extern class CcomcalcModule _AtlModule;
