﻿// NOTE:
//
// Both Program1.cs and Program2.cs are part of the solution/project,
// but one of them should always have a build action of "None" so
// that only one of them is compiled (depending on which version you
// want to experiment with).  In order for Program1.cs to compile,
// you'll need to add a reference to the comcalc COM component.
//
// In order for VS.NET to register the native comcalc.dll component,
// it will need to be running as an administrator.  Alternatively,
// use a command shell running as admin to manually run regsvr32.exe.
//
using System;
using System.Runtime.InteropServices;
using comcalcLib;

class App
{
    [STAThread]
    static void Main()
    {
        ICalc c = (ICalc)new CalcClass();
        Console.WriteLine("2 + 3 = {0}", c.Add(2, 3));
    }
}