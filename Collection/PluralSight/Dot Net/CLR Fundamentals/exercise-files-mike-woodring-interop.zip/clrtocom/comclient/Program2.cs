﻿// NOTE:
//
// Both Program1.cs and Program2.cs are part of the solution/project,
// but one of them should always have a build action of "None" so
// that only one of them is compiled (depending on which version you
// want to experiment with).  In order for Program1.cs to compile,
// you'll need to add a reference to the comcalc COM component.
//
// In order for VS.NET to register the native comcalc.dll component,
// it will need to be running as an administrator.  Alternatively,
// use a command shell running as admin to manually run regsvr32.exe.
//
using System;
using System.Runtime.InteropServices;

[
    ComImport,
    Guid("37DE3F74-99BE-4DD9-A06D-422203752987")
]
class CalcClass
{
}

[
    Guid("22E8E9BF-552E-4A09-8B93-33778020F240"),
    InterfaceType(ComInterfaceType.InterfaceIsIUnknown)
]
interface ICalc
{
    int Add(int a, int b);
    int Sum([MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 1)] int[] values, int count);
}

class App
{
    [STAThread]
    static void Main()
    {
        ICalc c = (ICalc)new CalcClass();
        int[] values = { 1, 2, 3, 4 }; // 10
        int sum = c.Sum(values, values.Length);
    }
}