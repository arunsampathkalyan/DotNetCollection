﻿using System;
using System.Windows;

namespace Pluralsight.PSOD.Demos.Interop
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            FontSmoothingType currentFontSmoothingType = SystemParameters.FontSmoothingType;
            _useStandard.IsChecked = (currentFontSmoothingType == FontSmoothingType.Standard);
            _useClearType.IsChecked = (currentFontSmoothingType == FontSmoothingType.ClearType);
            _fontSmoothingEnabled.IsChecked = SystemParameters.FontSmoothingEnabled;
        }

        void _fontSmoothingEnabled_Checked(object sender, RoutedEventArgs e)
        {
            SystemParameters.FontSmoothingEnabled = _fontSmoothingEnabled.IsChecked ?? false;
        }

        void _fontSmoothingType_Checked(object sender, RoutedEventArgs e)
        {
            SystemParameters.FontSmoothingType = (_useStandard.IsChecked.Value ? FontSmoothingType.Standard : FontSmoothingType.ClearType);
        }
    }
}
