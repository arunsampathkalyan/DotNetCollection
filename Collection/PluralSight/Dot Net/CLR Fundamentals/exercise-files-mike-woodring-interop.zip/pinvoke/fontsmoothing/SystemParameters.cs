﻿using System;
using System.Runtime.InteropServices;

// The use and values of enumerations that appear below are taken from the
// MSDN documentation for the SystemParametersInfo function and WinUser.h.
//
namespace Pluralsight.PSOD.Demos.Interop
{
    public enum FontSmoothingType : uint
    {
        Standard = 0x0001,
        ClearType = 0x0002
    }

    public static class SystemParameters
    {
        public static bool FontSmoothingEnabled
        {
            get { return NativeSystemParameters.IsFontSmoothingEnabled(); }
            set { NativeSystemParameters.EnableFontSmoothing(value); }
        }

        public static FontSmoothingType FontSmoothingType
        {
            get { return NativeSystemParameters.GetFontSmoothingType(); }
            set { NativeSystemParameters.SetFontSmoothingType(value); }
        }
    }

    internal static class NativeSystemParameters
    {
        enum SPICommand : uint
        {
            GetFontSmoothing = 0x004A,      // SPI_GETFONTSMOOTHING
            SetFontSmoothing = 0x004B,      // SPI_SETFONTSMOOTHING

            GetFontSmoothingType = 0x200A,  // SPI_GETFONTSMOOTHINGTYPE
            SetFontSmoothingType = 0x200B   // SPI_SETFONTSMOOTHINGTYPE
        }

        [Flags]
        enum ChangeFlags : uint
        {
            None = 0x0000,
            UpdateProfile = 0x0001,         // SPIF_UPDATEINIFILE
            Broadcast = 0x002,              // SPIF_SENDWININICHANGE/SPIF_SENDCHANGE
            UpdateProfileAndBroadcast = UpdateProfile | Broadcast
        }

        [DllImport("user32.dll", EntryPoint="SystemParametersInfo", SetLastError=true)]
        static extern bool GetFontSmoothing(
            SPICommand command,
            uint unused,
            out bool enabled,
            ChangeFlags flags
        );

        internal static bool IsFontSmoothingEnabled()
        {
            bool enabled;

            if (!GetFontSmoothing(SPICommand.GetFontSmoothing, 0, out enabled, ChangeFlags.None))
            {
                ThrowLastWin32Error();
            }

            return (enabled);
        }

        [DllImport("user32.dll", EntryPoint = "SystemParametersInfo", SetLastError = true)]
        static extern bool SetFontSmoothing(
            SPICommand command,
            bool enabled,
            IntPtr unused,
            ChangeFlags flags
        );

        internal static void EnableFontSmoothing(bool enabled)
        {
            if (!SetFontSmoothing(SPICommand.SetFontSmoothing, enabled, IntPtr.Zero, ChangeFlags.UpdateProfileAndBroadcast))
            {
                ThrowLastWin32Error();
            }
        }

        [DllImport("user32.dll", EntryPoint = "SystemParametersInfo", SetLastError = true)]
        static extern bool GetFontSmoothingType(
            SPICommand command,
            uint unused,
            out FontSmoothingType type,
            ChangeFlags flags
        );

        internal static FontSmoothingType GetFontSmoothingType()
        {
            FontSmoothingType type;

            if (!GetFontSmoothingType(SPICommand.GetFontSmoothingType, 0, out type, ChangeFlags.None))
            {
                ThrowLastWin32Error();
            }

            return (type);
        }

        [DllImport("user32.dll", EntryPoint = "SystemParametersInfo", SetLastError = true)]
        static extern bool SetFontSmoothingType(
            SPICommand command,
            uint unused,
            FontSmoothingType type,
            ChangeFlags flags
        );

        internal static void SetFontSmoothingType(FontSmoothingType type)
        {
            if (!SetFontSmoothingType(SPICommand.SetFontSmoothingType, 0, type, ChangeFlags.UpdateProfileAndBroadcast))
            {
                ThrowLastWin32Error();
            }
        }

        internal static void ThrowLastWin32Error()
        {
            int hr = Marshal.GetHRForLastWin32Error();
            throw Marshal.GetExceptionForHR(hr);
        }
    }
}
