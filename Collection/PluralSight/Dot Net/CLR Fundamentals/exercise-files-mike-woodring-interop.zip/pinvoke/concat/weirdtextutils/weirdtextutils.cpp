#include "stdafx.h"
#include "weirdtextutils.h"

BSTR WINAPI Concat( wchar_t *s1, char *s2 )
{
    // Find out how many characters we need for the Unicode
    // version of s2.
    //
    int cchs2 = MultiByteToWideChar(CP_THREAD_ACP, MB_PRECOMPOSED, s2, -1, NULL, 0);

    // Allocate a buffer large enough to hold the Unicode version of s2.
    //
    wchar_t *ws2 = new wchar_t[cchs2];

    // Conver s2 to unicode.
    //
    MultiByteToWideChar(CP_THREAD_ACP, MB_PRECOMPOSED, s2, -1, ws2, cchs2);

    // Allocate a unicode buffer large enough to hold the combined
    // value of s1+ws2, then copy in s1 & ws2.
    //
    int cchs1 = wcslen(s1);
    int combinedLength = cchs1 + cchs2 + 1;
    wchar_t *combinedUnicode = new wchar_t[combinedLength];
    wcscpy(combinedUnicode, s1);
    wcscat(combinedUnicode, ws2);

    // Allocate the BSTR version of combinedUnicode.
    //
    BSTR combinedBSTR = ::SysAllocString(combinedUnicode);

    // Free up the temporary string buffers.
    //
    delete [] ws2;
    delete [] combinedUnicode;

    return(combinedBSTR);
}
