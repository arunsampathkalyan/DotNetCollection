#ifdef WEIRDTEXTUTILS_EXPORTS
#define WEIRDTEXTUTILS_API __declspec(dllexport)
#else
#define WEIRDTEXTUTILS_API __declspec(dllimport)
#endif

WEIRDTEXTUTILS_API BSTR WINAPI Concat( wchar_t *s1, char *s2 );
