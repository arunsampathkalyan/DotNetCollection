﻿using System;
using System.Runtime.InteropServices;

class Program
{
    static void Main()
    {
        string s = Concat("Hello, ", "world!");
        Console.WriteLine(s);
    }

    [DllImport("weirdtextutils.dll")]
    [return: MarshalAs(UnmanagedType.BStr)]
    static extern string Concat( [MarshalAs(UnmanagedType.LPWStr)] string s1,
                                 [MarshalAs(UnmanagedType.LPStr)] string s2 );
}
