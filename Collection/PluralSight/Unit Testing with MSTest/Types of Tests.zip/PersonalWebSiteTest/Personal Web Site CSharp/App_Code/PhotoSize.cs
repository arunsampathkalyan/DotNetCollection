public enum PhotoSize {
	Small = 1,		// 100px
	Medium = 2,		// 198px
	Large = 3,		// 600px
	Original = 4	// Original Size
}
