﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UserRegistration;


namespace UserRegistrationTest
{
    [TestClass]
    public class PasswordStrengthTest
    {
        [TestMethod]
        public void GetPasswordStrengthTest()
        {
            // arrange
            string password = "P2ssw0rd#";
            int expected = 5;

            // act
            int actual = UserRegistration.PasswordStrengthMeter.GetPasswordStrength(password);

            // assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForCaps()
        {
            // Arrange
            string password = "Password";
            int expected = 3; // for caps 1, for length 1, for small case 1

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        // Tests for numbers
        [TestMethod]
        public void PasswordStrengthTest_ForNumber_0()
        {
            // Arrange
            string password = "Passw0rd";

            // for caps 1, for length 1, for small case 1
            // for number 1
            int expected = 4;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForNumber_1()
        {
            // Arrange
            string password = "Passw1rd";

            // for caps 1, for length 1, for small case 1
            // for number 1
            int expected = 4;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForNumber_2()
        {
            // Arrange
            string password = "Passw2rd";

            // for caps 1, for length 1, for small case 1
            // for number 1
            int expected = 4;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForNumber_3()
        {
            // Arrange
            string password = "Passw3rd";

            // for caps 1, for length 1, for small case 1
            // for number 1
            int expected = 4;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForNumber_4()
        {
            // Arrange
            string password = "Passw4rd";

            // for caps 1, for length 1, for small case 1
            // for number 1
            int expected = 4;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        // Tests for special chars

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_at()
        {
            // Arrange
            string password = "Passw0rd@";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Hash()
        {
            // Arrange
            string password = "Passw0rd#";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Excl()
        {
            // Arrange
            string password = "Passw0rd!";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Astr()
        {
            // Arrange
            string password = "Passw0rd*";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Doll()
        {
            // Arrange
            string password = "Passw0rd$";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Minus()
        {
            // Arrange
            string password = "Passw0rd-";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Plus()
        {
            // Arrange
            string password = "Passw0rd+";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void PasswordStrengthTest_ForSpecialChar_Perc()
        {
            // Arrange
            string password = "Passw0rd%";

            // for caps 1, for length 1, for small case 1
            // for number 1, for special char 1
            int expected = 5;

            // Act
            int actual = PasswordStrengthMeter.GetPasswordStrength(password);

            // Assert

            Assert.AreEqual(expected, actual);
        }

    }
}
