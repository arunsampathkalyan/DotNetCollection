﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using InitializeAndCleanUp;
using System.Diagnostics;

namespace TestIniAndCleanUp
{
    [TestClass]
    public class ShoppingCartTest
    {
        private static ShoppingCart cart;

        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext context)
        {
            
            cart = new ShoppingCart();
            cart.Add(new Item { ItemName = "HTC WP7", ItemQuantity = 10 });

            SerializationHelper.helper.BinarySerialize("C:\\cart.txt", cart);
        }

        [ClassCleanup]
        public static void MyClassCleanUp()
        {

        }

        [ClassInitialize]
        public static void MyClassInitialize(TestContext context)
        {
            cart = new ShoppingCart();
            cart.Add(new Item { ItemName = "LG WP7", ItemQuantity = 10 });
        }

        [TestInitialize]
        public void TestInitialize()
        {

        }

        [TestCleanup]
        public void TestCleanUp()
        {

        }

        [AssemblyCleanup]
        public static void AssemblyCleanUp()
        {
            cart.Dispose();
        }

        [TestMethod]
        public void Assembly_CountAfterAddTest()
        {
            int expected = cart.ItemCount + 1;

            cart.Add(new Item { ItemName = "Samsung WP 7", ItemQuantity = 10 });

            Assert.AreEqual(expected, cart.ItemCount);

        }

        [TestMethod]
        public void Assembly_CountAfterRemoveTest()
        {
            int expected = cart.ItemCount - 1;
            cart.Remove(0);

            Assert.AreEqual(expected, cart.ItemCount);
        }

    }
}
