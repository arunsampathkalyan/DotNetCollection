﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using InitializeAndCleanUp;
using System.Diagnostics;

namespace TestIniAndCleanUp
{
    [TestClass]
    public class ShoppingCartTest2
    {
        private static ShoppingCart cart;

        [TestMethodAttribute]
        public void Assembly_Class2_TestCountAfterAdd()
        {
            
            cart = (ShoppingCart)SerializationHelper.helper.BinaryDeserialize("C:\\cart.txt");

            int expected = cart.ItemCount + 1;

            cart.Add(new Item { ItemName = "LG WP7", ItemQuantity = 10 });

            Assert.AreEqual(expected, cart.ItemCount);

        }

    }
}
