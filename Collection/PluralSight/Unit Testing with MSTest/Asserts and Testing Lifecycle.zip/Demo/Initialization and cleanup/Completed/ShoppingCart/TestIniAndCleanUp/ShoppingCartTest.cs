﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using InitializeAndCleanUp;
using System.Diagnostics;
using System.Transactions;

namespace TestIniAndCleanUp
{
    [TestClass]
    public class ShoppingCartTest
    {
        private ShoppingCart cart;
        private Item item;

        #region Test Initialize and CleanUp
        
        [TestInitialize]
        public void TestInitialize()
        {
            item = new Item();
            item.ItemName = "Samsung Windows Phone 7";
            item.ItemQuantity = 10;

            cart = new ShoppingCart();
            cart.Add(item);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            cart.Dispose();
        }

        #endregion

        #region Test Methods
        
        [TestMethod]
        public void CheckOutTest()
        {
            CollectionAssert.Contains(cart.Items, item);
        }

        [TestMethod]
        public void RemoveItemTest()
        {
            int expected = 0;
            cart.Remove(0);
            
            Assert.AreEqual(expected, cart.ItemCount);
        }

        #endregion
    }
}
