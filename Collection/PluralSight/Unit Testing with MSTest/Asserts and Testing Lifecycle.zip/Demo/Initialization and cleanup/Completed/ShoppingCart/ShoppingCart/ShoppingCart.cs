﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace InitializeAndCleanUp
{
    [Serializable]
    public class ShoppingCart:IDisposable
    {
        public ArrayList Items = new ArrayList();

        public int ItemCount
        {
            get { return Items.Count; }
        }

        public void Add(Item item)
        {
            this.Items.Add(item);           
        }

        public void Dispose()
        {
            // cleanup code
        }

        public void Remove(int index)
        {
            this.Items.RemoveAt(index);
        }
    }

    [Serializable]
    public class Item
    {
        public string ItemName { get; set; }
        public int ItemQuantity { get; set; }
    }
}
