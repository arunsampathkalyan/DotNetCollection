﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.IO;
using System.Xml.Serialization;

using InitializeAndCleanUp;
using System.Runtime.Serialization.Formatters.Binary;


namespace SerializationHelper
{
    public static class helper
    {
        #region Binary Serialization/Deserialization

        public static void BinarySerialize(string filename, ShoppingCart cart)
        {

            FileStream fileStreamObject = null;
            try
            {
                fileStreamObject = new FileStream(filename, FileMode.Create, 
                    FileAccess.Write);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStreamObject, cart);
            }

            finally
            {
                fileStreamObject.Close();
            }
        }

        public static object BinaryDeserialize(string filename)
        {
            FileStream fileStreamObject = null;

            try
            {
                fileStreamObject = new FileStream(filename, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                return (binaryFormatter.Deserialize(fileStreamObject));
            }
            finally
            {
                fileStreamObject.Close();
            }
        }

        #endregion

    }
}
