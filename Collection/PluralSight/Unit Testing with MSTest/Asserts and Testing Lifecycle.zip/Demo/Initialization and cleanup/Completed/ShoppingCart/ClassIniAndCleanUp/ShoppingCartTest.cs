﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using InitializeAndCleanUp;
using System.Diagnostics;

namespace TestIniAndCleanUp
{
    [TestClass]
    public class ShoppingCartTest
    {
        private static ShoppingCart cart;

        [ClassInitialize]
        public static void MyClassInitialize(TestContext context)
        {
            cart = new ShoppingCart();
            cart.Add(new Item { ItemName = "LG WP7", ItemQuantity = 10 });
        }

        [TestInitialize]
        public void TestInitialize()
        {
            item = new Item();
            item.ItemName = "Samsung Windows Phone 7";
            item.ItemQuantity = 10;

            cart = new ShoppingCart();
            cart.Add(item);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            cart.Dispose();
        }

        [ClassCleanup]
        public static void MyClassCleanUp()
        {
            cart.Dispose();
        }

        [ClassCleanup]
        public static void MyClassCleanUp()
        {
            cart.Dispose();
        }

        [TestMethod]
        public void Class_AddToCartTest()
        {
            int expected = cart.ItemCount + 1;

            cart.Add(new Item { ItemName = "HTC WP7", ItemQuantity = 10 });

            Assert.AreEqual(expected, cart.ItemCount);
        }

        [TestMethod]
        public void Class_RemovedFromCartTest()
        {
            int expected = cart.ItemCount - 1;
            cart.Remove(0);

            Assert.AreEqual(expected, cart.ItemCount);
        }

    }
}
