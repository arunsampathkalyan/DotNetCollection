﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Data;

namespace UserDetailsEntryTest
{
    /// <summary>
    /// Summary description for DataDrivenTest
    /// </summary>
    [TestClass]
    public class DataDrivenTest
    {
        private static UserDetails.UserDetailEntry user;

        public DataDrivenTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        [ClassInitialize]
        public static void ClassInit(TestContext context)
        {
            user = new UserDetails.UserDetailEntry();
        }

        public TestContext TestContext { get; set; }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [DataSource("Microsoft.VisualStudio.TestTools.DataSource.XML", 
            "|DataDirectory|\\UserDetails.xml", 
            "User", 
            DataAccessMethod.Sequential), 
        DeploymentItem("UserDetailsEntryTest\\UserDetails.xml"), 
        TestMethod]
        public void DataTest()
        {
            //
            // TODO: Add test logic here
            //

            string userId = Convert.ToString(TestContext.DataRow["userid"]);
            string telephone = Convert.ToString(TestContext.DataRow["telephone"]);
            string email = Convert.ToString(TestContext.DataRow["email"]);

            bool result = user.Add(userId, telephone, email);

            Assert.IsTrue(result, "User could not be created!");
            
        }
    }
}
