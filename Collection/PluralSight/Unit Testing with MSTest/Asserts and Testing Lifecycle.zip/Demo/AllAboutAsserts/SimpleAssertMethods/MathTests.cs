﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AssertMethods
{
    [TestClass]
    public class MathTests
    {
        [TestMethod]
        public void IsSqrtTest()
        {
            // arrange
            const double INPUT = 4;
            const double EXPECTED = 2;

            // act
            double actual = Math.Sqrt(INPUT);

            // assert
            Assert.AreEqual(EXPECTED,actual,
                "Sqrt of {0} should have been 2!",INPUT);

        }

        [TestMethod]
        public void DeltaTest()
        {
            const double EXPECTED = 3.1622;
            const double DELTA = 0.00006;

            // 3.1622776601683795
            // 0.000077...
            double actual = Math.Sqrt(10);

            Assert.AreEqual(EXPECTED, actual, DELTA, "fail message!!!");

        }

        [TestMethod]
        public void IsStringSame()
        {
            // arrange
            const string INPUT = "HELLO";
            const string EXPECTED = "hello";

            // act and assert

            Assert.AreEqual(EXPECTED, INPUT, true);

        }

        [TestMethod]
        public void StringSameTest()
        {
            string a = "Hello";
            string b = "Hello";

            Assert.AreSame(a, b);
        }

        [TestMethod]
        public void IntegersSameTest()
        {
            int i = 10;
            int j = 10;

            Assert.AreEqual(i, j);

        }

    }
}
