﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnderstandingTestContext
{
    [TestClass]
    public class UnitTest1
    {
        public TestContext TestContext { get; set; }

        [TestMethod]
        public void StringsTest()
        {
            const string a = "HELLO";
            const string b = "hello";

            TestContext.WriteLine("TestRunDirectory: {0}",
                            TestContext.TestRunDirectory);

            TestContext.WriteLine("Name: {0}",TestContext.TestName);

            TestContext.WriteLine("Test Outcome: {0}", 
                            TestContext.CurrentTestOutcome);

            Assert.AreEqual(a,b,true);
        }

        [TestInitialize]
        public void TestIni()
        {
            // initialize
        }

        [TestCleanup]
        public void TestCleanup()
        { 
            // cleanup
            TestContext.WriteLine("Name: {0}", TestContext.TestName);

            TestContext.WriteLine("Test Outcome: {0}",
                TestContext.CurrentTestOutcome);
        }
    }
}
