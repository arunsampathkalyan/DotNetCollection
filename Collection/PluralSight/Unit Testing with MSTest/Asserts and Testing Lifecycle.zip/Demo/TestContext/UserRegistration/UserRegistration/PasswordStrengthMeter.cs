﻿using System;
using System.Text;

namespace UserRegistration
{
    public static class PasswordStrengthMeter
    {
        // This method would return the strength of the password
        // For example: "P2ssw0rd#" -> points would
        // Length (1) + Lower Case(1) + Upper Case (1) + 
        //                                  Symbol (1) + Number (1)
        // Total points = 5

        public static int GetPasswordStrength(string password)
        {
             if (string.IsNullOrEmpty(password))
                return 0;

             int result = 0;

              // +1 for length  
              if(Math.Max(password.Length, 7) > 7)
                  result += 1;
 
              //+1 for a number
              if (System.Text.RegularExpressions.Regex.Match(password, "[0-9]").Success)
                result += 1;

              //+1 for a special char
              if (System.Text.RegularExpressions.Regex.Match(password, 
                     "[\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\{\\}\\[\\]\\:\\'\\;\\\"\\/\\?\\.\\>\\,\\<\\~\\`\\-\\\\_\\=\\+\\|]").Success)
                result += 1;

              //+1 for a lower case letter
              if (System.Text.RegularExpressions.Regex.Match(password, "[a-z]").Success)
                  result += 1;

              //+1 for a upper case letter
              if (System.Text.RegularExpressions.Regex.Match(password, "[A-Z]").Success)
                  result += 1;

             return result;
        }
    }
}
