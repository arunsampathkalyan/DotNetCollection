﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UserRegistration;


namespace UserRegistrationTest
{
    [TestClass]
    public class PasswordStrengthTest
    {

        public TestContext TestContext { get; set; }

        [TestInitialize]
        public void TestIni()
        {
            // initialize
        }

        [TestMethod]
        public void GetPasswordStrengthTest()
        {
            // arrange

            string password = "P2ssw0rd#";
            int expected = 5;

            // using TextContext

            TestContext.WriteLine("TestRunDirectory: {0}", 
                                    TestContext.TestRunDirectory);
         
            TestContext.BeginTimer("some long running process");

            System.Threading.Thread.Sleep(3000);
            // database call
            // business method call

            // act
            int actual = UserRegistration.PasswordStrengthMeter.GetPasswordStrength(password);

            TestContext.EndTimer("some long running process");

            // assert

            TestContext.WriteLine("From Tst Method--- {0} : {1}", TestContext.TestName,
             TestContext.CurrentTestOutcome);

            Assert.AreEqual(expected, actual);
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            TestContext.WriteLine("{0} : {1}", TestContext.TestName,
                         TestContext.CurrentTestOutcome);
        }


    }
}
